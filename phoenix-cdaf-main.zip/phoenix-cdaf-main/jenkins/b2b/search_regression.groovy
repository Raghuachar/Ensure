import java.time.LocalDateTime

def uniqueId = UUID.randomUUID().toString()
pipeline {
    agent any
    tools {
        maven 'maven'
        jdk 'JDK-11'
        allure 'Allure-report'
    }
    parameters {
        booleanParam(name: 'sendNotification', defaultValue: true, description: 'Whether to send the notification or not')
        choice(name: 'env', choices: 'dev\ndev2\ndev3\nstng\nsit')
        choice(name: 'brand', choices: 'be\nnl\nfr\nma\nvip')
        choice(name: 'agent', choices: 'b2c-h\nb2c-flight\ninhouse-flight\nthird-flight\ninhouse-h\nthird-h')
        choice(name: 'locale', choices: 'nl\nen\nfr')
    }
    stages {
        stage('clean') {
            steps {
                script {
                    deleteFolderIfExists(uniqueId)
                }
            }
        }
        stage('Set Display Name') {
            steps {
                script {
                    currentBuild.displayName = "B2B PackageSearch Regression for ${params.brand.toUpperCase()} on ${params.env.toUpperCase()}"
                }
            }
        }
        stage('chrome desktop be package') {
            steps {
                script {
                    String tagsList = "(not @no_run and not @wip and not @obsolete and not @manual) and @searchregression"
                    bat "mvn clean test -Ddefault.build.directory=${uniqueId} -Dcucumber.filter.tags=\"${tagsList}\" -Denv=${params.env} -Dbrand=${params.brand} -Dagent=${params.agent} -Dlocale=${params.locale}"
                }
            }

            post {
                always {
                    script {
                        def sendNotification = params.sendNotification
                        sendNotification ? sendMessage(currentBuild.displayName, BUILD_URL, currentBuild.currentResult) : null
                    }
                    allureReport(uniqueId)
                    deleteFolderIfExists(uniqueId)
                }
            }
        }
    }
}

def sendMessage(displayName, buildUrl, currentResult) {
    def message = "Successfully executed '${displayName}<br> " +
            "BuildTime : ${String.format('%tF %<tH:%<tM', LocalDateTime.now())} <br> " +
            "Please find logs : ${buildUrl}console <br> " +
            "Please find Alure report : ${buildUrl}allure/ <br> "

    echo "Sending message to 'Dev 1 env - Packages' channel message:\n" + message
    office365ConnectorSend message: message,
            color: currentResult == 'SUCCESS' ? '#00FF00' : '#FF0000',
            status: currentResult,
            webhookUrl: 'https://tuigroup.webhook.office.com/webhookb2/17257d6f-0ab2-46aa-be18-506626864b27@e3e1f65b-b973-440d-b61c-bc895fc98e28/IncomingWebhook/611db08ae05a46e99b8fb374461f98a5/7b113af6-e5ea-4e52-b093-910669b80b0d'

    echo "Sending message to 'BDD_Automation_Updates' channel message:\n" + message
    office365ConnectorSend message: message,
            color: currentResult == 'SUCCESS' ? '#00FF00' : '#FF0000',
            status: currentResult,
            webhookUrl: 'https://tuigroup.webhook.office.com/webhookb2/17257d6f-0ab2-46aa-be18-506626864b27@e3e1f65b-b973-440d-b61c-bc895fc98e28/IncomingWebhook/36489d89d7694d4c83fc75fa4b261ccc/7b113af6-e5ea-4e52-b093-910669b80b0d'
}

def allureReport(uniqueId) {
    allure([
            includeProperties: true, jdk: 'JDK-1.8', reportBuildPolicy: 'ALWAYS',
            results          : [[path: "${uniqueId}/allureresults"]]
    ])
}

def deleteFolderIfExists(uniqueId) {
    bat "echo Deleting workspace... && if exist \"${WORKSPACE}\\target\" rmdir /S /Q \"${WORKSPACE}\\target\""
    bat "echo Deleting workspace... && if exist \"${WORKSPACE}\\allure-results\" rmdir /S /Q \"${WORKSPACE}\\allure-results\""
    bat "echo Deleting workspace... && if exist \"${WORKSPACE}\\${uniqueId}\" rmdir /S /Q \"${WORKSPACE}\\${uniqueId}\""
}
