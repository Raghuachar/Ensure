package uk.co.tui.cdaf.frontend.pom.wr.search.enums;

import lombok.Getter;

@Getter
public enum FlexibleDates
{
   STRICT(0),
   THREE_DAYS(1),
   SEVEN_DAYS(2),
   FOURTEEN_DAYS(3);

   private final int value;

   FlexibleDates(int value)
   {
      this.value = value;
   }
}
