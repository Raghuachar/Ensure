package uk.co.tui.cdaf.api.requests.search.capabilities;

import io.restassured.response.Response;
import lombok.SneakyThrows;
import uk.co.tui.cdaf.api.pojo.search.legacy.DestinationResponse;
import uk.co.tui.cdaf.api.pojo.search.mfe.CountryData;
import uk.co.tui.cdaf.api.pojo.search.mfe.Destination;
import uk.co.tui.cdaf.api.requests.search.parameters.SearchParameters;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SuggestionApi extends BaseApi
{

   @SneakyThrows
   public List<Destination> getAvailableSuggestions(@Nullable TestDataAttributes tda,
            SearchParameters searchParameters)
   {
      if (tda == null || tda.getSuggestion() == null)
         return Collections.emptyList();

      String searchKey = tda.getSuggestion();
      Response response = getSuggestionsResponse(searchKey, searchParameters);
      String responseBody = response.getBody().asString();
      CountryData countryData;
      if (ExecParams.isSitEnv())
         countryData = objectMapper.readValue(responseBody, DestinationResponse.class).getData();
      else
         countryData = objectMapper.readValue(responseBody, CountryData.class);
      List<Destination> countries =
               countryData.getCountries() != null ? countryData.getCountries() :
                        Collections.emptyList();
      List<Destination> destinations =
               countryData.getDestinations() != null ? countryData.getDestinations() :
                        Collections.emptyList();
      List<Destination> hotels =
               countryData.getHotels() != null ? countryData.getHotels() : Collections.emptyList();
      return Stream.of(countries, destinations, hotels)
               .flatMap(List::stream)
               .collect(Collectors.toList());
   }
}
