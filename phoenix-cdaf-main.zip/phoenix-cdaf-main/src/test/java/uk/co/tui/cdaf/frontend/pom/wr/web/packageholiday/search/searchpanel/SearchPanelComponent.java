package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchCustom;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static org.junit.Assert.*;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class SearchPanelComponent extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchPanelComponent.class);

   public final SearchCustom searchCustom;

   public final SearchPanel searchPanel;

   private final SearchDataHelper searchDataHelper;

   private final Random random;

   private final Map<String, WebElement> searchCardMap;

   private final String mfeParentElement = "tui-search-panel-mfe";

   private final String mfeFlexibleOptions = "ul[class=\"flexibleOptions\"]";

   private final String mfeDone = "span[aria-label=\"undefined Departure date\"]";

   private final String roomAndGuestsLabelMFE = "label[aria-label='Rooms and Guests header']";

   private final String mfeRoomXModal = "span[aria-label=\"Rooms and Guests close\"]";

   private final String mfeNoOfRooms = "div[class=\"paxHeader\"]";

   private final String mfeIdontMind = "option[value=\"auto\"]";

   private final String mfeAdults = "div[aria-label=\"adults\"]";

   private final String mfeChild = "div[aria-label=\"nonAdults\"]";

   private final String mfeAdultsPlusMinus = "div[aria-label=\"adults controlBlock\"]";

   private final String mfeChildPlusMinus = "div[aria-label=\"nonAdults controlBlock\"]";

   private final String mfeRoomClearAll = "a[aria-label=\"undefined Rooms and Guests\"]";

   private final String mfeRoomDone = "span[aria-label=\"undefined Rooms and Guests\"]";

   private final String mfeRoomHeaderText = "span[class=\"paxHeaderText\"]";

   private final String roomIcon = "svg[aria-label=\"double bed icon\"]";

   private final String childHeader = "span[aria-label=\"childrenHeader\"]";

   private final String childText = "span[aria-label=\"childrenText\"]";

   private final String cellDateSelectedMFE = ".SelectLegacyDate__selected";

   private final String monthSelectorMFE = "select[aria-label='selectMonth'] option";

   public WebElementWait wait;

   @FindBy(css = "[aria-label='select duration'] option")
   private List<WebElement> durationOptions;

   @FindBy(css = "[id='cmCloseBanner']")
   private WebElement popUpMessage;

   @FindBy(css = "[class='Duration__durationList']")
   private List<WebElement> durationList;

   @FindBy(css = "[class='inputs__circle inputs__alignmiddle'] ")
   private List<WebElement> brandToggleLabel;

   @FindBy(css = "[aria-label='room select'] select option")
   private List<WebElement> numberOfRooms;

   @FindBy(css = "[aria-label='adult select'] select option")
   private List<WebElement> adults;

   @FindBy(css = "[aria-label='holiday count']")
   private WebElement holidayCountText;

   @FindBy(css = "#progressBarNavigation__component > div > div > div > div > div.ProgressbarNavigation__pricePanelWrapper > div > div > div:nth-child(1) > div > div.ProgressbarNavigation__perPerson > span.ProgressbarNavigation__ppPart1")
   private WebElement roomPrice;

   @FindBy(css = "[aria-label='room selecton'] button[role='button']")
   private List<WebElement> extraPrice;

   @FindBy(css = "[aria-label='all gone']")
   private WebElement allGonePanel;

   @FindBy(xpath = "//body")
   private WebElement body;

   public SearchPanelComponent()
   {
      wait = new WebElementWait();
      searchDataHelper = new SearchDataHelper();
      searchCustom = new SearchCustom();
      searchPanel = getSearchPanel();
      random = new Random();
      searchCardMap = new HashMap<>();
   }

   public boolean validateAccommodationSingleAccomm()
   {
      return $(".Duration__durationList").should(appear, Duration.ofSeconds(10)).isDisplayed();
   }

   public Map<String, WebElement> getBrandToggleComponents()
   {
      searchCardMap.put("Radio button with TUI Holidays copy", brandToggleLabel.get(0));
      searchCardMap.put("Radio button with VIP Selection copy", brandToggleLabel.get(1));
      return searchCardMap;
   }

   public boolean isDefaultRoomValuePresent(String value)
   {
      int i = 0;
      while (i < numberOfRooms.size())
      {
         if (StringUtils.equalsIgnoreCase(value.trim(),
                  WebElementTools.getElementText(numberOfRooms.get(i)).trim()))
         {
            return false;
         }
         i++;
      }
      return true;
   }

   public void clickOnSearchButton()
   {
      getSearchPanel().doSearch();
   }

   public void holidays_present()
   {
      assertNotNull(wait.getWebElementWithLazyWait(holidayCountText));

   }

   public void checkCheapestRoom()
   {
      int initial_price = Integer.parseInt(roomPrice.getText().replaceAll("\\D+", ""));
      if (roomPrice.isDisplayed())
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.clickElementJavaScript(extraPrice.get(0));
      }
      wait.forJSExecutionReadyLazy(1000);
      assertTrue(Integer.parseInt(roomPrice.getText().replaceAll("\\D+", "")) > initial_price);
   }

   public boolean isAllGone()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(allGonePanel);
   }

   public boolean isDefaultRoomPresent(String value)
   {
      return StringUtils.equalsIgnoreCase(value.trim(),
               WebElementTools.getElementText(numberOfRooms.get(0)).trim());
   }

   public Map<String, WebElement> getSearchPanelComponentsMFE()
   {
      String departureDateLabelMFE = "[aria-label*='Departure date header']";
      searchCardMap.put("Departure Date title",
               SelenideHelper.getShadowRootElement(departureDateLabelMFE, mfeParentElement));
      String mfeXModal = "[aria-label='Departure date close']";
      searchCardMap.put("X close modal link",
               SelenideHelper.getShadowRootElement(mfeXModal, mfeParentElement));
      String mfeMonthValue = "select[aria-label=\"selectMonth\"]";
      searchCardMap.put("Month selector",
               SelenideHelper.getShadowRootElement(mfeMonthValue, mfeParentElement));
      String mfeCalendar = "div[class=\"calendar\"]";
      searchCardMap.put("Calendar",
               SelenideHelper.getShadowRootElement(mfeCalendar, mfeParentElement));
      searchCardMap.put("Flexibility options",
               SelenideHelper.getShadowRootElement(mfeFlexibleOptions, mfeParentElement));
      String mfeClearAll = "a[aria-label=\"undefined Departure date\"]";
      searchCardMap.put("CLEAR ALL",
               SelenideHelper.getShadowRootElement(mfeClearAll, mfeParentElement));
      searchCardMap.put("DONE", SelenideHelper.getShadowRootElement(mfeDone, mfeParentElement));
      return searchCardMap;
   }

   public Map<String, WebElement> getSearchPanelComponentsFlexibleMFE()
   {
      List<WebElement> listOfFlexibility = SelenideHelper
               .getShadowRootElement(mfeFlexibleOptions, mfeParentElement)
               .findElements(By.tagName("li"));
      searchCardMap.put("Not Flexible", listOfFlexibility.get(0));
      searchCardMap.put("+/- 3 days", listOfFlexibility.get(1));
      searchCardMap.put("+/- 7 days", listOfFlexibility.get(2));
      searchCardMap.put("+/- 14 days", listOfFlexibility.get(3));
      return searchCardMap;
   }

   public boolean isDefaultFlexibleSelectedMFE()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(mfeFlexibleOptions, mfeParentElement)
                        .findElements(By.tagName("li")).get(1));
   }

   public void isRadioFlexibleSelectedMFE()
   {
      WebElementTools.mouseOverAndClick(
               SelenideHelper.getShadowRootElement(mfeFlexibleOptions, mfeParentElement)
                        .findElements(By.tagName("li")).get(2));
   }

   public void closeDepartureDateModalMFE()
   {
      WebElementTools
               .clickElementJavaScript(
                        SelenideHelper.getShadowRootElement(mfeDone, mfeParentElement));
   }

   public Map<String, WebElement> getRoomAndGuestsComponentsMFE()
   {
      searchCardMap.put("Room & Guests title",
               SelenideHelper.getShadowRootElement(roomAndGuestsLabelMFE, mfeParentElement));
      searchCardMap.put("X close modal",
               SelenideHelper.getShadowRootElement(mfeRoomXModal, mfeParentElement));
      searchCardMap.put("Number of rooms",
               SelenideHelper.getShadowRootElement(mfeNoOfRooms, mfeParentElement));
      searchCardMap.put("I don't mind",
               SelenideHelper.getShadowRootElement(mfeIdontMind, mfeParentElement));
      searchCardMap.put("Adults", SelenideHelper.getShadowRootElement(mfeAdults, mfeParentElement));
      searchCardMap.put("Adults - / +",
               SelenideHelper.getShadowRootElement(mfeAdultsPlusMinus, mfeParentElement));
      searchCardMap.put("Children (0-17)",
               SelenideHelper.getShadowRootElement(mfeChild, mfeParentElement));
      searchCardMap.put("Children - / +",
               SelenideHelper.getShadowRootElement(mfeChildPlusMinus, mfeParentElement));
      searchCardMap.put("CLEAR ALL",
               SelenideHelper.getShadowRootElement(mfeRoomClearAll, mfeParentElement));
      searchCardMap.put("DONE", SelenideHelper.getShadowRootElement(mfeRoomDone, mfeParentElement));
      return searchCardMap;
   }

   public void closeRoomAndGuestsModalMFE()
   {
      SelenideHelper.getShadowRootElement(mfeRoomXModal, mfeParentElement).click();
      wait.forJSExecutionReadyLazy();
   }

   public void clickRoomsDoneButton()
   {
      wait.forJSExecutionReadyLazy();
      SelenideHelper.getShadowRootElement(mfeRoomDone, mfeParentElement).click();
   }

   public void clickOutsideOfModal()
   {
      wait.forJSExecutionReadyLazy();
      body.click();
   }

   public List<String> getRoomAndGuestsTranslationMFE()
   {
      List<String> translations = new ArrayList<>();
      translations.add(
               SelenideHelper.getShadowRootElement(roomAndGuestsLabelMFE, mfeParentElement)
                        .getText());
      translations
               .add(SelenideHelper.getShadowRootElement(mfeNoOfRooms, mfeParentElement).getText());
      translations
               .add(SelenideHelper.getShadowRootElement(mfeIdontMind, mfeParentElement).getText());
      translations.add(SelenideHelper.getShadowRootElement(mfeAdults, mfeParentElement).getText());
      translations.add(SelenideHelper.getShadowRootElement(mfeChild, mfeParentElement).getText());
      translations
               .add(SelenideHelper.getShadowRootElement(mfeRoomClearAll, mfeParentElement)
                        .getText());
      translations
               .add(SelenideHelper.getShadowRootElement(mfeRoomDone, mfeParentElement).getText());
      return translations;
   }

   public List<String> getSingleRoomTranslationsMFE()
   {
      List<String> translations = new ArrayList<>();
      translations
               .add(SelenideHelper.getShadowRootElement(mfeRoomHeaderText, mfeParentElement)
                        .getText());
      translations.add(SelenideHelper.getShadowRootElement(mfeAdults, mfeParentElement).getText());
      translations.add(SelenideHelper.getShadowRootElement(mfeChild, mfeParentElement).getText());
      return translations;
   }

   public String getChildrenAgeNotEnteredErrorMessage()
   {
      String childrenErrorMessage = "div[class=\"childrenErrorMessage\"]";
      return SelenideHelper.getShadowRootElement(childrenErrorMessage, mfeParentElement).getText();
   }

   public List<String> getChildTranslationsMFE()
   {
      List<String> translations = new ArrayList<>();
      translations
               .add(SelenideHelper.getShadowRootElement(childHeader, mfeParentElement).getText());
      translations.add(SelenideHelper.getShadowRootElement(childText, mfeParentElement).getText());
      String childPlaceholderText =
               "span[aria-label=\"Children age selection input-selectedText\"]";
      translations.add(
               SelenideHelper.getShadowRootElement(childPlaceholderText, mfeParentElement)
                        .getText());
      return translations;
   }

   public Map<String, WebElement> getRoomAndGuestsSingleRoomComponents()
   {
      searchCardMap.put("Room icon",
               SelenideHelper.getShadowRootElement(roomIcon, mfeParentElement));
      searchCardMap.put("ROOM 1 title",
               SelenideHelper.getShadowRootElement(mfeRoomHeaderText, mfeParentElement));
      searchCardMap.put("Adults", SelenideHelper.getShadowRootElement(mfeAdults, mfeParentElement));
      searchCardMap.put("Adults - / +",
               SelenideHelper.getShadowRootElement(mfeAdultsPlusMinus, mfeParentElement));
      searchCardMap.put("Children (0-17)",
               SelenideHelper.getShadowRootElement(mfeChild, mfeParentElement));
      searchCardMap.put("Children - / +",
               SelenideHelper.getShadowRootElement(mfeChildPlusMinus, mfeParentElement));
      return searchCardMap;
   }

   public Map<String, WebElement> getRoomAndGuestsChildRoomComponents()
   {
      searchCardMap.put("Child header",
               SelenideHelper.getShadowRootElement(childHeader, mfeParentElement));
      searchCardMap.put("Child text",
               SelenideHelper.getShadowRootElement(childText, mfeParentElement));
      String childPlaceholder = "select[aria-label=\"Children age selection\"]";
      searchCardMap.put("Child placeholder",
               SelenideHelper.getShadowRootElement(childPlaceholder, mfeParentElement));
      return searchCardMap;
   }

   public void verifyFlexibleCheckedMFE()
   {
      String mfeFlexibleChecked = "[class='inputs__radioButton undefined  '] input:checked";
      SelenideHelper.getShadowRootElement(mfeFlexibleChecked, mfeParentElement);
   }

   public String retainedOnModal()
   {
      String[] flexible = SelenideHelper.getShadowRootElement(mfeFlexibleOptions, mfeParentElement)
               .findElements(By.tagName("li")).get(2).getText().split(" ");
      return flexible[0] + flexible[1];
   }

   public void clickDepartureDoneButton()
   {
      String mfeDepartureDone = "span[aria-label=\"undefined Departure date\"]";
      SelenideHelper.getShadowRootElement(mfeDepartureDone, mfeParentElement).click();
   }

   public Map<String, List<SelenideElement>> getAllRoomComponents()
   {
      Map<String, List<SelenideElement>> allRoomComponents = new HashMap<>();
      allRoomComponents.put("Room icon",
               SelenideHelper.getShadowRootElements(roomIcon, mfeParentElement));
      allRoomComponents.put("\"ROOM x\" title where x = room number",
               SelenideHelper.getShadowRootElements(mfeRoomHeaderText, mfeParentElement));
      allRoomComponents.put("Adults",
               SelenideHelper.getShadowRootElements(mfeAdults, mfeParentElement));
      allRoomComponents.put("Adults - / +",
               SelenideHelper.getShadowRootElements(mfeAdultsPlusMinus, mfeParentElement));
      allRoomComponents.put("Children (0-17)",
               SelenideHelper.getShadowRootElements(mfeChild, mfeParentElement));
      allRoomComponents.put("Children - / +",
               SelenideHelper.getShadowRootElements(mfeChildPlusMinus, mfeParentElement));
      return allRoomComponents;
   }

   public void selectAvailableDateFromCalendar()
   {
      String availableDatesMFE = ".SelectLegacyDate__available";
      List<SelenideElement> listOfAvailableDates =
               SelenideHelper.getShadowRootElements(availableDatesMFE, mfeParentElement);
      if (listOfAvailableDates.size() >= 3)
      {
         WebElementTools.clickElementJavaScript(listOfAvailableDates.get(2));
      }
      else
      {
         WebElementTools.clickElementJavaScript(listOfAvailableDates.get(0));
      }
   }

   public boolean isDateCellIsSelectedStateMFE()
   {
      return WebElementTools
               .isPresent(
                        SelenideHelper.getShadowRootElement(cellDateSelectedMFE, mfeParentElement));
   }

   public String getSelectedTextMFE()
   {
      String cellDateSelectedTextMFE = ".day.current.sheet.legecyDate.SelectLegacyDate__selected";
      String expectedValue =
               SelenideHelper.getShadowRootElement(cellDateSelectedTextMFE, mfeParentElement)
                        .getText();
      if (expectedValue.length() == 1 && Character.isDigit(expectedValue.charAt(0)))
      {
         int value = Integer.parseInt(expectedValue);
         if (value >= 1 && value <= 9)
         {
            expectedValue = "0" + expectedValue;
         }
      }
      return expectedValue;
   }

   public String getMFEDepartureDateFieldTextMFE()
   {
      String mfeDepartureDateFieldText = "input.readOnlyText";
      List<SelenideElement> inputElement =
               SelenideHelper.getShadowRootElements(mfeDepartureDateFieldText, mfeParentElement);
      return inputElement.get(1).getAttribute("placeholder");
   }

   public boolean isNoDateCellIsSelectedStateMFE()
   {
      List<SelenideElement> selectedDates =
               SelenideHelper.getShadowRootElements(cellDateSelectedMFE, mfeParentElement);
      return selectedDates.isEmpty();
   }

   public String getCurrentDisplayedMonth()
   {
      String mfecurrentMonthText = "span.input-selectedText";
      return SelenideHelper.getShadowRootElement(mfecurrentMonthText, mfeParentElement).getText();
   }

   public String getFirstMonthWithAvailability()
   {
      List<SelenideElement> monthElements =
               SelenideHelper.getShadowRootElements(monthSelectorMFE, mfeParentElement);
      return monthElements.get(1).getText();
   }

   public String getDepartureDateTitleTextMFE()
   {
      String departureDateHeaderMFE = "[aria-label*='Departure date header']";
      return SelenideHelper.getShadowRootElement(departureDateHeaderMFE, mfeParentElement)
               .getText();
   }

   public String getClearAllTextMFE()
   {
      String departureDateClearAllMFE = "a[aria-label=\"undefined Departure date\"]";
      return SelenideHelper.getShadowRootElement(departureDateClearAllMFE, mfeParentElement)
               .getText();
   }

   public String getDoneTextMFE()
   {
      return SelenideHelper.getShadowRootElement(mfeDone, mfeParentElement).getText();
   }

   public String getFlexibleTitleTextMFE()
   {
      String flexibleHeaderMFE = "[class='flexibleHeader']";
      return SelenideHelper.getShadowRootElement(flexibleHeaderMFE, mfeParentElement).getText();
   }

   public List<String> getFlexibleOptionTextMFE()
   {
      List<WebElement> listOfFlexibility = SelenideHelper
               .getShadowRootElement(mfeFlexibleOptions, mfeParentElement)
               .findElements(By.tagName("li"));

      List<String> flexibleOptionsText = new ArrayList<>();
      for (WebElement option : listOfFlexibility)
      {
         String optionText = option.getText();
         flexibleOptionsText.add(optionText);
      }
      return flexibleOptionsText;
   }

   public List<String> getActualAvailableMonths()
   {
      ElementsCollection availableMonths =
               $$(shadowDeepCss("select[aria-label='selectMonth'] option"));
      return availableMonths.asFixedIterable().stream()
               .map(monthElement -> monthElement.getText().split(" ")[0])
               .collect(Collectors.toList());
   }

   public void verifyMonthSelectorTranslations(String siteId,
            List<Map<String, String>> translations)
   {
      List<String> actualAvailableMonths = getActualAvailableMonths();

      Map<String, String> expectedTranslations = null;
      for (Map<String, String> translation : translations)
      {
         if (translation.containsKey("site") && translation.get("site").equalsIgnoreCase(siteId))
         {
            expectedTranslations = translation;
            break;
         }
      }

      if (expectedTranslations == null)
      {
         throw new IllegalArgumentException("Site ID not found in translations: " + siteId);
      }
      List<String> expectedMonths = Arrays.asList("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL",
               "AUG", "SEP", "OCT", "NOV", "DEC");
      for (String month : expectedMonths)
      {
         String expectedTranslation = expectedTranslations.get(month);
         if (actualAvailableMonths.contains(expectedTranslation))
         {
            String actualTranslation =
                     actualAvailableMonths.get(actualAvailableMonths.indexOf(expectedTranslation));
            assertEquals("Translation for " + month + " is not matching!", expectedTranslation,
                     actualTranslation);
         }
      }
   }

   public List<String> getActualDays()
   {
      String dayMFE = "div.weekdays span";
      List<SelenideElement> dayElements =
               SelenideHelper.getShadowRootElements(dayMFE, mfeParentElement);
      List<String> actualDays = new ArrayList<>();
      for (SelenideElement dayElement : dayElements)
      {
         String dayText = dayElement.getText();
         actualDays.add(dayText);
      }
      return actualDays;
   }

   public void verifyDayTranslations(String siteId, List<Map<String, String>> translations)
   {
      List<String> actualDays = getActualDays();

      Map<String, String> expectedTranslations = null;
      for (Map<String, String> translation : translations)
      {
         if (translation.containsKey("site") && translation.get("site").equalsIgnoreCase(siteId))
         {
            expectedTranslations = translation;
            break;
         }
      }

      if (expectedTranslations == null)
      {
         throw new IllegalArgumentException("Site ID not found in translations: " + siteId);
      }
      List<String> expectedDays = Arrays.asList("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun");
      for (String day : expectedDays)
      {
         String expectedTranslation = expectedTranslations.get(day);
         String actualTranslation = actualDays.get(actualDays.indexOf(expectedTranslation));
         assertEquals("Translation for " + day + " is not matching!", expectedTranslation,
                  actualTranslation);
      }
   }

   public boolean isCalendarPopulatedWithCurrentMonthDates()
   {
      return $(shadowDeepCss("[class='days legecy']")).isDisplayed();
   }

   public void customerAgentAbleToSelectMonthsInFuture()
   {
      ElementsCollection monthElements =
               $$(shadowDeepCss("select[aria-label='selectMonth'] option"));
      for (int i = 1; i <= monthElements.size(); i++)
      {
         SelenideElement monthElement = monthElements.get(i - 1);
         monthElement.click();
         assertTrue("Future month " + i + " is not selectable", isMonthSelected());
      }
   }

   public boolean isMonthSelected()
   {
      return Objects.requireNonNull($(shadowDeepCss(".input-selectedText")).getAttribute("class"))
               .contains("input-selectedText");
   }

   public boolean verifyPastDatesGreyedOut()
   {
      ElementsCollection pastDatesElements = $$(shadowDeepCss(".day.passive.legecyDate.sheet"));
      return pastDatesElements.asFixedIterable().stream()
               .allMatch(pastDate -> pastDate.has(Condition.cssClass("passive")));
   }

   public boolean verifyPastDatesUnselectable()
   {
      ElementsCollection pastDatesUnselectableElements =
               $$(shadowDeepCss(".day.passive.legecyDate.sheet"));
      return pastDatesUnselectableElements.asFixedIterable().stream().peek(SelenideElement::click)
               .noneMatch(SelenideElement::isSelected);
   }

   public SelenideElement getCurrentDateElement()
   {
      JavascriptExecutor js = (JavascriptExecutor) WebDriverRunner.getWebDriver();
      String currentDate =
               js.executeScript(
                                 "return new Date().toLocaleDateString('en-GB').split('/').join('-');")
                        .toString();
      String currentDateElementSelector = "time[datetime='" + currentDate + "']";
      return $(shadowDeepCss(currentDateElementSelector));
   }

   public boolean verifyCurrentDateGreyedOut()
   {
      return getCurrentDateElement().has(Condition.cssClass("passive"));
   }

   public boolean verifyCurrentDateUnselectable()
   {
      SelenideElement currentDateElement = getCurrentDateElement();
      currentDateElement.click();
      return !currentDateElement.isSelected();
   }
}
