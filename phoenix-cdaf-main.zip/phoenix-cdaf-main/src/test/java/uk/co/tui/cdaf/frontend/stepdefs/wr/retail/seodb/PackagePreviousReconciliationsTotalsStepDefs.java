package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackagePreviousReconciliationsPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePreviousReconciliationsTotalsStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackagePreviousReconciliationsPageComponents
            pKgPreviousReconciliationsPageComponents;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   public PackagePreviousReconciliationsTotalsStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      pKgPreviousReconciliationsPageComponents = new PackagePreviousReconciliationsPageComponents();
   }

   @Given("that the agent has pressed the SEARCH CTA")
   public void that_the_agent_has_pressed_the_SEARCH_CTA()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pKgPreviousReconciliationsPageComponents.navigateToPreviousReconciliationPage();
      pKgPreviousReconciliationsPageComponents.clickSearchButton();

   }

   @When("they view the search results")
   public void they_view_the_search_results()
   {
      assertThat("Previous Reconciliation search result present",
               pKgPreviousReconciliationsPageComponents.isSearchResultContainer(), is(true));
   }

   @Then("they can see the respective totals component within the search results")
   public void they_can_see_the_respective_totals_component_within_the_search_results(
            io.cucumber.datatable.DataTable dataTable)
   {

      assertThat("Total Discrepancies Label present",
               pKgPreviousReconciliationsPageComponents.isTotalDiscrepanciesLabel(), is(true));
      assertThat("Total Discrepancies Amount present",
               pKgPreviousReconciliationsPageComponents.isTotalDiscrepanciesAmount(), is(true));
      assertThat("Authorised By present",
               pKgPreviousReconciliationsPageComponents.isTotalDiscrepanciesAmount(), is(true));
      retailpassengerdetailspage.userLogout();
   }

}
