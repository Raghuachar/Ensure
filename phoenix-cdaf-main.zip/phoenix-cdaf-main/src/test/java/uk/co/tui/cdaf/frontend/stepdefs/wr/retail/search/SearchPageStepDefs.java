package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.search;

import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults.SearchResults;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class SearchPageStepDefs
{
   public static final String MAD_CURRENCY = "MAD";

   SearchResults searchResults;

   public SearchPageStepDefs()
   {
      searchResults = new SearchResults();
   }

   @Then("the currency should be set to Dirham \\(MAD)")
   public void the_currency_should_be_set_to_Dirham_MAD()
   {
      assertTrue("Outbound currencies are not " + MAD_CURRENCY,
               searchResults.getOutboundPriceAvailableList().stream()
                        .allMatch(p -> p.endsWith(MAD_CURRENCY)));
      assertEquals("Outbound currency not valid ", MAD_CURRENCY,
               searchResults.getOutboundCurrency());
      assertTrue("Return currencies are not " + MAD_CURRENCY,
               searchResults.getReturnPriceAvailableList().stream()
                        .allMatch(p -> p.endsWith(MAD_CURRENCY)));
      assertEquals("Outbound currency not valid ", MAD_CURRENCY, searchResults.getReturnCurrency());
   }
}
