package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class SkipPaymentInhouseBookingStepDefs
{
   private final RetailPassengerDetailsPage retailpassengerPage;

   private final PackageNavigation packagenavigation;

   private final RetailPage retailPage = new RetailPage();

   public SkipPaymentInhouseBookingStepDefs()
   {
      retailpassengerPage = new RetailPassengerDetailsPage();
      packagenavigation = new PackageNavigation();
   }

   @Given("the agent is on the retail bookflow")
   public void the_agent_is_on_the_retail_bookflow()
   {
      retailPage.inhouseAgentLogin();
   }

   @When("they are viewing the payment page")
   public void they_are_viewing_the_payment_page()
   {
      packagenavigation.addPassengerDetailsandwaitforAddFeetype();
   }

   @Then("they should see {string} CTA hyperlink")
   public void they_should_see_CTA_hyperlink(String string)
   {
      retailpassengerPage.getSkippaymenttext().equalsIgnoreCase(string);
      retailpassengerPage.skippaymentCTA();
      retailpassengerPage.skippaymentbookingconfirmation();
      retailpassengerPage.userLogout();
   }

   @Given("the agent is on the retail bookflow payment page")
   public void the_agent_is_on_the_retail_bookflow_payment_page()
   {
      retailPage.inhouseAgentLogin();
      packagenavigation.addPassengerDetailsandwaitforAddFeetype();
   }

   @When("they select skip payment")
   public void they_select_skip_payment()
   {
      retailpassengerPage.skippayment();
   }

   @Then("they should land on booking confirmation page")
   public void they_should_land_on_booking_confirmation_page()
   {
      retailpassengerPage.skippaymentbookingconfirmation();
      retailpassengerPage.userLogout();

   }

}
