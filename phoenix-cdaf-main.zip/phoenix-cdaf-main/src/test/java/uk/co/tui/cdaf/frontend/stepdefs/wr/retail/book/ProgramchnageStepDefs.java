package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class ProgramchnageStepDefs
{
   private final PackageNavigation packageNavigation = new PackageNavigation();

   private final RetailPassengerDetailsPage retailpassengerdetailspage =
            new RetailPassengerDetailsPage();

   @Given("the agent has applied a program change")
   public void the_agent_has_applied_a_program_change()
   {
      packageNavigation.retailLoginChangeagent();
      packageNavigation.navigateToPassengerPage();
      packageNavigation.addPassengerDetailsandwaitforAddFeetype();
   }

   @And("they have clicked {string} CTA button")
   public void they_have_clicked_CTA_button(String string)
   {
      retailpassengerdetailspage.addFeeType();
   }

   @When("they are viewing the price breakdown summary component")
   public void they_are_viewing_the_price_breakdown_summary_component()
   {
      packageNavigation.programchange();
   }

   @Then("they should see the {string} show with discount amount value")
   public void they_should_see_the_show_with_discount_amount_value(String string)
   {
      retailpassengerdetailspage.userLogout();
   }

}
