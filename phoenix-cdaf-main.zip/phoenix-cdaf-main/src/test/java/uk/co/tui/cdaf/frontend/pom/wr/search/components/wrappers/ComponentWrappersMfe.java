package uk.co.tui.cdaf.frontend.pom.wr.search.components.wrappers;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;

import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;

@Getter
public class ComponentWrappersMfe implements ComponentWrappers
{

   final SelenideElement airportWrapper = $(shadowDeepCss(".airportWrapper"));

   final SelenideElement destinationWrapper = $(shadowDeepCss(".destinationWrapper"));

   final SelenideElement departureWrapper = $(shadowDeepCss(".departureWrapper"));

   final SelenideElement durationWrapper = $(shadowDeepCss(".durationWrapper"));

   final SelenideElement paxAndRoomsWrapper = $(shadowDeepCss(".paxAndRoomsWrapper"));

   final SelenideElement searchButtonWrapper = $(shadowDeepCss(".searchButtonWrapper"));
}
