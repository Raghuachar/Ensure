package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.DOMElement;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

import static com.codeborne.selenide.CollectionCondition.sizeGreaterThan;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static junit.framework.TestCase.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class SearchPanelComponent extends AbstractPage
{

   private final String departureDateInputMFE = "input[aria-label = 'select date']";

   private final String mfeParentElemnt = "tui-search-panel-mfe";

   private final String roomAndGuestInputMFE = "input[aria-label='room and guests']";

   private final String roomAndGuestsLabelMFE = "label[aria-label='Rooms and Guests header']";

   private final String adultsMinus = "button[aria-label=\"adults0 minus\"]";

   private final String adultsPlus = "button[aria-label=\"adults0 plus\"]";

   private final String childrenMinus = "button[aria-label=\"nonAdults0 minus\"]";

   private final String childrenPlus = "button[aria-label=\"nonAdults0 plus\"]";

   private final String adultsMinusInRoom = "button[aria-label=\"adults%s minus\"]";

   private final String adultsPlusInRoom = "button[aria-label=\"adults%s plus\"]";

   private final String childrenMinusInRoom = "button[aria-label=\"nonAdults%s minus\"]";

   private final String childrenPlusInRoom = "button[aria-label=\"nonAdults%s plus\"]";

   private final String numberOfRoomsMFE = "select[aria-label=\"Rooms selection\"]";

   private final String optionsMFE = "option[value=\"%s\"]";

   private final String mfeRoomHeader = "span[class=\"paxHeaderText\"]";

   private final String childrenHeader = "span[aria-label=\"childrenHeader\"]";

   private final String childrenText = "span[aria-label=\"childrenText\"]";

   private final String numberOfChildren = "select[aria-label=\"Children age selection\"]";

   private final String childrenErrorLink = "a[class=\"childrenErrorLink\"]";

   private final String destinationLabel =
            "div[class='destinationWrapper col col-12 col-sm-6 col-md-6 pr-none'] span[class='label']";

   private final String airportLabel =
            "div[class='airportWrapper col col-12 col-sm-6 col-md-6 pr-none'] div[class='group  ']";

   private final String departureLabel =
            "div[class='departureWrapper col col-6 col-sm-6 col-md-3 pr-none'] span[class='label']";

   private final String errorText =
            "div[class='errorWrapper col col-12 col-sm-6 col-md-12 pr-none'] p[class='errorText']";

   private final String done = "[class='button primary septenary medium']";

   private final String defaultText = "div[class='group  '] input";

   private final String clearsSearch = "div[class='row clearSearchLink']";

   private final WebElementWait wait;

   private final SearchPanel searchPanelMfe = getSearchPanel();

   @FindBy(css = "[aria-label = 'clear search'] a")
   protected List<WebElement> clearSearch;

   @FindBy(css = "[aria-label='select duration'] option")
   List<WebElement> durationOptions;

   @FindBy(css = "[aria-label='search panel container']")
   private WebElement searchPanelContainer;

   @Getter
   @FindAll({ @FindBy(css = "#airports span"), @FindBy(css = "#airports"),
            @FindBy(css = "[aria-label='text input']~span.inputs__children") })
   private WebElement airportIcon;

   @FindAll({ @FindBy(css = "div[data-dojo-type *= 'searchpanel.views.CheckBox']"),
            @FindBy(css = "[aria-label ='airports'] input[type='checkbox']:enabled+span+.inputs__text"),
            @FindBy(css = ".DropdownAirportSelection__airportListItem") })
   private List<WebElement> airportList;

   @FindAll({ @FindBy(css = "div[class*='Flying-From'] div[class^='btn done'] a"),
            @FindBy(css = "[aria-label='Done airports'] button"),
            @FindBy(css = "[aria-label*='airports'] button") })
   private WebElement airportDone;

   @FindAll({ @FindBy(css = "input[aria-label='select destinations']"), @FindBy(css = "#where-to"),
            @FindBy(css = "[name='units[]']"),
            @FindBy(css = ".SearchPanel__cities input[aria-label='text input']"),
            @FindBy(css = "#destinationSearch a"), @FindBy(css = "[name='Destination Airport']"), })
   private WebElement destinationInput;

   @FindAll({ @FindBy(css = "[class *= 'suggestions'] li:nth-child(2)"),
            @FindBy(css = "[aria-label = 'suggestions'] li:nth-child(2)"),
            @FindBy(css = "[class = 'SelectDestinations__link ']"),
            @FindBy(css = ".viewport li a:not([class*='disabled'])"),
            @FindBy(css = ".SelectCities__groupcontainer label[aria-label='checkbox'] .inputs__text") })
   private List<WebElement> destinationsAutoComplete;

   @FindBy(css = "input[aria-label='select destinations']+span>span")
   private WebElement destinationsListIcon;

   @FindAll({ @FindBy(css = "[aria-label = 'destinations header']"),
            @FindBy(css = "[analytics-text = 'Where-To-Selection']"),
            @FindBy(css = "[aria-label='cities header']") })
   private WebElement destinationHeaderOverlay;

   @FindAll({ @FindBy(css = "[class = 'SelectDestinations__link ']"),
            @FindBy(css = ".viewport li a:not([class*='disabled'])"),
            @FindBy(css = "[class = 'dest-country']"),
            @FindBy(css = ".SelectCities__groupcontainer label[aria-label='checkbox'] .inputs__text"), })
   private List<WebElement> destinationsList;

   @FindAll({ @FindBy(xpath = "//*[contains(text(), '(ALL)')]/preceding-sibling::span"),
            @FindBy(xpath = "//span[contains(text(), '(All)')]"),
            @FindBy(xpath = "//div[contains(text(), '(All)')]"),
            @FindBy(xpath = "//div[contains(text(), '(All)')]/span") })
   private WebElement destinationSelectAll;

   @FindAll({ @FindBy(css = "[aria-label='Done destinations'] button"),
            @FindBy(css = "[aria-label='Klar destinations'] button"),
            @FindBy(css = "[aria-label='F?rdig destinations'] button"),
            @FindBy(css = "[aria-label='Ferdig destinations'] button"),
            @FindBy(css = "[aria-label='Valmis destinations'] button"),
            @FindBy(css = "div[analytics-text*='Where-To-Selection'] div[class^='btn done'] a"),
            @FindBy(css = "[aria-label*='destinations'] button") })
   private WebElement destinationsDone;

   @FindAll({ @FindBy(css = "#when"), @FindBy(css = "input[aria-label = 'select date']") })
   private WebElement departureDateInput;

   @FindBy(css = "[aria-label='Departure date header']")
   private WebElement calendarHeader;

   @FindAll({ @FindBy(css = "[class *= 'SelectDate__available']"),
            @FindBy(css = "[class *= 'SelectLegacyDate__available']") })
   private List<WebElement> availableDates;

   @FindAll({ @FindBy(xpath = "//td[contains(@class,'SelectDate__cell')]"),
            @FindBy(css = "td[class*='SelectLegacyDate__cell'][class*='available']") })
   private List<WebElement> anyDates;

   @FindAll({ @FindBy(css = ".month-navigator div"),
            @FindBy(css = "[class*='SelectDate__monthSelectList']"),
            @FindBy(css = "[arialabel = 'select month']"),
            @FindBy(css = "[class*='SelectDate__monthSelector']") })
   private WebElement calendarMonth;

   @FindAll({ @FindBy(css = ".calendar .next"),
            @FindBy(css = "div.SelectDate__monthSelector > a:nth-child(3)"),
            @FindBy(css = "div.SelectLegacyDate__monthSelector > a:nth-child(3)") })
   private WebElement calendarNext;

   @FindAll({ @FindBy(css = "div.SelectDate__monthSelector > div > div > select"),
            @FindBy(css = "div.month-navigator > div > select"), })
   private WebElement calendarMonthSelectedValue;

   @FindAll({ @FindBy(css = "[aria-label='Done Departure date'] button"),
            @FindBy(css = ".clear-panel"), @FindBy(xpath = "(//*[text()='Done'])[3]"),
            @FindBy(css = ".date-picker-drop-list .btn.done"),
            @FindBy(css = "[aria-label*='Departure date'] button") })
   private WebElement departureDateDone;

   @FindAll({ @FindBy(id = "duration"), @FindBy(css = "[aria-label = 'select duration'] select"),
            @FindBy(css = ".inputs__selectList select"),
            @FindBy(css = ".inputs__selectList option") })
   private WebElement duration;

   @FindAll({ @FindBy(css = "input[aria-label='rooms and guests']"), @FindBy(id = "whosgoing") })
   private WebElement roomsGuest;

   @FindBy(css = "[aria-label='rooms and guest header']")
   private List<WebElement> roomHeaderText;

   @FindBy(css = "[aria-label='room select'] select option")
   private List<WebElement> numberOfRooms;

   @FindAll({ @FindBy(css = "#adults"), @FindBy(css = "[aria-label = 'adult select'] select"),
            @FindBy(css = "[id *= 'RoomPax_1'] select") })
   private WebElement adults;

   @FindAll({ @FindBy(css = "#children"), @FindBy(css = "[aria-label = 'child select'] select"),
            @FindBy(css = "[id *= 'RoomPax_2'] select") })
   private WebElement child;

   @FindAll({ @FindBy(css = "[aria-label = 'Done cabin and guest'] button"),
            @FindBy(css = "[aria-label = 'Done room and guest'] button"),
            @FindBy(css = "[aria-label='room and guest'] button") })
   private WebElement roomsAndGuestDone;

   @FindBy(css = ".alerts__message")
   private List<WebElement> errorMessage;

   @FindAll({ @FindBy(css = "[aria-label*='search button'] button"),
            @FindBy(css = "#tui_widget_searchpanel_views_SubmitButton_0")

   })
   private WebElement searchButton;

   @FindBy(css = "[aria-label='cities close'] svg")
   private WebElement closeCityOverlay;

   @FindBy(xpath = "//select[@id='setLanguage']")
   private WebElement setLanguage;

   @FindBy(xpath = "//select[@id='setSiteId']")
   private WebElement setSiteId;

   public SearchPanelComponent()
   {
      wait = new WebElementWait();
   }

   public boolean isSearchPanelContainerPresent()
   {
      return WebElementTools.isPresent(searchPanelContainer);
   }

   public boolean isNumberOfRoomsValuesPresent(List<String> noOfRooms)
   {
      wait.forAppear(numberOfRooms);
      for (int j = 0; j < noOfRooms.size(); j++)
      {
         if (!StringUtils.equalsIgnoreCase(noOfRooms.get(j).trim(),
                  WebElementTools.getElementText(numberOfRooms.get(j)).trim()))
         {
            return false;
         }
      }
      return true;
   }

   public void clickOnRoomAndGuestDone()
   {
      wait.forAppear(roomsAndGuestDone);
      WebElementTools.clickElementJavaScript(roomsAndGuestDone);
   }

   public void selectDestinationList()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(getDestinationIcon());
   }

   public WebElement getDestinationForGivenValue(String ariaLabel)
   {
      return DOMElement.getElementByAriaLabel(ariaLabel);
   }

   public void selectWhenField()
   {
      WebElementTools.clickElementJavaScript(departureDateInput);
      wait.waitForElementToBePresent(calendarHeader);
   }

   public void clickOnDurationField()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(duration);
   }

   public boolean isDurationValuesPresent(List<String> duration)
   {
      wait.forAppear(durationOptions);
      for (int j = 0; j < duration.size(); j++)
      {
         if (!StringUtils.equalsIgnoreCase(duration.get(j),
                  WebElementTools.getElementText(durationOptions.get(j))))
         {
            return false;
         }
      }
      return true;
   }

   public boolean isDurationValuesPresentForFc(List<String> duration)
   {
      wait.forAppear(durationOptions);
      for (int j = 0; j < duration.size() - 1; j++)
      {
         if (!StringUtils.equalsIgnoreCase(duration.get(j),
                  WebElementTools.getElementText(durationOptions.get(j))))
         {
            return false;
         }
      }
      return true;
   }

   public WebElement getDestinationIcon()
   {
      wait.forAppear(destinationsListIcon);
      WebElementTools.scrollTo(destinationsListIcon);
      return destinationsListIcon;
   }

   public List<WebElement> getListOfAirports()
   {
      assertTrue("Airport Values are not present", DOMElement.isElementPresent(airportList));
      return airportList;
   }

   public WebElement getAirportDoneElement()
   {
      return wait.getWebElementWithLazyWait(airportDone);
   }

   public void clickOnAirportDone()
   {
      WebElementTools.clickElementJavaScript(getAirportDoneElement());
   }

   public WebElement getDestinationInput()
   {
      return wait.getWebElementWithLazyWait(destinationInput);
   }

   public WebElement getDestinationElement()
   {
      return destinationInput;
   }

   public WebElement getDepartureDateInput()
   {
      return departureDateInput;
   }

   public WebElement getDurationElement()
   {
      return duration;
   }

   public WebElement getRoomAndGuestInput()
   {
      return roomsGuest;
   }

   public void selectAdult(Object adult)
   {
      WebElementTools.selectDropDownByValue(adults, String.valueOf(adult));
   }

   public void selectChild(Object childern)
   {
      WebElementTools.selectDropDownByValue(child, String.valueOf(childern));
   }

   public List<WebElement> getErrorElement()
   {
      return errorMessage;
   }

   public void clickOnAdultDropDown()
   {

      WebElementTools.click(wait.getWebElementWithLazyWait(getAdultElement()));
   }

   public void clickOnChildDropDown()
   {
      WebElementTools.click(getChildElement());
   }

   public WebElement getAdultElement()
   {
      return adults;
   }

   public WebElement getChildElement()
   {
      return child;
   }

   public void clickOnSearchButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(getSearchButton());
   }

   public WebElement getSearchButton()
   {
      return searchButton;
   }

   public WebElement getCalendarMonth()
   {
      return calendarMonth;
   }

   public List<WebElement> getAvailableDates()
   {
      assertTrue("Search Panel calendar data are not available",
               DOMElement.isElementPresent(availableDates));
      return availableDates;
   }

   public List<WebElement> getAllDates()
   {
      $$(anyDates).shouldBe(sizeGreaterThan(0));
      return anyDates;
   }

   public WebElement getDepartureDateDone()
   {
      return departureDateDone;
   }

   public WebElement getCalendarNext()
   {
      return calendarNext;
   }

   public WebElement getMonthSelected()
   {
      return calendarMonthSelectedValue;
   }

   public List<WebElement> getDestinationAutoComplete()
   {
      wait.getWebElementWithLazyWait(destinationsAutoComplete);
      wait.forAppear(destinationsAutoComplete.get(0));
      return destinationsAutoComplete;
   }

   public WebElement getDestinationHeaderOverlay()
   {
      return wait.forAppear(destinationHeaderOverlay);
   }

   public List<WebElement> getDestinationList()
   {
      return wait.getWebElementWithLazyWait(destinationsList);
   }

   public void selectAllDestination()
   {
      wait.forAppear(destinationSelectAll);
      WebElementTools.click((destinationSelectAll));
   }

   public WebElement getDestinationDone()
   {
      return destinationsDone;
   }

   public WebElement getRoomAndGuestDoneElement()
   {
      return roomsAndGuestDone;
   }

   public List<WebElement> getRoomHeaderElement()
   {
      return roomHeaderText;
   }

   public void closeCityOverlay()
   {
      wait.forAppear(closeCityOverlay);
      WebElementTools.click(closeCityOverlay);
   }

   public void selectMFEWhenField()
   {
      searchPanelMfe.departure();
      String calendarHeaderMFE = "[aria-label='Departure date header']";
      wait.waitForElementToBePresent(
               SelenideHelper.getShadowRootElement(calendarHeaderMFE, mfeParentElemnt));
   }

   public void selectRoomAndGuestMFEInputField()
   {
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(roomAndGuestInputMFE, mfeParentElemnt));
      wait.waitForElementToBePresent(
               SelenideHelper.getShadowRootElement(roomAndGuestsLabelMFE, mfeParentElemnt));
   }

   public void selectPassengerIcon()
   {
      String passengerIconMFE = "svg[aria-label='room and guests icon']";
      SelenideHelper.getShadowRootElement(passengerIconMFE, mfeParentElemnt).click();
      wait.waitForElementToBePresent(
               SelenideHelper.getShadowRootElement(roomAndGuestsLabelMFE, mfeParentElemnt));
   }

   public boolean isRoomAndGuestModalDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(roomAndGuestsLabelMFE,
                        mfeParentElemnt));
   }

   public String getNumberOfAdults()
   {
      String noOfAdults = "span[id=\"adults0\"]";
      return SelenideHelper.getShadowRootElement(noOfAdults, mfeParentElemnt).getText();
   }

   public String getNumberOfChildren()
   {
      String noOfChildren = "span[id=\"nonAdults0\"]";
      return SelenideHelper.getShadowRootElement(noOfChildren, mfeParentElemnt).getText();
   }

   public boolean isStepperEnabled(String stepper)
   {
      return SelenideHelper.getShadowRootElement(stepper, mfeParentElemnt).isEnabled();
   }

   public boolean isAdultsPlusMinusStepperEnabled()
   {
      return isAdultPlusStepperEnabled() && isAdultMinusStepperEnabled();
   }

   public boolean isAdultPlusStepperEnabled()
   {
      return isStepperEnabled(adultsPlus);
   }

   public boolean isAdultMinusStepperEnabled()
   {
      return isStepperEnabled(adultsMinus);
   }

   public boolean isChildrenPlusStepperEnabled()
   {
      return isStepperEnabled(childrenPlus);
   }

   public boolean searchButtonEnabled()
   {
      String searchButtonMFE = "button[class=\"button secondary medium\"]";
      return isStepperEnabled(searchButtonMFE);
   }

   public boolean isChildrenMinusStepperEnabled()
   {
      return isStepperEnabled(childrenMinus);
   }

   public boolean isRoomsModalClosed()
   {
      return !SelenideHelper.getShadowRootElement(roomAndGuestsLabelMFE, mfeParentElemnt)
               .isDisplayed();
   }

   public void selectLanguageMFE(String language)
   {
      if (language.equals("nl"))
      {
         WebElementTools.selectDropDownByVisibleText(setSiteId, "NL");
      }
      else
      {
         WebElementTools.selectDropDownByVisibleText(setLanguage, language);
      }
      wait.forJSExecutionReadyLazy();
   }

   public void clickNumberOfRooms()
   {
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(numberOfRoomsMFE, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
   }

   public void clickChildrenErrorLink()
   {
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(childrenErrorLink, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
   }

   public WebElement childrenErrorMessageLinkText()
   {
      WebElement errorLinkText =
               SelenideHelper.getShadowRootElement(childrenErrorLink, mfeParentElemnt);
      wait.forAppear(errorLinkText);
      WebElementTools.javaScriptScrollToElement(errorLinkText);
      return errorLinkText;
   }

   public void clickDoneButton()
   {
      String roomAndGuestDoneButton = "button[class=\"button primary septenary medium\"]";
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(roomAndGuestDoneButton, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
   }

   public void clickRoomOption(String option)
   {
      if (option.equalsIgnoreCase("I don't mind"))
      {
         WebElementTools.selectDropDownByIndex(
                  SelenideHelper.getShadowRootElement(numberOfRoomsMFE, mfeParentElemnt), 0);
      }
      else
      {
         WebElementTools.selectDropDownByVisibleText(
                  SelenideHelper.getShadowRootElement(numberOfRoomsMFE, mfeParentElemnt), option);
      }
      wait.forJSExecutionReadyLazy();
   }

   public void clickChildrenOption(String option)
   {
      WebElementTools.selectDropDownByVisibleText(
               SelenideHelper.getShadowRootElement(numberOfChildren, mfeParentElemnt), option);
      wait.forJSExecutionReadyLazy();
   }

   public void clickChildrenOptions(String option, int childNumber)
   {
      String children3 = "select[class=\"childrenAgeSelection Kind 3\"]";
      String children2 = "select[class=\"childrenAgeSelection Kind 2\"]";
      String children1 = "select[class=\"childrenAgeSelection Kind 1\"]";
      WebElementTools.selectDropDownByVisibleText(SelenideHelper.getShadowRootElement(
                        childNumber == 1 ? children1 : childNumber == 2 ? children2 : children3,
                        mfeParentElemnt),
               option);
   }

   public boolean roomsDropDownPresent()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(numberOfRoomsMFE, mfeParentElemnt));
   }

   public boolean childrenDropDownPresent()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(numberOfChildren, mfeParentElemnt));
   }

   public boolean childrenDropDownDisplayed()
   {
      return !SelenideHelper.getShadowRootElement(childrenText, mfeParentElemnt).isDisplayed();
   }

   public boolean childrenHeaderDisplayed()
   {
      return !SelenideHelper.getShadowRootElement(childrenHeader, mfeParentElemnt).isDisplayed();
   }

   public boolean adultAndInfantErrorMessageDisplayed()
   {
      String adultAndInfantErrorMessage =
               "div[class=\"childrenErrorMessageContent maxPaxErrorMsg\"]";
      return WebElementTools.isPresent(
               SelenideHelper.getShadowRootElement(adultAndInfantErrorMessage, mfeParentElemnt));
   }

   public boolean scrolledToMfePaxHeader()
   {
      String mfeNoOfRooms = "div[class=\"paxHeader\"]";
      WebElement paxHeader = SelenideHelper.getShadowRootElement(mfeNoOfRooms, mfeParentElemnt);
      WebElementTools.scrollTo(paxHeader);
      return WebElementTools.isVisible(paxHeader);
   }

   public boolean childrenTextDisplayed()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(childrenText, mfeParentElemnt));
   }

   public boolean isChildrenAgeRedBorderDisplayed()
   {
      String paxAndRoomChildBorder = "div[class=\"group paxAndRoomChildBorder\"]";
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(paxAndRoomChildBorder,
                        mfeParentElemnt));
   }

   public boolean isChildrenExplanationMarkDisplayed()
   {
      String paxAndRoomChildSelection = "label[class=\"paxAndRoomChildSelection\"]";
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(paxAndRoomChildSelection,
                        mfeParentElemnt));
   }

   public boolean isChildrenAgeSelectionDisplayed()
   {
      String childrenAgeSelection =
               "span[aria-label=\"Children age selection input-selectedText\"]";
      return WebElementTools
               .isPresent(
                        SelenideHelper.getShadowRootElement(childrenAgeSelection, mfeParentElemnt));
   }

   public boolean roomSelectionOptionPresent(String option)
   {
      if (option.equalsIgnoreCase("I don't mind"))
      {
         return WebElementTools.isPresent(SelenideHelper
                  .getShadowRootElement(String.format(optionsMFE, "auto"), mfeParentElemnt));
      }
      else
      {
         return WebElementTools.isPresent(SelenideHelper
                  .getShadowRootElement(String.format(optionsMFE, option), mfeParentElemnt));
      }
   }

   public boolean childrenSelectionOptionPresent(String option)
   {
      if (option.equalsIgnoreCase("Choose age"))
      {
         return WebElementTools.isPresent(
                  SelenideHelper.getShadowRootElement(String.format(optionsMFE, "0"),
                           mfeParentElemnt));
      }
      else
      {
         return WebElementTools.isPresent(SelenideHelper
                  .getShadowRootElement(String.format(optionsMFE, option), mfeParentElemnt));
      }
   }

   public boolean roomComponentPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(mfeRoomHeader, mfeParentElemnt));
   }

   public boolean childComponentPresent()
   {
      wait.forAppear(SelenideHelper.getShadowRootElement(childrenHeader, mfeParentElemnt));
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(childrenHeader, mfeParentElemnt));
   }

   public boolean singleRoomRetained()
   {
      return WebElementTools
               .dropDownSelectedOptionText(
                        SelenideHelper.getShadowRootElement(numberOfRoomsMFE, mfeParentElemnt))
               .equals("1")
               && WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(mfeRoomHeader, mfeParentElemnt));
   }

   public int getRoomAndGuestsMFEInputValue()
   {
      return Integer.parseInt(WebElementTools.getElementAttribute(
               SelenideHelper.getShadowRootElement(roomAndGuestInputMFE, mfeParentElemnt),
               "placeholder").split("\\s+")[0]);
   }

   public void clickAdultsStepper(String stepper, int times)
   {
      if (stepper.equals("+"))
      {
         for (int i = 0; i < times; i++)
         {
            WebElementTools.clickElementJavaScript(
                     SelenideHelper.getShadowRootElement(adultsPlus, mfeParentElemnt));
            wait.forJSExecutionReadyLazy();
         }
      }
      if (stepper.equals("-"))
      {
         for (int i = 0; i < times; i++)
         {
            WebElementTools.clickElementJavaScript(
                     SelenideHelper.getShadowRootElement(adultsMinus, mfeParentElemnt));
            wait.forJSExecutionReadyLazy();
         }
      }
   }

   public void clickChildrenStepper(String stepper, int times)
   {
      if (stepper.equals("+"))
      {
         for (int i = 0; i < times; i++)
         {
            WebElementTools.clickElementJavaScript(
                     SelenideHelper.getShadowRootElement(childrenPlus, mfeParentElemnt));
            wait.forJSExecutionReadyLazy();
         }
      }
      if (stepper.equals("-"))
      {
         for (int i = 0; i < times; i++)
         {
            WebElementTools.clickElementJavaScript(
                     SelenideHelper.getShadowRootElement(childrenMinus, mfeParentElemnt));
            wait.forJSExecutionReadyLazy();
         }
      }
   }

   public void clickAdultStepperSpecificRoomMFE(String stepper, int times, int roomNumber)
   {
      if (stepper.equals("+"))
      {
         for (int i = 0; i < times; i++)
         {
            WebElementTools.clickElementJavaScript(
                     SelenideHelper.getShadowRootElement(
                              String.format(adultsPlusInRoom, roomNumber),
                              mfeParentElemnt));
            wait.forJSExecutionReadyLazy();
         }
      }
      if (stepper.equals("-"))
      {
         for (int i = 0; i < times; i++)
         {
            WebElementTools.clickElementJavaScript(
                     SelenideHelper.getShadowRootElement(
                              String.format(adultsMinusInRoom, roomNumber),
                              mfeParentElemnt));
            wait.forJSExecutionReadyLazy();
         }
      }
   }

   public String getRoomAndGuestsMFEInputText()
   {
      return WebElementTools.getElementAttribute(
               SelenideHelper.getShadowRootElement(roomAndGuestInputMFE, mfeParentElemnt),
               "placeholder");
   }

   public String getRoomAndGuestsMFEInputAdultNumber()
   {
      return WebElementTools.getElementAttribute(
                        SelenideHelper.getShadowRootElement(roomAndGuestInputMFE, mfeParentElemnt),
                        "placeholder")
               .split("\\s+")[0];
   }

   public String getRoomAndGuestsMFEInputAdultText()
   {
      return WebElementTools.getElementAttribute(
                        SelenideHelper.getShadowRootElement(roomAndGuestInputMFE, mfeParentElemnt),
                        "placeholder")
               .split("\\s+")[1];
   }

   public boolean isDefaultDepartureMFE()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(departureDateInputMFE,
                        mfeParentElemnt));
   }

   public String getRoomAndGuestsMFEInputChildText()
   {
      return WebElementTools.getElementAttribute(
                        SelenideHelper.getShadowRootElement(roomAndGuestInputMFE, mfeParentElemnt),
                        "placeholder")
               .split("\\s+")[2];
   }

   public String getNumberOfRoomsMFE()
   {
      return WebElementTools
               .dropDownSelectedOptionText(
                        SelenideHelper.getShadowRootElement(numberOfRoomsMFE, mfeParentElemnt));
   }

   public String getNumberOfRoomsTextMFE()
   {
      String numberOfRoomsTextMFE = "span[aria-label=\"Rooms selection input-selectedText\"]";
      return SelenideHelper.getShadowRootElement(numberOfRoomsTextMFE, mfeParentElemnt).getText();
   }

   public Integer getNumberOfRoomsComponentMFE()
   {
      return SelenideHelper.getShadowRootElements(mfeRoomHeader, mfeParentElemnt).size();
   }

   public String getNumberOfAdultsInRoomIndex(int roomNumber)
   {
      String adultsInRoomMFE = "span[id=\"adults%s\"]";
      return SelenideHelper.getShadowRootElement(String.format(adultsInRoomMFE, roomNumber),
               mfeParentElemnt).getText();
   }

   public String getNumberOfChildrenInRoom(int roomNumber)
   {
      String childrenInRoomMFE = "span[id=\"nonAdults%s\"]";
      return SelenideHelper.getShadowRootElement(String.format(childrenInRoomMFE, roomNumber),
               mfeParentElemnt).getText();
   }

   public boolean isStepperEnabledInRoom(int roomNumber, String typeOfStepper, String typeOfPax)
   {
      if (typeOfStepper.equals("+"))
      {
         if (typeOfPax.equalsIgnoreCase("adults"))
         {
            return isStepperEnabled(String.format(adultsPlusInRoom, roomNumber));
         }
         else if (typeOfPax.equalsIgnoreCase("Children (0-17)"))
         {
            return isStepperEnabled(String.format(childrenPlusInRoom, roomNumber));
         }
      }
      else if (typeOfStepper.equals("-"))
      {
         if (typeOfPax.equalsIgnoreCase("adults"))
         {
            return isStepperEnabled(String.format(adultsMinusInRoom, roomNumber));
         }
         else if (typeOfPax.equalsIgnoreCase("Children (0-17)"))
         {
            return isStepperEnabled(String.format(childrenMinusInRoom, roomNumber));
         }
      }
      return false;
   }

   public String getFirstChildAge()
   {
      return WebElementTools.dropDownSelectedOptionText(
               SelenideHelper.getShadowRootElement(numberOfChildren, mfeParentElemnt));
   }

   public void clickChildrenStepperSpecificRoomMFE(String stepper, int times, int roomNumber)
   {
      if (stepper.equals("+"))
      {
         for (int i = 0; i < times; i++)
         {
            WebElementTools.clickElementJavaScript(
                     SelenideHelper.getShadowRootElement(
                              String.format(childrenPlusInRoom, roomNumber),
                              mfeParentElemnt));
            wait.forJSExecutionReadyLazy();
         }
      }
      if (stepper.equals("-"))
      {
         for (int i = 0; i < times; i++)
         {
            WebElementTools.clickElementJavaScript(
                     SelenideHelper.getShadowRootElement(
                              String.format(childrenMinusInRoom, roomNumber),
                              mfeParentElemnt));
            wait.forJSExecutionReadyLazy();
         }
      }
   }

   public void selectRoomsFromDropDownValues()
   {
      WebElementTools.selectDropDownByVisibleText(
               SelenideHelper.getShadowRootElement(numberOfRoomsMFE, mfeParentElemnt), "2");
   }

   public void clickOnClearAllPaxAndRooms()
   {
      String clearRooms = "[aria-label=\"undefined Rooms and Guests\"]";
      WebElementTools
               .clickElementJavaScript(
                        SelenideHelper.getShadowRootElement(clearRooms, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
   }

   public boolean isAirportFieldPresent()
   {
      wait.forJSExecutionReadyLazy();
      return (SelenideHelper.getShadowRootElements(defaultText, mfeParentElemnt)
               .get(0).getAttribute("placeholder").equals("Kies luchthaven(s)"));
   }

   public boolean isDestinationFieldPresent()
   {
      wait.forJSExecutionReadyLazy();
      return (SelenideHelper.getShadowRootElements(defaultText, mfeParentElemnt)
               .get(1).getAttribute("placeholder").equals("Bijv. Aruba"));
   }

   public boolean isDepartureFieldPresent()
   {
      wait.forJSExecutionReadyLazy();
      return (SelenideHelper.getShadowRootElements(defaultText, mfeParentElemnt)
               .get(2).getAttribute("placeholder").equals("Kies een datum"));
   }

   public void clickSearchBtn()
   {
      String searchBtn =
               "div[class='search-button-wrapper'] button[class='button secondary medium']";
      WebElementTools
               .clickElementJavaScript(
                        SelenideHelper.getShadowRootElement(searchBtn, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
   }

   public boolean isError()
   {
      wait.forJSExecutionReadyLazy();
      String errorWrapper = "div[class='errorWrapper col col-12 col-sm-6 col-md-12 pr-none']";
      return (SelenideHelper.getShadowRootElement(errorWrapper, mfeParentElemnt)
               .getCssValue("background-color").equals("rgba(211, 13, 20, 1)"));
   }

   public boolean departureDateError()
   {
      String departureDateError =
               "div[class='departureWrapper col col-6 col-sm-6 col-md-3 pr-none'] div[class='group  departureDateError']";
      return (SelenideHelper.getShadowRootElement(departureDateError, mfeParentElemnt)
               .getCssValue("border-color").equals("rgb(211, 13, 20)"));
   }

   public boolean airportError()
   {
      String airportError = "[class='group  airportError']";
      return (SelenideHelper.getShadowRootElement(airportError, mfeParentElemnt)
               .getCssValue("border-color").equals("rgb(211, 13, 20)"));
   }

   public String getErrorMessage()
   {
      return (SelenideHelper.getShadowRootElements(errorText, mfeParentElemnt).get(0).getText());
   }

   public String getSecondErrorMessage()
   {
      return (SelenideHelper.getShadowRootElements(errorText, mfeParentElemnt).get(1).getText());
   }

   public void selectDate()
   {
      String departure =
               "div[class='departureWrapper col col-6 col-sm-6 col-md-3 pr-none'] div[class='group  ']";
      WebElementTools
               .clickElementJavaScript(
                        SelenideHelper.getShadowRootElement(departure, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
      String availableDate =
               "div[class='departureWrapper col col-6 col-sm-6 col-md-3 pr-none'] div[class='dropModal DepartureDate'] div[class='days legecy'] time[class='day current sheet legecyDate SelectLegacyDate__available']";
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(availableDate, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
      WebElementTools
               .clickElementJavaScript(SelenideHelper.getShadowRootElement(done, mfeParentElemnt));
   }

   public void selectAirport()
   {
      String airports =
               "div[class='airportWrapper col col-12 col-sm-6 col-md-6 pr-none'] div[class='group  ']";
      WebElementTools
               .clickElementJavaScript(
                        SelenideHelper.getShadowRootElement(airports, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
      String allAirports = "[class='group enabled']";
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(allAirports, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
      WebElementTools
               .clickElementJavaScript(SelenideHelper.getShadowRootElement(done, mfeParentElemnt));
   }

   public SelenideElement getDefaultDepartureDate()
   {
      return SelenideHelper.getShadowRootElement(departureDateInputMFE, mfeParentElemnt);
   }

   public SelenideElement getDefaultRoomAndGuest()
   {
      String roomAndGuest = "label [aria-label='room and guests']";
      return SelenideHelper.getShadowRootElement(roomAndGuest, mfeParentElemnt);
   }

   public List<SelenideElement> selectAvailableDateMfe()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(departureDateInputMFE, mfeParentElemnt));
      wait.forJSExecutionReadyLazy();
      String selectAvailableDate =
               "[class='day current sheet legecyDate SelectLegacyDate__available']";
      return SelenideHelper.getShadowRootElements(selectAvailableDate, mfeParentElemnt);
   }

   public void closeDepartureDate()
   {
      String closeDepartureDate = "span[aria-label=\"Departure date close\"]";
      WebElementTools
               .clickElementJavaScript(
                        SelenideHelper.getShadowRootElement(closeDepartureDate, mfeParentElemnt));
   }

   public boolean isRoomAndGuestModalNotDisplayed()
   {
      SelenideElement roomAndGuestModal =
               $(By.cssSelector("label[aria-label='Rooms and Guests header']"));
      return !roomAndGuestModal.is(visible);
   }

   public String moreInfantsThanAdultsErrorMessageDisplayed()
   {
      return $(shadowDeepCss(".childrenErrorMessageContent.moreInfantErrorMsg")).getText();
   }

   public String greaterThanNineErrorMessageDisplayed()
   {
      return $(shadowDeepCss(".childrenErrorMessageContent.maxPaxErrorMsg")).getText();
   }
}
