package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.unitdetails;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPriceChangeDisplayComponent;

public class UnitDetailsPriceChangeDisplayStepDefs
{

   public final UnitDetailsPriceChangeDisplayComponent unitDetailsPriceChangeDisplay;

   public final PackageNavigation packageNavigation;

   public final UnitDetailsPage unitDetailsPage;

   public final UnitDetailsPriceChangeDisplayComponent unitDetailsPriceChangeDisplayComponent;

   public UnitDetailsPriceChangeDisplayStepDefs()
   {
      packageNavigation = new PackageNavigation();
      unitDetailsPage = new UnitDetailsPage();
      unitDetailsPriceChangeDisplay = new UnitDetailsPriceChangeDisplayComponent();
      unitDetailsPriceChangeDisplayComponent = new UnitDetailsPriceChangeDisplayComponent();
   }

   @Given("that the customer is on the Search page")
   public void that_the_customer_is_on_the_Search_page()
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @Given("that the customer is on the Search page for price change")
   public void that_the_customer_is_on_the_Search_page_for_price_change()
   {
      packageNavigation.navigateToUnitDetailsPageWithPriceChange();
   }

   @When("there has been a price increase in either the unit price or flight price")
   public void there_has_been_a_price_increase_in_either_the_unit_price_or_flight_price()
   {

      unitDetailsPriceChangeDisplay.isPriceChangeComponentsDisplayed();
   }

   @Then("they will be presented with the Price Increase Message")
   public void they_will_be_presented_with_the_Price_Increase_Message()
   {
      unitDetailsPriceChangeDisplay.isPriceChangeIncreaseMessageDisplayed();
   }

   @Then("they will be presented with the Price Decrease Message")
   public void they_will_be_presented_with_the_Price_Decrease_Message()
   {
      unitDetailsPriceChangeDisplay.isPriceChangeDecreaseMessageDisplayed();
   }

}
