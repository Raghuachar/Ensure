package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

public class WCMSComponent extends AbstractPage
{
   @FindAll({ @FindBy(css = "[aria-label='payment details'] button"),
            @FindBy(css = "[aria-label='continue button'] button") })
   private WebElement continueButton;

   public WebElement getContinueElement()
   {
      return continueButton;
   }

}
