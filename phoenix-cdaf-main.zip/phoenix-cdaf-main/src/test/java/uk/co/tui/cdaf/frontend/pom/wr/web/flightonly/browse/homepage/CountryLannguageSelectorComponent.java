package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.ArrayList;
import java.util.List;

public class CountryLannguageSelectorComponent extends AbstractPage
{

   private static String bookingLang;

   @FindBy(css = "#tui-country-selector p")
   private WebElement overlayText;

   @FindBy(css = ".SelectDropdown__selectdropdown label")
   private List<WebElement> labelsInModal;

   @FindBy(css = ".SelectDropdown__large.SelectDropdown__button span")
   private WebElement selectedCountry;

   @FindBy(css = ".SelectDropdown__menuOpen li div span")
   private List<WebElement> availableCountriesInDropdown;

   @FindBy(css = "button[data-testid='country-switcher-button']")
   private WebElement selectedlanguage;

   @FindBy(css = "div[class='SelectDropdown__menuOpen'] ul li")
   private List<WebElement> availableLanguagesInDropdown;

   @FindBy(css = "footer>button")
   private WebElement changeSiteButton;

   @FindBy(css = ".Modal__modalBody")
   private WebElement langSelctorModal;

   @FindBy(css = ".SelectDropdown__prefixOptionSpace svg")
   private WebElement countryTick;

   @FindBy(css = "[class='LanguageCountrySelector__languageText']")
   private WebElement language;

   private List<String> tempList;

   public WebElement getOverlayText()
   {
      return overlayText;
   }

   public WebElement getSelectedCountry()
   {
      return selectedCountry;
   }

   public List<WebElement> getAvailableCountriesInDropdown()
   {
      return availableCountriesInDropdown;
   }

   public List<String> getAvailableCountriesTextInDropdown()
   {
      tempList = new ArrayList<>();
      getAvailableCountriesInDropdown().forEach(val -> tempList.add(val.getText()));
      return tempList;
   }

   public WebElement getSelectedlanguage()
   {
      return selectedlanguage;
   }

   public List<WebElement> getAvailableLanguagesInDropdown()
   {
      return availableLanguagesInDropdown;
   }

   public List<String> getAvailableLanguagesTextInDropdown()
   {
      tempList = new ArrayList<>();
      getAvailableLanguagesInDropdown().forEach(val -> tempList.add(val.getText()));
      return tempList;
   }

   public WebElement getChangeSiteButton()
   {
      return changeSiteButton;
   }

   public WebElement getLangSelctorModal()
   {
      return langSelctorModal;
   }

   public WebElement getCountryLabelInModal()
   {
      return labelsInModal.get(0);
   }

   public WebElement getLanguageLabelInModal()
   {
      return labelsInModal.get(1);
   }

   public WebElement getCountryTick()
   {
      return countryTick;
   }

}
