package uk.co.tui.cdaf.frontend.pom.wr.web.shared;

public enum JourneyLeg
{
   OUTBOUND, RETURN
}
