package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.flightoptions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class FlightLuggageSelectionStepDefs
{

   static AutomationLogManager LOGGER =
            new AutomationLogManager(FlightLuggageSelectionStepDefs.class);

   private final FlightOnlyPageNavigation flightPageNavigation;

   private String totalPriceBeforeUpgrade;

   public FlightLuggageSelectionStepDefs()
   {
      flightPageNavigation = new FlightOnlyPageNavigation();
   }

   @Given("that a {string} is on the WR FO Flight Options page")
   public void that_a_is_on_the_WR_FO_Flight_Options_page(String string)
   {
      flightPageNavigation.navigateToFlightPage();
   }

   @When("there are multiple matching luggage options available for all flight segments")
   public void there_are_multiple_matching_luggage_options_available_for_all_flight_segments()
   {
      boolean actual =
               flightPageNavigation.flightOptionsPage.luggageComponent.isLuggageSectionDisplayed();
      assertThat(
               ReportFormatter.generateReportStatementForComponentCheck("Luggage Section", actual,
                        true),
               actual, is(true));
   }

   @Then("the following luggage components should be displayed on the Flight Options page")
   public void the_following_luggage_components_should_be_displayed_on_the_Flight_Options_page(
            List<String> components)
   {
      flightPageNavigation.wait.forJSExecutionReadyLazy();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = flightPageNavigation.flightOptionsPage.luggageComponent
                     .getFlightLuggageComponent().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Given("there are matching luggage options available for all flight segments")
   public void there_are_matching_luggage_options_available_for_all_flight_segments()
   {
      boolean actual =
               flightPageNavigation.flightOptionsPage.luggageComponent.isLuggageSectionDisplayed();
      assertThat(
               ReportFormatter.generateReportStatementForComponentCheck("Luggage Section", actual,
                        true),
               actual, is(true));
   }

   @When("they select a luggage amount")
   public void they_select_a_luggage_amount()
   {
      totalPriceBeforeUpgrade =
               flightPageNavigation.flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
      flightPageNavigation.flightOptionsPage.luggageComponent.selectAlternateLuggage();
   }

   @Then("the luggage selected should be all flight segments")
   public void the_luggage_selected_should_be_all_flight_segments()
   {
      throw new PendingException();
   }

   @Then("total price of WR FO package should be updated on WR FO Flight Options page")
   public void total_price_of_WR_FO_package_should_be_updated_on_WR_FO_Flight_Options_page()
   {
      flightPageNavigation.wait.forJSExecutionReadyLazy();
      String totalPriceAfterUpgrade =
               flightPageNavigation.flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
      assertThat(ReportFormatter.generateReportStatement("TotalPrice",
                        "values are same after luggage upgrade", totalPriceAfterUpgrade,
                        totalPriceBeforeUpgrade),
               StringUtils.equalsIgnoreCase(totalPriceAfterUpgrade, totalPriceBeforeUpgrade),
               is(false));
   }

   @When("the customer selects a option without matching luggage options for all flight segments")
   public void the_customer_selects_a_option_without_matching_luggage_options_for_all_flight_segments()
   {
      throw new PendingException();
   }

   @Then("those luggage options that do not match should not display as available")
   public void those_luggage_options_that_do_not_match_should_not_display_as_available()
   {
      throw new PendingException();
   }

   @When("the customer has selected a option with no luggage options available")
   public void the_customer_has_selected_a_option_with_no_luggage_options_available()
   {
      LOGGER.log(LogLevel.INFO, "Implementation not required");
   }

   @Then("the luggage component shall only display HLO option")
   public void the_luggage_component_shall_only_display_HLO_option()
   {
      flightPageNavigation.wait.forJSExecutionReadyLazy();
      boolean luggageDisplayed = flightPageNavigation.flightOptionsPage.luggageComponent
               .isAlternateLuggageButtonDisplayed();
      assertThat(ReportFormatter.generateReportStatement("Alternate Luggage",
               "components were displayed", luggageDisplayed, false), luggageDisplayed, is(false));
   }

   @And("they select the luggage other than Okg")
   public void they_select_the_luggage_other_than_Okg()
   {
      totalPriceBeforeUpgrade =
               flightPageNavigation.flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
      flightPageNavigation.flightOptionsPage.luggageComponent.selectAlternateLuggage();
   }

   @And("Selected luggage should be displayed with the text")
   public void Selected_luggage_should_be_displayed_with_the_text(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      flightPageNavigation.wait.forJSExecutionReadyLazy();
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual =
                  flightPageNavigation.flightOptionsPage.luggageComponent.getTextForSelectedLuggage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Selected luggage card doesn't have the expected text", actual,
                           expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("Other luggage price also should be updated")
   public void Other_luggage_price_also_should_be_updated()
   {
      throw new PendingException();
   }

   @And("the difference amount of selected luggage should get added to the total price")
   public void the_difference_amount_of_selected_luggage_should_get_added_to_the_total_price()
   {
      String totalPriceAfterUpgrade =
               flightPageNavigation.flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
      boolean isPriceMatched = flightPageNavigation.flightOptionsPage.luggageComponent
               .isPriceMatched(totalPriceBeforeUpgrade, totalPriceAfterUpgrade);
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Total price is not updated after alternate luggae selection",
                        totalPriceAfterUpgrade,
                        flightPageNavigation.flightOptionsPage.luggageComponent.totPriceAfterFormat),
               isPriceMatched, is(true));
   }

   @And("the selected luggage weight also should be added to all flight segments")
   public void the_selected_luggage_weight_also_should_be_added_to_all_flight_segments()
   {
      flightPageNavigation.flightOptionsPage.summaryPanelComponent.clickOnPriceSummary();
      flightPageNavigation.flightOptionsPage.wait.forJSExecutionReadyLazy();
      List<WebElement> flightExtrasElement =
               flightPageNavigation.flightOptionsPage.summaryPanelComponent.getFlightsExtrasElement();
      boolean isMatched = flightPageNavigation.flightOptionsPage.luggageComponent
               .isLugaggeWeightMatched(flightExtrasElement);
      String selectedWeight =
               flightPageNavigation.flightOptionsPage.luggageComponent.selectedLuggageWeight;
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Selected luggage weight is not updated for flights", StringUtils.EMPTY,
               selectedWeight + " kg luggage × 1"), isMatched, is(true));
      flightPageNavigation.flightOptionsPage.summaryPanelComponent.clickOnPriceSummaryCloseBtn();
   }

   @When("the customer pay for their booking using required details")
   public void the_customer_pay_for_their_booking_using_required_details()
   {
      flightPageNavigation.flightOptionsPage.clickOnContinue();
      flightPageNavigation.searchPanelComponent.closePrivacyPopUp();
      flightPageNavigation.errorHandler.isPageLoadingCorrectly();
      flightPageNavigation.extraOptionsPage.clickOnContinue();
      flightPageNavigation.searchPanelComponent.closePrivacyPopUp();
      flightPageNavigation.errorHandler.isPageLoadingCorrectly();
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.fillThePassengerDetailsForWr();
      flightPageNavigation.searchPanelComponent.closePrivacyPopUp();
      flightPageNavigation.errorHandler.isPageLoadingCorrectly();
      flightPageNavigation.wait.forJSExecutionReadyLazy();
      flightPageNavigation.paymentOptionPage.paymentOptionComponent.clickPaymentMethod();
      flightPageNavigation.paymentOptionPage.paymentOptionComponent.clickOnPayButton();
      flightPageNavigation.wait.forJSExecutionReadyLazy();
      flightPageNavigation.searchPanelComponent.closePrivacyPopUp();
      flightPageNavigation.paymentOptionPage.paymentProviderPage.enterCardDetails();
      flightPageNavigation.searchPanelComponent.closePrivacyPopUp();
   }
}
