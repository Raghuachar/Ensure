package uk.co.tui.cdaf.api.pojo.search.legacy.calendar;

@lombok.Data
public class CheckIn
{
   private String date;
}
