package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;

import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.junit.Assert.assertTrue;

public class AmendTotalpriceTooltipStepDefs
{
   private final SearchResultsComponent searchResultsComponent = new SearchResultsComponent();

   @When("they mouse over the information icon next to the total price")
   public void they_mouse_over_the_information_icon_next_to_the_total_price()
   {
      searchResultsComponent.mouseOverTheInformationIcon();
   }

   @Then("the tooltip comes into view")
   public void the_tooltip_comes_into_view()
   {
      assertThat("Search Panel is not present", searchResultsComponent.isToolTipViewDisplyed(),
               is(true));
   }

   @And("the copy reads as follows:")
   public void the_copy_reads_as_follows(io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String expected = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
               ? map.get((BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
               + (BDDSiteIdResolver.getSiteRTId().toLowerCase()))
               : map.get(BDDSiteIdResolver.getSiteRTId().toLowerCase());
      String actual = searchResultsComponent.getToolTipText();
      assertThat("amend total price tool tip message is not matched", actual,
               equalToIgnoringCase(expected));
   }

   @Then("the info icon \\(highlighted below) has been replaced with the ? icon")
   public void the_info_icon_highlighted_below_has_been_replaced_with_the_icon()
   {
      assertTrue("Question mark was not displayed",
               searchResultsComponent.isQuestionMarkDisplayed());
   }

   @And("the tooltip works {string}")
   public void the_tooltip_works(String string)
   {
      assertTrue("Search Panel is not present", searchResultsComponent.isToolTipViewDisplyed());
   }

}
