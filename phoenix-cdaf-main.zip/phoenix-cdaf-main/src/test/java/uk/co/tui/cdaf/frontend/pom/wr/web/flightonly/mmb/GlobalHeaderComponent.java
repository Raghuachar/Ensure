package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.mmb;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

public class GlobalHeaderComponent extends AbstractPage
{

   public final WebElementWait wait;

   @FindBy(css = ".LanguageCountrySelector__countrySwitcher button")
   private WebElement languageSelector;

   @FindBy(css = "#tui-country-selector li")
   private List<WebElement> availableLanguages;

   @FindBy(css = "#tui-country-selector .SelectDropdown__selectbox")
   private WebElement languageSelectorDropdown;

   @FindBy(css = ".LanguageCountrySelector__languageText")
   private WebElement defaultLanguage;

   @FindBy(css = ".Modal__applyButton")
   private WebElement changeLanguageButton;

   public GlobalHeaderComponent()
   {
      wait = new WebElementWait();
   }

   public void selectLanguageSelector()
   {
      wait.forAppear(languageSelector);
      WebElementTools.clickElementJavaScript(languageSelector);
   }

   public void clickOnLanguageSelectorDropdown()
   {
      wait.forAppear(languageSelectorDropdown);
      WebElementTools.clickElementJavaScript(languageSelectorDropdown);
   }

   public List<String> getAvailableLanguages()
   {
      return availableLanguages.stream().map(WebElement::getText).collect(Collectors.toList());
   }

   public void selectLanguageFromList(String language)
   {
      availableLanguages.stream()
               .filter(l -> l.getText().equals(language)).findFirst()
               .orElseThrow(() -> new NoSuchElementException(
                        language + " is not exist in languages list"))
               .click();
   }

   public void clickOnChangeLanguageButton()
   {
      changeLanguageButton.click();
   }

   public String getDefaultLanguage()
   {
      wait.forAppear(defaultLanguage);
      return defaultLanguage.getText();
   }

}
