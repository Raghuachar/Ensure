package uk.co.tui.cdaf.frontend.pom.wr.web.stay.book.yourholiday;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class PriceBreakdownComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[aria-label='price breakdown']")
   private WebElement priceBreakdown;

   @FindBy(css = "[class*='PriceBreakDown__continue']")
   private WebElement bookNowButton;

   public PriceBreakdownComponent()
   {
      wait = new WebElementWait();
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getPriceBreakdownComponent()
   {
      return new HashMap<>()
      {
         {
            put("Price Breakdown", priceBreakdown);
            put("Continue Button", bookNowButton);
         }
      };
   }

   public WebElement getBooknowButton()
   {
      return wait.getWebElementWithLazyWait(bookNowButton);
   }

   public void clickBooknowButton()
   {
      WebElementTools.click(getBooknowButton());
   }
}
