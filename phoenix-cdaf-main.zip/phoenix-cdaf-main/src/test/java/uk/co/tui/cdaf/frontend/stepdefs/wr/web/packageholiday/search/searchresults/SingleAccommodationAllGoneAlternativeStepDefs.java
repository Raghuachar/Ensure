package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;

public class SingleAccommodationAllGoneAlternativeStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SingleAccommodationAllGoneAlternativeStepDefs.class);

   private static String hotelName = "";

   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   private final Map<String, WebElement> searchMap;

   public SingleAccommodationAllGoneAlternativeStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      searchMap = new HashMap<>();
   }

   @Given("the {string} has conducted a package single accommodation search")
   public void the_has_conducted_a_package_single_accommodation_search(String string)
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
   }

   @And("the backend returns no results for the month searched for")
   public void the_backend_returns_no_results_for_the_month_searched_for()
   {
      searchResultsPage.singleAccommodationComponent.alternativeMonthsInDeeplink("10-02-2022");
   }

   @Then("they will be presented with the single accom 'All Gone' page")
   public void they_will_be_presented_with_the_single_accom_page()
   {
      assertThat("Single accom 'All Gone' is not displayed",
               searchResultsPage.singleAccommodationComponent.isAllGonePageDisplayed(), is(true));
   }

   @And("up to +3 months of on sale months in the future are available")
   public void up_to_3_months_of_on_sale_months_in_the_future_are_available()
   {
      searchResultsPage.singleAccommodationComponent.isAvailableDepartureMonths();
   }

   @When("the 'All Gone' alternative page loads")
   public void the_All_Gone_alternative_page_loads()
   {
      assertThat("Single accom 'All Gone' Alternative is not displayed",
               searchResultsPage.singleAccommodationComponent.isAllGoneAlternativePageDisplayed(),
               is(true));
   }

   @Then("they will see following:")
   public void they_will_see_following(List<String> component)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap
               .putAll(searchResultsPage.singleAccommodationComponent.getAllGoneAlternativeComponents());
      component.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they still want to find results for the same hotel")
   public void they_still_want_to_find_results_for_the_same_hotel()
   {
      hotelName = searchResultsPage.singleAccommodationComponent.getUnitName();
      LOGGER.log(LogLevel.INFO, hotelName);
   }

   @And("there are up to +3 available departure months to choose from")
   public void there_are_up_to_available_departure_months_to_choose_from()
   {
      searchResultsPage.singleAccommodationComponent.isAvailableDepartureMonths();
      LOGGER.log(LogLevel.INFO,
               searchResultsPage.singleAccommodationComponent.isAvailableDepartureMonths());
   }

   @When("they select an alternative month from the options provided")
   public void they_select_an_alternative_month_from_the_options_provided()
   {
      searchResultsPage.singleAccommodationComponent.clickOnAvailableDepartureMonths();
   }

   @Then("the single accom page for that hotel will display and the calendar will display for the month that was selected")
   public void the_single_accom_page_for_that_hotel_will_display_and_the_calendar_will_display_for_the_month_that_was_selected()
   {

      assertEquals("Hotel names are not displayed same", hotelName,
               searchResultsPage.singleAccommodationComponent.getUnitName());
      assertThat("Calender is not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomCalenderDisplayed(),
               is(true));
      searchResultsPage.singleAccommodationComponent.clickOnChangeMonthSelector();
   }

   @Then("they can see a result list of alternative hotels underneath the hotel card")
   public void they_can_see_a_result_list_of_alternative_hotels_underneath_the_hotel_card()
   {
      searchResultsPage.singleAccommodationComponent.alternativeMonthsInDeeplink("26-12-2021");
      assertThat("Calender is not displayed",
               searchResultsPage.singleAccommodationComponent.alternativeHotelCard(), is(true));
   }

   @And("they can see alternative hotels:")
   public void they_can_see_alternative_hotels(List<String> component)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap
               .putAll(searchResultsPage.singleAccommodationComponent.getAlternativeHotelsComponents());
      component.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they can see a message at the top:")
   public void they_can_see_a_message_at_the_top(List<String> component)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.singleAccommodationComponent.getIconErrorMsgComponent());
      component.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("the single accom all gone page loads")
   public void the_single_accom_all_gone_page_loads()
   {
      searchResultsPage.singleAccommodationComponent.alternativeMonthsInDeeplink("26-12-2040");
   }

   @And("the backend has returned hotel availability for {int} month in the past Availability in August")
   public void the_backend_has_returned_hotel_availability_for_month_in_the_past_Availability_in_August(
            Integer int1)
   {
      assertThat("-1 month is not avialble",
               searchResultsPage.singleAccommodationComponent.alternativePastMonth(), is(true));
   }

   @When("they review the hotel card component")
   public void they_review_the_hotel_card_component()
   {
      assertThat("Hotel card is not displayed",
               searchResultsPage.singleAccommodationComponent.hotelCard(), is(true));
   }

   @Then("they will see {int} month from the searched month")
   public void they_will_see_month_from_the_searched_month(Integer int1)
   {
      LOGGER.log(LogLevel.INFO,
               searchResultsPage.singleAccommodationComponent.getPastAvailaibityMonth());
   }

   @When("there is {int} month available to select")
   public void there_is_month_available_to_select(Integer int1)
   {
      searchResultsPage.singleAccommodationComponent.alternativeMonthsInDeeplink("10-02-2022");
      searchResultsPage.singleAccommodationComponent.clickOnAvailableDepartureMonths();
   }

}
