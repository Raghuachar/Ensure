package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Package3PAPasswordChange extends AbstractPage
{

   private final List<String> changePwdFieldsList;

   private final Map<String, String> searchCardMap;

   private final WebDriverUtils webDriverUtils;

   public WebElementWait wait;

   @FindBy(css = "[class='ThirdPartyLogin__passwordLink']")
   private WebElement changePasswordLink;

   @FindBy(css = "[class='ThirdPartyChangePassword__pageHeading']")
   private WebElement changePasswordheader;

   @FindBy(css = "#thirdPartyChangePassword__component form > div:nth-child(2)")
   private WebElement agentcode;

   @FindBy(css = "#thirdPartyChangePassword__component div:nth-child(3) label")
   private WebElement currentPwd;

   @FindBy(css = "#thirdPartyChangePassword__component div:nth-child(3) a")
   private WebElement currentPwdWithShowPwdLink;

   @FindBy(css = "#thirdPartyChangePassword__component div:nth-child(5) label")
   private WebElement newPwd;

   @FindBy(css = "#thirdPartyChangePassword__component div:nth-child(5) a")
   private WebElement newPwdWithShowPwdLink;

   @FindBy(css = "#thirdPartyChangePassword__component div:nth-child(6) label")
   private WebElement reEntryPwd;

   @FindBy(css = "#thirdPartyChangePassword__component div:nth-child(6) a")
   private WebElement reEnterPwdWithShowPwdLink;

   @FindBy(css = "[role='button']")
   private WebElement saveBtn;

   @FindBy(css = "[class='ThirdPartyChangePassword__passwordLink']")
   private WebElement backToLogin;

   @FindBy(xpath = "//label[text()='Kantoor/ABTA ID']/..//input[@aria-label='Kantoor/ABTA ID']")
   private WebElement officeABTAIDInput;

   @FindBy(css = "input#currentpassword")
   private WebElement currentPasswordTextBox;

   @FindBy(css = "#newpassword")
   private WebElement newPasswordField;

   @FindBy(css = "[class*='ThirdPartyChangePassword__confirm']")
   private List<WebElement> tickAppersNewPassword;

   @FindBy(css = "[id*='recaptcha_Component']")
   private WebElement captchaComponentPresent;

   @FindBy(css = "[id*='thirdPartyChangePassword__component']")
   private WebElement changePasswordCompnent;

   @FindBy(xpath = "//button[@type='button']/../../..//div[@id='recaptcha_Component']")
   private WebElement belowCaptchaSave;

   @FindBy(xpath = "//input[@aria-label='Nieuw wachtwoord']")
   private WebElement passwordCreterias;

   @FindBy(xpath = "//input[@aria-label='Re-enter password']")
   private WebElement reEnterPassword;

   @FindBy(css = "[arialabel='alert header']")
   private WebElement alertABTAFailed;

   @FindAll({ @FindBy(css = " input[type=password]"), @FindBy(css = " input[type=text]") })
   private List<WebElement> textFieldValue;

   @FindBy(css = "[arialabel='alert header']")
   private WebElement successSummaryHeading;

   @FindBy(css = "[arialabel='alert description']")
   private WebElement successSummaryDescription;

   @FindBy(css = "[class='recaptcha-checkbox-checkmark']")
   private WebElement reCaptchaCheckbox;

   @FindBy(css = "[title='reCAPTCHA']")
   private WebElement iFrameSwitch;

   @FindBy(css = "[title='recaptcha challenge expires in two minutes']")
   private WebElement reCaptcha;

   @FindBy(css = "[class='rc-imageselect-desc-no-canonical']")
   private WebElement captchaImage;

   @FindBy(css = "[class='ThirdPartyChangePassword__captchaError']")
   private WebElement captchaError;

   public Package3PAPasswordChange()
   {
      changePwdFieldsList = new ArrayList<>();
      wait = new WebElementWait();
      searchCardMap = new HashMap<>();
      webDriverUtils = new WebDriverUtils();
   }

   public WebElement getChangePasswordLabel()
   {
      return changePasswordLink;
   }

   public boolean verifyingNewPasswordLabels(List<String> list)
   {
      boolean flag = false;
      for (String s : list)
      {
         flag = WebDriverUtils.getDriver()
                  .findElement(By.xpath(String.format("//span[text()='%s']", s)))
                  .isDisplayed();
         if (!flag)
         {
            break;
         }
      }
      return flag;
   }

   public boolean verifyingChangedpasswordfields(List<String> changePwdFields)
   {
      changePwdFieldsList.add(WebElementTools.getElementText(changePasswordheader));
      changePwdFieldsList.add(WebElementTools.getElementText(agentcode));
      changePwdFieldsList.add(WebElementTools.getElementText(currentPwd));
      changePwdFieldsList.add(WebElementTools.getElementText(currentPwdWithShowPwdLink));
      changePwdFieldsList.add(WebElementTools.getElementText(newPwd));
      changePwdFieldsList.add(WebElementTools.getElementText(newPwdWithShowPwdLink));
      changePwdFieldsList.add(WebElementTools.getElementText(reEntryPwd));
      changePwdFieldsList.add(WebElementTools.getElementText(reEnterPwdWithShowPwdLink));
      changePwdFieldsList.add(WebElementTools.getElementText(saveBtn));
      changePwdFieldsList.add(WebElementTools.getElementText(backToLogin));
      return changePwdFieldsList.equals(changePwdFields);
   }

   public void clickAndEnterOnOfficeAbTAId()
   {
      WebElementTools.enterText(officeABTAIDInput, "jwojqe123432^&*&^");
   }

   public boolean verifiyingOfficeABTAIdText()
   {
      return WebElementTools.isDisplayed(officeABTAIDInput);
   }

   public String getBackToLogin()
   {
      return WebElementTools.getElementText(backToLogin);
   }

   public void clickOnBackToLogin()
   {
      WebElementTools.click(backToLogin);
   }

   public void clickOnOutSide()
   {
      WebElementTools.click(changePasswordheader);
   }

   public boolean verifiyingErrorMsg(List<String> currentPswErrorMsg)
   {
      return WebDriverUtils.getDriver()
               .findElement(By.xpath("//*[text()='" + currentPswErrorMsg.get(0) + "']"))
               .isDisplayed();
   }

   public boolean getNewPasswordIsPresent()
   {
      return WebElementTools.isPresent(newPasswordField);
   }

   public void enterNewPassword()
   {
      WebElementTools.enterText(newPasswordField, "Tui1234567890Service");
   }

   public boolean getTickAppersNewPassword()
   {
      return tickAppersNewPassword.size() >= 4;
   }

   public boolean getChangePasswordCompnentIsPresent()
   {
      return WebElementTools.isPresent(changePasswordCompnent);
   }

   public boolean getCaptchaComponentIsPresent()
   {
      return WebElementTools.isPresent(captchaComponentPresent);
   }

   public boolean getBelowCaptchaSaveIsPresent()
   {
      return WebElementTools.isPresent(belowCaptchaSave);
   }

   public void clickOnTextBox(String Textfield)
   {
      WebDriverUtils.getDriver().findElement(By.xpath("//input[@aria-label='" + Textfield + "']"))
               .click();
   }

   public void verifyingNewPasswordCreteria(String list)
   {
      WebElementTools.enterText(passwordCreterias, list);
      clickOnOutSide();
   }

   public void verifyingReEnterPassword(String list)
   {
      WebElementTools.enterText(reEnterPassword, list);
      clickOnOutSide();
   }

   public boolean verifyReEnterPasswordErrorMessage(List<String> reEnterPswErrorMsg)
   {
      return WebDriverUtils.getDriver()
               .findElement(By.xpath("//span[text()='" + reEnterPswErrorMsg.get(0) + "']"))
               .isDisplayed();
   }

   public void enterChangePasswordFileds(String officeABTAID, String currentPassword,
            String newPassword)
   {
      WebElementTools.enterText(officeABTAIDInput, officeABTAID);
      WebElementTools.enterText(currentPasswordTextBox, currentPassword);
      WebElementTools.enterText(passwordCreterias, newPassword);
      WebElementTools.enterText(reEnterPassword, newPassword);
   }

   public void clickOnSaveButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(saveBtn);
   }

   public boolean getAlertABTAFailed()
   {
      wait.forComplexPageLoad();
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(alertABTAFailed);
      return WebElementTools.isPresent(alertABTAFailed);
   }

   public void enterPassword(String password)
   {
      WebDriverUtils.getDriver().findElement(By.xpath("//input[@aria-label='" + password + "']"))
               .sendKeys("TUI");
   }

   public void clickOnLink(String link, String field)
   {
      WebDriverUtils.getDriver()
               .findElement(
                        By.xpath("//label[text()='" + field + "']/../..//a[text()='" + link + "']"))
               .click();
   }

   public boolean verifyingLink(String link)
   {
      return WebDriverUtils.getDriver().findElement(By.xpath("//a[text()='" + link + "']"))
               .isDisplayed();
   }

   public boolean verifyingFieldValue()
   {
      return WebElementTools.isDisplayed(textFieldValue.get(0));
   }

   public Map<String, String> getSummaryDetails()
   {
      searchCardMap.put("Your password has been changed", successSummaryHeading.getText());
      searchCardMap.put("You can now log in to your account", successSummaryDescription.getText());
      return searchCardMap;

   }

   public boolean successMessage()
   {
      return WebElementTools.isDisplayed(successSummaryHeading);
   }

   public void clickOnLoginLink()
   {
      successSummaryDescription.click();
   }

   public void clickOnRecaptchaCheckbox()
   {
      wait.forJSExecutionReadyLazy();
      webDriverUtils.switchToIFrame(iFrameSwitch);
      WebElementTools.mouseOverAndClick(reCaptchaCheckbox);
      wait.forJSExecutionReadyLazy();
      webDriverUtils.switchToDefaultContent();
   }

   public boolean switchIFrameCaptchImage()
   {
      wait.forJSExecutionReadyLazy();
      webDriverUtils.switchToIFrame(reCaptcha);
      boolean captha = WebElementTools.isPresent(captchaImage);
      webDriverUtils.switchToDefaultContent();
      return captha;
   }

   public String getCapthaErrorMessage()
   {
      return WebElementTools.getElementText(captchaError);
   }
}
