package uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class FOReconcilationPaymentPageComponents extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(FOReconcilationPaymentPageComponents.class);

   public final WebElementWait wait;

   @FindAll({ @FindBy(css = ".GlobalHeader__siteHeader"),
            @FindBy(css = "#globalHeader__component") })
   private WebElement tuiGlobalHeader;

   @FindBy(css = ".MainNavigation__menuList ")
   private WebElement submenue;

   @FindBy(css = "[aria-label='menu-Admin'] span")
   private WebElement adminLink;

   @FindBy(css = "[aria-label='subMenuListLink-Banking & Reconciliation']")
   private WebElement bankingLink;

   @FindBy(css = ".ReconcilePaymentTable__seodbWrapper ")
   private WebElement ReconcilationTable;

   @FindBy(css = ".ReconcilePaymentTable__seodbArrowUp ")
   private WebElement cardChevron;

   @FindBy(css = ".ReconcilePaymentTable__paymentTypesDetailsContent ")
   private WebElement cardTypes;

   @FindBy(css = ".ReconcilePaymentTable__paymentTypesCard ")
   private WebElement cardName;

   @FindBy(css = ".ReconcilePaymentTable__paymentAmt ")
   private WebElement paymenttotalamount;

   @FindBy(css = ".ReconcilePaymentTable__paymentAmtInput ")
   private WebElement textbox;

   @FindBy(css = ".ReconcilePaymentTable__paymentDiscrepancyAmt ")
   private WebElement discrepancyamount;

   @FindAll({ @FindBy(css = ".GlobalFooter__sections component"),
            @FindBy(css = "#globalFooter__component") })
   private WebElement globalFooter;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableContent")
   private WebElement paymentMethodTypeAccordian;

   @FindBy(css = ".Links__SEODBTertiaryLinksWrapper li:last-child")
   private WebElement updateBankingLink;

   @FindBy(css = ".UI__addPaymentMethod p")
   private WebElement paymentMethodTitle;

   @FindBy(css = ".inputs__radioButton")
   private WebElement CashBRadiobutton;

   public FOReconcilationPaymentPageComponents()
   {
      wait = new WebElementWait();
   }

   public void navigateToReconcilePaymentPage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.isPresent(adminLink);
      WebElementTools.mouseOverAndClick(adminLink);
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(bankingLink);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isGlobalHeaderIsPresent()
   {
      LOGGER.log(LogLevel.INFO, "GlobalHeader is present in Reconcilation Page:");
      return WebElementTools.isPresent(tuiGlobalHeader);

   }

   public boolean isSubmenuePresent()
   {
      LOGGER.log(LogLevel.INFO, "GlobalHeader is present in Reconcilation Page:");
      return WebElementTools.isPresent(submenue);
   }

   public boolean globalFooter()
   {
      LOGGER.log(LogLevel.INFO, "GlobalFooter is present in Reconcilation Page:");
      return WebElementTools.isPresent(globalFooter);
   }

   public boolean isGlobalFooterPresent()
   {
      LOGGER.log(LogLevel.INFO, "GlobalFooter is present in Reconcilation Page:");
      return WebElementTools.isPresent(globalFooter);
   }

   public boolean isReconcilationTablePresent()
   {
      LOGGER.log(LogLevel.INFO, "ReconcilationTable is present in Reconcilation Page:");
      return WebElementTools.isPresent(ReconcilationTable);
   }

   public void navigateToCardChevron()
   {
      LOGGER.log(LogLevel.INFO, "cardChevron is present in Reconcilation Page:");
      WebElementTools.isPresent(cardChevron);
      WebElementTools.mouseOverAndClick(cardChevron);
   }

   public boolean isCardTypesPresent()
   {
      LOGGER.log(LogLevel.INFO, "cardTypes is present in Reconcilation Page:");
      return WebElementTools.isPresent(cardTypes);
   }

   public boolean isCardNamePresent()
   {
      LOGGER.log(LogLevel.INFO, "CardName is present in Reconcilation Page:");
      return WebElementTools.isPresent(cardName);
   }

   public boolean isPaymentTotalAmountPresent()
   {
      LOGGER.log(LogLevel.INFO, "PaymentTotalAmount is present in Reconcilation Page:");
      return WebElementTools.isPresent(paymenttotalamount);
   }

   public boolean isTextBoxPresent()
   {
      LOGGER.log(LogLevel.INFO, "TextBoxr is present in Reconcilation Page:");
      return WebElementTools.isPresent(textbox);
   }

   public boolean isDiscrepancyAmountPresent()
   {
      LOGGER.log(LogLevel.INFO, "DiscrepancyAmount is present in Reconcilation Page:");
      return WebElementTools.isPresent(discrepancyamount);
   }

   public boolean paymentMethodTypeAccordian()
   {
      LOGGER.log(LogLevel.INFO, "payment Method Type Accordian is present in Reconcilation Page:");
      return WebElementTools.isPresent(paymentMethodTypeAccordian);
   }

   public void clickOnUpdateBankingLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.isPresent(updateBankingLink);
      WebElementTools.mouseOverAndClick(updateBankingLink);
   }

   public boolean isPaymentMethodTitleDisplayed()
   {
      return WebElementTools.isPresent(paymentMethodTitle);
   }

   public boolean isCashBRadiobuttonPresent()
   {
      return WebElementTools.isPresent(CashBRadiobutton);
   }
}
