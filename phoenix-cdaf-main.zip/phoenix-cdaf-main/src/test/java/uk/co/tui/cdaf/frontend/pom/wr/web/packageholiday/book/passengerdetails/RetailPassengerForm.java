package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails;

public class RetailPassengerForm
{

   String address1;

   String city;

   String post;

   String email;

   String fName;

   String lName;

   String houseNum;

   public RetailPassengerForm()
   {
      address1 = "Address Line 1";
      city = "Luton";
      post = "1234";
      email = "ananthreddy.s@sonata-software.com";
      fName = "sonata";
      lName = "software";
      houseNum = "10";
   }

}

