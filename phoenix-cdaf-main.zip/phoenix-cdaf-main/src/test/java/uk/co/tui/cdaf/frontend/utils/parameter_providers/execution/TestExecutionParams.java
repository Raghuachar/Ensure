package uk.co.tui.cdaf.frontend.utils.parameter_providers.execution;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.Data;
import lombok.SneakyThrows;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.URL;

@Data
public class TestExecutionParams
{
   private static final Logger LOGGER = LogManager.getLogger(TestExecutionParams.class);

   private Agents agent;

   private Brands brand;

   private Environments env;

   private Locales locale;

   private URL url;

   private URL loginUrl;

   public TestExecutionParams(Agents agent, Brands brand, Environments env, Locales locale)
   {
      this.agent = agent;
      this.brand = brand;
      this.env = env;
      this.locale = locale;
   }

   @JsonIgnore
   public String getEnvStr()
   {
      return getEnv().toString().toLowerCase();
   }

   @JsonIgnore
   public String getLocaleStr()
   {
      return getLocale().toString().toLowerCase();
   }

   @JsonIgnore
   public String getUrlStr()
   {
      return getUrl().toString().toLowerCase();
   }

   @JsonIgnore
   public String getBrandStr()
   {
      return getBrand().toString().toLowerCase();
   }

   @JsonIgnore
   public boolean isBE()
   {
      return getBrand().equals(Brands.BE);
   }

   @JsonIgnore
   public boolean isNL()
   {
      return getBrand().equals(Brands.NL);
   }

   @JsonIgnore
   public boolean isMA()
   {
      return getBrand().equals(Brands.MA);
   }

   @JsonIgnore
   public boolean isFR()
   {
      return getBrand().equals(Brands.FR);
   }

   @JsonIgnore
   public boolean isVIPBE()
   {
      return getBrand().equals(Brands.VIP);
   }

   @SneakyThrows
   public void logParameters()
   {
      ObjectMapper objectMapper = new ObjectMapper();
      objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
      objectMapper.setSerializationInclusion(JsonInclude.Include.NON_DEFAULT);
      objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
      LOGGER.debug(objectMapper.writeValueAsString(this));
   }
}

