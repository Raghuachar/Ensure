package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VIPUSPComponent extends AbstractPage
{
   public final WebElementWait wait;

   private final Map<String, WebElement> uspComponentMap;

   @FindBy(css = "[class='UI__vipTitle'] span>svg")
   private WebElement vipIcon;

   @FindBy(css = "[class='UI__vipTitle'] span[class='cards__title']")
   private WebElement vipcomponentHeader;

   @FindBy(css = "[class='UI__content'] li")
   private List<WebElement> bulletPoints;

   @FindBy(css = "[class='UI__space'] a")
   private WebElement seeBenfitsLink;

   @FindBy(css = "section[class='Modal__modalBody']")
   private WebElement modelPopUp;

   @FindBy(css = "button[aria-label='action apply']")
   private List<WebElement> confirmButton;

   public VIPUSPComponent()
   {
      wait = new WebElementWait();
      uspComponentMap = new HashMap<>();
   }

   public Map<String, WebElement> getUSPComponent()
   {
      wait.forJSExecutionReadyLazy();
      uspComponentMap.put("Icon", vipIcon);
      uspComponentMap.put("Component header", vipcomponentHeader);
      uspComponentMap.put("Bullet pointed USPs", bulletPoints.get(0));
      uspComponentMap.put("See benefits in detail link", seeBenfitsLink);
      return uspComponentMap;
   }

   public Map<String, WebElement> getUSPModelPopUpComponent()
   {
      wait.forJSExecutionReadyLazy();
      uspComponentMap.put("Why choose VIP selection header", vipcomponentHeader);
      uspComponentMap.put("VIP selection headers and copy", bulletPoints.get(0));
      uspComponentMap.put("Confirm CTA", confirmButton.get(1));
      return uspComponentMap;
   }

   public boolean isSeeMoreBenfitsLinkDisplayed()
   {
      return WebElementTools.isPresent(seeBenfitsLink);
   }

   public boolean isModelViewPopUPDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(modelPopUp);
   }

   public void clickSeeMoreBenfitsLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(seeBenfitsLink);
   }

   public void clickOnConfirmButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(confirmButton.get(1));
   }

   public void clickOnModelCloseButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(confirmButton.get(1));
   }
}
