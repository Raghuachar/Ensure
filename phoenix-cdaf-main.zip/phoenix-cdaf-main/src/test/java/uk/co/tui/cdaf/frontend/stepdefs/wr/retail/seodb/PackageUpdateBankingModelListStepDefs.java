package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageUpdateBankingModelListStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageUpdateBankingModelListStepDefs()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @When("they have added seal bags to the modal")
   public void they_have_added_seal_bags_to_the_modal()
   {
      assertThat("Added seal bags found",
               pKgReconcilationPaymentPageComponents.isAddedSealBagDisplayed(), is(true));
   }

   @Then("they can be viewed as a list within the update banking modal")
   public void they_can_be_viewed_as_a_list_within_the_update_banking_modal()
   {
      assertThat("List within update banking model is visible",
               pKgReconcilationPaymentPageComponents.isAddedSealBagDisplayed(), is(true));
   }

   @Then("each seal bag listed will display following information")
   public void each_seal_bag_listed_will_display_following_information(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Payment method displayed in List",
               pKgReconcilationPaymentPageComponents.isPaymentMethodDisplayed(), is(true));
      assertThat("Banking amount displayed in List",
               pKgReconcilationPaymentPageComponents.isBankingAmountDisplayed(), is(true));
      assertThat("Seal bag number displayed in List",
               pKgReconcilationPaymentPageComponents.isSealBagNumberDisplayed(), is(true));
      assertThat("Edit seal bag number icon displayed in List",
               pKgReconcilationPaymentPageComponents.isEditSealBagIconDisplayed(), is(true));
   }
}
