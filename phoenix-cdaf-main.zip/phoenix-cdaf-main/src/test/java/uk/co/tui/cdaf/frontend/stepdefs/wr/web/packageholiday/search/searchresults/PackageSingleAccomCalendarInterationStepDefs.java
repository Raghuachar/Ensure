package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PackageSingleAccomCalendarInterationStepDefs
{

   public final SearchResultsPage searchResultsPage;

   public final UnitDetailsPage unitDetailsPage;

   private final PackageNavigation packageNavigation;

   private String siteId;

   private Set<String> initialHandles;

   public PackageSingleAccomCalendarInterationStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      unitDetailsPage = new UnitDetailsPage();
   }

   @And("they are on the single accommodation search result page")
   public void they_are_on_the_single_accommodation_search_result_page()
   {
      assertThat("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed(), is(true));
   }

   @And("they are viewing the calendar")
   public void they_are_viewing_the_calendar()
   {
      Assert.assertTrue(packageNavigation.searchResultsPage.isAvailabilityCalendarPresent());
   }

   @And("multiple months have been returned from the backend")
   public void multiple_months_have_been_returned_from_the_backend()
   {
      assertThat("multiple months are not displayed",
               searchResultsPage.singleAccommodationComponent.isMultipleMonthsDisplayed(),
               is(true));

   }

   @When("they select the left or right month chevron")
   public void they_select_the_left_or_right_month_chevron()
   {
      String defaultCheapestPrice =
               searchResultsPage.singleAccommodationComponent.getCheapestPriceForSingleAccomm();
      searchResultsPage.singleAccommodationComponent.selectMonthNav();
   }

   @Then("they are transitioned to the next, or previous month in the calendar")
   public void they_are_transitioned_to_the_next_or_previous_month_in_the_calendar()
   {
      boolean calendar;
      String changedCheapestPrice =
               searchResultsPage.singleAccommodationComponent.getCheapestPriceForSingleAccomm();
      calendar = true;
      assertThat("calendar data is not updated", true, is(true));
   }

   @When("they select the month dropdown")
   public void they_select_the_month_dropdown()
   {
      searchResultsPage.singleAccommodationComponent.selectMonthDropdown();
   }

   @Then("they are presented with all the available months in which the package is available to choose from")
   public void they_are_presented_with_all_the_available_months_in_which_the_package_is_available_to_choose_from()
   {
      assertThat("available months are not displayed",
               searchResultsPage.singleAccommodationComponent.isMonthsPresent(), is(true));
   }

   @And("they have selected a cell within the calendar")
   public void they_have_selected_a_cell_within_the_calendar()
   {
      searchResultsPage.singleAccommodationComponent.selectDateCell();
   }

   @And("they are on the unit details page")
   public void they_are_on_the_unit_details_page()
   {
      assertThat("Unit details page is not displayed",
               searchResultsPage.singleAccommodationComponent.isNavigatedToUnitDetailsPage(),
               is(true));
   }

   @Then("they are redirected to the single accom results page")
   public void they_are_redirected_to_the_single_accom_results_page()
   {
      assertThat("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed(), is(true));
   }

   @And("they are anchored down to the calendar view")
   public void they_are_anchored_down_to_the_calendar_view()
   {
      Assert.assertTrue(packageNavigation.searchResultsPage.isAvailabilityCalendarPresent());
   }

   @And("the Single Accom Search Results Legacy Message switch is set to On")
   public void the_Single_Accom_Search_Results_Legacy_Message_switch_is_set_to_On()
   {
      assertTrue(searchResultsPage.singleAccommodationComponent.isLeaveEarlierOptionDisplayed());
   }

   @And("the Single Accom Search Results Legacy Message switch is set to Off")
   public void the_Single_Accom_Search_Results_Legacy_Message_switch_is_set_to_Off()
   {
      assertFalse(searchResultsPage.singleAccommodationComponent.isLeaveEarlierOptionDisplayed());
   }

   @When("they select one of the LEAVE EARLIER option from the calendar")
   public void they_select_one_of_the_LEAVE_EARLIER_option_from_the_calendar()
   {
      searchResultsPage.singleAccommodationComponent.clickOnLeaveEarlierOption();
   }

   @Then("the Single Accom Search Results  calendar shall be display the following legacy message:")
   public void the_Single_Accom_Search_Results_calendar_shall_be_display_the_following_legacy_message(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      siteId = getTestExecutionParams().getBrandStr();

      Map<String, String> matchingRow =
               dataTableTemp.stream().filter(row -> row.get("Site").equals(siteId))
                        .findFirst()
                        .orElseThrow(() -> new IllegalArgumentException(
                                 "Cannot find expected strings for " + siteId));
      String expectedLegacyMessageText = matchingRow.get("legacyMessageText");
      String actualLegacyMessageText =
               searchResultsPage.singleAccommodationComponent.getLegacyMsgText();
      assertThat("legacyMessage not displayed", actualLegacyMessageText,
               equalToIgnoringCase(expectedLegacyMessageText));
      String expectedLegacyMessageHyperLink = matchingRow.get("legacyMessageHyperLink");
      String actualLegacyMessageHyperLink =
               searchResultsPage.singleAccommodationComponent.getLegacyHyperLinkText();
      assertThat("legacyMessage hyperlink not displayed", actualLegacyMessageHyperLink,
               equalToIgnoringCase(expectedLegacyMessageHyperLink));
   }

   @And("the Customer is viewing the legacy message on the Single Accom Search Results calendar")
   public void the_Customer_is_viewing_the_legacy_message_on_the_Single_Accom_Search_Results_calendar()
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
      searchResultsPage.singleAccommodationComponent.clickOnLeaveEarlierOption();
      initialHandles = WebDriverUtils.getDriver().getWindowHandles();
   }

   @Then("the Legacy website shall open on the existing browser tab")
   public void the_Legacy_website_shall_open_on_the_existing_browser_tab()
   {
      Set<String> currentHandles = WebDriverUtils.getDriver().getWindowHandles();
      assertThat("Website did not open in the existing tab",
               (currentHandles.containsAll(initialHandles)), is(true));
   }

   @Then("the {string} option within the calendar month dropdown shall not be available")
   public void the_option_within_the_calendar_month_dropdown_shall_not_be_available(String string)
   {
      assertFalse(searchResultsPage.singleAccommodationComponent.isLeaveEarlierOptionDisplayed());
   }

   @Then("the customer shall not see the legacy message")
   public void the_customer_shall_not_see_the_legacy_message()
   {
      assertFalse(searchResultsPage.singleAccommodationComponent.isLegacyMsgDisplayed());
   }

}
