package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class PricePanelComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[aria-label='price panel'] [class*='totalPrice']")
   private WebElement totalPrice;

   @FindBy(css = "[class*='PriceSummaryPanel__summaryDropdown']")
   private WebElement summaryDropdown;

   public PricePanelComponent()
   {
      wait = new WebElementWait();

   }

   public WebElement getSummaryDropdownElement()
   {
      return summaryDropdown;
   }

   public String getTotalPriceValue()
   {
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(totalPrice));
   }

}
