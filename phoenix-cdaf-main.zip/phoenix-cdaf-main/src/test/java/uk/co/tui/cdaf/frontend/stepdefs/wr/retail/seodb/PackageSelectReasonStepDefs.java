package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSelectReasonStepDefs
{
   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   public PackageSelectReasonStepDefs()
   {
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @When("they view a payment type accordion")
   public void they_view_a_payment_type_accordion()
   {
      assertThat("select a resson is  present",
               pKgReconcilationPaymentPageComponents.isSelectReasonDisplayed(), is(true));
   }

   @Then("they can see the {string} dropdown")
   public void they_can_see_the_dropdown(String string)
   {
      pKgReconcilationPaymentPageComponents.clickSelectReason();
   }

   @And("this includes the following options")
   public void this_includes_the_following_options(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("select a resson is  present",
               pKgReconcilationPaymentPageComponents.isSelectReasonListDisplayed(), is(true));
   }

   @And("then update discrepancy modal")
   public void then_update_discrepancy_modal()
   {
      pKgReconcilationPaymentPageComponents.selectOneReson();
      pKgReconcilationPaymentPageComponents.clickSelectReasonSubmitCTA();
      retailpassengerdetailspage.userLogout();

   }

}
