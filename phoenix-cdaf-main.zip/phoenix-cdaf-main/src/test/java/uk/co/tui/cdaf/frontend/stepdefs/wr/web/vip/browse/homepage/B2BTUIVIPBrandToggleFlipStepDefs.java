package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HeaderComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

public class B2BTUIVIPBrandToggleFlipStepDefs
{

   static AutomationLogManager LOGGER =
            new AutomationLogManager(B2BTUIVIPBrandToggleFlipStepDefs.class);

   public final SearchResultsPage searchResultsPage = new SearchResultsPage();

   public final PackageNavigation packageNavigation = new PackageNavigation();

   public final SearchResultsComponent searchResultsComponent = new SearchResultsComponent();

   public SearchPanel searchPanel = SearchPanelFactory.getSearchPanel();

   public WebElementWait wait = new WebElementWait();

   public HeaderComponent headercomp = new HeaderComponent();

   // TODO: cleanup, this step definition fully or partially duplicates step definitions from the list bellow:
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel.MFESearchPanelDepartureAirportStepDefs.java
   //        the_is_on_the_Belgium_Dutch_page(String, String)
   //        the_is_on_the_Belgium_French_page(String, String)
   //        the_is_on_the_Netherlands_page(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.RoomAndGuestAutoAllocationStepDefs.java
   //        is_on_the_page(String)
   //        they_re_on_the_page(String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.B2BVipSelectSingleAccommodationSearch.java
   //        the_is_on_the_page_VIP_Select_package(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage.B2BTUIVIPBrandToggleFlipStepDefs.java
   //        the_is_on_the_page(String, String)
   @Given("the {string} is on the {string} page")
   public void the_is_on_the_page(String agent, String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Homepage"))
      {
         packageNavigation.navigateToHoldaySearchPage();
      }
      else if (respectivePage.equalsIgnoreCase("Search Results"))
      {
         packageNavigation.navigateToSearchResultPage();
      }
      else if (respectivePage.equalsIgnoreCase("Unit details"))
      {
         packageNavigation.navigateToUnitDetailsPage();
      }
   }

   @Given("they are viewing the Main or Edit Search Panel")
   public void they_are_viewing_the_Main_Edit_Search_Panel()
   {
      assertTrue("Search Panel is not present", searchPanel.isSearchPanelDisplayed());
   }

   @Given("{string} is the selected brand toggle")
   public void is_the_selected_brand_toggle(String string)
   {
      wait.forJSExecutionReadyLazy();
      headercomp.selectTuiSelection();
   }

   @Given("they have entered their search criteria in the respective fields without selecting {string}")
   public void they_have_entered_their_search_criteria_in_the_respective_fields_without_selecting(
            String string)
   {
      searchPanel.selectDefaults();
      wait.forJSExecutionReadyLazy();
   }

   @Given("they've selected the VIP Select toggle")
   public void they_ve_selected_the_VIP_Select_toggle()
   {
      wait.forJSExecutionReadyLazy();
      headercomp.selectVipSelection();
   }

   @When("they select the {string} brand toggle again")
   public void they_select_the_brand_toggle_again(String string)
   {
      headercomp.selectTuiSelection();
      wait.forJSExecutionReadyLazy();
   }

   @Then("the previously entered search data is cleared")
   public void the_previously_entered_search_data_is_cleared()
   {
      assertThat("Clear search link displayed ", searchResultsComponent.clearSearchLink(),
               is(false));
      wait.forJSExecutionReadyLazy();
   }

   @Given("VIP Select is the selected brand toggle")
   public void vip_Select_is_the_selected_brand_toggle()
   {
      headercomp.selectVipSelection();
      wait.forJSExecutionReadyLazy();
   }

   @Given("they've selected the TUI Holidays Select toggle")
   public void they_ve_selected_the_TUI_Holidays_Select_toggle()
   {
      headercomp.selectTuiSelection();
      wait.forJSExecutionReadyLazy();
   }

   @When("they select the {string} brand toggle")
   public void they_select_the_brand_toggle(String string)
   {
      headercomp.selectVipSelection();
      wait.forJSExecutionReadyLazy();
   }

   @Given("they have selected the TUI Holidays radio button")
   public void they_have_selected_the_TUI_Holidays_radio_button()
   {
      headercomp.selectTuiSelection();
      wait.forJSExecutionReadyLazy();
   }

   @Given("they ve entered all of their search criteria, including a specific TUI brand hotel in the {string} field")
   public void they_Destination_field(String string)
   {
      searchPanel.airport().setAllAirportsSelected(true).confirmSelection();
      searchPanel.destinationSuggestions(string);
      searchPanel.departure().selectFirstAvailableDate().confirmSelection();
      wait.forJSExecutionReadyLazy();
   }

   @When("they select the Search cta")
   public void they_select_the_Search_cta()
   {
      searchPanel.doSearch();
   }

   @Then("they re redirected to the single accommodation results page for the TUI branded hotel in question")
   public void they_re_redirected_to_the_single_accommodation_results_page_for_the_TUI_branded_hotel_in_question()
   {
      LOGGER.log(LogLevel.INFO, headercomp.getRatingText());

   }

   @Given("they have selected the VIP Select radio button")
   public void they_have_selected_the_VIP_Select_radio_button()
   {
      headercomp.selectVipSelection();
      wait.forJSExecutionReadyLazy();
   }

   @Given("they ve entered all of their search criteria, including a specific VIP brand hotel in the {string} field")
   public void they_ve_entered_all_of_their_search_criteria_including_a_specific_VIP_brand_hotel_in_the_field(
            String string)
   {
      searchPanel.airport().setAllAirportsSelected(true).confirmSelection();
      searchPanel.destinationSuggestions(string);
      searchPanel.departure().selectFirstAvailableDate().confirmSelection();
      wait.forJSExecutionReadyLazy();
   }

   @Then("they re redirected to the single accommodation results page for the VIP brand hotel in question")
   public void they_re_redirected_to_the_single_accommodation_results_page_for_the_VIP_brand_hotel_in_question()
   {
      LOGGER.log(LogLevel.INFO, headercomp.getRatingText());
   }
}
