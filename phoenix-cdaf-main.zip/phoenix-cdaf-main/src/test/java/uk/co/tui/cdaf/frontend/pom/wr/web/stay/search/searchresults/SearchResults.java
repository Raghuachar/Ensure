package uk.co.tui.cdaf.frontend.pom.wr.web.stay.search.searchresults;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;

public class SearchResults extends AbstractPage
{

   // Elements
   ///////////
   @FindBy(css = ".SearchResults__resultsList a:first-of-type")
   private WebElement searchResultItemLink;

   @FindBy(css = ".SearchResults__resultsList")
   private List<WebElement> selectableCard;

   @FindBy(css = ".Galleries__galleryWrapperV2")
   private List<WebElement> imageGallery;

   @FindBy(css = ".roomTooltip")
   private List<WebElement> searchResultItemToolTip;

   @FindBy(css = "div[aria-label='simple-popup'] span")
   private List<WebElement> mapLinks;

   @FindBy(css = "div[aria-label='simple-popup'] [aria-label='overlay open']")
   private List<WebElement> mapModal;

   @FindBy(css = "div[role='tooltip']")
   private List<WebElement> tooltip;

   @FindBy(css = "div[role='tooltip'] span")
   private List<WebElement> priceTooltip;

   // Interactions
   ///////////////

   public void clickResultItemImage()
   {
      WebElementTools.click(searchResultItemLink);
   }

   public void hoverOverResultItemToolTip()
   {
      WebElementTools.mouseOverAndClick(searchResultItemToolTip.get(0));
   }

   public void mapLinkClick()
   {
      WebElementTools.click(mapLinks.get(0));
   }

   // Asserts
   //////////

   public boolean isSelectableCardPresent()
   {
      return !selectableCard.isEmpty();
   }

   public boolean isImageGalleryPresent()
   {
      return !imageGallery.isEmpty();
   }

   public boolean mapModalIsOpened()
   {
      return WebElementTools.isPresent(mapModal.get(0));
   }

   public boolean tooltipContainsText(String tooltipContent)
   {
      return WebElementTools.getElementText(tooltip.get(0)).equals(tooltipContent);
   }

   public boolean priceToolTipContainsText(String tooltipContent)
   {
      return WebElementTools.getElementText(priceTooltip.get(0)).equals(tooltipContent);
   }

}

