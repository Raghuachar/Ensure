package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOMASkipPaymentStepDefs
{

   public final FlightOptionsPage flightOptionsPage;

   public final ExtraOptionsPage extraOptionsPage;

   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final SearchPanelComponent searchPanelComponent;

   private final RetailSearchPanelComponent retailsearchpanelcomponent;

   public FOMASkipPaymentStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      searchPanelComponent = new SearchPanelComponent();
      retailsearchpanelcomponent = new RetailSearchPanelComponent();
      flightOptionsPage = new FlightOptionsPage();
      extraOptionsPage = new ExtraOptionsPage();
   }

   @Given("that the inhouse agent is on the ma payment page")
   public void that_the_inhouse_agent_is_on_the_ma_payment_page()
   {
      retailpackagenavigation.retailLogin();
      retailpackagenavigation.relaunchMAFO();
      searchPanelComponent.wrFoOneWaySearch();
      retailsearchpanelcomponent.selectFlight();
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
   }

   @When("they view the ma payment component")
   public void they_view_the_ma_payment_component()
   {
      retailpassengerdetailspage.fillRetailPassengerDetails();
   }

   @Then("there is an link to {string} next to the {string} button")
   public void there_is_an_link_to_next_to_the_button(String string, String string2)
   {
      assertThat("the Insurance component for NL is not displayed in the Header",
               retailpassengerdetailspage.isSkippaymentCTAPresent(), is(true));
   }

   @And("they click the SKIPPAYMENT link")
   public void they_click_the_SKIPPAYMENT_link()
   {
      retailpassengerdetailspage.skippayment();
   }

   @And("the agent will be navigated to the booking confirmation page")
   public void the_agent_will_be_navigated_to_the_booking_confirmation_page()
   {
      throw new PendingException();
   }
}
