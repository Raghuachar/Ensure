package uk.co.tui.cdaf.frontend.stepdefs.uk.web.beach_holiday.book.flight_options;

import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.book.flightoptions.FlightOptionsSeatsUpdatesComponent;
import uk.co.tui.cdaf.frontend.pom.uk.web.flight_only.search.search_results.FlightOnlySearchResultsNavigationPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * SeatsDesignUpdatesStepDefs
 */
public class SeatsDesignUpdatesStepDefs
{

   private final FlightOptionsPage flightOptionsPage;

   private final FlightOnlySearchResultsNavigationPage flightsSearch;

   FlightOptionsSeatsUpdatesComponent seatsDesignUpdatesPage;

   public SeatsDesignUpdatesStepDefs()
   {
      seatsDesignUpdatesPage = new FlightOptionsSeatsUpdatesComponent();
      flightsSearch = new FlightOnlySearchResultsNavigationPage();
      flightOptionsPage = new FlightOptionsPage();
   }

   @Then("there is no options for cabin class and seat upgrades, except luggage")
   public void there_is_no_options_for_cabin_class_and_seat_upgrades_except_luggage()
   {
      assertThat("YOUR CABIN CLASS & UPGRADES component is displayed",
               seatsDesignUpdatesPage.flightSeatAncillaryIsDisplayed(), is(false));
      assertThat("SEAT TYPE compo9nent is displayed",
               seatsDesignUpdatesPage.flightSeatAncillaryTypeIsDisplayed(), is(false));
      assertThat("Your Lugagge component is not displayed", flightsSearch.isLugggagePresent(),
               is(true));
      flightOptionsPage.clickOnContinue();
   }

}
