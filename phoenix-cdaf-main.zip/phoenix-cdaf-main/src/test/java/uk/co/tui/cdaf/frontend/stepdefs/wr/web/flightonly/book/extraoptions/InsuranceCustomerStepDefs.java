package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.extraoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class InsuranceCustomerStepDefs
{

   private final FlightOnlyPageNavigation flightPageNavigation;

   private final ExtraOptionsPage extraOptionsPage;

   public InsuranceCustomerStepDefs()
   {
      flightPageNavigation = new FlightOnlyPageNavigation();
      extraOptionsPage = new ExtraOptionsPage();
   }

   @Given("the customer is on the WR FO {string} page")
   public void the_customer_is_on_the_Extras_page(String pageName)
   {
      flightPageNavigation.navigateToExtraPage();
   }

   @When("they navigate to the Passenger Selection on the Insurance Component")
   public void they_navigate_to_the_Passenger_Selection_on_the_Insurance_Component()
   {
      extraOptionsPage.insuranceComponent.viewInsurance();
   }

   @Then("the component should display the following:")
   public void the_component_should_display_the_following(List<String> components)
   {
      extraOptionsPage.wait.forJSExecutionReadyLazy();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = extraOptionsPage.insuranceComponent
                     .getInsurancePassengerFormComponents().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("the {string} button should be in a disabled state")
   public void the_update_price_button_should_be_in_a_disabled_state(String priceButton)
   {
      assertThat("Update Prices Button is not disabled",
               extraOptionsPage.insuranceComponent.isUpdateButtonDisabled());
   }

   @When("they select the customer tick box")
   public void they_select_the_customer_tick_box()
   {
      extraOptionsPage.insuranceComponent.selectTickForLeadPassenger();
   }

   @When("they have selected a passenger")
   public void they_have_selected_a_passenger()
   {
      extraOptionsPage.insuranceComponent.selectTickForLeadPassenger();
   }

   @And("they have entered a valid dob for the selected passenger")
   public void they_have_entered_a_valid_dob_for_the_selected_passenger()
   {
      extraOptionsPage.insuranceComponent.enterLeadPaxDOB("12", "12", "1983");
   }

   @When("the customer enters a invalid DoB for any selected customer")
   public void the_customer_enters_a_invalid_DoB_for_any_selected_customer()
   {
      extraOptionsPage.insuranceComponent.enterLeadPaxDOB("40", "13", "2812");
   }

   @When("they select an additional passenger without adding a DoB")
   public void they_select_an_additional_passenger_without_adding_a_DoB()
   {
      extraOptionsPage.insuranceComponent.selectTickForNonLeadPassenger();
   }

   @When("they add a valid DoB")
   public void they_add_a_valid_DoB()
   {
      extraOptionsPage.insuranceComponent.enterLeadPaxDOB("12", "12", "1983");
   }

   @Then("the {string} button should be enabled")
   public void the_Update_Price_button_should_be_enabled(String button)
   {
      assertThat("Update Price Button is not enabled",
               extraOptionsPage.insuranceComponent.isUpdatePriceButtonEnabled(), is(false));
   }

   @Then("The Select all should display as follows")
   public void the_Select_all_should_display_as_follows(io.cucumber.datatable.DataTable dataTable)
   {

      assertThat("Select all link is not displayed",
               extraOptionsPage.insuranceComponent.isSelectAllLinkPresent());
   }

   @Given("they navigate to the Passenger Selection section")
   public void they_navigate_to_the_Passenger_Selection_section()
   {
      extraOptionsPage.insuranceComponent.viewInsurance();
   }

   @When("they select the Select all button")
   public void they_select_the_Select_all_button()
   {
      extraOptionsPage.insuranceComponent.clickSelectAllLink();
   }

   @Then("The select passenger tick box should be ticked")
   public void the_select_passenger_tick_box_should_be_ticked()
   {
      assertThat("passenger tick box is not checked",
               extraOptionsPage.insuranceComponent.isPassengerTickBoxTicked());
   }

   @Then("the Select all button should display as Deselect all")
   public void the_Select_all_button_should_display_as_Deselect_all()
   {
      assertThat("Select all link is not displayed as deselect all",
               extraOptionsPage.insuranceComponent.isSelectAllLinkPresent());
   }

   @Then("all the DoB fields should be enabled")
   public void all_the_DoB_fields_should_be_enabled()
   {
      assertThat("All the Dob fields are not enabled",
               extraOptionsPage.insuranceComponent.isPassengerTickBoxTicked());
   }

   @Given("they have selected the Select all link")
   public void they_have_selected_the_Select_all_link()
   {
      extraOptionsPage.insuranceComponent.clickSelectAllLink();
   }

   @When("the they select the Deselect link")
   public void the_they_select_the_Deselect_link()
   {
      extraOptionsPage.insuranceComponent.clickSelectAllLink();
   }

   @Then("All the selected passenger tick boxes should be unticked")
   public void all_the_selected_passenger_tick_boxes_should_be_unticked()
   {
      assertThat("passenger tick box is not checked",
               extraOptionsPage.insuranceComponent.isPassengerTickBoxTicked(), is(false));
   }

   @Then("the Select all link should display as Select all")
   public void the_Select_all_link_should_display_as_Select_all()
   {
      assertThat("Select all link is not displayed",
               extraOptionsPage.insuranceComponent.isSelectAllLinkPresent());
   }

   @Then("all the DoB fields should be disabled")
   public void all_the_DoB_fields_should_be_disabled()
   {
      assertThat("All dob fields are not disabled",
               extraOptionsPage.insuranceComponent.isPassengersDobDisabled());
   }

   @When("they select all of the passengers on their booking manually")
   public void they_select_all_of_the_passengers_on_their_booking_manually()
   {
      extraOptionsPage.insuranceComponent.selectAllPassengers();
   }

   @When("they select an enabled select insurance button")
   public void they_select_an_enabled_select_insurance_button()
   {
      extraOptionsPage.insuranceComponent.selectEnabledInsuranceButton();
   }

   @Then("the insurance should be added to the booking")
   public void the_insurance_should_be_added_to_the_booking()
   {
      assertThat("Insurance is not selected",
               extraOptionsPage.insuranceComponent.isInsuranceSelected(), is(true));
   }

   @Then("the insurance should only be able to select a single option at any time")
   public void the_insurance_should_only_be_able_to_select_a_single_option_at_any_time()
   {
      assertThat("Single insurance is not selected at any time",
               extraOptionsPage.insuranceComponent.isSingleInsuranceSelected(), is(true));
   }

   @Given("they have selected an insurance option")
   public void they_have_selected_an_insurance_option()
   {
      extraOptionsPage.insuranceComponent.selectEnabledInsuranceButton();
   }

   @When("they select an alternative insurance option")
   public void they_select_an_alternative_insurance_option()
   {
      extraOptionsPage.insuranceComponent.selectAlternateInsuranceOption();
   }

   @Then("the original selected option should be deselected")
   public void the_original_selected_option_should_be_deselected()
   {
      assertThat("The original selected option is not deselected",
               extraOptionsPage.insuranceComponent.isInsuranceDeselected(), is(true));
   }

   @Then("the new selected option should be added to the booking")
   public void the_new_selected_option_should_be_added_to_the_booking()
   {
      assertThat("New Insurance option is not added to the booking",
               extraOptionsPage.insuranceComponent.isInsuranceSelected(), is(true));
   }

   @When("they navigate to the insurance product component")
   public void they_navigate_to_the_insurance_product_component()
   {
      extraOptionsPage.insuranceComponent.viewInsurance();
   }

   @Given("they have a passenger aged {int} on their booking")
   public void they_have_a_passenger_aged_on_their_booking(Integer age)
   {
      assertThat("Infant is not part of search",
               extraOptionsPage.insuranceComponent.isInfantNotBornCriteria(), is(true));
   }

   @When("they navigate to the passenger aged {int} on the insurance component")
   public void they_navigate_to_the_passenger_aged_on_the_insurance_component(Integer age)
   {
      extraOptionsPage.insuranceComponent.navigateToInfantNotBornCheckBox();
   }

   @Then("they will see a Infant Not Born Yet tick box")
   public void they_will_see_a_Infant_Not_Born_Yet_tick_box()
   {
      assertThat("Infant Check box is not displayed",
               extraOptionsPage.insuranceComponent.isInfantCheckBoxDisplayed(), is(true));
   }

   @Then("the tick box will be disabled")
   public void the_tick_box_will_be_disabled()
   {
      assertThat("Infant tick Check box is not disabled",
               extraOptionsPage.insuranceComponent.isInfantCheckBoxDisabled(), is(true));
   }

   @When("they select the passenger tick box for the passenger aged {int}")
   public void they_select_the_passenger_tick_box_for_the_passenger_aged(Integer int1)
   {
      extraOptionsPage.insuranceComponent.clickInfantNotBornCheckBox();
   }

   @Then("the infant not born yet tick box should be enabled")
   public void the_infant_not_born_yet_tick_box_should_be_enabled()
   {
      assertThat("Infant tick Check box is not enabled",
               extraOptionsPage.insuranceComponent.isInfantCheckBoxEnabled(), is(true));
   }

   @When("they select the infant not born yet tick box")
   public void they_select_the_infant_not_born_yet_tick_box()
   {
      extraOptionsPage.insuranceComponent.isInfantNotYetBornCheckBoxClicked();
   }

   @Then("they will see the following message:")
   public void they_will_see_the_following_message(io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      assertThat("Infant not yet born message is not displayed",
               extraOptionsPage.insuranceComponent.isInfantNotYetBornMessageDisplayed(), is(true));
      try
      {
         actual = extraOptionsPage.insuranceComponent.getInfantErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Infant error message is not same", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Then("the should see a maximum of {int} USPs")
   public void the_should_see_a_maximum_of_USPs(Integer count)
   {
      assertThat("Insurance component has more than maximum USPs",
               extraOptionsPage.insuranceComponent.isMaxInsuranceUspCount(count), is(true));
   }

   @When("they navigate to the more Advantages and Information")
   public void they_navigate_to_the_more_Advantages_and_Information()
   {
      extraOptionsPage.insuranceComponent.viewInsurance();
   }

   @Then("{int} USP should display")
   public void usp_should_display(Integer count)
   {
      assertThat("Mobile Insurance component has more than default USP count",
               extraOptionsPage.insuranceComponent.isDefaultMobileInsuranceUspCount(count),
               is(true));
   }

   @Then("a show more link should be visible")
   public void a_show_more_link_should_be_visible()
   {
      assertThat("Show more link is not displayed",
               extraOptionsPage.insuranceComponent.hasShowMoreLink(), is(true));
   }

   @When("they select Show More")
   public void they_select_Show_More()
   {
      extraOptionsPage.insuranceComponent.selectShowMore();
   }

   @Then("the component should expand to display {int} USPs")
   public void the_component_should_expand_to_display_USPs(Integer count)
   {
      assertThat("Insurance component has more than maximum USPs",
               extraOptionsPage.insuranceComponent.isMaxInsuranceUspCount(count), is(true));
   }

   @Then("a Show Less link should display")
   public void a_Show_Less_link_should_display()
   {
      assertThat("Show less link is not displayed",
               extraOptionsPage.insuranceComponent.hasShowLessLink(), is(true));
   }

   @Given("they selected show more on the more Advantages and Information")
   public void they_selected_show_more_on_the_more_Advantages_and_Information()
   {
      extraOptionsPage.insuranceComponent.selectShowMore();
   }

   @Then("the component should contract to display {int} USP")
   public void the_component_should_contract_to_display_USP(Integer count)
   {
      assertThat("Mobile Insurance component is displaying more than default count",
               extraOptionsPage.insuranceComponent.isDefaultMobileInsuranceUspCount(count),
               is(true));
   }

   @Then("a Show More link should display")
   public void a_Show_More_link_should_display()
   {
      assertThat("Show more link is not displayed",
               extraOptionsPage.insuranceComponent.hasShowMoreLink(), is(true));
   }

   @Then("they should see following link in the product description:")
   public void they_should_see_following_link_in_the_product_description(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("More Information link is not displayed",
               extraOptionsPage.insuranceComponent.isShowMoreLinkDisplayed(), is(true));
   }

   @When("they select the More Advantages and Information link")
   public void they_select_the_More_Advantages_and_Information_link()
   {
      extraOptionsPage.insuranceComponent.selectMoreInformationLink();
   }

   @Then("they shall see a {string} containing the full information regarding the relevant insurance product")
   public void they_shall_see_a_containing_the_full_information_regarding_the_relevant_insurance_product(
            String modal)
   {
      assertThat("Insurance popup is not displayed",
               extraOptionsPage.insuranceComponent.isInsurancePopupDisplayed(), is(true));
   }

   @Given("they have opened More Advantages and Information")
   public void they_have_opened_More_Advantages_and_Information()
   {
      extraOptionsPage.insuranceComponent.selectMoreInformationLink();
   }

   @When("they select the close cross")
   public void they_select_the_close_cross()
   {
      extraOptionsPage.insuranceComponent.selectInsurancePopupCloseButton();
   }

   @When("they select outside the modal")
   public void they_select_outside_the_modal()
   {
      extraOptionsPage.insuranceComponent.selectAlternateInsuranceOption();
   }

   @Then("the popup modal should close")
   public void the_popup_modal_should_close()
   {
      assertThat("Insurance popup is not closed",
               extraOptionsPage.insuranceComponent.isInsurancePopupDisplayed(), is(false));
   }

   @When("they navigate to the insurance component")
   public void they_navigate_to_the_insurance_component()
   {
      extraOptionsPage.insuranceComponent.navigateToInsuranceComponent();
   }

   @Then("the age format should be displayed as follows")
   public void the_age_format_should_be_displayed_as_follows()
   {
      // extraOptionsPage.insuranceComponent.enterInValidRangeLeadPaxDOB();
   }

   @When("the enter a date outside the range of the age given by the customer")
   public void the_enter_a_date_outside_the_range_of_the_age_given_by_the_customer()
   {
      extraOptionsPage.wait.forJSExecutionReadyLazy();
      extraOptionsPage.insuranceComponent.enterLeadPaxDOB("12", "12", "2012");
   }

   @Then("the following error message should display")
   public void the_following_error_message_should_display(io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      extraOptionsPage.wait.forJSExecutionReadyLazy();
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      assertThat("Date range error message is not displayed",
               extraOptionsPage.insuranceComponent.isErrorMessageDisplayed(), is(true));
      try
      {
         actual = extraOptionsPage.insuranceComponent.getDobErromessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Date of birth error message not same", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @When("they hover over the Lead Passenger tool tip")
   public void they_hover_over_the_Lead_Passenger_tool_tip()
   {
      assertThat("Lead pax tooltip is not present",
               extraOptionsPage.insuranceComponent.isToolTipPresent(), is(true));
   }

   @Then("they should see the following content:")
   public void they_should_see_the_following_content(String text)
   {
      assertThat("Tool tip Text is not correcct ",
               extraOptionsPage.insuranceComponent.getLeadPaxToolTipText().equalsIgnoreCase(text),
               is(true));
   }

}
