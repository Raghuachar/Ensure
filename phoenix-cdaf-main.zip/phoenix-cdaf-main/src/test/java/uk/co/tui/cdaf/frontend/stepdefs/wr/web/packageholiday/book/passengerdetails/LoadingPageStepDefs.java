package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.passengerdetails;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.LoadingPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class LoadingPageStepDefs
{
   public final PackageNavigation packageNavigation;

   public final SummaryPage summaryPage;

   private final WebElementWait wait;

   private final PageErrorHandler errorHandler;

   private final LoadingPage loadingPage;

   public LoadingPageStepDefs()
   {
      loadingPage = new LoadingPage();
      packageNavigation = new PackageNavigation();
      wait = new WebElementWait();
      summaryPage = new SummaryPage();
      errorHandler = new PageErrorHandler();
   }

   @Given("I am a WR customer")
   public void i_am_a_WR_customer()
   {
      packageNavigation.navigateTosummaryPage();
   }

   @When("I have navigated to passenger details page")
   public void i_have_navigated_to_passenger_details_page()
   {
      wait.forJSExecutionReadyLazy();
      summaryPage.navigationComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   @When("I have completed the details")
   public void i_have_completed_the_details()
   {
      wait.forJSExecutionReadyLazy();
      loadingPage.fillThePassengerDetails();
   }

   @When("I press continue")
   public void i_press_continue()
   {
      loadingPage.clickOnPassengerContinueButton();
   }

   @Then("a loading image will display immediately")
   public void a_loading_image_will_display_immediately()
   {
      assertThat("Loading Page is Not Displayed", loadingPage.isLoadingPageDisplayed(), is(false));
   }

   @When("I have pressed continue")
   public void i_have_pressed_continue()
   {
      wait.forJSExecutionReadyLazy();
      summaryPage.navigationComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
      wait.forJSExecutionReadyLazy();
      loadingPage.fillThePassengerDetails();
      loadingPage.clickOnPassengerContinueButton();
   }

   @When("the loading image has displayed")
   public void the_loading_image_has_displayed()
   {
      assertThat("Loading Page is Not Displayed", loadingPage.isLoadingPageDisplayed(), is(false));
   }

   @When("the payment options page has loaded")
   public void the_payment_options_page_has_loaded()
   {
      assertThat("Payment Page is Not Displayed", loadingPage.isPaymentPageLoaded(), is(false));
   }

   @Then("the loading image will disappear immediately")
   public void the_loading_image_will_disappear_immediately()
   {
      assertThat("Loading Page is Displayed", loadingPage.isLoadingPageDisplayed(), is(false));
   }
}
