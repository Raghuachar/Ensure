package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.browse.homepage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.CommonPagesImplementation;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.browse.homepage.HomePageCommon;
import uk.co.tui.cdaf.utils.ConfigurationConstants;
import uk.co.tui.cdaf.utils.ConfigurationService;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.transformer.WesternRegionComponents;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageHeaderStepDefs
{

   private final HomePage homepage;

   private final HomePageCommon homepageShared;

   private final CommonPagesImplementation wrCommonPage;

   private String translationCode;

   private String headerLabel;

   public PackageHeaderStepDefs()
   {
      wrCommonPage = new uk.co.tui.cdaf.frontend.pom.wr.web.shared.CommonPagesImplementation();
      homepage = new HomePage();
      homepageShared = new HomePageCommon();
   }

   @Given("a {string} is on the TUI homepage")
   public void a_is_on_the_TUI_homepage(String string)
   {
      wrCommonPage.launchWRHomepage();
   }

   @When("they view the TUI WR Global Header")
   public void they_view_the_TUI_WR_Global_Header()
   {
      homepage.viewHeader();
      homepage.setHeaderLabelMap();
      homepage.setHeaderCompMap();
   }

   @When("they have selected {string} language on {string} website")
   public void they_have_selected_language_on_website(String language, String country)
   {

      translationCode = wrCommonPage.getTranslationCode(language, country);
   }

   @Then("the following options will be displayed in this order in TUI WR Global Header:")
   public void the_following_options_will_be_displayed_in_this_order_in_TUI_WR_Global_Header(
            DataTable dataTable)
   {
      List<WesternRegionComponents> headerComp = dataTable.asList(WesternRegionComponents.class);
      headerComp.forEach(row -> assertThat(
               row.getComponent() + " Label is not displayed/not in order \n Expected: "
                        + row.getTranslationValueFromMap(translationCode) + "\n Actual: "
                        + homepage.getHeaderLabel(row.getComponent()),
               homepage.checkHeaderLabel(homepage.getHeaderLabel(row.getComponent()),
                        row.getTranslationValueFromMap(translationCode)),
               is(true)));
   }

   @Then("they will see the following secondary options in this order in TUI WR Global Header:")
   public void they_will_see_the_following_secondary_options_in_this_order_in_TUI_WR_Global_Header(
            DataTable dataTable)
   {
      List<WesternRegionComponents> headerComp = dataTable.asList(WesternRegionComponents.class);
      headerComp.forEach(row -> assertThat(
               row.getComponent() + " Label is not displayed/not in order \n Expected: "
                        + row.getTranslationValueFromMap(translationCode) + "\n Actual: "
                        + homepage.getHeaderLabel(row.getComponent()),
               homepage.checkHeaderLabel(homepage.getHeaderLabel(row.getComponent()),
                        row.getTranslationValueFromMap(translationCode)),
               is(true)));
   }

   @When("they view the TUI WR Burger Menu")
   public void they_view_the_TUI_WR_Burger_Menu()
   {
      homepage.clickBurgerMenu();
      homepage.setHeaderLabelMap();
      homepage.setHeaderCompMap();

   }

   @Then("they will see the following options in this order in TUIWR Burger Menu:")
   public void they_will_see_the_following_options_in_this_order_in_TUIWR_Burger_Menu(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<WesternRegionComponents> headerComp = dataTable.asList(WesternRegionComponents.class);

      headerComp.forEach(row -> assertThat(
               row.getComponent() + " Label is not displayed/not in order \n Expected: "
                        + row.getTranslationValue(translationCode) + "\n Actual: "
                        + homepage.getHeaderLabel(row.getComponent()),
               homepage.checkHeaderLabel(homepage.getHeaderLabel(row.getComponent()),
                        row.getTranslationValue(translationCode)),
               is(true)));
   }

   @Then("I will see the following Icons in header as per prod:")
   public void i_will_see_the_following_Icons_as_per_prod(List<String> icons)
   {
      icons.forEach(component ->
      {
         try
         {
            assertThat(component + " componenet is not displayed",
                     WebElementTools.isPresent(homepage.getHeaderPageMap().get(component)),
                     is(true));
         }
         catch (Exception e)
         {
            assertThat(component + " componenet is not displayed", is(false), is(true));
         }

      });
   }

   @Then("they will see a logo for TUI in TUI WR Global Header \\(as per prod)")
   public void they_will_see_a_logo_for_TUI_in_TUI_WR_Global_Header_as_per_prod()
   {
      assertThat(" TUI Logo is not displayed", homepage.checkTUILogo(), is(true));
   }

   @Given("a {string} is viewing the header")
   public void a_is_viewing_the_header(String string)
   {
      homepageShared.viewHeader();
   }

   @When("they click the language selector in the header")
   public void they_click_the_language_selector_in_the_header()
   {
      homepageShared.clickCountryChangeLink();
   }

   @Then("the language selector will open in a modal \\(design attached)")
   public void the_language_selector_will_open_in_a_modal_design_attached()
   {
      assertThat("Language selector is not displayed", WebElementTools.isPresent(
               homepageShared.getHeaderComponent().getClOverlayComp().getOverlayLabel()), is(true));
   }

   @Given("a {string} has opened the language selector")
   public void a_has_opened_the_language_selector(String string)
   {
      WebDriverUtils.getDriver().manage().deleteAllCookies();
      homepageShared.visit();
      homepageShared.clickCountryChangeLink();
   }

   @When("they view the language selector modal")
   public void they_view_the_language_selector_modal()
   {
      homepageShared.viewLanguageSelector();
   }

   @Then("they should see the following in language selector modal:")
   public void they_should_see_the_following_in_language_selector_modal(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Text componenet is not displayed",
               WebElementTools.isPresent(
                        homepageShared.getHeaderComponent().getCountryLangSelectorComp()
                                 .getOverlayLabel()),
               is(true));
      assertThat("Language Dropdown label componenet is not displayed",
               WebElementTools.isPresent(
                        homepageShared.getHeaderComponent().getCountryLangSelectorComp()
                                 .getLanguageLabelInModal()),
               is(true));
      assertThat("Language dropdown componenet is not displayed",
               WebElementTools.isPresent(
                        homepageShared.getHeaderComponent().getCountryLangSelectorComp()
                                 .getSelectedlanguage()),
               is(true));
      assertThat("Change Language Button",
               WebElementTools.isPresent(
                        homepageShared.getHeaderComponent().getCountryLangSelectorComp()
                                 .getChangeSiteButton()),
               is(true));
   }

   @When("they view the language list dropdown in language dropdown")
   public void they_view_the_language_list_dropdown_in_language_dropdown()
   {
      homepageShared.getHeaderComponent().getCountryLangSelectorComp().getSelectedlanguageOnly();
   }

   @Then("the following options should be displayed in this order in language dropdown:")
   public void the_following_options_should_be_displayed_in_this_order_in_language_dropdown(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Languages in dropdowns is not as per requirement",
               homepageShared.validateLanguagesInDropdownForPackage(), is(true));
   }

   @When("they select a language in language dropdown list")
   public void they_select_a_language_in_language_dropdown_list()
   {
      homepageShared.clickLanguageInDropdown();
   }

   @When("they have selected {string} language")
   public void they_have_selected_language(String lang)
   {
      homepageShared.setHeaderLabelMap();
      headerLabel = homepageShared.getHeaderLabelMap().get("holidays");
      translationCode = wrCommonPage.getTranslationCode(lang, "");

      if (ConfigurationService.getProperty(ConfigurationConstants.SELENIUM_BROWSER)
               .contains("mobile"))
      {
         homepageShared.clickBurgerMenu();
         homepageShared.selectLanguage(lang);
         homepageShared.clickBurgerMenu();
      }
      else
      {
         homepageShared.selectLanguage(lang);
      }
   }

   @When("they click the {string} button in the language selector")
   public void they_click_the_button_in_the_language_selector(String string)
   {
      homepageShared.clickChangeSiteButton();
   }

   @Then("the site content and language will update according to their selection")
   public void the_site_content_and_language_will_update_according_to_their_selection()
   {
      homepageShared.setHeaderLabelMap();
      homepageShared.getHeaderComponent().getHeaderComp().isDisplayed();
      assertThat("Expected:" + headerLabel + " Actual: " + homepageShared.getHeaderLabelMap()
                        .get("holidays") + "Site Content is not updated after changing language",
               headerLabel.equals(homepageShared.getHeaderLabelMap().get("holidays")), is(false));
   }

}
