package uk.co.tui.cdaf.frontend.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public abstract class DOMElement
{
   private static final AutomationLogManager LOGGER = new AutomationLogManager(DOMElement.class);

   static WebElementWait wait;

   DOMElementHelper domHelper;

   public DOMElement()
   {
      domHelper = new DOMElementHelper();
      wait = new WebElementWait();
   }

   /*
    * Get the element returned from ARIA-LABEL or CLASSNAME OR ANCHOR tag OR
    * PLACEHOLDER
    * return boolean
    */
   public static boolean isElementExist(Enum<ByType> byType, String elementName)
   {
      return byType.equals(ByType.ARIA_LABEL) ?
               DOMElementHelper.isElementExistByAriaLabel(elementName)
               : byType.equals(ByType.CLASS_NAME) ?
               DOMElementHelper.isElementExistByClass(elementName)
               : byType.equals(ByType.ANCHOR_TAG) ? DOMElementHelper.getElementByAnchor(elementName)
               : byType.equals(ByType.PLACEHOLDER) && DOMElementHelper.getElementByPlaceholder(
               elementName);
   }

   /*
    * Get the first element returned from the aria-label
    * return WebElement
    */
   public static WebElement getElementByAriaLabel(String ariaLabel)
   {
      return DOMElementHelper.getElementsByAriaLabel(ariaLabel).get(0);
   }

   /*
    * Get the element returned from the text() with <span> tag
    * return List<WebElement>
    */
   public static List<WebElement> matchTextSpanTag(String text)
   {
      List<WebElement> element =
               getDriver().findElements(By.xpath("//*[contains(text() , '" + text + "')]"));
      if (!element.isEmpty())
      {
         LOGGER.log(LogLevel.INFO, text + " : text WebElement is present");
         return element;
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "Element with text: " + text + " is not present.");
         return null;
      }
   }

   /*
    * Get the element returned by h1 OR h2 OR Span tag
    * return boolean
    */
   public static boolean isPagePresent(String item)
   {
      if (WebDriverUtils.getDriver().getTitle().contains(item))
      {
         return true;
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "Inspecting the page headers.");
         String xpath =
                  "(//span[contains(text() , '" + item + "' )])[1] | (//h1[contains(text() , '" + item
                           + "')])[1] | //*[contains(@class,'region-title')]  | (//h2[contains(text() , '" + item
                           + "')])[1] | (//h3[contains(text() , '" + item + "')])[1]";
         WebElement element = WebDriverUtils.getDriver().findElement(By.xpath(xpath));
         return element != null && element.isDisplayed();
      }
   }

   /*
    * Get the element returned by h1 OR h2 OR Span tag
    * return boolean
    */
   public static boolean isElementPresent(List<WebElement> webElement)
   {
      return !webElement.isEmpty();
   }

   public enum ByType
   {
      CLASS_NAME, ARIA_LABEL, ANCHOR_TAG, PLACEHOLDER
   }
}
