package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOSeodbCardTypesStepDefs
{

   public final WebElementWait wait;

   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents;

   public FOSeodbCardTypesStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      wait = new WebElementWait();
      foReconcilationPaymentPageComponents = new FOReconcilationPaymentPageComponents();
   }

   @Given("that a shop has taken card payments against bookings")
   public void that_a_shop_has_taken_card_payments_against_bookings()
   {
      retailflightNavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      foReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      wait.forJSExecutionReadyLazy();
   }

   @When("the agent view the Banking & Reconciliation table")
   public void the_agent_view_the_Banking_Reconciliation_table()
   {
      wait.forJSExecutionReadyLazy();
      assertThat(" Global Header is not present",
               foReconcilationPaymentPageComponents.isReconcilationTablePresent(), is(true));

   }

   @When("they can see any card payments that have been made")
   public void they_can_see_any_card_payments_that_have_been_made()
   {
      wait.forJSExecutionReadyLazy();
      foReconcilationPaymentPageComponents.navigateToCardChevron();
   }

   @Then("these will be displayed as individual rows with accordions for each card type")
   public void these_will_be_displayed_as_individual_rows_with_accordions_for_each_card_type(
            io.cucumber.datatable.DataTable dataTable)
   {
      wait.forJSExecutionReadyLazy();
      assertThat(" CardTypes is not present",
               foReconcilationPaymentPageComponents.isCardTypesPresent(), is(true));

   }

   @Given("that Cards have been used to make a payment against a booking")
   public void that_Cards_have_been_used_to_make_a_payment_against_a_booking()
   {
      retailflightNavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      foReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();

   }

   @When("the agent views the Banking & Reconciliation page")
   public void the_agent_views_the_Banking_Reconciliation_page()
   {
      wait.forJSExecutionReadyLazy();

   }

   @When("clicks on the chevron within the {string} payment type accordion")
   public void clicks_on_the_chevron_within_the_payment_type_accordion(String string)
   {

      wait.forJSExecutionReadyLazy();
      foReconcilationPaymentPageComponents.navigateToCardChevron();

   }

   @Then("the table will expand and show all card types that have made payments on that day")
   public void the_table_will_expand_and_show_all_card_types_that_have_made_payments_on_that_day()
   {
      wait.forJSExecutionReadyLazy();
      assertThat(" CardTypes is not present",
               foReconcilationPaymentPageComponents.isCardTypesPresent(), is(true));

   }

   @Then("they will be displayed as individual rows below the cards accordion")
   public void they_will_be_displayed_as_individual_rows_below_the_cards_accordion(
            io.cucumber.datatable.DataTable dataTable)
   {
      wait.forJSExecutionReadyLazy();

      assertThat(" CardName is not present",
               foReconcilationPaymentPageComponents.isCardNamePresent(), is(true));
      assertThat(" PaymentTotalAmount is not present",
               foReconcilationPaymentPageComponents.isPaymentTotalAmountPresent(), is(true));
      assertThat(" TextBox is not present", foReconcilationPaymentPageComponents.isTextBoxPresent(),
               is(true));
      assertThat(" DiscrepancyAmount is not present",
               foReconcilationPaymentPageComponents.isDiscrepancyAmountPresent(), is(true));

      wait.forJSExecutionReadyLazy();

   }

   @Given("that a shop has not taken a payment using a specific card type")
   public void that_a_shop_has_not_taken_a_payment_using_a_specific_card_type()
   {
      retailflightNavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      foReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();

   }

   @When("they view the Banking & Reconciliation table")
   public void they_view_the_Banking_Reconciliation_table()
   {
      wait.forJSExecutionReadyLazy();

   }

   @Then("they cannot see that card type displayed in the table")
   public void they_cannot_see_that_card_type_displayed_in_the_table()
   {
      assertThat(" CardTypes is not present",
               foReconcilationPaymentPageComponents.isCardTypesPresent(), is(false));
   }

   @Then("the Banking & Reconciliation page will open for FO")
   public void the_Banking_and_Reconciliation_page_will_open_for_FO()
   {
      foReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

}
