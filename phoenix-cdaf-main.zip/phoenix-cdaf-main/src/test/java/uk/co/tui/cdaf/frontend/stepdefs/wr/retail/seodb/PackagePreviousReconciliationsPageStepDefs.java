package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePreviousReconciliationsPageStepDefs
{

   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackagePreviousReconciliationsPageStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent viewing the banking and reconciliations page")
   public void that_the_agent_viewing_the_banking_and_reconciliations_page()
   {
      packagenavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

   @When("they view the page sub header")
   public void they_view_the_page_sub_header()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("Page sub header is present",
               pKgReconcilationPaymentPageComponents.isPageHeaderAndLinksPresent(), is(true));
   }

   @Then("they can see a link to previous reconciliation")
   public void they_can_see_a_link_to_previous_reconciliation()
   {
      assertThat("Previous Reconciliation Link is Present",
               pKgReconcilationPaymentPageComponents.isPreviousReconciliationLinkPresent(),
               is(true));
   }
}
