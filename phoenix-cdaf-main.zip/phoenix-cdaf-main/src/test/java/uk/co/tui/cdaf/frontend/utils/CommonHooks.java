package uk.co.tui.cdaf.frontend.utils;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.logevents.SelenideLogger;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.junit.Assert;
import org.junit.Assume;
import org.openqa.selenium.OutputType;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.utils.BrowserConfig;

import static com.codeborne.selenide.Selenide.open;

public class CommonHooks
{
   public static ThreadLocal<Scenario> scenario = new ThreadLocal<>();

   private static boolean skipTest = false;

   @Before("@manual")
   public static void skipManual()
   {
      forceSkip();
   }

   @Before("@no_run")
   public static void skipNoRun()
   {
      forceSkip();
   }

   @Before("@ignorenl")
   public static void skipIfNlMarket()
   {
      boolean isNl = ExecParams.getTestExecutionParams().isNL();
      skipTest = isNl;
      Assume.assumeFalse("Skipping NL market", isNl);
   }

   @Before("@ignore3rdparty")
   public static void skipIf3rdParty()
   {
      boolean isThirdParty = ExecParams.getTestExecutionParams().getAgent().isThirdparty();
      skipTest = isThirdParty;
      Assume.assumeFalse("Skipping 3rd Party Agent", isThirdParty);
   }

   @Before("@ignoreInhouse")
   public static void skipInhouseAgent()
   {
      boolean isInHouse = ExecParams.getTestExecutionParams().getAgent().isInhouse();
      skipTest = isInHouse;
      Assume.assumeFalse("Skipping Inhouse Agent", isInHouse);
   }

   @Before(order = 20000)
   public static void readUrlTag(Scenario scenario)
   {
      if (skipTest)
      {
         // Skip browser config and run due to other @Before logic
         return;
      }
      ExecParams.nullifyTestExecutionParams();
      CommonHooks.scenario.set(scenario);
      if (scenario.getName().isEmpty())
      {
         Assert.fail("A name must be provided for a scenario");
      }
      BrowserConfig.initChromeConfig();
      open(ExecParams.getTestExecutionParams().getUrl());
      BrowserCookies.closePrivacyPopUp();
   }

   @After()
   public static void globalTearDown(Scenario scenario)
   {
      skipTest = false;
      if (scenario.isFailed())
      {
         scenario.attach(Selenide.screenshot(OutputType.BYTES), "image/png", "failure screenshot");
         SelenideLogger.removeListener("SelenideLogEventListener");
         log(AutomationLogManager.getEvents(), "log entry");
         AutomationLogManager.resetEvents(scenario);
      }
      SelenideLogger.removeListener("SelenideLogEventListener");
      log(AutomationLogManager.getEvents(), "log entry");
      AutomationLogManager.resetEvents(scenario);
      Selenide.clearBrowserCookies();
      Selenide.closeWebDriver();
   }

   @SuppressWarnings("ConstantConditions") // This is intentional to skip the test
   private static void forceSkip()
   {
      skipTest = true;
      Assume.assumeTrue("Test marked as to be skipped", false);
   }

   public static void log(String message, String messageTitle)
   {
      if (scenario.get() != null && !message.isEmpty())
      {
         scenario.get().attach(message, "text/plain", messageTitle);
      }
   }
}
