package uk.co.tui.cdaf.frontend.utils.testDataObjects;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.BookingTypes;

import java.io.File;

public class TripsBookingDataHelper
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(TripsBookingDataHelper.class);

   private static volatile BookingTypes instance;

   private TripsBookingDataHelper()
   {
   }

   @SneakyThrows
   public static BookingTypes getInstance()
   {
      if (instance == null)
      {
         String fileName = "src/test/resources/json/booking_data/trips.json";
         ObjectMapper objectMapper = new ObjectMapper();
         instance = objectMapper.readValue(new File(fileName), BookingTypes.class);
      }
      return instance;
   }
}
