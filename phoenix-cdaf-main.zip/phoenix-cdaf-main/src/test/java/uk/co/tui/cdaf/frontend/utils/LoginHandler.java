package uk.co.tui.cdaf.frontend.utils;

import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.AuthenticationAttributes;

import java.net.URL;
import java.util.NoSuchElementException;
import java.util.stream.Stream;

import static com.codeborne.selenide.Selenide.*;
import static uk.co.tui.cdaf.frontend.utils.logger.LogLevel.DEBUG;

public class LoginHandler
{
   private static final AutomationLogManager
            LOGGER = new AutomationLogManager(LoginHandler.class);

   public static void agentLogin(URL loginUrl, TestExecutionParams params)
   {
      open(loginUrl);
      BrowserCookies.closePrivacyPopUp();

      if (!$("span.RetailHeader__agencyDisplayFormat").isDisplayed())
      {
         enterCredentials(params);
         clickLoginBtn();
      }
      else
      {
         LOGGER.log(DEBUG, "User already logged in");
      }
   }

   private static void enterCredentials(TestExecutionParams params)
   {
      AuthenticationAttributes auth = AuthenticationAttributes.getCredentials(params);
      String referenceStr = auth.getReference();
      enterUsername(auth.getUsername());
      enterPassword(auth.getPassword());
      if (referenceStr != null)
      {
         enterReference(referenceStr);
      }
   }

   private static void enterUsername(String id)
   {
      Stream.of(
                        $x(".//*[@name='agentNumber']"),
                        $x(".//*[@name='userName']"),
                        $("[name*='user']"),
                        $("#userNameInput"))
               .filter(SelenideElement::exists).findFirst()
               .orElseThrow(() -> new NoSuchElementException("Username field was not found"))
               .sendKeys(id);
   }

   private static void enterPassword(String pass)
   {
      Stream.of(
                        $x(".//*[@name='agentPassword'] | .//*[@name='userPassword']"),
                        $("[name*='pass']"),
                        $("#passwordInput"))
               .filter(SelenideElement::exists).findFirst()
               .orElseThrow(() -> new NoSuchElementException("User Password field was not found"))
               .sendKeys(pass);
   }

   private static void clickLoginBtn()
   {
      Stream.of(
                        $x(".//*[@name='submit-button']"),
                        $(".ThirdPartyLogin__loginButton"),
                        $("#submitButton"))
               .filter(SelenideElement::exists).findFirst()
               .orElseThrow(() -> new NoSuchElementException("Login button was not found"))
               .click();
   }

   private static void enterReference(String ref)
   {
      $("input#agentref").setValue(ref);
   }
}
