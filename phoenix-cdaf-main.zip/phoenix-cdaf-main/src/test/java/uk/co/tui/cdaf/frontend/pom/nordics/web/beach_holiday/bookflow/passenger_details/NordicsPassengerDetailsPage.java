package uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details;

import com.codeborne.selenide.Condition;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.codeborne.selenide.Selenide.$;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class NordicsPassengerDetailsPage extends AbstractPage
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(NordicsPassengerDetailsPage.class);

   private static final String SITE_ID_REGEX = "SiteID\\s*=\\s*\"(.+?)\";";

   private static final String DEPARTURE_DATE_REGEX =
            "departureDateInMiliSeconds\"\\s*:\\s*\"(.+?)\"";

   private static final String ARRIVAL_DATE_REGEX = "\"arrivalDate\":\"(.+?)\"^^2";

   private final PageErrorHandler pageError;

   private final WebElementWait wait;

   private final WebDriverUtils utils;

   private final NordicPassengerForm passengerForm;

   @FindAll({ @FindBy(css = "[data-dojo-type*='itleSelect'] [id*=title]"),
            @FindBy(css = "[aria-label='gender'] select"),
            @FindBy(css = "[aria-label='Title'] select"),
            @FindBy(css = "[aria-label='Gender'] select"),
            @FindBy(css = "[aria-label='Geslacht'] select") })
   private List<WebElement> titleDropDown;

   @FindBy(xpath = "//input[contains(@name,'firstName')]")
   private List<WebElement> firstName;

   @FindAll({ @FindBy(xpath = "//input[contains(@name,'lastName')]"),
            @FindBy(xpath = "//input[contains(@name,'surName')]") })
   private List<WebElement> lastName;

   @FindAll({ @FindBy(css = "[name='address1']"), @FindBy(css = "[name*='address1']"),
            @FindBy(xpath = "//input[@name='address1']") })
   private WebElement addressLine1;

   @FindAll({ @FindBy(css = "[name='address2']"), @FindBy(css = "[name*='address2']") })
   private WebElement bus;

   @FindAll({ @FindBy(css = "[name='town']"), @FindBy(css = "[name*='town']") })
   private WebElement city;

   @FindBy(css = "[name='houseNum']")
   private WebElement houseNum;

   @FindAll({ @FindBy(css = "[name='postCode']"), @FindBy(css = "[name*='postCode']") })
   private WebElement postcode;

   @FindAll({ @FindBy(css = "[aria-label='telephone number']"),
            @FindBy(css = "[name*='mobileNum']") })
   private List<WebElement> telephone;

   @FindAll({ @FindBy(css = "[name='email']"), @FindBy(css = "[name*='email']") })
   private WebElement email;

   @FindBy(css = ".PassengerForm__dropDown select")
   private WebElement country;

   @FindBy(css = ".PassengerForm__dropDown select option")
   private List<WebElement> countryOption;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'ADULT')]//*[@placeholder='YYYY']"),
            @FindBy(css = ".ADULT [placeholder='YYYY']"),
            @FindBy(css = "[aria-label*='Adult'] [placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'VOLWASSENE')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'ADULT')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']"),
            @FindBy(css = "[aria-label*='Geboortedatum'] [placeholder='JJJJ']"),
            @FindBy(css = "[aria-label*='Geboortedatum (DD/MM/JJJJ)'] [placeholder='JJJJ']") })
   private List<WebElement> adultDOBYear;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'ADULT')]//*[@placeholder='MM']"),
            @FindBy(css = ".ADULT [placeholder='MM']"),
            @FindBy(css = "[aria-label*='Adult'] [placeholder='MM']"),
            @FindBy(css = " [aria-label*='Geboortedatum'] [placeholder='MM']"),
            @FindBy(xpath = "//h3[contains(text(),'VOLWASSENE')]/../../../../following-sibling::div[1]//*[@placeholder='MM']"),
            @FindBy(xpath = "//h3[contains(text(),'ADULT')]/../../../../following-sibling::div[1]//*[@placeholder='MM']") })
   private List<WebElement> adultDOBMonth;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'ADULT')]//*[@placeholder='DD']"),
            @FindBy(css = ".ADULT [placeholder='DD']"),
            @FindBy(css = "[aria-label*='Adult'] [placeholder='DD']"),
            @FindBy(css = "[aria-label*='Geboortedatum'] [placeholder='DD']"),
            @FindBy(xpath = "//h3[contains(text(),'VOLWASSENE')]/../../../../following-sibling::div[1]//*[@placeholder='DD']"),
            @FindBy(xpath = "//h3[contains(text(),'ADULT')]/../../../../following-sibling::div[1]//*[@placeholder='DD']") })
   private List<WebElement> adultDOBDate;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'CHILD')]//*[@placeholder='YYYY']"),
            @FindBy(css = ".CHILD [placeholder='YYYY']"),
            @FindBy(css = "[aria-label*='Child'] [placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'KIND') or contains(text(),'KIND')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'CHILD') or contains(text(),'Child')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']") })
   private List<WebElement> childDOBYear;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'INFANT')]//*[@placeholder='YYYY']"),
            @FindBy(css = "[aria-label*='INFANT'] [placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'INFANT')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']") })
   private List<WebElement> infantDOBYear;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'CHILD')]//*[@placeholder='MM']"),
            @FindBy(css = ".CHILD [placeholder='MM']"),
            @FindBy(css = "[aria-label*='Child'] [placeholder='MM']"),
            @FindBy(xpath = "//h3[contains(text(),'KIND') or contains(text(),'KIND')]/../../../../following-sibling::div[1]//*[@placeholder='MM']"),
            @FindBy(xpath = "//h3[contains(text(),'CHILD') or contains(text(),'Child')]/../../../../following-sibling::div[1]//*[@placeholder='MM']") })
   private List<WebElement> childDOBMonth;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'INFANT')]//*[@placeholder='MM']"),
            @FindBy(css = "[aria-label*='INFANT'] [placeholder='MM']"),
            @FindBy(xpath = "//h3[contains(text(),'INFANT')]/../../../../following-sibling::div[1]//*[@placeholder='MM']") })
   private List<WebElement> infantDOBMonth;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'CHILD')]//*[@placeholder='DD']"),
            @FindBy(css = ".CHILD [placeholder='DD']"),
            @FindBy(css = "[aria-label*='Child'] [placeholder='DD']"),
            @FindBy(xpath = "//h3[contains(text(),'KIND') or contains(text(),'KIND')]/../../../../following-sibling::div[1]//*[@placeholder='DD']"),
            @FindBy(xpath = "//h3[contains(text(),'CHILD') or contains(text(),'Child')]/../../../../following-sibling::div[1]//*[@placeholder='DD']") })
   private List<WebElement> childDOBDate;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'INFANT')]//*[@placeholder='DD']"),
            @FindBy(css = "[aria-label*='INFANT'] [placeholder='DD']"),
            @FindBy(xpath = "//h3[contains(text(),'INFANT')]/../../../../following-sibling::div[1]//*[@placeholder='DD']") })
   private List<WebElement> infantDOBDate;

   @FindAll({
            @FindBy(xpath = "//div[contains(@aria-label,'CHILD')]//*[@class='sections__title undefined']"),
            @FindBy(xpath = "//div[contains(@class,'pax-label')]//span[contains(text(),'CHILD')]"),
            @FindBy(css = ".GetQuote__age"),
            @FindBy(xpath = "//div[contains(@aria-label,'header bar')]//h3[contains(text(),'K')]"),
            @FindBy(xpath = "//div[contains(@aria-label,'header bar')]//h3[contains(text(),'C')]") })
   private List<WebElement> childAgesText;

   @FindAll({
            @FindBy(xpath = "//div[contains(@aria-label,'INFANT')]//*[@class='sections__title undefined']"),
            @FindBy(xpath = "//div[contains(@class,'pax-label')]//span[contains(text(),'INFANT')]"),
            @FindBy(css = "[aria-label*='INFANT'] h2 span:nth-child(2)"),
            @FindBy(css = ".GetQuote__age"),
            @FindBy(xpath = "//div[contains(@aria-label,'header bar')]//h3[contains(text(),'INFANT')]") })
   private List<WebElement> infantAgesText;

   @FindAll({ @FindBy(css = "[aria-label='important information'] [aria-label='checkbox']"),
            @FindBy(css = ".NordicsImportantInformation__content [aria-label='checkbox']") })
   private WebElement importantInfoCheckbox;

   @FindBy(css = ".InsuranceTermsAndconditions__contentIns [aria-label='checkbox']")
   private WebElement insuranceImportantInfoCheckbox;

   @FindBy(css = "[aria-label='DeparturerData']")
   private WebElement arrivalDate;

   @FindBy(css = "[class$='buttons__large']")
   private WebElement continueBooking;

   @FindBy(css = ".MarketingPermissions__infoText label[aria-label='checkbox']")
   private List<WebElement> communicationChannel;

   private NumberFormat f = new DecimalFormat("00");

   public NordicsPassengerDetailsPage()
   {
      pageError = new PageErrorHandler();
      wait = new WebElementWait();
      utils = new WebDriverUtils();
      passengerForm = new NordicPassengerForm();
      f = new DecimalFormat("00");
   }

   public NordicsPassengerDetailsPage(NordicPassengerForm passengerForm)
   {
      pageError = new PageErrorHandler();
      wait = new WebElementWait();
      utils = new WebDriverUtils();
      this.passengerForm = passengerForm;
   }

   public void setNordicsPaxDetails()
   {
      passengerForm.setfName(RandomStringUtils.random(8, true, false));
      passengerForm.setLastName(RandomStringUtils.random(8, true, false));
      passengerForm.setEmail(RandomStringUtils.random(8, true, false) + ".s@sonata-software.com");
      passengerForm.setAdress1(RandomStringUtils.random(4, true, false) + " street");
   }

   public void fillThePassengerInformationAndProceed()
   {
      pageError.isNordicPageLoadedCorrectly();
      setNordicsPaxDetails();
      selectPassengerTitle();
      enterAdultDOB();
      enterChildDOB();
      enterFirstName();
      enterLastName();
      selectCountry();
      enterAdressAndContact();
      selectCommunicationChannel();
      selectImportantInfoCheckbox();
      selectContinueBooking();
   }

   public void fillThePassengerDetailsForWr()
   {
      pageError.isNordicPageLoadedCorrectly();
      setNordicsPaxDetails();
      selectPassengerTitle();
      enterAdultDOB();
      enterChildDOB();
      enterFirstName();
      enterLastName();
      enterHouseNumber();
      enterAdressAndContactWR();
      wait.forJSExecutionReadyLazy();
      selectImportantInfoCheckbox();
      wait.forJSExecutionReadyLazy();
      selectContinueBookingWR();
   }

   public void selectCommunicationChannel()
   {
      int randomNum = new Random().nextInt(communicationChannel.size());
      WebElementTools.clickElementJavaScript(communicationChannel.get(randomNum));
   }

   public void selectImportantInfoCheckbox()
   {
      wait.forClickable(importantInfoCheckbox);
      WebElementTools.clickElementJavaScript(importantInfoCheckbox);
      if (WebElementTools.isPresent(insuranceImportantInfoCheckbox))
         WebElementTools.clickElementJavaScript(insuranceImportantInfoCheckbox);
   }

   public void selectContinueBooking()
   {
      WebDriverUtils.executeScript("arguments[0].scrollIntoView(true);", importantInfoCheckbox);
      WebElementTools.clickElementJavaScript(continueBooking);
   }

   public void selectContinueBookingWR()
   {
      $(continueBooking).should(Condition.appear).scrollTo().click();
   }

   public void selectPassengerTitle()
   {
      wait.forJSExecutionReadyLazy();
      try
      {
         titleDropDown.forEach(dropDown ->
         {
            WebElementTools.scrollToCenter(dropDown);
            WebElementTools.clickElementJavaScript(dropDown);
            wait.forJSExecutionReadyLazy();
            List<WebElement> dropDownOptions = dropDown.findElements(By.tagName("option"));
            Random rand = new Random();
            int index = rand.nextInt(dropDownOptions.size() - 1) + 1;
            WebElement dropDownElement = dropDownOptions.get(index);
            String dropDownText = WebElementTools.getElementText(dropDownElement);
            if (dropDownText.equals("Select") || dropDownText.equals("Dr")
                     || dropDownText.equals("Prof") || dropDownText.equals("Rev")
                     || dropDownText.equals("Not Required"))
            {
               WebElementTools.click(dropDownOptions.get(1));

            }
            else
            {
               WebElementTools.click(dropDownElement);
            }
         });
      }
      catch (Exception e)
      {
         LOGGER.log("Could not select passenger title value");
         LOGGER.log(LogLevel.ERROR, e.getMessage());
      }
   }

   public void enterFirstName()
   {
      firstName.forEach(name ->
      {
         name.clear();
         WebElementTools.enterText(name, passengerForm.fName);
      });
   }

   public void enterLastName()
   {
      lastName.forEach(name ->
      {
         name.clear();
         WebElementTools.enterText(name, passengerForm.lName);
      });
   }

   public void enterAdressAndContact()
   {
      WebElementTools.enterText(addressLine1, passengerForm.address1);
      WebElementTools.enterText(city, passengerForm.city);
      WebElementTools.enterText(postcode, getPostCode());
      WebElementTools.enterText(telephone.get(0), getTelephoneNum());
      WebElementTools.enterText(email, passengerForm.email);
   }

   public void enterAdressAndContactWR()
   {
      WebElementTools.enterText(addressLine1, passengerForm.address1);
      WebElementTools.enterText(city, passengerForm.city);
      WebElementTools.enterText(postcode, getPostCode());
      telephone.forEach(phone ->
      {
         $(phone).sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), Keys.BACK_SPACE,
                  getTelephoneNum());
      });
      WebElementTools.enterText(email, passengerForm.email);
   }

   public void enterHouseNumber()
   {
      WebElementTools.enterText(houseNum, passengerForm.houseNum);
   }

   public String getTelephoneNum()
   {
      String siteId = utils.findTagValue(getDriver().getPageSource(), SITE_ID_REGEX);
      if (StringUtils.containsIgnoreCase(siteId, "dk"))
      {
         return "10" + RandomStringUtils.random(6, false, true);
      }
      else if (StringUtils.containsIgnoreCase(siteId, "fi"))
      {
         return "012" + RandomStringUtils.random(6, false, true);
      }
      else if (StringUtils.containsIgnoreCase(siteId, "no"))
      {
         return "41" + RandomStringUtils.random(6, false, true);
      }
      else
      {
         return "0123" + RandomStringUtils.random(6, false, true);
      }
   }

   public String getPostCode()
   {
      TestExecutionParams execParams = ExecParams.getTestExecutionParams();
      if (execParams.isBE())
         return "1" + RandomStringUtils.random(3, false, true);
      else if (execParams.isNL())
         return "1" + RandomStringUtils.random(3, false, true) + "AB";
      else if (execParams.isFR())
         return "0" + RandomStringUtils.random(5, false, true);
      else
         return "1" + RandomStringUtils.random(3, false, true);
   }

   public void selectCountry()
   {
      try
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.clickElementJavaScript(country);
         final String siteId = utils.findTagValue(getDriver().getPageSource(), SITE_ID_REGEX);
         if (StringUtils.containsIgnoreCase(siteId, "se"))
         {
            WebElementTools.selectElementFromListBasedOnText(countryOption, "Sverige");
         }
         if (StringUtils.containsIgnoreCase(siteId, "no"))
         {
            WebElementTools.selectElementFromListBasedOnText(countryOption, "Norwegian");
         }
         if (StringUtils.containsIgnoreCase(siteId, "fi"))
         {
            WebElementTools.selectElementFromListBasedOnText(countryOption, "Finland");
         }
         if (StringUtils.containsIgnoreCase(siteId, "dk"))
         {
            WebElementTools.selectElementFromListBasedOnText(countryOption, "Danmark");
         }
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, "Error in while selecting the country:" + e);
      }
   }

   public void enterAdultDOB()
   {
      for (int i = 0; i < adultDOBYear.size(); i++)
      {
         wait.forJSExecutionReadyLazy();
         final String previousValue =
                  WebElementTools.getElementAttribute(adultDOBYear.get(i), "value");
         if (previousValue.isEmpty())
         {
            WebElementTools.enterText(adultDOBYear.get(i), "1980");
            WebElementTools.enterText(adultDOBMonth.get(i), "01");
            WebElementTools.enterText(adultDOBDate.get(i), "01");
            LOGGER.log("Adult DOB Value entered: " + "01/" + "01/" + "1980");
         }
      }
   }

   public void enterChildDOB()
   {
      int age = 0;
      Locale locale;
      String siteId = utils.findTagValue(getDriver().getPageSource(), SITE_ID_REGEX);
      locale = StringUtils.containsIgnoreCase(siteId, "dk") ? new Locale("dk", "DK")
               : StringUtils.containsIgnoreCase(siteId, "fi") ? new Locale("fi", "FI")
               : StringUtils.containsIgnoreCase(siteId, "no") ? new Locale("no", "NO")
               : StringUtils.containsIgnoreCase(siteId, "se") ? new Locale("se", "SE")
               : new Locale("en", "US");
      try
      {
         String departureDate =
                  utils.findTagValue(getDriver().getPageSource(), DEPARTURE_DATE_REGEX);
         departureDate = departureDate.replace(" ", "");
         for (int i = 0; i < childDOBYear.size(); i++)
         {
            wait.forJSExecutionReadyLazy();
            String ageText = WebElementTools.getElementText(childAgesText.get(i));
            LOGGER.log(LogLevel.INFO, "age text is" + ageText);
            Matcher matcher = Pattern.compile("\\([^\\d]*(\\d+)[^\\d]*\\)").matcher(ageText).find()
                     ? Pattern.compile("\\([^\\d]*(\\d+)[^\\d]*\\)").matcher(ageText)
                     : Pattern.compile("(\\d+)").matcher(ageText);
            while (matcher.find())
            {
               age = Integer.parseInt(matcher.group(1).trim());
            }
            Calendar calendar = getCalendar(locale, departureDate, age);
            int dd = calendar.get(Calendar.DATE);
            int month = calendar.get(Calendar.MONTH) + 1;
            int year = calendar.get(Calendar.YEAR) - 3;
            WebElementTools.enterText(childDOBYear.get(i), String.valueOf(year));
            WebElementTools.enterText(childDOBMonth.get(i), f.format(month));
            WebElementTools.enterText(childDOBDate.get(i), f.format(dd));
            LOGGER.log("Child DOB Value entered: " + dd + "/" + month + "/" + year);
         }
         enterInfantDOB();
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, "Error in entering Child DOB:" + e);
         LOGGER.log(LogLevel.ERROR, e.getMessage());
      }
   }

   private Calendar getCalendar(Locale locale, String departureDate, int age) throws ParseException
   {
      SimpleDateFormat formatter;
      Date arrivalDate;
      try
      {
         formatter = new SimpleDateFormat("MMMdd,yyyyhh:mm:ss", locale);
         arrivalDate = formatter.parse(departureDate);
      }
      catch (Exception e)
      {
         // to handle the old flow
         formatter = new SimpleDateFormat("ddMMMyyyy", locale);
         arrivalDate = formatter.parse(getArrivalDate());
      }
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(arrivalDate);
      calendar.add(Calendar.YEAR, -1 * age);
      calendar.add(Calendar.DATE, -1);
      return calendar;
   }

   public void enterInfantDOB()
   {
      int age = 0;
      Locale locale;
      String siteId = utils.findTagValue(getDriver().getPageSource(), SITE_ID_REGEX);
      locale = StringUtils.containsIgnoreCase(siteId, "dk") ? new Locale("dk", "DK")
               : StringUtils.containsIgnoreCase(siteId, "fi") ? new Locale("fi", "FI")
               : StringUtils.containsIgnoreCase(siteId, "no") ? new Locale("no", "NO")
               : StringUtils.containsIgnoreCase(siteId, "se") ? new Locale("se", "SE")
               : new Locale("en", "US");
      try
      {
         String departureDate =
                  utils.findTagValue(getDriver().getPageSource(), DEPARTURE_DATE_REGEX);
         departureDate = departureDate.replace(" ", "");
         for (int i = 0; i < infantDOBYear.size(); i++)
         {
            wait.forJSExecutionReadyLazy();
            String ageText = WebElementTools.getElementText(infantAgesText.get(i));
            Matcher matcher = Pattern.compile("\\([^\\d]*(\\d+)[^\\d]*\\)").matcher(ageText).find()
                     ? Pattern.compile("\\([^\\d]*(\\d+)[^\\d]*\\)").matcher(ageText)
                     : Pattern.compile("(\\d+)").matcher(ageText);
            while (matcher.find())
            {
               age = Integer.parseInt(matcher.group(1).trim());
            }
            SimpleDateFormat formatter;
            Date arrivalDate;
            try
            {
               formatter = new SimpleDateFormat("MMMdd,yyyyhh:mm:ss", locale);
               arrivalDate = formatter.parse(departureDate);
            }
            catch (Exception e)
            {
               // to handle the old flow
               formatter = new SimpleDateFormat("ddMMMyyyy", locale);
               arrivalDate = formatter.parse(getArrivalDate());
            }

            Calendar calendar = Calendar.getInstance();
            int month = calendar.get(Calendar.MONTH) + 1;
            int year = calendar.get(Calendar.YEAR);
            int dd = calendar.get(Calendar.DATE);
            calendar.setTime(arrivalDate);
            calendar.add(Calendar.YEAR, -1 * age);
            calendar.add(Calendar.DATE, -1);
            dd = age == 0 ? dd : calendar.get(Calendar.DATE);
            month = age != 0 ? calendar.get(Calendar.MONTH) + 1 : month;
            year = age == 0 ? year : calendar.get(Calendar.YEAR);
            WebElementTools.enterText(infantDOBYear.get(i), String.valueOf(year));
            WebElementTools.enterText(infantDOBMonth.get(i), f.format(month));
            WebElementTools.enterText(infantDOBDate.get(i), f.format(dd));
            LOGGER.log("INFANT DOB Value entered: " + dd + "/" + month + "/" + year);
         }
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, "Error in entering Infant DOB:" + e);
      }
   }

   public String getArrivalDate()
   {
      try
      {
         String arrDate =
                  WebElementTools.getElementText(arrivalDate).replace(" ", StringUtils.EMPTY);
         arrDate = StringUtils.isNotEmpty(arrDate) ? arrDate
                  :
                  WebDriverUtils.regexExtractor(ARRIVAL_DATE_REGEX, WebDriverUtils.getPageSource());
         return arrDate.substring(3).trim();
      }
      catch (ParseException e)
      {
         return StringUtils.EMPTY;
      }
   }

   public void setvalidationPaxDetailsForWr(int value)
   {
      pageError.isNordicPageLoadedCorrectly();
      passengerForm.setfName(RandomStringUtils.random(value, true, false));
      passengerForm.setLastName(RandomStringUtils.random(value, true, false));
      enterFirstName();
      enterLastName();
   }

   public void setValidationAddressForWr(int value)
   {
      wait.forJSExecutionReadyLazy();
      passengerForm.setAdress1(RandomStringUtils.random(value, true, false));
      enterAddressWR();
   }

   public void setValidationBusForWr(int value)
   {
      wait.forJSExecutionReadyLazy();
      passengerForm.setBus(RandomStringUtils.random(value, true, false));
      enterBusWR();
   }

   public void enterAddressWR()
   {

      WebElementTools.enterText(addressLine1, passengerForm.address1);

   }

   public void enterBusWR()
   {

      WebElementTools.enterText(bus, passengerForm.busNum);
   }

   public void verifyPassengerDetails()
   {
      wait.forJSExecutionReadyLazy();
      for (WebElement fname : firstName)
      {
         assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "First text data is not present", fname.getText(), true), fname.getText(),
                  is(true));
      }
      wait.forJSExecutionReadyLazy();
      for (WebElement lname : lastName)
      {
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "last name text data is not present", lname.getText(), true),
                  lname.getText(), is(true));
      }
      wait.forJSExecutionReadyLazy();
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "address line text data is not present", addressLine1.getText(), true),
               addressLine1.getText(), is(true));
      wait.forJSExecutionReadyLazy();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "City text data is not present", city.getText(), true), bus.getText(), is(true));
      wait.forJSExecutionReadyLazy();
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Postcode text data is not present", postcode.getText(), true),
               addressLine1.getText(), is(true));
      wait.forJSExecutionReadyLazy();
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Telephone text data is not present", telephone.get(0).getText(), true),
               telephone.get(0).getText(), is(true));
      wait.forJSExecutionReadyLazy();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Email text data is not present", email.getText(), true), bus.getText(), is(true));

      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Bus text data is not present", bus.getText(), true), bus.getText(), is(true));
      wait.forJSExecutionReadyLazy();
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "address line text data is not present",
                        WebElementTools.isPresent(insuranceImportantInfoCheckbox), true),
               bus.getText(), is(true));

   }

}
