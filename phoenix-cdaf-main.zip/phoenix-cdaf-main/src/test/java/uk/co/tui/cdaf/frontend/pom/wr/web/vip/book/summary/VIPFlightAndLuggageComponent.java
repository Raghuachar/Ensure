package uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;

public class VIPFlightAndLuggageComponent extends AbstractPage
{

   private final HashMap<String, WebElement> vipSummaryComponentsMap;

   @FindBy(css = "[aria-label='your flights']")
   private WebElement yourFlight;

   @FindBy(css = "[aria-label='luggage ancillary']")
   private WebElement luggage;

   public VIPFlightAndLuggageComponent()
   {
      WebElementWait wait = new WebElementWait();
      vipSummaryComponentsMap = new HashMap<>();
   }

   public HashMap<String, WebElement> getVipSummaryComponentsMap()
   {
      vipSummaryComponentsMap.put("Your Flight", yourFlight);
      vipSummaryComponentsMap.put("Luggage", luggage);
      return vipSummaryComponentsMap;
   }
}
