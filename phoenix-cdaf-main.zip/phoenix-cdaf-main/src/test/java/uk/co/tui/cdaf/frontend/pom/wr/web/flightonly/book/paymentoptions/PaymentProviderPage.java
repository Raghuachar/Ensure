package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.TestDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.PaymentAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class PaymentProviderPage extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PaymentTypeComponent.class);

   public final WebDriverUtils utils;

   private final WebElementWait wait;

   @FindAll({ @FindBy(css = "[name*='Card_Name']"), @FindBy(css = "[name*='ccname']") })
   private WebElement cardHolderInput;

   @FindAll({ @FindBy(xpath = "//label[contains(text(),'Card number')]/following-sibling::input"),
            @FindBy(css = "[class='cardNumber'] input"),
            @FindBy(css = "input[name*='Card_Number']") })
   private WebElement cardNumberInput;

   @FindAll({ @FindBy(xpath = "//label[contains(text(),'Security')]/following-sibling::div/input"),
            @FindBy(css = "[class='cvv'] input"), @FindBy(css = "[id*='Card_Verification']"),
            @FindBy(css = "[name*='cvc']") })
   private WebElement cvvInput;

   @FindAll({ @FindBy(css = "[id*='ExpDate_Month']"), @FindBy(css = "#expdatemonth") })
   private WebElement expriyMonth;

   @FindAll({ @FindBy(css = "#expdatemonth+select"), @FindBy(css = "[id*='ExpDate_Year']") })
   private WebElement expiryYear;

   @FindBy(css = "[name*='exp-date']")
   private WebElement expMonthYear;

   @FindBy(css = "[type='submit']")
   private List<WebElement> confirmButton;

   @FindBy(css = "[id='bankId']")
   private WebElement bankDropdown;

   @FindBy(css = "[type='submit']")
   private WebElement confirmTransactionBtn;

   public PaymentProviderPage()
   {
      wait = new WebElementWait();
      utils = new WebDriverUtils();
   }

   public boolean isOnPaymentProviderPage()
   {
      wait.forJSExecutionReadyLazy();
      wait.waitForAWhile(3000);
      wait.forAppear(confirmButton.get(0));
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(confirmButton.get(0)));
   }

   public void enterCardDetails()
   {
      wait.forJSExecutionReadyLazy();
      wait.waitForAWhile(5000);
      if (WebElementTools.isPresent(bankDropdown))
      {
         selectPaymentMethodForNL();
      }
      else
      {
         wait.waitForAWhile(5000);
         if (WebElementTools.isPresent(cardHolderInput))
            WebElementTools.enterText(cardHolderInput, getData().getCardHolderName());
         WebElementTools.enterText(cardNumberInput, getData().getCardNumber());
         WebElementTools.selectDropDownByValue(expiryYear, getData().getExpiryYear());
         WebElementTools.selectDropDownByValue(expriyMonth, getData().getExpiryMonth());
         WebElementTools.enterText(cvvInput, getData().getSecurityCode());
         clickOnConfirmButton();
      }
   }

   public PaymentAttributes getData()
   {
      return TestDataHelper.paymentDetailsDataHelper().getWrCreditCardDetails();
   }

   public void clickOnConfirmButton()
   {
      LOGGER.log(LogLevel.INFO, "clickOnConfirmButton" + confirmButton.size());
      WebElementTools.click(confirmButton.get(0));
   }

   public void selectPaymentMethodForNL()
   {
      WebElementTools.selectDropDownByVisibleText(bankDropdown, "ING");
      clickOnConfirmButton();
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(confirmTransactionBtn);
      wait.forJSExecutionReadyLazy();
   }

}
