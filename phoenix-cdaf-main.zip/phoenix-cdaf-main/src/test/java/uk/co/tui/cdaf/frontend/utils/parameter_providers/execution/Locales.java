package uk.co.tui.cdaf.frontend.utils.parameter_providers.execution;

public enum Locales
{
   NL,
   FR,
   EN;

   public static Locales fromString(String value)
   {
      for (Locales local : Locales.values())
      {
         if (local.name().equalsIgnoreCase(value.replaceAll("-", "_")))
         {
            return local;
         }
      }
      throw new IllegalArgumentException("Invalid Local: " + value);
   }
}

