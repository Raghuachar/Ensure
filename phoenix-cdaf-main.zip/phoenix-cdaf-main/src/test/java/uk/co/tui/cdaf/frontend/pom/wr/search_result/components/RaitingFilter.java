package uk.co.tui.cdaf.frontend.pom.wr.search_result.components;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;

import static com.codeborne.selenide.Selenide.$;

public class RaitingFilter extends BaseComponent
{
   public void selectLowestRating()
   {
      selectElement(getRatingRadioboxes().first());
   }

   public void selectHighestRating()
   {
      selectElement(getRatingRadioboxes().last());
   }

   private ElementsCollection getRatingRadioboxes()
   {
      return $("div.Components__customerRatingContainer").$$("div.Components__customerRatingBlock")
               .filter(Condition.not(Condition.cssClass("Components__disabled")));
   }
}
