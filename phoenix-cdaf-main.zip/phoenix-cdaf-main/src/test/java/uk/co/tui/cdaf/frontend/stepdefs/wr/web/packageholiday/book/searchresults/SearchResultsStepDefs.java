package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.api.requests.search.PackageSearchApi;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.Brands;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.open;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class SearchResultsStepDefs
{
   static AutomationLogManager LOGGER = new AutomationLogManager(SearchResultsStepDefs.class);

   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   private final Map<String, WebElement> searchMap;

   public SearchResultsStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      searchMap = new HashMap<>();
   }

   @Given("user navigates directly to search results page with available capabilities")
   public void openSearchResultsPage()
   {
      String searchUrl = PackageSearchApi.uriBuilder();
      open(searchUrl);
      BrowserCookies.closePrivacyPopUp();
   }

   @Given("the \"customer or agent\" is on the package search results page")
   public void the_is_on_the_package_search_results_page()
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @Given("the {string} is on the smoke package search results page")
   public void the_is_on_the_smoke_package_search_results_page(String customer)
   {
      TestExecutionParams testExecutionParams = ExecParams.getTestExecutionParams();
      testExecutionParams.setBrand(Brands.fromString(customer));
      ExecParams.getTemporaryUrl(testExecutionParams);
      packageNavigation.navigateToSmokeSearchResultPage();
   }

   @And("the customer should be able to see the following items on search result page")
   public void the_customer_should_be_able_to_see_the_following_items_on_search_result_page(
            List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchResultComponent.getSearchCardComponents());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they select the hotel")
   public void they_select_the_hotel()
   {
      searchResultsPage.searchResultComponent.selectRandomResultCard();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   @And("they select the first hotel in the search results list")
   public void they_select_the_first_hotel_in_the_search_results_list()
   {
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   @And("the user can capture the values from the search result page")
   public void the_user_can_capture_the_values_from_the_search_result_page()
   {
      searchResultsPage.searchResultComponent.searchResultsCardComponents();
   }

   @Given("user navigates directly to search results")
   public void userNavigatesDirectlyToSearchResults()
   {
      String searchUrl = PackageSearchApi.uriBuilder();
      open(searchUrl);
      BrowserCookies.closePrivacyPopUp();
   }
}
