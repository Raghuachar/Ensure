package uk.co.tui.cdaf.frontend.pom.generic_page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class PageErrorHandler extends AbstractPage
{
   @FindBy(xpath = "//h2[contains(text() , 'Endeca')]")
   static List<WebElement> endecaException;

   /**
    * Checks if the web page is loading correctly by verifying the absence of common error messages.
    *
    * @return void
    */
   public void isPageLoadingCorrectly()
   {
      assertThat("Deployment underway, Service is Temporarily Unavailable",
               getDriver().getPageSource().contains("503 Service Temporarily Unavailable"),
               is(false));
      assertThat("Error 404 Page is Displayed", getDriver().getPageSource().contains("error-404"),
               is(false));
      assertThat("Technical Difficulty Page is Displayed",
               getDriver().getPageSource().contains("having some technical problems"), is(false));
      assertThat("Page cannot be found is Displayed", getDriver().getPageSource().contains("html"),
               is(true));
      assertThat("Gateway Time-out is Displayed",
               getDriver().getPageSource().contains("504 Gateway Time-out"), is(false));
      assertThat("Search Results are not available, All Gone!",
               getDriver().getPageSource().contains("We couldn't find any matching"), is(false));
      assertThat("Endeca Exception Page is Displayed", !endecaException.isEmpty(), is(false));
      assertThat("Elastic Connection Exception is displayed",
               getDriver().getPageSource().contains("<h2>Elastic Connection Exception</h2>"),
               is(false));
      assertThat("E14331:Technical Error is displayed",
               getDriver().getPageSource().contains("alt=\"Technical Difficulties\""), is(false));
      assertThat("All Gone Page is Displayed",
               getDriver().getPageSource().contains("<h1>All gone!</h1>"), is(false));
   }

   public void isNordicPageLoadedCorrectly()
   {
      assertThat("Deployment underway, Service is Temporarily Unavailable",
               getDriver().getPageSource().contains("503 Service Temporarily Unavailable"),
               is(false));
      assertThat("Page can't be found!", getDriver().getTitle().contains("page can’t be found"),
               is(false));

      assertThat("Page not found:",
               getDriver().getPageSource().contains("Tyvärr verkar den här sidan vara bortrest"),
               is(false));
      assertThat("Page not found:", getDriver().getPageSource()
               .contains("Beklager, men vi kan ikke finde det du søger efter"), is(false));
      assertThat("Page not found:", getDriver().getPageSource()
               .contains("Sivu ei valitettavasti ole tällä hetkellä käytettävissä"), is(false));
      assertThat("Page not found:",
               getDriver().getPageSource().contains("Dessverre, vi finner ikke det du søker etter"),
               is(false));

      assertThat("Technical Difficulty Page is Displayed", getDriver().getPageSource().contains(
                        "Ett tekniskt problem verkar ha uppstått, vi ber så hemskt mycket om ursäkt."),
               is(false));
      assertThat("Technical Difficulty Page is Displayed", getDriver().getPageSource()
               .contains("Beklager, men vi har nogle tekniske problemer"), is(false));
      assertThat("Technical Difficulty Page is Displayed", getDriver().getPageSource()
               .contains("Valitettavasti meillä on teknisiä ongelmia tällä hetkellä."), is(false));
      assertThat("Technical Difficulty Page is Displayed",
               getDriver().getPageSource().contains("Beklager, men vi har noen tekniske problemer"),
               is(false));

      assertThat("All Gone Page is Displayed", getDriver().getPageSource().contains("Helt slut"),
               is(false));
      assertThat("All Gone Page is Displayed", getDriver().getPageSource().contains("Loppuunmyyty"),
               is(false));
      assertThat("All Gone Page is Displayed", getDriver().getPageSource().contains("INGEN REJSER"),
               is(false));
      if (!endecaException.isEmpty())
      {
         assertThat("Endeca Exception Page is Displayed", !endecaException.isEmpty(), is(false));
      }
   }

}
