package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class ExtraOptionsPage extends AbstractPage
{
   public final WebElementWait wait;

   public final InsuranceComponent insuranceComponent;

   public final StepIndicatorComponent stepIndicator;

   public final PricePanelComponent pricePanelComponent;

   private final Map<String, WebElement> extraPageComponent;

   @FindBy(css = "#globalHeader__component")
   private WebElement globaleHeader;

   @FindBy(css = "[class*='ContinueButton'] button")
   private WebElement continueButton;

   @FindBy(css = "[aria-label='page heading']")
   private WebElement pageTitle;

   @FindBy(css = "div[class*='summaryDropdown']")
   private WebElement summarryClick;

   @FindBy(css = "[aria-label=\"totalPrice Details\"]")
   private WebElement totalPrice;

   @FindBy(css = "[aria-label*='passenger details']")
   private WebElement pax;

   @FindBy(css = "[class*='PriceSummaryPanel__contentBlock PriceSummaryPanel__summaryCloseBtn']")
   private WebElement summarryClose;

   public ExtraOptionsPage()
   {
      extraPageComponent = new HashMap<>();
      wait = new WebElementWait();
      insuranceComponent = new InsuranceComponent();
      stepIndicator = new StepIndicatorComponent();
      pricePanelComponent = new PricePanelComponent();
   }

   public WebElement getContinuteElement()
   {
      return wait.getWebElementWithLazyWait(continueButton);
   }

   public void clickOnContinue()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(getContinuteElement());
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
   }

   public WebElement getPageTitleElement()
   {
      return wait.getWebElementWithLazyWait(pageTitle);
   }

   public boolean isPageTitleDisplayed()
   {
      return WebElementTools.isPresent(getPageTitleElement());
   }

   public Map<String, WebElement> getExtrasComponents()
   {
      extraPageComponent.putAll(insuranceComponent.getInsurancePassengerFormComponents());
      extraPageComponent.put("Global Header", globaleHeader);
      extraPageComponent.put("Navigation Panel", stepIndicator.getNavigationPanelElement());
      extraPageComponent.put("Price Drop Down Panel",
               pricePanelComponent.getSummaryDropdownElement());
      extraPageComponent.put("Continue Buttons", getContinuteElement());
      return extraPageComponent;
   }

   public String extrasSummaryDetails(String componentValues)
   {
      return componentValues.equalsIgnoreCase("first")
               ? WebElementTools.getElementText(wait.getWebElementWithLazyWait(totalPrice))
               : WebElementTools.getElementText(wait.getWebElementWithLazyWait(pax));
   }

   public void extrasSummaryOpen()
   {
      WebElementTools.click(summarryClick);
      wait.forJSExecutionReadyLazy();
   }

   public void extrasSummaryClose()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(summarryClose);

   }

}
