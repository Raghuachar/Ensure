package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlightSummaryComponent extends AbstractPage
{

   private final WebElementWait wait;

   private final Map<String, WebElement> flightMap;

   @FindAll({ @FindBy(css = ".Itinerary__CTALink a"),
            @FindBy(css = ".Itinerary__CTALink"),
            @FindBy(css = "a[aria-label='show alt flights']") })
   private WebElement flightLink;

   @FindBy(css = "[aria-label='your flights'] h2")
   private WebElement yourFlightText;

   @FindAll({ @FindBy(css = "[class*='SelectedFlights'] [class*='Itinerary__date']"),
            @FindBy(css = "[aria-label='your flights'] [class*='Itinerary__date']") })
   private List<WebElement> flightDate;

   @FindAll({
            @FindBy(css = "[aria-label='your flights'] [class='Itinerary__departure'] .Itinerary__departureTime"),
            @FindBy(css = "[class*='SelectedFlights'] [class='Itinerary__departure'] .Itinerary__departureTime") })
   private List<WebElement> departureTime;

   @FindAll({
            @FindBy(css = "[class*='SelectedFlights'] [class='Itinerary__arrival'] .Itinerary__departureTime"),
            @FindBy(css = "[aria-label='your flights'] [class='Itinerary__arrival'] .Itinerary__departureTime") })
   private List<WebElement> arrivalTime;

   @FindAll({
            @FindBy(css = "[aria-label='your flights'] [class='Itinerary__departure']>div:nth-child(3)"),
            @FindBy(css = "[class*='SelectedFlights'] [class='Itinerary__departure']>div:nth-child(3)") })
   private List<WebElement> airportName;

   @FindAll({
            @FindBy(css = "[aria-label='your flights'] [class='Itinerary__arrival']>div:nth-child(3)"),
            @FindBy(css = "[class*='SelectedFlights'] [class='Itinerary__arrival']>div:nth-child(3)") })
   private List<WebElement> retAirportName;

   @FindAll({ @FindBy(css = "[aria-label='your flights'] [class*='journeyInfo']>div:first-child"),
            @FindBy(css = "[class*='SelectedFlights'] [class*='journeyInfo']>div:first-child") })
   private List<WebElement> typeOfLight;

   @FindBy(css = ".Itinerary__careerName")
   private List<WebElement> airLine;

   public FlightSummaryComponent()
   {
      wait = new WebElementWait();
      flightMap = new HashMap<>();
   }

   public void clickOnFlightLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(flightLink);
   }

   public Map<String, WebElement> getFlightSummaryComponents()
   {
      flightMap.put("YOUR FLIGHTS", yourFlightText);
      flightMap.put("Outbound Flight Date", flightDate.get(0));
      flightMap.put("Departure Time", departureTime.get(0));
      flightMap.put("Type of Flight", typeOfLight.get(0));
      flightMap.put("Arrival Time", arrivalTime.get(0));
      flightMap.put("Outbound Airport", airportName.get(0));
      flightMap.put("Destination Airport", retAirportName.get(0));
      flightMap.put("Outbound Airline", airLine.get(0));
      flightMap.put("Ret Flight Date", flightDate.get(1));
      flightMap.put("Ret Departure Time", departureTime.get(1));
      flightMap.put("Ret Type of Flight", typeOfLight.get(1));
      flightMap.put("Ret Arrival Time", arrivalTime.get(1));
      flightMap.put("Ret Outbound Airport", airportName.get(1));
      flightMap.put("Ret Destination Airport", retAirportName.get(1));
      flightMap.put("Ret Airline", airLine.get(1));
      return flightMap;
   }
}
