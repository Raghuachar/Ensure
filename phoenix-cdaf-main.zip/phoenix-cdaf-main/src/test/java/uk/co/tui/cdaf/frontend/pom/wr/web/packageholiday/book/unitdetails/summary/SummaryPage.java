package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.flightoptions.BackToYourHolidayComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class SummaryPage
{
   public final ProgressionbarNavigationComponent navigationComponent;

   public final CabinAndSeatAncillaryComponent seatAncillaryComponent;

   public final FlightSummaryComponent flightSummaryComponent;

   public final LuggageAncillaryComponent luggageAncillaryComponent;

   public final InsuranceAndExtrasComponent insExComponent;

   public final PriceBreakDownComponent priceBreakComponent;

   public final AccommodationComponent accomodationComponent;

   public final TransferComponent transferComponent;

   public final RoomAndBoardComponent roomAndBoardComponent;

   public final PriceChangeAlertComponent priceChangeAlertComponent;

   public final BackToYourHolidayComponent backToYourHolidayComponent;

   public final SummaryFreeCancellationComponent freeCancellationComponent;

   public final PageErrorHandler errorHandler;

   public final WebElementWait wait;

   public SummaryPage()
   {
      navigationComponent = new ProgressionbarNavigationComponent();
      seatAncillaryComponent = new CabinAndSeatAncillaryComponent();
      flightSummaryComponent = new FlightSummaryComponent();
      luggageAncillaryComponent = new LuggageAncillaryComponent();
      insExComponent = new InsuranceAndExtrasComponent();
      priceBreakComponent = new PriceBreakDownComponent();
      accomodationComponent = new AccommodationComponent();
      transferComponent = new TransferComponent();
      roomAndBoardComponent = new RoomAndBoardComponent();
      priceChangeAlertComponent = new PriceChangeAlertComponent();
      backToYourHolidayComponent = new BackToYourHolidayComponent();
      freeCancellationComponent = new SummaryFreeCancellationComponent();
      errorHandler = new PageErrorHandler();
      wait = new WebElementWait();
   }

   public void Pricechange()
   {
      WebDriver driver = new ChromeDriver();
      driver.get("https://sit.tuiprjuat.be/h/updateBasePackagePrice?totalPrice=3100");
      driver.navigate().refresh();
      driver.navigate().refresh();
      WebDriverUtils.switchToParentTabHandles();
   }

   public void BookingFee()
   {
      wait.forJSExecutionReadyLazy();
      priceBreakComponent.ClickonBookingFee();
      wait.forJSExecutionReadyLazy();
      priceBreakComponent.DisplayBookingfee();

   }
}
