package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.paymentoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentOptionPage;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOPaymentOptionsPageStepDefs
{

   private final FlightOnlyPageNavigation pageNavigation;

   private final PaymentOptionPage foPaymentOptionPage;

   public FOPaymentOptionsPageStepDefs()
   {
      foPaymentOptionPage = new PaymentOptionPage();
      pageNavigation = new FlightOnlyPageNavigation();
   }

   @Given("the customer is on the FO Passenger Details Page")
   public void the_customer_is_on_the_FO_Passenger_Details_Page()
   {
      pageNavigation.navigateToPassengerDetailsPage();
   }

   @When("They navigate to the Payment Options Page")
   public void they_navigate_to_the_Payment_Options_Page()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.fillThePassengerDetailsForWr();
   }

   @Then("following component options should display:")
   public void following_component_options_should_display(List<String> components)
   {
      foPaymentOptionPage.setPaymentComponentOptionsMap();
      components.forEach(component ->
               assertThat(component + " component is not displayed", WebElementTools.isPresent(
                                 foPaymentOptionPage.getPaymentComponentOptionsMap().get(component)),
                        is(true)));
   }

   @Then("following payment options should display:")
   public void following_payment_options_should_display(List<String> components)
   {
      foPaymentOptionPage.setPaymentOptionsMap();
      components.forEach(component ->
      {
         WebElement getComponent = foPaymentOptionPage.getPaymentOptionsMap().get(component);
         assertThat(component + " component is not displayed",
                  WebElementTools.isPresent(getComponent), is(true));
      });
   }

   @Then("The payment methods available should display with an image and text under the following title")
   public void the_payment_methods_available_should_display_with_an_image_and_text_under_the_following_title(
            List<String> components)
   {
      assertThat("Payment method title not displayed",
               foPaymentOptionPage.paymentOptionComponent.isPaymentMethodsTitleDisplayed(),
               is(true));
      assertThat("Payment methods should be available",
               foPaymentOptionPage.paymentOptionComponent.validatePaymentMethodsList(), is(true));
   }

   @Given("the customer is on the FO Payment Options Page")
   public void the_customer_is_on_the_FO_Payment_Options_Page()
   {
      pageNavigation.navigateToPaymentOptionsPage();
   }

   @Given("they have selected a payment method")
   public void they_have_selected_a_payment_method()
   {
      foPaymentOptionPage.paymentOptionComponent.clickPaymentMethod();
   }

   @When("They select to continue")
   public void they_select_to_continue()
   {
      foPaymentOptionPage.paymentOptionComponent.clickOnPayButton();
   }

   @Then("The customer should be navigated to the Payment Gateway Page for the relevant Payment Service Provider")
   public void the_customer_should_be_navigated_to_the_Payment_Gateway_Page_for_the_relevant_Payment_Service_Provider()
   {
      boolean actual = foPaymentOptionPage.paymentProviderPage.isOnPaymentProviderPage();
      assertThat("It wasn't navigated to the relevant Payment provider", actual, is(true));
   }

   @And("payment page should be displayed with the following components")
   public void the_following_components_should_be_displayed_on_fo_payment_page(
            List<String> components)
   {
      pageNavigation.wait.forJSExecutionReadyLazy();
      following_component_options_should_display(components);
   }

   @And("they select any of the payment method and click on continue")
   public void they_select_any_of_the_payment_method_and_click_on_continue()
   {
      they_have_selected_a_payment_method();
      pageNavigation.paymentOptionPage.paymentOptionComponent.clickOnPayButton();
      pageNavigation.searchPanelComponent.closePrivacyPopUp();
   }

   @And("respective page PSP page should be displayed")
   public void respective_page_PSP_page_should_be_displayed()
   {
      pageNavigation.wait.forJSExecutionReadyLazy();
      boolean actual = foPaymentOptionPage.paymentProviderPage.isOnPaymentProviderPage();
      assertThat("It wasn't navigated to the relevant Payment provider", actual, is(true));
   }

   @And("they fill card details in PSP page then click on Confirm button")
   public void they_fill_card_details_in_PSP_page_then_click_on_Confirm_button()
   {
      foPaymentOptionPage.paymentProviderPage.enterCardDetails();
      pageNavigation.searchPanelComponent.closePrivacyPopUp();
   }

   @And("Compare search results values with payment page value")
   public void compare_search_results_values_with_payment_page_value()
   {
      Map<String, String> searchvalue = searchStoreValues.getSearchValues();
      String paymentValue = foPaymentOptionPage.progressbarComponent.getTotalPrice();
      assertThat("Total price error message is not matched",
               searchvalue.get("Total_Price").trim().equalsIgnoreCase(paymentValue), is(true));
   }

}
