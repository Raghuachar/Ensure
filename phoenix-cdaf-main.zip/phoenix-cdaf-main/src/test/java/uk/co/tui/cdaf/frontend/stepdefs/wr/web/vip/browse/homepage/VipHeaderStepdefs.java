package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.CommonPagesImplementation;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.browse.homepage.HomePageCommon;
import uk.co.tui.cdaf.frontend.pom.wr.web.vip.browse.homepage.HomePage;
import uk.co.tui.cdaf.utils.ConfigurationConstants;
import uk.co.tui.cdaf.utils.ConfigurationService;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.transformer.WesternRegionComponents;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

public class VipHeaderStepdefs
{

   private final Map<String, WebElement> searchMap;

   private final HomePage homepage;

   private final HomePageCommon homepageShared;

   private final CommonPagesImplementation wrCommonPage;

   private String translationCode;

   public VipHeaderStepdefs()
   {
      searchMap = new HashMap<>();
      homepage = new HomePage();
      homepageShared = new HomePageCommon();
      wrCommonPage = new CommonPagesImplementation();
   }

   @Given("a {string} is on the VIP Selection homepage")
   public void a_is_on_the_VIP_Selection_homepage(String string)
   {
      homepage.visit();
   }

   @Given("they have selected {string} language on vip website")
   public void they_have_selected_language_on_vip_website(String lang)
   {

      translationCode = wrCommonPage.getTranslationCode(lang, "vip");

      if (ConfigurationService.getProperty(ConfigurationConstants.SELENIUM_BROWSER)
               .contains("mobile"))
      {
         homepageShared.clickBurgerMenu();
         homepageShared.changeLanguage(lang);
         homepageShared.clickBurgerMenu();
      }
      else
      {
         homepageShared.changeLanguage(lang);
      }

   }

   @When("they view the VIP Selection Global Header")
   public void they_view_the_VIP_Selection_Global_Header()
   {
      homepageShared.viewHeader();
      homepageShared.setVIPHeaderLabelMap();
      homepageShared.setHeaderCompMap();
   }

   @When("they view the VIP Selection Burger Menu")
   public void they_view_the_VIP_Selection_Burger_Menu()
   {
      homepageShared.viewHeader();
      homepageShared.setVIPHeaderLabelMap();
      homepageShared.setHeaderCompMap();
   }

   @Then("the following options will be displayed in this order in VIP Selection Global Header:")
   public void the_following_options_will_be_displayed_in_this_order_in_VIP_Selection_Global_Header(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<WesternRegionComponents> headerComp = dataTable.asList(WesternRegionComponents.class);
      headerComp.forEach(row -> assertThat(
               row.getComponent() + " Label is not displayed/not in order \n Expected: "
                        + row.getTranslationValue(translationCode.split("-")[1]) + "\n Actual: "
                        + homepageShared.getHeaderLabel(row.getComponent().toLowerCase()),
               homepageShared.checkHeaderLabel(
                        homepageShared.getHeaderLabel(row.getComponent().toLowerCase()),
                        row.getTranslationValue(translationCode.split("-")[1])),
               is(true)));
   }

   @Then("customer will see the following Icons in VIP Header:")
   public void customer_will_see_the_following_Icons_in_VIP_Header(List<String> icons)
   {
      icons.forEach(component ->
      {
         try
         {
            assertThat(component + " componenet is not displayed",
                     WebElementTools.isPresent(homepageShared.getHeaderPageMap().get(component)),
                     is(true));
         }
         catch (Exception e)
         {
            assertThat(component + " componenet is not displayed", is(false), is(true));
         }

      });
   }

   @Then("they will see a logo for VIP Selection")
   public void they_will_see_a_logo_for_VIP_Selection()
   {
      assertThat(" TUI Logo is not displayed", homepageShared.checkVIPLogo(), is(true));
   }

   @Then("they can see the following header links:")
   public void they_can_see_the_following_header_links(List<String> components)
   {
      searchMap.putAll(homepageShared.getVIPHeaderComponents());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("they hover over the {string} link")
   public void they_hover_over_the_link(String string)
   {
      homepageShared.mouseOver(string);
   }

   /*
    * // @Then("the {string} mega menu expands") public void the_mega_menu_expands() {
    * assertThat(homepageShared.checkMegaMenuExpanded(), is(true)); }
    */
   @Then("the pure indulgence mega menu expands")
   public void the_pure_indulgence_mega_menu_expands()
   {
      assertThat(homepageShared.checkMegaMenuExpanded(), is(true));
   }

   @Then("the enjoy carefree sub menu expands")
   public void the_enjoy_carefree_sub_menu_expands()
   {
      assertThat(homepageShared.checkMegaMenuExpanded(), is(true));
   }

   @Then("it contains the following links:")
   public void it_contains_the_following_links(List<String> string)
   {
      assertThat(homepageShared.isSubmenuValuesPresent(string), is(true));

   }

   @Given("the {string} has the pure indulgence sub menu open")
   public void the_has_the_sub_menu_open(String string)
   {
      homepage.visit();
      homepageShared.mouseOver(string);
   }

   @When("they roll away from the sub menu")
   public void they_roll_away_from_the_sub_menu()
   {
      homepageShared.mouseOver("");
   }

   @Then("it closes")
   public void it_closes()
   {
      assertThat(homepageShared.isClosed(), is(true));
   }

}
