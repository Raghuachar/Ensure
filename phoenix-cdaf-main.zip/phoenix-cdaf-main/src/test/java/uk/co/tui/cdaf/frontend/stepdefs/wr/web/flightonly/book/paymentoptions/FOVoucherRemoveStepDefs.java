package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.paymentoptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentOptionPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOVoucherRemoveStepDefs
{
   private final FlightOnlyPageNavigation pageNavigation;

   private final PaymentOptionPage foPaymentOptionPage;

   public FOVoucherRemoveStepDefs()
   {
      foPaymentOptionPage = new PaymentOptionPage();
      pageNavigation = new FlightOnlyPageNavigation();
   }

   @Given("that a customer is on the Payment Page")
   public void that_a_customer_is_on_the_Payment_Page()
   {
      pageNavigation.navigateToPaymentOptionsPage();
   }

   @When("they have had a voucher applied")
   public void they_have_had_a_voucher_applied()
   {
      foPaymentOptionPage.voucherRemove.getAppliedVoucherCodeElement();
   }

   @Then("there will be no ability to remove that voucher from the page")
   public void there_will_be_no_ability_to_remove_that_voucher_from_the_page()
   {
      boolean actual = foPaymentOptionPage.voucherRemove.getVoucherRemoveButtonElement();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Voucher Remove button was displayed", actual, false), actual, is(false));
   }

}
