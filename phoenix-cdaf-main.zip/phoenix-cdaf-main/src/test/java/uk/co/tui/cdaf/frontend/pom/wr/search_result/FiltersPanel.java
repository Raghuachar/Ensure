package uk.co.tui.cdaf.frontend.pom.wr.search_result;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import uk.co.tui.cdaf.frontend.pom.wr.search_result.components.BaseComponent;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class FiltersPanel extends BaseComponent
{

   public List<String> getDisabledCheckboxes()
   {
      ElementsCollection disabledInputs = $$("[disabled]");
      return disabledInputs.asFixedIterable().stream()
               .map(el ->
               {
                  SelenideElement element = el.parent().$("span.inputs__text > span");
                  if (element.exists())
                  {
                     String text = element.getText();
                     return text.isEmpty() ? null : text;
                  }
                  else
                  {
                     return null;
                  }
               })
               .filter(Objects::nonNull)
               .collect(Collectors.toList());
   }

   public boolean isClearFilterAllLinkDisplayed()
   {
      return getClearAllBtn().isDisplayed();
   }

   private SelenideElement getClearAllBtn()
   {
      return $(By.cssSelector("a.ActiveFiltersPanel__clearAllLink"));
   }

   public void clickClearAllBtn()
   {
      selectElement(getClearAllBtn());
   }

   public ElementsCollection getActiveFiltersOptions()
   {
      return $$("div.ActiveFiltersOption__container");
   }
}
