package uk.co.tui.cdaf.frontend.pom.uk.web.flight_only.search.search_results;

import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import static com.codeborne.selenide.Selenide.$;

public class FlightOnlySearchResultsNavigationPage extends AbstractPage
{

   public boolean isLugggagePresent()
   {
      return $("#fligtLuggageAncillary__component").isDisplayed();
   }

}
