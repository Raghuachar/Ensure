package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class FOSubHeaderStepDefs
{
   public final WebElementWait wait;

   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents;

   public FOSubHeaderStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      wait = new WebElementWait();
      foReconcilationPaymentPageComponents = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Agent has navigated to the Banking & reconciliation page")
   public void that_the_Agent_has_navigated_to_the_Banking_reconciliation_page()
   {
      retailflightNavigation.retailLoginFO();
      foReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

}
