package uk.co.tui.cdaf.frontend.stepdefs.wr.web.stay.book.paymentoptions;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.web.stay.book.StayPageNavigation;

public class PaymentOptionsStepDefs
{
   private final StayPageNavigation pageNavigation;

   public PaymentOptionsStepDefs()
   {
      pageNavigation = new StayPageNavigation();
   }

   @Given("the customer is on the Stay Passenger Details Page")
   public void the_customer_is_on_the_Stay_Passenger_Details_Page()
   {
      pageNavigation.navigateToPasengerDetailsPage();
   }

   @Given("the customer is on the Stay Payment Options Page")
   public void the_customer_is_on_the_Stay_Payment_Options_Page()
   {
      pageNavigation.navigateToPaymentOptionsPage();
   }

}
