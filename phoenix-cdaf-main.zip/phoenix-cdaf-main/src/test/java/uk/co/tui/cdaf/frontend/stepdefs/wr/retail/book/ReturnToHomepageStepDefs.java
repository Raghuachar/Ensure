package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailHomepageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class ReturnToHomepageStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailSearchPanelComponent retailsearchPanelComponent;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final RetailHomepageComponents retailhomepagecomponents;

   private final RetailFlightOnlyPageNavigation retailFlightOnlyPageNavigation;

   public ReturnToHomepageStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailsearchPanelComponent = new RetailSearchPanelComponent();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      retailhomepagecomponents = new RetailHomepageComponents();
      retailFlightOnlyPageNavigation = new RetailFlightOnlyPageNavigation();
   }

   @Given("the agent is on packages or flights pages")
   public void the_agent_is_on_packages_or_flights_pages()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();
   }

   @When("they click on the tui logo in bookflow")
   public void they_click_on_the_tui_logo_in_bookflow()
   {
      retailpassengerdetailspage.returntoHomepage();
   }

   @Then("they should navigate back to btob homepage")
   public void they_should_navigate_back_to_btob_homepage()
   {
      retailhomepagecomponents.isHomePagePresent();
      retailpassengerdetailspage.userLogout();
   }

   @Given("the agent is on flights pages")
   public void the_agent_is_on_flights_pages()
   {
      retailpackagenavigation.retailLogin();
      retailFlightOnlyPageNavigation.wrMFEFoOneWaySearch();
      retailsearchPanelComponent.selectFlight();
   }

   @When("they click on the tui logo in flightbookflow")
   public void they_click_on_the_tui_logo_in_flightbookflow()
   {
      retailpassengerdetailspage.returntoHomepage();
   }

   @Then("they should navigate back to btob flighthomepage")
   public void they_should_navigate_back_to_btob_flighthomepage()
   {
      retailhomepagecomponents.isHomePagePresent();
      retailpassengerdetailspage.userLogout();
   }

}
