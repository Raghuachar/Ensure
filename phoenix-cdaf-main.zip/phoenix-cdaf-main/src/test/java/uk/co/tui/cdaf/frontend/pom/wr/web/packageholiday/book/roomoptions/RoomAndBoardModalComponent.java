package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.roomoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.HashMap;

public class RoomAndBoardModalComponent extends AbstractPage
{

   private final HashMap<String, WebElement> roomAndBoardOptionsMap;

   @FindBy(css = "[class*='RoomTypesV2__moreDetailsIcon']")
   private WebElement roomIcon;

   @FindBy(xpath = "(//a[@class='RoomTypesV2__moreDetailsLink']) [2]")
   private WebElement moreDetails;

   @FindBy(css = "[class*='RoomTypesV2__popupSectionContainer'] [aria-label='room option title']")
   private WebElement roomTypeName;

   @FindBy(css = "[class*='RoomTypesV2__occupancy'] span")
   private WebElement imgCarousel;

   @FindBy(css = "[class*='RoomTypesV2__infoSection']")
   private WebElement roomFeatures;

   @FindBy(css = "[src='/destinations/_ui/mobile/12345/framework/tui/Placeholder.png']")
   private WebElement imageCommingSoon;

   public RoomAndBoardModalComponent()
   {
      roomAndBoardOptionsMap = new HashMap<>();
   }

   public void clickOnImageChevron()
   {
      WebElementTools.click(roomIcon);
   }

   public void clickOnMoreDetailsLink()
   {
      WebElementTools.click(moreDetails);
   }

   public HashMap<String, WebElement> getRoomAndBoardOptionsComps()
   {
      roomAndBoardOptionsMap.put("Room Type name", roomTypeName);
      roomAndBoardOptionsMap.put("Image carousel", imgCarousel);
      roomAndBoardOptionsMap.put("Room attribute bullet points", roomFeatures);
      return roomAndBoardOptionsMap;
   }

   public boolean getImageCommingSoonElement()
   {
      return WebElementTools.isPresent(imageCommingSoon);
   }
}
