package uk.co.tui.cdaf.api.pojo.search.legacy;

import uk.co.tui.cdaf.api.pojo.search.mfe.CountryData;

@lombok.Data
public class DestinationResponse
{
   private String error;

   private int errorCode;

   private CountryData data;
}
