package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HeaderComponent extends AbstractPage
{

   private final CountryLannguageSelectorComponent clOverlayComp;

   private List<String> airportList;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(1) a.MenuItem__menuLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(1) ul li a.GlobalHeaderAccordion__headingLink")
   })
   private WebElement flightsLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(2) a.MenuItem__menuLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(2) ul li a.GlobalHeaderAccordion__headingLink"),
            @FindBy(css = ".MenuItem__menuItemContainer a[href='/retail']") })
   private WebElement promotionsLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(3) a.MenuItem__menuLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(3) ul li a.GlobalHeaderAccordion__headingLink")
   })
   private WebElement destinationsLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(4) a.MenuItem__menuLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(4) ul li a.GlobalHeaderAccordion__headingLink")
   })
   private WebElement stayLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(5) a.MenuItem__menuLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(5) ul li a.GlobalHeaderAccordion__headingLink")
   })
   private WebElement extrasLabel;

   @FindAll({
            @FindBy(css = "#globalHeader__component")
   })
   private WebElement headerComp;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(1) a.StandardLink__standardLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(6) ul li a.GlobalHeaderAccordion__headingLink")
   })
   private WebElement questionsLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(2) a.StandardLink__standardLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(7) ul li a.GlobalHeaderAccordion__headingLink")
   })
   private WebElement checkinLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(3) a.StandardLink__standardLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(8) ul li a.GlobalHeaderAccordion__headingLink")
   })
   private WebElement flyAppLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(4) a.StandardLink__standardLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(9) ul li a.GlobalHeaderAccordion__headingLink")
   })
   private WebElement travelInformationLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(5) a.StandardLink__standardLink"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(12) a")
   })
   private WebElement accountBookingLabel;

   @FindAll({
            @FindBy(css = "[aria-label='burger menu main']")
   })
   private WebElement burgerMenu;

   @FindAll({
            @FindBy(css = "[aria-label='no of shortlited holidays']"),
            @FindBy(css = "[aria-label='Shortlist Icon']")
   })
   private WebElement shortlistIcon;

   @FindBy(css = "[aria-label='CA Icon']")
   private WebElement accountBookingIcon;

   @FindBy(css = "#globalHeader__component  a > img")
   private WebElement tuiFlyLogoIcon;

   @FindBy(css = ".LanguageCountrySelector__countrySwitcher button")
   private WebElement countrySwitcherLink;

   @FindBy(css = "[name='Departure Airport']")
   private WebElement departureAirportTextInput;

   @FindBy(css = ".alerts__alertMessages div")
   private List<WebElement> searchPanelErrorMessages;

   @FindBy(xpath = "//section[@aria-label='destination airports']//a[contains(@class, 'HighlightedLink__disabled')]")
   private List<WebElement> disabledDestinationAirports;

   @FindBy(css = "[name='Destination Airport']")
   private WebElement destinationAirportTextInput;

   @FindBy(css = "[name='Rooms & Guests']")
   private WebElement passengerTextInput;

   @FindBy(css = "div[aria-label='adult select'] .inputs__selectText")
   private WebElement adultsPassengerSelectInput;

   @FindBy(css = "div[aria-label='child select'] .inputs__selectText")
   private WebElement childrenPassengerSelectInput;

   @FindBy(css = "section[aria-label='destination airports'] .DropModal__content ul li")
   private WebElement destinationAirportsDropdownModal;

   @FindBy(css = "section[aria-label='airports'] .Flights__airportsListWrapperModal")
   private WebElement departureAirportsDropdownModal;

   @FindBy(css = "div[aria-label='pax header']")
   private WebElement passengerTitleInDropdownModal;

   @FindBy(xpath = "//section[@aria-label='airports']//a[not(contains(@class, 'HighlightedLink__disabled'))]")
   private List<WebElement> availableDepartureAirports;

   @FindBy(xpath = "//section[@aria-label='destination airports']//a[not(contains(@class, 'HighlightedLink__disabled'))]")
   private List<WebElement> availableDestinationAirports;

   @FindBy(css = "section[aria-label='destination airports'] .DropModal__content ul:first-of-type li")
   private List<WebElement> availableAirports;

   @FindBy(css = "section[aria-label='destination airports'] footer a")
   private WebElement departureAirportsDropdownModalClearAllButton;

   @FindBy(css = ".SearchPanel__searchButton")
   private WebElement searchPanelSubmitButton;

   @FindBy(css = ".DropModal__dropModalContent .DropModal__clear")
   private List<WebElement> clearAllButtons;

   @FindBy(css = "section[aria-label='destination airports'] footer button")
   private WebElement departureAirportsDropdownModalDoneButton;

   @FindBy(css = "input[name='Departure Date']")
   private WebElement departureDateTextInput;

   @FindBy(css = "input[name='Departure Date']")
   private WebElement destinationDateTextInput;

   public HeaderComponent()
   {
      clOverlayComp = new CountryLannguageSelectorComponent();
   }

   public WebElement getQuestionsLabel()
   {
      return questionsLabel;
   }

   public WebElement getTuiFlyLogoIcon()
   {
      return tuiFlyLogoIcon;
   }

   public WebElement getShortlistIcon()
   {
      return shortlistIcon;
   }

   public WebElement getAccountBookingIcon()
   {
      return accountBookingIcon;
   }

   public WebElement getCheckinLabel()
   {
      return checkinLabel;
   }

   public WebElement getFlyAppLabel()
   {
      return flyAppLabel;
   }

   public WebElement getFlightsLabel()
   {
      return flightsLabel;
   }

   public WebElement getPromotionsLabel()
   {
      return promotionsLabel;
   }

   public WebElement getStayLabel()
   {
      return stayLabel;
   }

   public CountryLannguageSelectorComponent getClOverlayComp()
   {
      return clOverlayComp;
   }

   public WebElement getDestinationsLabel()
   {
      return destinationsLabel;
   }

   public WebElement getExtrasLabel()
   {
      return extrasLabel;
   }

   public WebElement getHeaderComp()
   {
      return headerComp;
   }

   public WebElement getTravelInformationLabel()
   {
      return travelInformationLabel;
   }

   public WebElement getAccountBookingLabel()
   {
      return accountBookingLabel;
   }

   public WebElement getBurgerMenu()
   {
      return burgerMenu;
   }

   public WebElement getCountrySwitcherLink()
   {
      return countrySwitcherLink;
   }

   public CountryLannguageSelectorComponent getCountryLangSelectorComp()
   {
      return clOverlayComp;
   }

   public List<String> isSearchPanelDefaultState()
   {
      List<String> searchPanelDefaultList = new ArrayList<>();
      searchPanelDefaultList.add(departureAirportTextInput.getText());
      searchPanelDefaultList.add(destinationAirportTextInput.getText());
      searchPanelDefaultList.add(departureDateTextInput.getText());
      searchPanelDefaultList.add(destinationDateTextInput.getText());
      searchPanelDefaultList.removeAll(Collections.singleton(""));
      return searchPanelDefaultList;
   }

   public WebElement getDepartureAirportTextInput()
   {
      return departureAirportTextInput;
   }

   public List<WebElement> geterrorMessages()
   {
      return searchPanelErrorMessages;
   }

   public List<WebElement> getDisabledDestinationAirports()
   {
      return disabledDestinationAirports;
   }

   public WebElement getCurrentVisibleClearAllButton()
   {
      return WebElementTools.filterVisibleElements(clearAllButtons).get(0);
   }

   public WebElement getSearchPanelSubmitButton()
   {
      return searchPanelSubmitButton;
   }

   public WebElement getFirstDisabledDestinationAirport()
   {
      return WebElementTools.getFirstElement(getDisabledDestinationAirports());
   }

   public WebElement getDepartureAirportBasedOnPosition(Integer elementPosition)
   {
      WebElementTools.javaScriptScrollToElement(availableDepartureAirports.get(elementPosition));
      return availableDepartureAirports.get(elementPosition);
   }

   public WebElement getDestinationAirportBasedOnPosition(Integer elementPosition)
   {
      WebElement destinationAirport = availableDestinationAirports.get(elementPosition);
      WebElementTools.javaScriptScrollToElement(destinationAirport);
      return destinationAirport;
   }

   public WebElement getDestinationAirportTextInput()
   {
      return destinationAirportTextInput;
   }

   public WebElement getPassengerTextInput()
   {
      return passengerTextInput;
   }

   public WebElement getPassangerAdultSelectInput()
   {
      return adultsPassengerSelectInput;
   }

   public WebElement getPassangerChildrenSelectInput()
   {
      return childrenPassengerSelectInput;
   }

   public WebElement getDestinationAirportsDropdownModal()
   {
      return destinationAirportsDropdownModal;
   }

   public WebElement getDepartureAirportsDropdownModal()
   {
      return departureAirportsDropdownModal;
   }

   public WebElement getPassengerTitleDropdownModal()
   {
      return passengerTitleInDropdownModal;
   }

   public WebElement getDepartureAirportsDropdownModalClearAllButton()
   {
      return departureAirportsDropdownModalClearAllButton;
   }

   public WebElement getDepartureAirportsDropdownModalDoneButton()
   {
      return departureAirportsDropdownModalDoneButton;
   }

   public List<String> getDepartureAirportsInDropdownModal()
   {
      airportList = new ArrayList<>();
      availableDestinationAirports.forEach(val -> airportList.add(val.getText()));
      return airportList;
   }

   public List<String> getNearbyAirportsInDropdownModal()
   {
      airportList = new ArrayList<>();
      availableAirports.forEach(val -> airportList.add(val.getText()));
      return airportList;
   }

}
