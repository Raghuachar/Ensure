package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static org.junit.Assert.assertNotNull;

public class PriceBreakDownComponent extends AbstractPage
{
   private final Map<String, WebElement> priceMap;

   public static ThreadLocal<List<String>> discountsTypesApplied = new ThreadLocal<>();

   private final WebElementWait wait;

   @FindBy(css = "[class*='ProgressbarNavigation__IconStyle']")
   public WebElement summaryPageToolTip;

   @FindBy(xpath = "(//div[@class='Standard__tooltiptext']/span)[1]")
   public WebElement extrasPageToolTipText;

   @FindBy(xpath = "(//div[@class='Standard__tooltiptext']/span)[1]")
   public WebElement roomBoardPageToolTipText;

   @FindBy(xpath = "(//div[@class='Standard__tooltiptext']/span[@class])[1]")
   public WebElement passengerDetailsPageToolTipText;

   @FindBy(css = "[class='PriceDiscountBreakDownV2__detailedPriceBreakdownPageLink']")
   public WebElement detailedBreakdownLink;

   @FindBy(css = "[aria-label*='price breakdownV2']")
   private WebElement priceBreakdownComp;

   @FindBy(xpath = "//li[@aria-label='basicholiday']/div/span[2]")
   private WebElement basicHolidayPrice;

   @FindBy(css = "[aria-label*='price breakdownV2'] [class*='perPerson']>span:first-child")
   private WebElement ppPriceText;

   @FindBy(css = "[class='PriceDiscountBreakDownV2__tpDescription']")
   private WebElement totalPriceText;

   @FindBy(css = "[aria-label*='price breakdownV2'] [class*='totalPrice']>span:nth-child(2)")
   private WebElement totalPrice;

   @FindBy(css = "[class*='PriceDiscountBreakDownV2__subtitle']")
   private WebElement Bookingfee;

   @FindBy(css = "[class*='ShowMore__showMoreHighlightedLink']")
   private WebElement Bookingfeelink;

   public PriceBreakDownComponent()
   {
      priceMap = new HashMap<>();
      wait = new WebElementWait();
   }

   public WebElement getTotlPriceElement()
   {
      return wait.getWebElementWithLazyWait(totalPrice);
   }

   public String getTotlPriceValue()
   {
      return WebElementTools.getElementText(getTotlPriceElement());
   }

   public Map<String, WebElement> getPriceBreakdownComps()
   {
      priceMap.put("PRICE BREAKDOWN", priceBreakdownComp);
      priceMap.put("Basic Holiday", basicHolidayPrice);
      priceMap.put("Price Per Person", ppPriceText);
      priceMap.put("TOTAL PRICE", totalPriceText);
      return priceMap;
   }

   public void ClickonBookingFee()
   {
      wait.forJSExecutionReadyLazy();
      Bookingfeelink.click();
   }

   public void DisplayBookingfee()
   {
      wait.forJSExecutionReadyLazy();
      Bookingfee.isDisplayed();
   }

   public void VerifySummarypageTooltip()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(summaryPageToolTip);
      wait.forJSExecutionReadyLazy();
   }

   public String tooltipTextForSummaryPage()
   {
      ElementsCollection spanElements = $$("[role='tooltip'] span");
      SelenideElement firstSpanWithNonArrowClass = spanElements.asFixedIterable().stream()
               .filter(element -> !Objects.equals(element.getAttribute("class"), "Standard__arrow"))
               .findFirst()
               .orElse(null);
      assertNotNull("Impossible to find tooltip text element", firstSpanWithNonArrowClass);
      return firstSpanWithNonArrowClass.getText();
   }

   public String tooltipTextForExtrasPage()
   {
      return $(extrasPageToolTipText).should(Condition.appear).getText();
   }

   public String tooltipTextForRoomBoardPage()
   {
      return $(roomBoardPageToolTipText).should(Condition.appear).getText();
   }

   public String tooltipTextForPassengerDetailsPage()
   {
      return $(passengerDetailsPageToolTipText).should(Condition.appear).getText();
   }

   public void clickOnDetailedBreakdownLink()
   {
      wait.forJSExecutionReadyLazy();
      detailedBreakdownLink.click();
   }

   public void clickShowMoreOfOptionsExtras()
   {
      $(".PriceDiscountBreakDownV2__title + .ShowMore__showMoreWrapper svg")
               .shouldBe(Condition.visible, Duration.ofSeconds(10)).click();
   }

   public List<String> getElementsTexts(ElementsCollection collection)
   {
      List<String> list = new ArrayList<>();
      for (SelenideElement element : collection)
      {
         list.add(element.shouldBe(Condition.visible).getText());
      }
      return list;
   }

   private ElementsCollection getInsuranceProductTitles()
   {
      return $$(".PriceDiscountBreakDownV2__insuranceWrapper span:nth-of-type(1)");
   }

   public List<String> getInsuranceProductTitlesTexts()
   {
      return getElementsTexts(getInsuranceProductTitles());
   }

   private ElementsCollection getInsuranceProductTaxesFees()
   {
      return $$(".PriceDiscountBreakDownV2__insuranceWrapper span:nth-of-type(2)");
   }

   public List<String> getInsuranceProductTaxesFeesTexts()
   {
      return getElementsTexts(getInsuranceProductTaxesFees());
   }

   public Double getInsurancePriceDouble()
   {
      double doubleInsurancePrice = 0.0;
      ElementsCollection insurancePrice =
            $$(".PriceDiscountBreakDownV2__insuranceWrapper div:nth-of-type(2)")
                     .filterBy(Condition.visible).shouldHave(CollectionCondition.sizeGreaterThan(0));
      for (SelenideElement element : insurancePrice)
      {
         doubleInsurancePrice += Double.parseDouble(element.getText().split("€")[1].trim());
      }
      return doubleInsurancePrice;
   }

   public void clickShowMoreOfDiscounts()
   {
      $$(By.xpath("//span[@class='ShowMore__icon']//*[name()='svg']")).first()
               .shouldBe(Condition.visible, Duration.ofSeconds(10)).click();
   }

   public List<String> getDiscountsAppliedToBooking()
   {
      return $$(By.xpath("//div[@class='ShowMore__showMoreWrapper']" +
               "//li/span[not(contains(@class,'PriceDiscountBreakDownV2__right'))]"))
               .filter(Condition.visible).asDynamicIterable().stream().map(SelenideElement::getText)
               .collect(Collectors.toList());
   }
}
