package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageAgentTypeSelectionStepDefs
{
   public final RetailPackageNavigation retailpackagenavigation;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   public PackageAgentTypeSelectionStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @Given("the agent is on the retail passenger details page")
   public void the_agent_is_on_the_retail_passenger_details_page()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();
   }

   @When("they scroll down towards the bottom of this page")
   public void they_scroll_down_towards_the_bottom_of_this_page()
   {
      retailpassengerdetailspage.agentSeletorCompoenent();
   }

   @Then("they will see a new component titled Agent Selector")
   public void they_will_see_a_new_component_titled_Agent_Selector()
   {
      assertThat("will see a new component titled Agent Selector",
               retailpassengerdetailspage.agentSelectorTitle(), is(true));
   }

   @When("they are viewing the Agent Selector component")
   public void they_are_viewing_the_Agent_Selector_component()
   {
      retailpassengerdetailspage.agentSeletorCompoenent();
   }

   @Then("by default Agent should be prepopulated as a radio button selected")
   public void by_default_Agent_should_be_prepopulated_as_a_radio_button_selected()
   {
      assertThat("by default Agent should be prepopulated as a radio button selected",
               retailpassengerdetailspage.agentSelectorChecked(), is(true));
   }

   @Then("will have two options to select via radio button as the following:")
   public void will_have_two_options_to_select_via_radio_button_as_the_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("will have two options to select via radio button",
               retailpassengerdetailspage.agentoneSelector(), is(true));

      assertThat("will have two options to select via radio button",
               retailpassengerdetailspage.agenttwoSelector(), is(true));
   }

   @And("complete the retail booking")
   public void complete_the_retail_booking()
   {
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.userLogout();
   }

}
