package uk.co.tui.cdaf.frontend.utils.parameter_providers.execution;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.agent_types.BussinessType;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.agent_types.PackageType;

@Data
public class Agents
{
   private BussinessType bussinessType;

   private PackageType packageType;

   public static Agents fromString(String input)
   {
      String[] parts = input.split("-");
      int length = parts.length;
      if (length != 2)
      {
         throw new IllegalArgumentException("Invalid input format: " + input);
      }

      Agents agent = new Agents();
      agent.setBussinessType(BussinessType.fromString(parts[0]));
      agent.setPackageType(PackageType.fromString(parts[1]));

      return agent;
   }

   @JsonIgnore
   public String getPackageTypeStr()
   {
      if (packageType == PackageType.H && !this.isB2C())
         return "";
      else
         return "/" + packageType.toString().toLowerCase();

   }

   @JsonIgnore
   public boolean isInhouse()
   {
      return getBussinessType().equals(BussinessType.INHOUSE);
   }

   @JsonIgnore
   public boolean isThirdparty()
   {
      return getBussinessType().equals(BussinessType.THIRD);
   }

   @JsonIgnore
   public boolean isB2C()
   {
      return getBussinessType().equals(BussinessType.B2C);
   }

   @JsonIgnore
   public boolean isFlightPackageType()
   {
      return getPackageType().equals(PackageType.FLIGHT);
   }

   @JsonIgnore
   public boolean isHolidayPackageType()
   {
      return getPackageType().equals(PackageType.H);
   }
}
