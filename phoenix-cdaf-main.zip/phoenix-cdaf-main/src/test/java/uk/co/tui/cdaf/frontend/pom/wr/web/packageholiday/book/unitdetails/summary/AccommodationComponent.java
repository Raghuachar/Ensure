package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AccommodationComponent extends AbstractPage
{
   private final Map<String, WebElement> accomMap;

   private final WebElementWait wait;

   @FindBy(css = "[aria-label='Your accommodation'] h2")
   private WebElement accommodationTitle;

   @FindBy(css = "[class^='Accommodation__copyContainer'] header > h5")
   private WebElement accommodationName;

   @FindBy(css = "[aria-label='Your accommodation'] [aria-label='ratings']")
   private WebElement tuiRating;

   @FindBy(css = "[aria-label='Your accommodation'] [class*='capitalize']")
   private WebElement duration;

   @FindBy(css = "[aria-label='Your accommodation'] [class*='capitalize']+li")
   private WebElement paxDetails;

   @FindBy(css = ".RoomAndBoard__content h4")
   private WebElement roomAndBoardTitle;

   @FindBy(css = ".RoomAndBoard__content .RoomAndBoard__info")
   private List<WebElement> roomCategory;

   @FindBy(css = ".Accommodation__details>li:first-child")
   private WebElement destinationName;

   @FindBy(css = ".Accommodation__details>li:first-child")
   private WebElement changeRoomAnBoardLink;

   public AccommodationComponent()
   {
      accomMap = new HashMap<>();
      wait = new WebElementWait();
   }

   public Map<String, WebElement> getAccomodationComponents()
   {
      accomMap.put("YOUR ACCOMMODATION", accommodationTitle);
      accomMap.put("Accommodation Name", accommodationName);
      accomMap.put("TUI Rating", tuiRating);
      accomMap.put("Number of Nights Stay", duration);
      accomMap.put("Number of People on Booking", paxDetails);
      accomMap.put("ROOM & BOARD", roomAndBoardTitle);
      accomMap.put("Room Category", roomCategory.get(1));
      accomMap.put("Package Destination Name", destinationName);
      accomMap.put("Change room or board link", changeRoomAnBoardLink);
      return accomMap;
   }

   public String getAccommodationdetails()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(accommodationName);
   }

}
