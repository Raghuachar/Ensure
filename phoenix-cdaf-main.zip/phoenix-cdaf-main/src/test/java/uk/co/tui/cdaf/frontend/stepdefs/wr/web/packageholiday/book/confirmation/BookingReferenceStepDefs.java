package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.confirmation;

import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.confirmation.BookingReferenceComponent;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class BookingReferenceStepDefs
{

   public final BookingReferenceComponent bookingReferenceComponent;

   public BookingReferenceStepDefs()
   {
      bookingReferenceComponent = new BookingReferenceComponent();
   }

   @Then("they will able to see twelve digit booking reference")
   public void they_will_able_to_see_twelve_digit_booking_reference()
   {
      if (bookingReferenceComponent.getBookingNumber().length() >= 12)
      {
         assertThat("Booking Reference is Not Displayed",
                  bookingReferenceComponent.isBookingNumberDisplayed(), is(true));
      }
      else
      {
         assertThat("Booking Reference is Not Displayed",
                  bookingReferenceComponent.isBookingNumberDisplayed(), is(false));
      }
   }
}
