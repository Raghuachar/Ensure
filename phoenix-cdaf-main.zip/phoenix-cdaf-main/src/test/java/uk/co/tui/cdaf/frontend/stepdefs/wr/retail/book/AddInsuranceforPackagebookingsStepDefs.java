package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.AddInsuranceforPackagebookingsComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class AddInsuranceforPackagebookingsStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation = new RetailPackageNavigation();

   private final RetailPassengerDetailsPage retailpassengerdetailspage =
            new RetailPassengerDetailsPage();

   private final AddInsuranceforPackagebookingsComponents addInsuranceforPackagebookingsComponents =
            new AddInsuranceforPackagebookingsComponents();

   @Given("the agent is on package extras options page")
   public void the_agent_is_on_package_extras_options_page()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToSummaryPage();
      addInsuranceforPackagebookingsComponents.insuranceTypeselectButton();
   }

   @When("they select the insurance on package extras options page")
   public void they_select_the_insurance_on_package_extras_options_page()
   {
      retailpassengerdetailspage.addPackageInsurance();
   }

   @Then("insurance should be selected on package extras options page")
   public void insurance_should_be_selected_on_package_extras_options_page()
   {
      retailpassengerdetailspage.selectContinueSummary();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }

   @Given("the agent is on package summary options page")
   public void the_agent_is_on_package_summary_options_page()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToSummaryPage();
   }

   @When("they upgrade the seat on package summary options page")
   public void they_upgrade_the_seat_on_package_summary_options_page()
   {
      retailpassengerdetailspage.seatUpgardePkg();
   }

   @Then("the seat should be upgraded on package summary options page")
   public void the_seat_should_be_upgraded_on_package_summary_options_page()
   {
      retailpassengerdetailspage.selectContinueSummary();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }

   @When("they upgrade the baggage on package summary options page")
   public void they_upgrade_the_baggage_on_package_summary_options_page()
   {
      retailpassengerdetailspage.upgradeBaggagePkg();
   }

   @Then("the baggage should be upgraded on package summary options page")
   public void the_baggage_should_be_upgraded_on_package_summary_options_page()
   {
      retailpassengerdetailspage.selectContinueSummary();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }
}
