package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class InsuranceAndExtrasComponent extends AbstractPage
{
   private final Map<String, WebElement> insuranceMap;

   private final WebElementWait wait;

   @FindBy(css = "div[class^='InsuranceType'] h3[aria-label^='Insurance']")
   List<WebElement> CCInsuranceoption;

   @FindBy(css = "[aria-label*='Insurance Type'] button")
   private WebElement chooseInsuranceButton;

   @FindBy(css = "[aria-label*='Insurance Type'] button")
   private WebElement changeInsuranceLink;

   @FindBy(css = "[aria-label*='Insurance component'] p[class*='insuranceContent']")
   private WebElement insuranceContent;

   @FindBy(css = "[aria-label*='Insurance component'] h2")
   private WebElement insuranceHeadingText;

   @FindBy(css = "[class$=selectedIndicator]")
   private WebElement dontNeedInsurance;

   @FindBy(xpath = "(//*[@class='inputs__checkIcon'])[1]")
   private WebElement checkpassenger1;

   @FindBy(css = "span[class$=selected]")
   private WebElement noInsuranceOpted;

   @FindBy(css = "[class*='multiselectInsurancesList'] [class*='insuranceTitle']")
   private List<WebElement> selectedMultiInsuranceList;

   public InsuranceAndExtrasComponent()
   {
      insuranceMap = new HashMap<>();
      wait = new WebElementWait();
   }

   public void clickOnBackToVacationButton()
   {
      $(".BackToYourHolidayButtonComponent__backButtonClass")
               .shouldBe(Condition.visible).click();
   }

   public void clickOnChooseInsurance()
   {
      $(shadowDeepCss("[aria-label*='Insurance Type']")).$("button")
               .shouldBe(Condition.visible, Duration.ofSeconds(30))
               .scrollIntoView("{block: \"center\"}")
               .click();
   }

   public void clickOnChangeInsuranceoption()
   {
      WebElementTools.click(CCInsuranceoption.get(1));
   }

   public void selectpassengerforinsurance()
   {
      WebElementTools.click(checkpassenger1);
   }

   public Map<String, WebElement> getInsuranceComponents()
   {
      insuranceMap.put("INSURANCE", insuranceHeadingText);
      insuranceMap.put("Insurance Text", insuranceContent);
      insuranceMap.put("Yes to Insurance", chooseInsuranceButton);
      insuranceMap.put("No to Insurance Option", dontNeedInsurance);
      insuranceMap.put("Change Insurance Link", changeInsuranceLink);
      return insuranceMap;
   }

   public boolean noInsuranceOpted()
   {
      return WebElementTools.isPresent(noInsuranceOpted);
   }

   public boolean isMultiInsuranceSelected()
   {
      wait.forJSExecutionReadyLazy();
      return !selectedMultiInsuranceList.isEmpty();
   }

   public List<SelenideElement> titles()
   {
      return $$(".InsuranceAndExtras__insuranceTitle");
   }

   public List<String> getSelectedInsuranceTitlesText()
   {
      List<String> insTitles = new ArrayList<>();
      for (SelenideElement title : titles())
      {
         insTitles.add(title.getText());
      }
      return insTitles;
   }

   public void clickSelectOfIDontNeedInsuranceSection()
   {
      $("button[class*='InsuranceType__selectButton']").click();
   }
}
