package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.wr.retail.AddInsuranceforPackagebookingsComponents;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.utils.ConfigurationService;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import static uk.co.tui.cdaf.utils.ConfigurationConstants.RETAIL_WR_TP_AGENTBEID;
import static uk.co.tui.cdaf.utils.ConfigurationConstants.RETAIL_WR_TP_AGENTNLID;
import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class RetailPassengerDetailsPage extends AbstractPage
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(RetailPassengerDetailsPage.class);

   private static final String SITE_ID_REGEX = "SiteID\\s*=\\s*\"(.+?)\";";

   public final RetailPage retailPage;

   public final SearchResultsPage searchResultsPage;

   public final UnitDetailsPage unitPage;

   public final SummaryPage summaryPage;

   private final PageErrorHandler pageError;

   private final WebElementWait wait;

   private final WebDriverUtils utils;

   private final RetailPassengerForm passengerForm;

   private final SearchPanel searchPanel = getSearchPanel();

   private final AddInsuranceforPackagebookingsComponents addInsuranceforPackagebookingsComponents;

   @FindBy(css = ".GenderField__selectListBox label")
   private List<WebElement> genderTitle;

   @FindAll({ @FindBy(css = "[class*='selectOption'].inputs__selectDropdown"),
            @FindBy(xpath = "//select[contains(@id,'GENDER')]") })
   private List<WebElement> genderDropdown;

   @FindBy(css = ".GenderField__selectListBox label")
   private List<WebElement> genderDropdownoptions;

   @FindBy(xpath = "//input[contains(@name,'firstName')]")
   private List<WebElement> firstName;

   @FindBy(css = "[for*='FIRSTNAMEADULT']")
   private List<WebElement> firstNameTitle;

   @FindAll({ @FindBy(xpath = "//input[contains(@name,'lastName')]"),
            @FindBy(xpath = "//input[contains(@name,'surName')]") })
   private List<WebElement> lastName;

   @FindBy(css = "[for*='SURNAMEADULT']")
   private List<WebElement> surNameTitle;

   @FindAll({ @FindBy(css = "[name='address1']"), @FindBy(css = "[name*='address1']") })
   private WebElement addressLine1;

   @FindAll({ @FindBy(css = "[name='town']"), @FindBy(css = "[name*='town']") })
   private WebElement city;

   @FindBy(css = "[name='houseNum']")
   private WebElement houseNum;

   @FindAll({ @FindBy(css = "[name='postCode']"), @FindBy(css = "[name*='postCode']") })
   private WebElement postcode;

   // FIXME: for some reason the phone is not getting cleared
   // @FindAll({ @FindBy(css = "[aria-label='telephone number']"), @FindBy(css = "[name='mobileNum']"),
   //          @FindBy(css = "[name*='mobileNum']") })
   @FindAll({ @FindBy(css = "[aria-label='telephone number']"),
            @FindBy(css = "[name*='mobileNum']") })
   private List<WebElement> telephone;

   @FindAll({ @FindBy(css = "[aria-label='E-mailadres'] label"),
            @FindBy(css = ".FieldMapper__MOBILENUMBER"),
            @FindBy(css = ".SelectField__selectListBox label") })
   private List<WebElement> telephoneNumberTitle;

   @FindAll({ @FindBy(css = "[name='email']"), @FindBy(css = "[name*='email']") })
   private WebElement email;

   @FindAll({ @FindBy(css = "[aria-label='E-mailadres'] label"),
            @FindBy(css = "[for='EMAILADDRESSADULT1']"), @FindBy(css = "[id*='EMAILADDRESSADULT']"),
            @FindBy(css = ".TextField__inputTextBox .inputs__textInput label[for*='EMAILADDRESSADULT1']") })
   private WebElement emailAddressTitle;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'ADULT')]//*[@placeholder='YYYY']"),
            @FindBy(css = ".ADULT [placeholder='YYYY']"),
            @FindBy(css = ".DateInput__field input[aria-label='year']"),
            @FindBy(css = ".DateInput__field input[placeholder='YYYY']"),
            @FindBy(css = "[aria-label*='Adult'] [placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'VOLWASSENE')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'ADULT')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']") })
   private List<WebElement> adultDOBYear;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'ADULT')]//*[@placeholder='MM']"),
            @FindBy(css = ".ADULT [placeholder='MM']"),
            @FindBy(css = ".DateInput__field input[aria-label='month']"),
            @FindBy(css = ".DateInput__field input[placeholder='MM']"),
            @FindBy(css = "[aria-label*='Adult'] [placeholder='MM']"),
            @FindBy(xpath = "//h3[contains(text(),'VOLWASSENE')]/../../../../following-sibling::div[1]//*[@placeholder='MM']"),
            @FindBy(xpath = "//h3[contains(text(),'ADULT')]/../../../../following-sibling::div[1]//*[@placeholder='MM']") })
   private List<WebElement> adultDOBMonth;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'ADULT')]//*[@placeholder='DD']"),
            @FindBy(css = ".ADULT [placeholder='DD']"),
            @FindBy(css = ".DateInput__field input[aria-label='day']"),
            @FindBy(css = ".DateInput__field input[placeholder='DD']"),
            @FindBy(css = "[aria-label*='Adult'] [placeholder='DD']"),
            @FindBy(xpath = "//h3[contains(text(),'VOLWASSENE')]/../../../../following-sibling::div[1]//*[@placeholder='DD']"),
            @FindBy(xpath = "//h3[contains(text(),'ADULT')]/../../../../following-sibling::div[1]//*[@placeholder='DD']") })
   private List<WebElement> adultDOBDate;

   @FindAll({ @FindBy(xpath = "//div[contains(@aria-label,'CHILD')]//*[@placeholder='YYYY']"),
            @FindBy(css = ".CHILD [placeholder='YYYY']"),
            @FindBy(xpath = "//*[@placeholder='YYYY']"),
            @FindBy(css = ".inputs__textInput input[placeholder='YYYY']"),
            @FindBy(css = ".DateOfBirth__inputTextBox input[aria-label='year']"),
            @FindBy(css = "[aria-label*='Child'] [placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'KIND') or contains(text(),'KIND')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']"),
            @FindBy(xpath = "//h3[contains(text(),'CHILD') or contains(text(),'Child')]/../../../../following-sibling::div[1]//*[@placeholder='YYYY']") })
   private List<WebElement> childDOBYear;

   @FindAll({ @FindBy(css = "[aria-label='important information'] [aria-label='checkbox']"),
            @FindBy(css = ".NordicsImportantInformation__content [aria-label='checkbox']") })
   private WebElement importantInfoCheckbox;

   @FindBy(css = ".InsuranceTermsAndconditions__contentIns [aria-label='checkbox']")
   private WebElement insuranceImportantInfoCheckbox;

   @FindAll({ @FindBy(css = ".ContinueAndBackBlock__continue button"),
            @FindBy(css = ".ContinueAndBackBlock__continue a"),
            @FindBy(css = ".ContinueAndBackBlock__continue a"), @FindBy(css = ".buttons__button"),
            @FindBy(css = ".buttons__button"), @FindBy(css = ".buttons__button.buttons__primary"),
            @FindBy(xpath = "//a[@href='/retail/nl/book/passengerdetails']"),
            @FindBy(css = ".buttons__button.buttons__primary.buttons__fill") })
   private WebElement continueBacktopassengerdetails;

   @FindAll({ @FindBy(css = ".ContinueButton__continue a button"),
            @FindBy(css = ".HubAndSpokeNavigation__summaryButton button"),
            @FindBy(css = ".ProgressbarNavigation__pricePanelWrapper button"),
            @FindBy(css = ".PriceDiscountBreakDownV2__continue button") })
   private WebElement continueButton;

   @FindAll({ @FindBy(css = ".ProgressbarNavigation__summaryButton button"),
            @FindBy(css = ".PriceDiscountBreakDownV2__continue button") })
   private WebElement continueSummaryButton;

   /* add fee */
   @FindBy(css = ".UI__PriceBreakDownChevronSection")
   private WebElement priceoverviewButton;

   @FindAll({ @FindBy(css = ".UI__agentInfoChevronSection a"),
            @FindBy(css = ".HighlightedLink__text") })
   private List<WebElement> agentInformation;

   @FindBy(css = ".UI__feesReason .inputs__selectList select")
   private WebElement feetypedropdown;

   @FindAll({ @FindBy(xpath = "(//div[@class='UI__navigationTab']//li)[2]"),
            @FindBy(xpath = "//ul[@class='UI__wrapper']/li[(not(contains(@class,'UI__current')))]") })
   private WebElement discounttab;

   @FindBy(css = ".UI__discountReason select")
   private WebElement discounttypedropdown;

   @FindAll({ @FindBy(css = ".UI__total .UI__price"), @FindBy(xpath = "//*[@class='UI__total']") })
   private WebElement gettotprice;

   @FindAll({ @FindBy(xpath = "//input[@name='AmountInputField']"),
            @FindBy(xpath = "//div[@class='UI__amountInputBox']/input']") })
   private WebElement EnterDiscount;

   @FindAll({ @FindBy(xpath = "//input[@name='AmountInputField']"),
            @FindBy(xpath = "//div[@class='UI__amountInputBox']/input']") })
   private WebElement programchangebookref;

   @FindBy(xpath = "//input[@name='AmountInputField']")
   private WebElement EnterFee;

   @FindBy(css = ".UI__textarea")
   private WebElement addremarks;

   @FindBy(css = ".UI__applyFees button")
   private WebElement Applyfee;

   @FindBy(css = ".UI__applyDiscount button")
   private WebElement Applydiscount;

   @FindBy(css = ".UI__errorMessageColor")
   private WebElement discounterror;

   @FindAll({ @FindBy(css = ".UI__skipPaymentsWrapper"), @FindBy(css = ".UI__container a") })
   private WebElement skipPaymentslink;

   @FindBy(css = ".TransferAndExtras__transferSection")
   private WebElement scrolltoinsurance;

   @FindAll({ @FindBy(xpath = "(//button[@class='popups__primary'])[2]"),
            @FindBy(css = ".popups__primary") })
   private List<WebElement> actionapply;

   @FindAll({ @FindBy(xpath = "(//span[@class='RetailHeader__agencyDisplayFormat'])[2]"),
            @FindBy(css = ".RetailHeader__retailHeader .RetailHeader__agencyDisplayFormat"),
            @FindBy(css = ".RetailHeader__retailHeader a") })
   private List<WebElement> changeagentlink;

   @FindAll({ @FindBy(xpath = "//button[text()='Search']"),
            @FindBy(css = ".SearchModal__modalContent button") }) // 2
   private List<WebElement> searchagent;

   @FindBy(css = ".StandardLink__standardLink.StandardLink__primary") // 2
   private WebElement selectagent;

   @FindBy(css = ".inputs__outer input[type='cashPayer']")
   private WebElement cashPayer;

   @FindBy(xpath = "//input[@name='paymentAmt']")
   private WebElement depositPrice;

   @FindBy(css = ".UI__addPayment")
   private WebElement addPayment;

   @FindAll({ @FindBy(css = ".BookingReference__referenceID"),
            @FindBy(css = ".BookingReference__bookingReference span"),
            @FindBy(xpath = "//div[@class='BookingReference__bookingReference']//span") })
   private WebElement BookingReference;

   @FindBy(css = ".RetailHeader__logout")
   private WebElement logoutlink;

   @FindBy(css = ".InsuranceAndExtras__insuranceBorder .sections__level3")
   private WebElement insurancethirdparty;

   @FindAll({ @FindBy(xpath = "(//button[@class='popups__primary'])[2]"),
            @FindBy(css = "[aria-label='action close']"),
            @FindBy(css = "footer .popups__primary") })
   private WebElement confirmlogout;

   @FindBy(css = ".Logo__siteLogo a")
   private WebElement tuilogo;

   @FindBy(css = ".UI__information a")
   private WebElement tncLink;

   @FindBy(css = ".UI__agentSelectorWrap")
   private WebElement agentSelectorCompnent;

   @FindBy(css = ".UI__agentSelectorWrap h3")
   private WebElement agentSelectorTitle;

   @FindBy(css = ".UI__agentSelectorWrap .inputs__radioButton")
   private List<WebElement> agentSelectorChecked;

   @FindBy(css = ".UI__agentSelectorWrap .inputs__radioButton")
   private List<WebElement> retailagents;

   @FindBy(css = ".UI__continue button")
   private WebElement paymentcta;

   @FindBy(css = ".UI__priceDescription")
   private List<WebElement> priceDescription;

   @FindAll({ @FindBy(css = ".SelectDate__available "),
            @FindBy(css = ".SelectLegacyDate__calendar .SelectLegacyDate__available") })
   private List<WebElement> selectdate;

   @FindBy(css = ".inputs__checkBox")
   private List<WebElement> selectinsurancepax;

   @FindAll({ @FindBy(css = ".GetQuoteV2__getQuote button"),
            @FindBy(css = ".GetQuoteV2__wrapper .GetQuoteV2__getQuote button"),
            @FindBy(css = ".GetQuoteV2__wrapper button") })
   private WebElement getQuoteinsurance;

   @FindBy(css = ".InsuranceType__collapsibleIcon")
   private WebElement InsuranceTypeaccordion;

   @FindBy(css = ".PerPersonSelectList__checkbox")
   private List<WebElement> selectinsurance;

   @FindBy(css = ".cards__third .buttons__button.buttons__senary.buttons__fill")
   private List<WebElement> upgradeBaggagePkg;

   @FindBy(css = "View3__circle")
   private List<WebElement> seatUpgarde;

   @FindBy(css = "#paymentForm > div.UI__paymentTypeCash > div.UI__cashDetails > div > div:nth-child(1) > div > span.inputs__errorMessage")
   private WebElement PayerErrorMessege;

   @FindBy(xpath = "//span[text()='Debit/Credit Card']")
   private WebElement creditcarddebittype;

   @FindAll({
            @FindBy(css = "(//button[@class='popups__primary'])[2].ContinueButton__ctaContainer  button"),
            @FindBy(css = ".ContinueButton__ctaContainer .ContinueButton__continue, .ContinueButton__ctaContainer .ContinueButton__vipButton"),
            @FindBy(css = ".ContinueButton__ctaContainer .ContinueButton__continue button") })
   private WebElement makePaymentText;

   @FindBy(css = ".LanguageCountrySelector__countrySwitcher button")
   private WebElement languageCountrySelector;

   @FindBy(css = ".SelectDropdown__large")
   private List<WebElement> languageCountrySelectordropdown;

   @FindBy(css = ".SelectDropdown__selectdropdown .SelectDropdown__option")
   private List<WebElement> languageCountrySelectDropdownption;

   public RetailPassengerDetailsPage()
   {
      pageError = new PageErrorHandler();
      wait = new WebElementWait();
      unitPage = new UnitDetailsPage();
      summaryPage = new SummaryPage();
      utils = new WebDriverUtils();
      passengerForm = new RetailPassengerForm();
      retailPage = new RetailPage();
      searchResultsPage = new SearchResultsPage();
      addInsuranceforPackagebookingsComponents = new AddInsuranceforPackagebookingsComponents();
   }

   public WebElement getTPagent()
   {
      return changeagentlink.get(2);
   }

   public void navigateToSearchResultPage()
   {
      BrowserCookies.closePrivacyPopUp();
      searchPanel.searchDefaults();
      pageError.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToUnitDetailsPage()
   {
      navigateToSearchResultPage();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      pageError.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   public void navigateToSummaryPage()
   {
      navigateToUnitDetailsPage();
      wait.forJSExecutionReadyLazy();
      unitPage.progressbarComponent.clickOnContinueButton();
      pageError.isPageLoadingCorrectly();
   }

   public void navigateToPassengerPage()
   {
      navigateToSummaryPage();
      wait.forJSExecutionReadyLazy();
      summaryPage.navigationComponent.clickOnContinueButton();
      pageError.isPageLoadingCorrectly();
   }

   public void fillThePassengerDetailsInhouse()
   {
      enterFirstName();
      enterLastName();
      selectGender();
      enterAdultDOB();
      enterHouseNumber();
      enterAdressAndContactWR();
      selectImportantInfoCheckbox();
      selectContinueBookingWR();
   }

   public void fillThePassengerDetailsThirdparty()
   {
      enterFirstName();
      enterLastName();
      selectGender();
      enterAdultDOB();
      enterContacTPWR();
      selectImportantInfoCheckbox();
      selectContinueBookingWR();
   }

   public void fillRetailPassengerDetails()
   {
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getAgent().isThirdparty())
      {
         fillThePassengerDetailsThirdparty();
      }
      else if (ExecParams.getAgent().isInhouse())
      {
         fillThePassengerDetailsInhouse();
      }
      else
      {
         fail("Incorrect URL. Test should be executed with B2B params: " + ExecParams.getTestExecutionParams()
                  .getUrl());
      }
      wait.forJSExecutionReadyLazy();
   }

   public void fillThePassengerDetailsForAddFeeType()
   {
      selectGender();
      enterFirstName();
      enterLastName();
      enterAdultDOB();
      enterHouseNumber();
      enterAdressAndContactWR();
      wait.forJSExecutionReadyLazy();
      selectImportantInfoCheckbox();
   }

   public void fillRetailPassengerDetailsPriceBreakdown()
   {
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getAgent().isThirdparty())
         fillThePassengerDetailsForTPPriceBreakdown();
      if (ExecParams.getAgent().isInhouse())
         fillThePassengerDetailsForAddFeeType();
      wait.forJSExecutionReadyLazy();
   }

   public void fillThePassengerDetailsForTPPriceBreakdown()
   {
      enterFirstName();
      enterLastName();
      selectGender();
      enterAdultDOB();
      enterContacTPWR();
      wait.forJSExecutionReadyLazy();
      selectImportantInfoCheckbox();
   }

   public void enterContacTPWR()
   {
      enterPhones();
      WebElementTools.enterText(email, passengerForm.email);
   }

   private void enterPhones()
   {
      telephone.stream().map(Selenide::$).forEach(phone ->
      {
         phone.sendKeys(Keys.chord(Keys.CONTROL, "a"));
         phone.sendKeys(Keys.BACK_SPACE);
         phone.setValue(getTelephoneNum());
      });
   }

   public void enterAdressAndContactWR()
   {
      WebElementTools.enterText(addressLine1, passengerForm.address1);
      WebElementTools.enterText(city, passengerForm.city);
      WebElementTools.enterText(postcode, getPostCode());
      enterPhones();
      WebElementTools.enterText(email, passengerForm.email);
   }

   public void selectGender()
   {
      wait.forJSExecutionReadyLazy();
      try
      {
         genderDropdown.forEach(dropDown ->
         {
            WebElementTools.scrollToCenter(dropDown);
            WebElementTools.clickElementJavaScript(dropDown);
            wait.forJSExecutionReadyLazy();
            List<WebElement> dropDownOptions = dropDown.findElements(By.tagName("option"));
            Random rand = new Random();
            int index = rand.nextInt(dropDownOptions.size() - 1) + 1;
            WebElement dropDownElement = dropDownOptions.get(index);
            String dropDownText = WebElementTools.getElementText(dropDownElement);
            if (dropDownText.equals("MALE") || dropDownText.equals("FEMALE"))
            {
               WebElementTools.click(dropDownOptions.get(1));
            }
            else
            {
               WebElementTools.click(dropDownElement);
            }
         });
      }
      catch (Exception e)
      {
         LOGGER.log("Could not select genderDropdown value");
         LOGGER.log(LogLevel.ERROR, e.getMessage());
      }
   }

   public SelenideElement marketingPermissions()
   {
      return $(".MarketingPermissions__infoText p span");
   }

   public WebElement getGenderTitle()
   {
      return genderTitle.get(1);
   }

   public WebElement getFirstnameTitle()
   {
      return firstNameTitle.get(1);
   }

   public WebElement getSurnameTitle()
   {
      return surNameTitle.get(1);
   }

   public WebElement getEmailAddressTitle()
   {
      return emailAddressTitle;
   }

   public WebElement getTelephoneNumberTitle()
   {
      return telephoneNumberTitle.get(1);
   }

   public void skippayment()
   {
      skippaymentCTA();
      BrowserCookies.feedbackPopUp();
      LOGGER.log(LogLevel.INFO, "Booking ref: " + getBookingNumber());
   }

   public boolean isSkippaymentCTAPresent()
   {
      return WebElementTools.isPresent(skipPaymentslink);
   }

   public String retailPayment()
   {
      assertFalse("Incorrect Agent used for this test", ExecParams.getAgent().isB2C());
      if (ExecParams.getAgent().isInhouse())
      {
         skippaymentCTA();
      }
      BrowserCookies.feedbackPopUp();
      String bookingNumber = getBookingNumber();
      LOGGER.log(LogLevel.INFO, "Booking ref: " + bookingNumber);
      return bookingNumber;
   }

   @NotNull
   private String getBookingNumber()
   {
      return $(BookingReference).should(Condition.appear, Duration.ofSeconds(15)).getText();
   }

   public void partialpayment()
   {
      WebElementTools.click(cashPayer);
      WebElementTools.enterText(cashPayer, "cashPayer");
      WebElementTools.mouseHover(addPayment);
      WebElementTools.click(addPayment);
      WebElementTools.enterText(depositPrice, "100");
      WebElementTools.mouseHover(addPayment);
      WebElementTools.click(addPayment);
      selectContinueBookingWR();
      LOGGER.log(LogLevel.INFO, "Country selected as: " + BookingReference);
   }

   public void retailPartialPayment()
   {
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getAgent().isThirdparty())
         LOGGER.log(LogLevel.INFO, "No Payment for Thirdparty");
      BrowserCookies.feedbackPopUp();
      wait.forShown(BookingReference);
      LOGGER.log(LogLevel.INFO, "Country selected as: " + BookingReference);
      if (ExecParams.getAgent().isInhouse())
         partialpayment();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
   }

   public void passengerDetailisDisplayed()
   {
      assertThat("firstName is dispalyed", WebElementTools.isPresent(firstName.get(1)), is(true));
      assertThat("lastName is dispalyed", WebElementTools.isPresent(genderDropdownoptions.get(1)),
               is(true));
   }

   public void passengeraddressisnotDisplayed()
   {
      assertThat("housenumber is not dispalyed", WebElementTools.isPresent(houseNum), is(true));
      assertThat("postcode is not dispalyed", WebElementTools.isPresent(postcode), is(true));
   }

   public void selectImportantInfoCheckbox()
   {
      wait.forClickable(importantInfoCheckbox);
      WebElementTools.clickElementJavaScript(importantInfoCheckbox);
      if (WebElementTools.isPresent(insuranceImportantInfoCheckbox))
         WebElementTools.clickElementJavaScript(insuranceImportantInfoCheckbox);
   }

   public void selectContinueBookingWR()
   {
      $("div.ContinueButtonV2__continueBottom").$("button")
               .should(Condition.appear, Duration.ofSeconds(60))
               .scrollTo()
               .click();
   }

   public void selectContinueSummary()
   {
      $(continueSummaryButton)
               .should(Condition.appear, Duration.ofSeconds(10))
               .scrollTo()
               .click();
   }

   public void enterFirstName()
   {
      firstName.forEach(name ->
      {
         name.clear();
         WebElementTools.enterText(name, RandomStringUtils.random(8, true, false));
      });
   }

   public void enterLastName()
   {
      lastName.forEach(name ->
      {
         name.clear();
         WebElementTools.enterText(name, passengerForm.lName);
      });
   }

   public void enterHouseNumber()
   {
      WebElementTools.enterText(houseNum, passengerForm.houseNum);
   }

   public String getTelephoneNum()
   {
      String siteId = utils.findTagValue(getDriver().getPageSource(), SITE_ID_REGEX);
      if (StringUtils.containsIgnoreCase(siteId, "dk"))
      {
         return "10" + RandomStringUtils.random(6, false, true);
      }
      else if (StringUtils.containsIgnoreCase(siteId, "fi"))
      {
         return "012" + RandomStringUtils.random(6, false, true);
      }
      else if (StringUtils.containsIgnoreCase(siteId, "no"))
      {
         return "41" + RandomStringUtils.random(6, false, true);
      }
      else
      {
         return "0123" + RandomStringUtils.random(6, false, true);
      }
   }

   public String getPostCode()
   {
      TestExecutionParams testParams = ExecParams.getTestExecutionParams();
      if (testParams.isBE())
         return "1" + RandomStringUtils.random(3, false, true);
      else if (testParams.isNL())
         return "1" + RandomStringUtils.random(3, false, true) + "AB";
      else if (testParams.isFR())
         return "0" + RandomStringUtils.random(5, false, true);
      else
         return "1" + RandomStringUtils.random(3, false, true);
   }

   public void enterAdultDOB()
   {
      try
      {
         for (int i = 0; i < adultDOBYear.size(); i++)
         {
            wait.forJSExecutionReadyLazy();
            final String previousValue =
                     WebElementTools.getElementAttribute(adultDOBYear.get(i), "value");
            if (previousValue.isEmpty())
            {
               WebElementTools.enterText(adultDOBYear.get(i), "1980");
               WebElementTools.enterText(adultDOBMonth.get(i), "01");
               WebElementTools.enterText(adultDOBDate.get(i), "01");
               LOGGER.log("Adult DOB Value entered: " + "01/" + "01/" + "1980");
            }
         }
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, "Error in entering the adult DOB:" + e);
      }
   }

   public String getSkippaymenttext()
   {
      return WebElementTools.getElementText(skipPaymentslink);
   }

   public void skippaymentCTA()
   {
      $(".UI__skipPaymentsWrapper, .UI__container a").click();
   }

   public void skippaymentbookingconfirmation()
   {
      LOGGER.log(LogLevel.INFO, "Booking ref: " + WebElementTools.getElementText(BookingReference));
   }

   public void expandPriceBreakdown()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(priceoverviewButton);
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(priceoverviewButton);
      wait.forJSExecutionReadyLazy();
   }

   public void addFeeType()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(priceoverviewButton);
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(priceoverviewButton);
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(agentInformation.get(1));
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(agentInformation.get(1));
      wait.forJSExecutionReadyLazy();
   }

   public void selectFeetype()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(feetypedropdown);
      Select dropdown = new Select(feetypedropdown);
      wait.forJSExecutionReadyLazy();
      dropdown.selectByIndex(2);

   }

   public void calamiteitenfondstype()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(feetypedropdown);
      Select dropdown = new Select(feetypedropdown);
      dropdown.selectByVisibleText("Calamiteitenfonds");
   }

   public void discounttabclick()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(discounttab);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(discounttab);
   }

   public void selectDiscounttype()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(discounttypedropdown);
      Select dropdown = new Select(discounttypedropdown);
      dropdown.selectByIndex(1);
   }

   public void selectProgramChnage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(discounttypedropdown);
      Select dropdown = new Select(discounttypedropdown);
      wait.forJSExecutionReadyLazy();
      dropdown.selectByVisibleText("Programme Change");
   }

   public void addFee()
   {
      selectFeetype();
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(EnterFee, "100");
      WebElementTools.enterText(addremarks, "updated price");
      WebElementTools.click(Applyfee);
   }

   public void calamiteitenfonds()
   {
      calamiteitenfondstype();
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(EnterFee, "100");
      WebElementTools.enterText(addremarks, "updated price");
      WebElementTools.click(Applyfee);
      selectContinueBookingWR();
   }

   public void addDiscountlessthantotal()
   {
      String totprc = WebElementTools.getElementText(gettotprice).replace("€", "");
      double totprice = Double.parseDouble(totprc);
      int i = 1;
      double tprice = totprice - i;
      String totalprice = Double.toString(tprice);
      WebElementTools.enterText(EnterDiscount, totalprice);
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(addremarks, "updated discount");
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(Applydiscount);
   }

   public void addProgramChnageAmount()
   {

      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(programchangebookref, "100");
      WebElementTools.enterText(addremarks, "Program Chnage Amount");
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(Applydiscount);
   }

   public void addDiscountmorethantotal()
   {
      String totprc = WebElementTools.getElementText(gettotprice).replace("€", "");
      double totprice = Double.parseDouble(totprc);
      int i = 1;
      double tprice = totprice + i;
      String totalprice = Double.toString(tprice);
      WebElementTools.enterText(EnterDiscount, totalprice);
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(addremarks, "updated discount");
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(Applydiscount);
   }

   public String getdiscountErrMsg()
   {
      return WebElementTools.getElementText(discounterror);
   }

   public void nextCustomer()
   {
      $x("//span[@aria-label='next customer link']").should(Condition.appear).scrollTo().click();
      $("div.RetailHeader__nextCustomerText").parent().$("button[aria-label='action close']")
               .click();
   }

   public void nextCustomerButton()
   {
      $("div.PaymentDetails__nextCustomer").$("button").should(Condition.appear).scrollTo().click();
   }

   public void scrollToInsurence()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(scrolltoinsurance);
   }

   public void addTPagent()
   {
      RetailPage retailPage = new RetailPage();
      wait.forJSExecutionReadyLazy();
      $(changeagentlink.get(2)).click();
      if (ExecParams.getTestExecutionParams().isBE())
         retailPage.changeagentId(ConfigurationService.getHybrisProperty(RETAIL_WR_TP_AGENTBEID));
      else if (ExecParams.getTestExecutionParams().isNL())
         retailPage.changeagentId(ConfigurationService.getHybrisProperty(RETAIL_WR_TP_AGENTNLID));
      $(searchagent.get(0)).click();
      $(selectagent).click();
   }

   public void userLogout()
   {
      SelenideElement logoutLink = $(".RetailHeader__logout");
      if (logoutLink.isDisplayed())
      {
         logoutLink.click();
         $("div.popups__opened").should(Condition.appear)
                  .$("button.buttons__primary").click();
      }
   }

   public void nlTnCLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(tncLink);
      WebElementTools.click(tncLink);
      wait.forJSExecutionReadyLazy();
      pageError.isPageLoadingCorrectly();
      WebElementTools.closeLastOpenBrowserTab();
   }

   public void returntoHomepage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(tuilogo);
      WebElementTools.click(tuilogo);
      wait.forJSExecutionReadyLazy();

   }

   public boolean defaultAgency()
   {
      RetailPage retailPage = new RetailPage();
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(changeagentlink.get(2));
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getTestExecutionParams().isBE())
      {
         retailPage.changeagentId(ConfigurationService.getHybrisProperty(RETAIL_WR_TP_AGENTBEID));
         return true;
      }
      else if (ExecParams.getTestExecutionParams().isNL())
      {
         retailPage.changeagentId(ConfigurationService.getHybrisProperty(RETAIL_WR_TP_AGENTNLID));
         return true;
      }
      wait.forJSExecutionReadyLazy();
      return false;
   }

   public void agentSeletorCompoenent()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(agentSelectorCompnent);
      WebElementTools.click(agentSelectorCompnent);
   }

   public boolean agentSelectorTitle()
   {
      return WebElementTools.isPresent(agentSelectorTitle);
   }

   public boolean agentSelectorChecked()
   {
      return WebElementTools.isPresent(agentSelectorChecked.get(0));
   }

   public boolean agentoneSelector()
   {
      return WebElementTools.isPresent(retailagents.get(0));
   }

   public boolean agenttwoSelector()
   {
      return WebElementTools.isPresent(retailagents.get(1));
   }

   public boolean enableContinueButtonPKG()
   {
      return WebElementTools.isPresent(paymentcta);
   }

   public boolean detailPriceBreakdown()
   {
      return WebElementTools.isPresent(priceDescription.get(1));
   }

   public void clickOnContinueButton()
   {
      wait.forJSExecutionReadyLazy();
      wait.fluentWaitForWebElement(continueButton);
      WebElementTools.mouseHover(continueButton);
      WebElementTools.click(continueButton);
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
   }

   public void continueBacktoPassengerdetails()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(continueBacktopassengerdetails);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(continueBacktopassengerdetails);
      wait.forJSExecutionReadyLazy();
   }

   public void addInsurance()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(selectinsurancepax.get(0));
      WebElementTools.click(selectinsurancepax.get(0));
   }

   public void addPackageInsurance()
   {
      TestExecutionParams execParams = ExecParams.getTestExecutionParams();
      if (execParams.getAgent().isThirdparty() && execParams.isNL())
      {
         LOGGER.log(LogLevel.INFO, "No Insurance for NL thirdparty ");
      }
      else if (execParams.getAgent().isThirdparty() && execParams.isBE())
      {
         addInsurancePkg();
         enterAdultDOB();
         updatePriceCTA();
         expandInsuranceAccordion();
         selectInsurancePkg();
         addInsuranceforPackagebookingsComponents.backToYourHolidayLinkComponent();
         addInsuranceforPackagebookingsComponents.backToYourHolidayAndConfirm();
      }
      else if (execParams.getAgent().isInhouse())
      {
         addInsurancePkg();
         enterAdultDOB();
         updatePriceCTA();
         expandInsuranceAccordion();
         selectInsurancePkg();
         addInsuranceforPackagebookingsComponents.backToYourHolidayLinkComponent();
         addInsuranceforPackagebookingsComponents.backToYourHolidayAndConfirm();
      }
   }

   public void addInsurancePkg()
   {
      try
      {
         for (int i = 0; i <= selectinsurancepax.size(); i++)
         {
            wait.forJSExecutionReadyLazy();
            WebElementTools.mouseHover(selectinsurancepax.get(i));
            WebElementTools.click(selectinsurancepax.get(i));
         }
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, "Error in entering the adult DOB:" + e);
      }
   }

   public void updatePriceCTA()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(getQuoteinsurance);
      WebElementTools.click(getQuoteinsurance);
      wait.forJSExecutionReadyLazy();
   }

   public void expandInsuranceAccordion()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(InsuranceTypeaccordion);
      WebElementTools.click(InsuranceTypeaccordion);
   }

   public void selectInsurance()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(selectinsurance.get(0));
      WebElementTools.click(selectinsurance.get(0));
   }

   public void selectInsurancePkg()
   {
      try
      {
         for (int i = 0; i <= selectinsurance.size(); i++)
         {
            wait.forJSExecutionReadyLazy();
            WebElementTools.mouseHover(selectinsurance.get(i));
            WebElementTools.click(selectinsurance.get(i));
         }
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, "unable to add insurance" + e);
      }
   }

   public void upgradeBaggagePkg()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(upgradeBaggagePkg.get(0));
      WebElementTools.click(upgradeBaggagePkg.get(0));
      WebElementTools.mouseHover(upgradeBaggagePkg.get(2));
      WebElementTools.click(upgradeBaggagePkg.get(2));
   }

   public void seatUpgardePkg()
   {
      wait.forJSExecutionReadyLazy();
      if (!seatUpgarde.isEmpty())
      {
         WebElementTools.mouseHover(seatUpgarde.get(1));
         WebElementTools.click(seatUpgarde.get(1));
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "No Seat Upgrade");
      }

   }

   public void enterPayernameWithAccents()
   {
      WebElementTools.click(cashPayer);
      WebElementTools.enterText(cashPayer, "Johnéèêëçñøðåæœēčŭ");
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(addPayment);
      WebElementTools.click(addPayment);
      wait.forJSExecutionReadyLazy();
   }

   public boolean validatePayerName()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(PayerErrorMessege);
   }

   public boolean verifyisInsuranceNotDisplayed()
   {
      return WebElementTools.isDisplayed(insurancethirdparty);
   }

   public void nlTPInsurance()
   {
      if (ExecParams.getAgent().isThirdparty() && ExecParams.getTestExecutionParams().isNL())
         assertThat("the Insurance component for NL is not displayed",
                  verifyisInsuranceNotDisplayed(), is(false));
      if (ExecParams.getAgent().isThirdparty()
               && ExecParams.getTestExecutionParams().isBE())
         assertThat("the Insurance component for be is  displayed", verifyisInsuranceNotDisplayed(),
                  is(true));
      if (ExecParams.getAgent().isThirdparty()
               && ExecParams.getTestExecutionParams().isMA())
         assertThat("the Insurance component for ma is not displayed in the Header",
                  verifyisInsuranceNotDisplayed(), is(false));
   }

   public boolean isCreditDebitTypePresent()
   {
      return WebElementTools.isPresent(creditcarddebittype);
   }

   public void CreditDebitTypeNotPresent()
   {
      if (ExecParams.getAgent().isThirdparty()
               && ExecParams.getTestExecutionParams().isNL())
         assertThat("the Insurance component for NL is not displayed", isCreditDebitTypePresent(),
                  is(false));
      if (ExecParams.getAgent().isThirdparty()
               && ExecParams.getTestExecutionParams().isBE())
         assertThat("the Insurance component for be is  displayed", isCreditDebitTypePresent(),
                  is(true));
      if (ExecParams.getAgent().isThirdparty()
               && ExecParams.getTestExecutionParams().isMA())
         assertThat("the Insurance component for ma is not displayed in the Header",
                  isCreditDebitTypePresent(), is(true));
   }

   public void makeBookingText()
   {
      String[] makeBookingtext = { "RESERVEER", "Réserver", "MAKE BOOKING" };
      String makeBooking = WebElementTools.getElementText(makePaymentText);
      for (int i = 0; i < makeBookingtext.length; i++)
      {
         if (makeBooking.equalsIgnoreCase(makeBookingtext[0])
                  | makeBooking.equalsIgnoreCase(makeBookingtext[1])
                  | makeBooking.equalsIgnoreCase(makeBookingtext[2]))
         {
            LOGGER.log(LogLevel.INFO, "Make payment text is dispaled ");
         }
      }
   }

   public void changeLanguageFr()
   {
      WebElementTools.scrollAndMouseHover(languageCountrySelector);
      WebElementTools.click(languageCountrySelector);
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(languageCountrySelectordropdown.get(1));
      WebElementTools.click(languageCountrySelectordropdown.get(1));
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(languageCountrySelectDropdownption.get(0));
      WebElementTools.click(languageCountrySelectDropdownption.get(0));

   }

   public void fillRetailPassengerDetailsForSalesQuote()
   {
      fillRetailPassengerDetailsPriceBreakdown();
   }

   public SelenideElement getContinueButton()
   {
      return $("#PassengerV2ContinueButton__component .ContinueButtonV2__ctaContainer button");
   }

   public SelenideElement getPaxScrollToErrorComponentAlert()
   {
      return $("#PaxPageScrollToError__component .alerts__alert");
   }
}
