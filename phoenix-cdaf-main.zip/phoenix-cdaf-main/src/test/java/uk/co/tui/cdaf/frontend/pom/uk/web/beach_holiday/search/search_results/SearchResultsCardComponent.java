package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class SearchResultsCardComponent extends AbstractPage
{

   public static int index;

   private final PageErrorHandler error = new PageErrorHandler();

   @FindAll({ @FindBy(css = ".ResultsListItem__location"), @FindBy(css = ".package-card .copy>p") })
   public List<WebElement> packageAccomLocation;

   public SearchResultsCardComponent()
   {
      WebElementWait wait = new WebElementWait();
      WebDriverUtils wbUtils = new WebDriverUtils();
   }

   public List<WebElement> getLocation()
   {
      return packageAccomLocation;
   }

}
