package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.jetbrains.annotations.NotNull;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.DOMElement;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.codeborne.selenide.Selenide.*;
import static org.junit.Assert.assertTrue;

public class SearchResultsComponent extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchResultsComponent.class);

   private final Map<String, WebElement> searchCardMap;

   private final HashMap<String, String> searchResultsCardMap;

   private final WebElementWait wait;

   @FindAll({ @FindBy(css = ".Image__imgContainer"),
            @FindBy(css = "[class='Picture__imgContainer']") })
   public List<WebElement> packageImage;

   @FindBy(css = "[aria-label*='accomodation name']")
   public List<WebElement> hotelName;

   @FindBy(css = "p[class*='location']")
   public List<WebElement> hotelLoction;

   @FindAll({
            @FindBy(xpath = "//*[contains(@class,'priceSection')]//*[contains(@class,'shortlistMobile')]/../span/div"),
            @FindBy(css = "div[class*='packagePrice'] [class*='perPersonPrice']") })
   public List<WebElement> ppPrice;

   @FindAll({ @FindBy(css = "div[class*='packagePrice'] [class*='totalPrice']"),
            @FindBy(xpath = "//*[contains(@class,'priceSection')]//*[contains(@class,'shortlistMobile')]/../span[3]"),
            @FindBy(css = "div[class*='packagePrice'] [class*='totalParty']") })
   public List<WebElement> totalPrice;

   @FindAll({ @FindBy(css = ".SortResults__sortTypeList select[aria-label='Select'] option") })
   public List<WebElement> sortByOption;

   @FindAll({ @FindBy(css = "[class*='packageInfo'] [class*='showPacka'] button"),
            @FindBy(css = "[class*='packageInfo'] [class*='continue'] button"),
            @FindBy(css = "[class*='pricePanelWrapper'] [class*='buttons']") })
   private List<WebElement> continueButton;

   @FindBy(css = "[class*='viewMap']")
   private List<WebElement> mapLink;

   @FindBy(css = "[aria-label = 'ratings']")
   private List<WebElement> tripAdvisorRatings;

   @FindBy(css = "[aria-label = 'duration']")
   private List<WebElement> dateAndDuration;

   @FindBy(css = "[aria-label='room details']>span:nth-child(2)")
   private List<WebElement> roomDetils;

   @FindBy(css = "div[class*='priceSection'] [class*='totalPartyText']")
   private List<WebElement> discount;

   @FindBy(css = "[class*='flightName']")
   private List<WebElement> flightName;

   @FindBy(css = "[class*='fightInfo']")
   private List<WebElement> flightInfoLink;

   @FindBy(css = "[aria-label='holiday count']")
   private WebElement holidayCountText;

   @FindBy(css = "[aria-label*='button']")
   private List<WebElement> editSearchButton;

   @FindAll({ @FindBy(css = "[class *='Clear-Search'] a"),
            @FindBy(css = "[aria-label = 'clear search'] a"),
            @FindBy(css = "#tui_widget_searchpanel_views_ClearPanel_0") })
   private List<WebElement> clearSearch;

   @FindAll({
            @FindBy(css = "[class='ExpandablePanel__expandablePanel EditSearch__holidaySearch ExpandablePanel__editableView']"),
            @FindBy(css = "[class='ExpandablePanel__expandablePanel EditSearch__holidaySearch ExpandablePanel__editableView']") })
   private WebElement expandableEditSearchPanel;

   @FindBy(css = "[class='SearchPanel__searchPanelWrapper']")
   private WebElement expandableOpenDefault;

   @FindBy(css = "[class=EditSearch__searchOption]>span")
   private List<WebElement> lessThanEqual17Characters;

   @FindBy(css = "[class=EditSearch__searchDateBlock] span")
   private List<WebElement> departureDateWithFlexibilityRange;

   @FindBy(css = "[id='cmCloseBanner']")
   private WebElement durationInNights;

   @FindBy(css = "[class=EditSearch__editSearchLink] button")
   private WebElement editSearch;

   @FindBy(css = "[aria-label='accomodation name'] span")
   private List<WebElement> accomodationName;

   @FindBy(css = "[aria-label='accomodation name']")
   private List<WebElement> accomodationLinkElements;

   @FindBy(css = "[class='Standard__tooltip ResultListItemV2__noUnderlinePrice'] svg[class='ResultListItemV2__IconStyle']")
   private List<WebElement> standardToolTip;

   @FindBy(xpath = "//div[@role='tooltip']/span[contains(.,'prijs')]")
   private List<WebElement> toolTipInformation;

   @FindBy(css = ".ResultListItemV2__packageInfo")
   private List<WebElement> accomInfoPackage;

   @FindBy(css = "[class='ResultListItemV2__boardType']")
   private List<WebElement> boardBasis;

   @FindBy(css = "div[class*='packagePrice'] [class='ResultListItemV2__totalPartyText'] span[class='ResultListItemV2__totalParty']")
   private List<WebElement> totalPriceamount;

   @FindBy(css = "[aria-label='room details']>span:nth-child(1)")
   private List<WebElement> bedIcon;

   @FindBy(css = "[class*='Standard__tooltip ResultListItemV2__tooltip roomTooltip']")
   private List<WebElement> roomsLeft;

   @FindBy(css = "[class*='roomTooltipContentText']")
   private List<WebElement> toolTipsText;

   @FindBy(css = "[aria-label='back to search'] a")
   private WebElement backToSearchResultLink;

   public SearchResultsComponent()
   {
      searchCardMap = new HashMap<>();
      searchResultsCardMap = new HashMap<>();
      wait = new WebElementWait();
   }

   public static boolean wasAccommodationOpenned()
   {
      return $("div.Header__accomodationSection").shouldBe(Condition.visible, Duration.ofSeconds(5)).isDisplayed();
   }

   public void selectFirstAvailableResultCard()
   {
      $$("div.ResultsListItem__continue").filter(Condition.visible).asDynamicIterable()
               .forEach(visibleAccomodationBtns ->
               {
                  visibleAccomodationBtns.scrollTo().click();
                  if (!wasAccommodationOpenned())
                     Selenide.back();
               });
      assertTrue("No valid search results were found with search URL:\n" +
               WebDriverUtils.getDriver().getCurrentUrl(), wasAccommodationOpenned());
   }

   public void selectSpecificResultCard(String accomodation)
   {
      if (!continueButton.isEmpty())
      {
         for (WebElement webElement : accomodationName)
         {
            String accomNames = webElement.getText();
            if (accomNames.equalsIgnoreCase(accomodation))
            {
               WebElementTools.javaScriptScrollToElement(webElement);
               WebElementTools.clickElementJavaScript(webElement);
               break;
            }
            if (accomNames.equalsIgnoreCase("Hotel H10 Timanfaya Palace"))
            {
               WebElementTools.javaScriptScrollToElement(webElement);
               WebElementTools.clickElementJavaScript(webElement);
               break;
            }
         }
      }
      else
      {
         selectFirstAvailableResultCard();
      }
   }

   public void selectSpecificResultCardByCode(String accomodationCode)
   {
      for (WebElement linkElements : accomodationLinkElements)
      {
         String accomLink = linkElements.getAttribute("href");
         if (accomLink.contains(accomodationCode))
         {
            WebElementTools.javaScriptScrollToElement(linkElements);
            WebElementTools.clickElementJavaScript(linkElements);
            return;
         }
      }
      selectFirstAvailableResultCard();
   }

   public void selectRandomResultCard()
   {
      Random random = new Random();
      ElementsCollection continueBtns =
               $$("div.ResultsListItem__continue[aria-label='continue']").filter(Condition.visible);
      int randomResultCard = random.nextInt(continueBtns.size());
      continueBtns.get(randomResultCard).scrollTo().click();
   }

   public Map<String, WebElement> getSearchCardComponents()
   {
      searchCardMap.put("Image", packageImage.get(0));
      searchCardMap.put("Gallery", packageImage.get(0));
      searchCardMap.put("Hotel Name", hotelName.get(0));
      searchCardMap.put("Location", hotelLoction.get(0));
      searchCardMap.put("Map", mapLink.get(0));
      searchCardMap.put("TUI Rating", tripAdvisorRatings.get(0));
      searchCardMap.put("Date & Duration", dateAndDuration.get(0));
      searchCardMap.put("Room", roomDetils.get(0));
      searchCardMap.put("Airport", flightName.get(0));
      searchCardMap.put("Per person price", ppPrice.get(0));
      searchCardMap.put("Total price", totalPrice.get(0));
      searchCardMap.put("Discount", discount.get(0));
      searchCardMap.put("Continue", continueButton.get(0));
      searchCardMap.put("Flight info", flightInfoLink.get(0));
      return searchCardMap;

   }

   public Map<String, WebElement> getSortByComponents()
   {
      searchCardMap.put("Total Price - low to high", sortByOption.get(0));
      searchCardMap.put("Total Price - high to low", sortByOption.get(1));
      searchCardMap.put("Price - low to high", sortByOption.get(2));
      searchCardMap.put("Price - high to low", sortByOption.get(3));
      searchCardMap.put("Saving Amount", sortByOption.get(3));
      return searchCardMap;

   }

   public void searchResultsCardComponents()
   {
      searchResultsCardMap.put("Per person price", ppPrice.get(0).getText());
      searchResultsCardMap.put("Total price", totalPrice.get(0).getText());
      searchResultsCardMap.put("Airport", flightName.get(0).getText());
      searchResultsCardMap.put("Room", roomDetils.get(0).getText());
      searchResultsCardMap.put("Hotel Name", hotelName.get(0).getText());
      searchStoreValues.setSearchValues(searchResultsCardMap);
   }

   public boolean isHolidayCountDisplayed()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(holidayCountText));
   }

   public void clickEditSearchButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(editSearchButton.get(1));
   }

   public boolean clearSearchLink()
   {
      return DOMElement.isElementPresent(clearSearch);
   }

   public boolean isExpandableEditSearchPanelDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(expandableEditSearchPanel);
   }

   public boolean isExpandableOpenDefaultDisplayed()
   {
      return WebElementTools.isDisplayed(expandableOpenDefault);
   }

   public boolean getLessThanEqual17Characters()
   {
      boolean character = false;
      String firstValue = WebElementTools.getElementText(lessThanEqual17Characters.get(0));
      int len = firstValue.length();
      return character;
   }

   public Map<String, WebElement> getSearchPanelView()
   {
      searchCardMap.put("Destination/Hotel name in full (No ellipsis)",
               lessThanEqual17Characters.get(0));
      searchCardMap.put("Departure date with flexibility range",
               departureDateWithFlexibilityRange.get(0));
      searchCardMap.put("Duration in nights", departureDateWithFlexibilityRange.get(1));
      searchCardMap.put("EDIT SEARCH cta", editSearch);
      return searchCardMap;
   }

   public String destinationNotSelected()
   {
      return WebElementTools.getElementText(lessThanEqual17Characters.get(0));
   }

   public void clickEditSearchMobile()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(editSearch);
   }

   public void mouseOverTheInformationIcon()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(standardToolTip.get(1));
   }

   public boolean isToolTipViewDisplyed()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(standardToolTip.get(1)));
   }

   public String getToolTipText()
   {
      ElementsCollection allToolTipHolders = $$("div.Standard__tooltiptext");
      for (SelenideElement element : allToolTipHolders)
      {
         String display = element.getCssValue("display");
         if ("block".equals(display))
         {
            return element.$("span").text();
         }
      }
      LOGGER.log(LogLevel.ERROR,
               "Impossible to find any active tooltip holder out of " + allToolTipHolders.size() + " available tooltip holders");
      return "";
   }

   public boolean isQuestionMarkDisplayed()
   {
      for (WebElement element : standardToolTip)
      {
         WebElementTools.isPresent(element);
         return true;
      }
      return false;
   }

   public WebElement holidayCountText()
   {
      return holidayCountText;
   }

   public boolean visibileAccomInfoComponent()
   {
      boolean value = false;
      for (WebElement element : accomInfoPackage)
      {
         WebElementTools.isPresent(element);
         value = true;
         break;
      }
      return value;
   }

   public Map<String, WebElement> getSearchCardResults()
   {
      searchCardMap.put("Unit Name", hotelName.get(0));
      searchCardMap.put("Geo Location", hotelLoction.get(0));
      searchCardMap.put("Imagery", packageImage.get(0));
      searchCardMap.put("View Map", mapLink.get(0));
      searchCardMap.put("Date & Duration", dateAndDuration.get(0));
      searchCardMap.put("Board Basis", boardBasis.get(1));
      searchCardMap.put("Room Type", roomDetils.get(0));
      searchCardMap.put("Flight Information", flightInfoLink.get(0));
      searchCardMap.put("Per person price", ppPrice.get(0));
      searchCardMap.put("Total price", totalPriceamount.get(0));
      searchCardMap.put("Continue", continueButton.get(0));
      return searchCardMap;
   }

   public boolean getSearchCardWithRegion(Map<String, WebElement> searchMap)
   {
      boolean value = false;
      for (int i = 0; i < hotelLoction.size(); i++)
      {
         String text = hotelLoction.get(i).getText();
         int length = text.split(",").length;
         if (length == 4)
         {
            searchMap.put("Hotel Name", hotelName.get(i));
            value = true;
            break;
         }
      }
      return value;
   }

   public void changeURL(String data, String regex)
   {
      Matcher r = Pattern.compile(regex).matcher(WebDriverUtils.getDriver().getCurrentUrl());
      if (r.find())
      {
         String updatedUrl = WebDriverUtils.getDriver().getCurrentUrl().replace(r.group(1), data);
         open(updatedUrl);
      }
   }

   public String getRoomDetails()
   {
      String roomDetails = WebElementTools.getElemsTexts(roomDetils).get(0);

      if (roomDetails.contains("Nog"))
      {
         String[] actualRoomDetail = roomDetails.split(" Nog");
         return actualRoomDetail[0].trim();
      }
      return roomDetails;
   }

   public String getBoardBasis()
   {
      return WebElementTools.getElemsTexts(boardBasis).get(1);
   }

   public Map<String, WebElement> getSearchCardRoom()
   {
      LOGGER.log(LogLevel.INFO, "0");
      searchCardMap.put("Bed icon", bedIcon.get(0));
      LOGGER.log(LogLevel.INFO, "1");
      searchCardMap.put("Number of rooms", WebElementTools.getFirstElement(roomDetils));
      LOGGER.log(LogLevel.INFO, WebElementTools.getFirstElement(roomDetils).toString());
      LOGGER.log(LogLevel.INFO, "2");
      searchCardMap.put("Room type name", roomDetils.get(0));
      return searchCardMap;
   }

   public boolean getSearchCardWithRoomType(Map<String, WebElement> searchMap)
   {
      boolean value = false;
      for (int i = 0; i < accomInfoPackage.size(); i++)
      {
         if (roomDetils.size() > 1)
         {
            searchMap.put("Hotel Name", hotelName.get(i));
            value = true;
            break;
         }
      }
      return value;
   }

   public List<WebElement> getRoomOptions()
   {
      return roomDetils;
   }

   public String getRoomsLeft()
   {
      loadAllResults();
      return getRoomsLeftIndicators().asDynamicIterable().stream().filter(WebElement::isDisplayed)
               .findFirst().map(WebElement::getText).orElse("");
   }

   public void loadAllResults(){
      SelenideElement resultsLoader = $("div.UI__loadMoreResults");
      SelenideElement allResultsLoadedMsg = resultsLoader.$("span.UI__noMoreHolidays");
      while (!allResultsLoadedMsg.isDisplayed()){
         resultsLoader.scrollTo();
      }
   }

   @NotNull
   private static ElementsCollection getRoomsLeftIndicators()
   {
      return $$("[class*='Standard__tooltip ResultListItemV2__tooltip roomTooltip']");
   }

   public void clickOnRoomLAIToolTip()
   {
      WebElementTools.mouseOverAndClick(roomsLeft.get(0));
   }

   public String getRoomsLeftToolTiptext()
   {
      wait.waitForAWhile(1000);
      return WebElementTools.getElementText(toolTipsText.get(0));
   }

   public int searchResultSize()
   {
      return continueButton.size();
   }

   public void selectNthResultCard(int i)
   {
      WebElementTools.javaScriptScrollToElement(continueButton.get(i));
      WebElementTools.clickElementJavaScript(continueButton.get(i));
   }

   public void selectSearchCardWithAlternateRoom()
   {
      $$("div.ResultsListItem__continue").filter(Condition.visible).asDynamicIterable()
               .forEach(visibleAccomodationBtns ->
               {
                  visibleAccomodationBtns.scrollTo().click();
                  if (!isSearchCardHasAlternativeRooms())
                     Selenide.back();
               });
      assertTrue("No valid search results were found", wasAccommodationOpenned());
   }

   private boolean isSearchCardHasAlternativeRooms()
   {
      ElementsCollection yourRoomAccordionList = $$("[aria-label*='room option 1']");
      ElementsCollection alternativeRoom = $$(".stylesRoomTypesV4__roomMobileActions");
      ElementsCollection roomContainer = $$(".stylesRoomTypesV4__roomContainer");
      return yourRoomAccordionList.size() >= 2 || alternativeRoom.size() > 1 || roomContainer.size() > 1;
   }

   public void selectContractedPackage()
   {
      Random random = new Random();
      boolean isContracted = false;
      SelenideElement packageUrl = null;
      String packageUrlText = null;
      Set<Integer> usedIndexes = new HashSet<>();
      ElementsCollection cardsContainers = $$(".Container__container > div[class*='Row__row']")
               .filterBy(Condition.visible);

      do
      {
         int randomResultCard = getIndex(cardsContainers.size(), random, usedIndexes);
         packageUrl = cardsContainers.get(randomResultCard).$("h5").$("a[href]");
         packageUrlText = packageUrl.getAttribute("href");
         isContracted = isContractedPackage(packageUrlText);
      }
      while (!isContracted && usedIndexes.size() != cardsContainers.size());

      if (isContracted)
      {
         packageUrl.click();
      }

      assertTrue("No valid search results were found", wasAccommodationOpenned());
   }

   public Integer getIndex(int arraySize, Random random, Set<Integer> usedIndexes)
   {
      int randomResultCard = 0;
      do
      {
         randomResultCard = random.nextInt(arraySize);
      }
      while (usedIndexes.contains(randomResultCard));
      usedIndexes.add(randomResultCard);
      return randomResultCard;
   }

   public boolean isContractedPackage(String url)
   {
      return url.toLowerCase().contains("contracted");
   }

   public void selectSearchCardWithAltBoard()
   {
      ElementsCollection boardUpgradeContainers = $$(".BoardUpgrades__boardContainer");
      if (continueButton.size() > 1)
      {
         for (int i = 0; i < accomodationName.size(); i++)
         {
            $(accomodationName.get(i)).scrollTo().click();
            if (boardUpgradeContainers.size() >= 2)
            {
               break;
            }
            else
            {
               Selenide.back();
            }
            if (i == (accomodationName.size() - 1) && (boardUpgradeContainers.size() < 2))
            {
               Assert.fail("No search card with alternative board found");
            }
         }
      }
   }

   public void selectSearchCardWithDiscount()
   {
      Random random = new Random();
      ElementsCollection continueButtonsWithDiscount =
               $$(By.xpath("//span[@class='ResultListItemV2__deposit']" +
                        "/ancestor::div[contains(@class,'Column__col')]" +
                        "/descendant::div[contains(@class,'Column__col')]" +
                        "//div[contains(@class,'ResultsListItem__continue')]"))
                        .filter(Condition.visible);
      if (!continueButtonsWithDiscount.isEmpty())
      {
         int randomResultCard = random.nextInt(continueButtonsWithDiscount.size());
         continueButtonsWithDiscount.get(randomResultCard).scrollTo().click();
      }
      else
      {
         Assert.fail("No search card with discount found");
      }
   }

   public void clickOnBackToSearchResults()
   {
      $(backToSearchResultLink).shouldBe(Condition.visible).shouldBe(Condition.enabled).scrollTo()
               .click();
   }
}
