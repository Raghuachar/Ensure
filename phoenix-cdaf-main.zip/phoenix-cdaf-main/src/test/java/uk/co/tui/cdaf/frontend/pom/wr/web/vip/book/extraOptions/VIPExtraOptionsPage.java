package uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.extraOptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;

public class VIPExtraOptionsPage
{

   private final HashMap<String, WebElement> VIPExtraOptionsPageComponentMap;

   @FindBy(css = "#yourTransfers__component")
   private WebElement transfersComponent;

   @FindBy(css = "#insurance__component")
   private WebElement insuranceComponent;

   @FindBy(css = "#backtoyourholidaybuttoncomponent__component")
   private WebElement backToYourHolidayButton;

   public VIPExtraOptionsPage()
   {
      WebElementWait wait = new WebElementWait();
      VIPExtraOptionsPageComponentMap = new HashMap<>();
   }

   public HashMap<String, WebElement> getVipExtraOptionsPageComponentsMap()
   {
      VIPExtraOptionsPageComponentMap.put("YOUR TRANSFERS", transfersComponent);
      VIPExtraOptionsPageComponentMap.put("INSURANCE", insuranceComponent);
      VIPExtraOptionsPageComponentMap.put("Apply changes and go back CTA", backToYourHolidayButton);
      return VIPExtraOptionsPageComponentMap;
   }

   public boolean isInsuranceComponentDisplayed()
   {
      return WebElementTools.isPresent(insuranceComponent);
   }

}
