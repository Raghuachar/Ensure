package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageSEODBComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSEODBPageTemplateAgentDataHeaderStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageSEODBComponents packageSEODBComponents;

   public PackageSEODBPageTemplateAgentDataHeaderStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      packageSEODBComponents = new PackageSEODBComponents();
   }

   @Then("they can see the respective information")
   public void they_can_see_the_respective_information(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Agent icon present", packageSEODBComponents.isAgentNameIcon(), is(true));
      assertThat("Agent name present", packageSEODBComponents.isAgentName(), is(true));
      assertThat("Store icon present", packageSEODBComponents.isStoreIcon(), is(true));
      assertThat("Store number present", packageSEODBComponents.isStoreNumber(), is(true));
      assertThat("Date icon present", packageSEODBComponents.isDateIcon(), is(true));
      assertThat("Current date present", packageSEODBComponents.isCurrentDate(), is(true));
   }
}
