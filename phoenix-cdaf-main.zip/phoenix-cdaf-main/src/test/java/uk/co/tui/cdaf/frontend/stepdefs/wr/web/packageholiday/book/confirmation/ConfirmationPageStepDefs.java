package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.confirmation;

import io.cucumber.java.en.Then;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.retail.BookingRetrievalPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.mmb.MmbLoginPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.confirmation.ConfirmationPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.mmb.PackageRetrieval;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class ConfirmationPageStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(ConfirmationPageStepDefs.class);

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   public final WebDriverUtils utils;

   public final BookingRetrievalPage bookingRetrievalPage;

   public final MmbLoginPage mmbLoginPage;

   private final ConfirmationPage confirmationPage;

   private final PackageRetrieval packageRetrieval;

   public String bookingReferenceNumber;

   public String leadPaxLastName;

   public String departureDate;

   public String departureMonthYear;

   public ConfirmationPageStepDefs()
   {
      confirmationPage = new ConfirmationPage();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      bookingRetrievalPage = new BookingRetrievalPage();
      utils = new WebDriverUtils();
      mmbLoginPage = new MmbLoginPage();
      packageRetrieval = new PackageRetrieval();
   }

   @Then("the customer should able to see booking reference number")
   public void the_customer_should_able_to_see_booking_reference_number()
   {
      boolean isBookIdDisplayed =
               confirmationPage.bookReferenceComponent.isBookReferenceIdDisplayed();
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Booking reference id wasn't displayed", isBookIdDisplayed, true),
               isBookIdDisplayed, is(true));
      LOGGER.log(
               "Booking reference number:" + confirmationPage.bookReferenceComponent.getBookingRefId());

      bookingReferenceNumber = confirmationPage.bookReferenceComponent.getBookingRefId();
      // retailpassengerdetailspage.userLogout();

      leadPaxLastName = confirmationPage.passengerDetailsComponent.getLeadPassengrLastName();
      departureDate = confirmationPage.flightSummaryComponent.getOutboundFlightDepDate();
      departureMonthYear = confirmationPage.flightSummaryComponent.getFlightDepartureMonthYear();
      LOGGER.log(
               "Booking reference number:" + confirmationPage.bookReferenceComponent.getBookingRefId());
      LOGGER.log("Lead Passenger Last Name:"
               + confirmationPage.passengerDetailsComponent.getLeadPassengrLastName());
      LOGGER.log(
               "Departure Date:" + confirmationPage.flightSummaryComponent.getOutboundFlightDepDate()
                        + confirmationPage.flightSummaryComponent.getFlightDepartureMonthYear());
   }

   @Then("the customer should be able to retrieve the booking")
   public void the_customer_should_be_able_to_retrieve_the_booking()
   {
      String currentUrl = utils.getCurrentURL();
      if (currentUrl.contains("retail"))
      {
         bookingRetrievalPage.retrieveRetailBooking(bookingReferenceNumber);
      }
      else if (currentUrl.contains(".tuiprjuat.be/h/") || currentUrl.contains(".tuiprjuat.nl/h/"))
      {
         String url =
                  currentUrl.replace("/nl/book/confirm/booking",
                           "/your-account/managemybooking/login");
         mmbLoginPage.retrieveBooking(url, bookingReferenceNumber, departureMonthYear,
                  departureDate, leadPaxLastName);
      }
      else
      {
         String url = currentUrl.replace("/h/nl/book/confirm/booking",
                  "/travel/your-account/managemybooking/login");
         mmbLoginPage.retrieveBooking(url, bookingReferenceNumber, departureMonthYear,
                  departureDate, leadPaxLastName);
      }
   }

   @Then("the customer able to see the count down and destination text in confirmation page")
   public void the_customer_able_to_see_the_count_down_and_destination_text_in_confirmation_page()
   {

      confirmationPage.bookReferenceComponent.isBookcountdownDisplayed();
      confirmationPage.bookReferenceComponent.isBookDestinationTextDisplayed();

   }

   @Then("they should see the following components:")
   public void they_should_see_the_following_components(List<String> components)
   {
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element =
                     packageRetrieval.getPackageRetrievalComponents()
                              .get(componentIdentifier.trim());
            WebElementTools.scrollTo(element);
            assertThat(componentIdentifier + " component not found in the unit details section",
                     element, is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }
}
