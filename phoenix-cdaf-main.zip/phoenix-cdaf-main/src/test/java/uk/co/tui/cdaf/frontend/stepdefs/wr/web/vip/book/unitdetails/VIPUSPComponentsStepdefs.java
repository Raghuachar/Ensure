package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.book.unitdetails;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.unit_details.AccommodationInfoPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.VIPUSPComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class VIPUSPComponentsStepdefs
{
   private final Map<String, WebElement> uspComponent;

   private final SearchResultsComponent searchResultsComponent;

   private final UnitDetailsPage unitDetailsPage;

   private final VIPUSPComponent vipUSPComponent;

   private final PackageNavigation packageNavigation;

   private final AccommodationInfoPage unitDetailsaccommodation;

   public VIPUSPComponentsStepdefs()
   {
      searchResultsComponent = new SearchResultsComponent();
      unitDetailsPage = new UnitDetailsPage();
      vipUSPComponent = new VIPUSPComponent();
      uspComponent = new HashMap<>();
      packageNavigation = new PackageNavigation();
      unitDetailsaccommodation = new AccommodationInfoPage();
   }

   @And("they ve selected a package")
   public void they_ve_selected_a_package()
   {
      searchResultsComponent.selectRandomResultCard();
   }

   @And("they re on the unit details page")
   public void they_re_on_the_unit_details_page()
   {
      assertThat("Date filter is displayed", unitDetailsPage.isHotelDetailsPageDisplayed(),
               is(true));
   }

   @When("they review the space underneath the 'At a glance' component")
   public void they_review_the_space_underneath_the_component()
   {
      vipUSPComponent.wait.forJSExecutionReadyLazy();
   }

   @Then("they can see the vip 'Why choose VIP Selection?' component:")
   public void they_can_see_the_component(List<String> components)
   {
      vipUSPComponent.wait.forJSExecutionReadyLazy();
      uspComponent.putAll(vipUSPComponent.getUSPComponent());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = uspComponent.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("they select the vip {string} link")
   public void they_select_the_See_benefits_in_detail_link(String string)
   {
      assertThat("See benefits details link is not displayed",
               vipUSPComponent.isSeeMoreBenfitsLinkDisplayed(), is(true));
      vipUSPComponent.clickSeeMoreBenfitsLink();
   }

   @Then("the 'Why choose VIP selection?' modal pops us")
   public void the_modal_pops_us()
   {
      vipUSPComponent.isModelViewPopUPDisplayed();
   }

   @And("it contains:")
   public void it_contains(List<String> components)
   {
      vipUSPComponent.wait.forJSExecutionReadyLazy();
      uspComponent.putAll(vipUSPComponent.getUSPModelPopUpComponent());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = uspComponent.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });

   }

   @When("they select the vip {string} cta")
   public void they_select_the_cta(String user)
   {
      vipUSPComponent.wait.forJSExecutionReadyLazy();
      searchResultsComponent.selectRandomResultCard();
      vipUSPComponent.clickSeeMoreBenfitsLink();
      if (user.equalsIgnoreCase("CONFIRM"))
      {
         vipUSPComponent.clickOnConfirmButton();
      }
      else
      {
         vipUSPComponent.clickOnModelCloseButton();
      }

   }

   @Then("the vip modal closes")
   public void the_vip_modal_closes()
   {
      assertThat("Date filter is displayed", vipUSPComponent.isSeeMoreBenfitsLinkDisplayed(),
               is(true));
   }

   @Given("the {string} has conducted a search via the VIP storefront")
   public void the_has_conducted_a_search_via_the_VIP_storefront(String string)
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @And("they're on the VIP unit details page")
   public void they_re_on_the_VIP_unit_details_page()
   {
      searchResultsComponent.selectRandomResultCard();
      assertThat("unit details page is not displayed",
               unitDetailsPage.isHotelDetailsPageDisplayed(), is(true));

   }

   @When("they review the unit header component")
   public void they_review_the_unit_header_component()
   {
      assertThat("Hotel name component is not displayed",
               unitDetailsaccommodation.getAccommodationHeader().isDisplayed(), is(true));
   }

   @Then("they can see the {string} rating icon in the existing ratings position")
   public void they_can_see_the_rating_icon_in_the_existing_ratings_position(String string)
   {
      String getVRatingText = unitDetailsaccommodation.getAccomodationRating().getText();
      assertThat("V Rating is not displayed", "V".trim().contains(getVRatingText), is(true));
   }
}
