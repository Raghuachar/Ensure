package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.*;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class PackageGuestRatingFilter extends AbstractPage
{

   private final WebElementWait wait = new WebElementWait();

   private final Map<String, List<SelenideElement>> searchCardMap = new HashMap<>();

   private String selectedOptionText;

   @FindBy(css = "div[class='ResultListItemV2__guestReviewContainer']")
   private List<WebElement> guestReviewRatings;

   @FindBy(css = "[class='Components__ratings Components__ratingContainer ']")
   private WebElement filterComponentRatings;

   @FindBy(css = "[class='Components__customerRatingContainer Components__v2']")
   private WebElement guestRatingfilterComponent;

   @FindBy(css = "[class='Components__header']")
   private List<WebElement> guestReviewRatingTitle;

   @FindBy(css = ".Components__customerRatingBlock span[class='inputs__circle inputs__alignmiddle']")
   private List<WebElement> guestReviewRatingsRadioButtons;

   @FindBy(css = ".Components__customerRatingBlock:not(.Components__disabled) .inputs__text.inputs__alignmiddle")
   private List<WebElement> guestReviewFilterOptions;

   @FindBy(css = ".Components__customerRatingBlock .inputs__text.inputs__alignmiddle")
   private List<WebElement> guestReviewAllFilterOptions;

   @FindBy(css = ".Components__customerRatingBlock.Components__disabled label .inputs__text.inputs__alignmiddle")
   private List<WebElement> guestReviewFilterOptionsDisabled;

   @FindBy(css = ".Components__customerRatingBlock.Components__disabled label .inputs__text.inputs__alignmiddle")
   private List<WebElement> guestReviewFilterRadioOptionsDisabled;

   @FindBy(css = ".Components__customerRatingBlock input[type='radio']:checked + span + span")
   private WebElement guestReviewRatingSelected;

   @FindBy(css = "Span[class='ResultListItemV2__ratingNumber']")
   private List<WebElement> guestReviewRatingNumber;

   @FindBy(css = "span.BoardBasis__clearLink a")
   private WebElement guestRatingClearLink;

   @FindBy(css = "a.FilterPanelV2__clearAll")
   private WebElement clearAllLink;

   @FindBy(css = ".FilterPanelV2__holidayCounts span")
   private WebElement noofHolidays;

   public boolean isGuestReviewsDisplayed()
   {
      return $$(guestReviewRatings).asFixedIterable().stream()
               .allMatch(SelenideElement::isDisplayed);
   }

   public boolean isFiltersComponentDisplayed()
   {
      return filterComponentRatings.isDisplayed();
   }

   public boolean isGuestRatingFilterComponentDisplayed()
   {
      return guestRatingfilterComponent.isDisplayed();
   }

   public List<String> getRatingTitleText()
   {
      return $$(guestReviewRatingTitle).asFixedIterable().stream().map(SelenideElement::getText)
               .collect(Collectors.toList());
   }

   public Map<String, List<SelenideElement>> isGuestRatingFiltersComponentsDisplayed()
   {
      List<SelenideElement> guestReviewRatingsRadioButton = $$(guestReviewRatingsRadioButtons);
      List<SelenideElement> guestReviewFilterOption = $$(guestReviewFilterOptions);

      searchCardMap.put("Radio button", guestReviewRatingsRadioButton);
      searchCardMap.put("A row for each guest rating", guestReviewFilterOption);
      return searchCardMap;
   }

   public List<String> guestReviewFilterOptionsText()
   {
      List<String> optionsText = new ArrayList<>();
      guestReviewAllFilterOptions.forEach(option -> optionsText.add(option.getText()));
      return optionsText;
   }

   public boolean isGuestRatingFilterOptionsValid()
   {
      return $$(guestReviewFilterOptions).asFixedIterable().stream().map(SelenideElement::getText)
               .map(ratingText -> Double.parseDouble(ratingText.split(" ")[0]))
               .allMatch(rating -> rating >= 5.0);
   }

   public boolean verifyDisabledFilterOptions()
   {
      return $$(guestReviewFilterRadioOptionsDisabled).asFixedIterable().stream()
               .allMatch(option -> option.is(enabled));
   }

   public List<Double> getDisabledRatings()
   {
      return $$(guestReviewFilterOptionsDisabled).asFixedIterable().stream()
               .map(SelenideElement::getText)
               .map(ratingText -> Double.parseDouble(ratingText.split(" ")[0]))
               .collect(Collectors.toList());
   }

   public void selectGuestFilterOption()
   {
      int randomIndex = new Random().nextInt($$(guestReviewFilterOptions).size());
      SelenideElement randomRadioButton = $$(guestReviewFilterOptions).get(randomIndex);
      selectedOptionText =
               randomRadioButton.scrollIntoView(true).should(Condition.appear).getText();
      randomRadioButton.click();
      wait.forJSExecutionReadyLazy();
   }

   public Double getSelectedRatingValue()
   {
      return Double.parseDouble($(guestReviewRatingSelected).getText().split(" ")[0]);
   }

   public Double getGuestReviewRatingSelected()
   {
      String[] ratingText = selectedOptionText.split(" ");
      return Double.parseDouble(ratingText[0]);
   }

   public List<Double> getRatingsInSearchCard()
   {
      ElementsCollection guestReviewRatingNumber = $$("span.ResultListItemV2__ratingNumber");
      guestReviewRatingNumber.first().should(appear);
      return guestReviewRatingNumber.asFixedIterable().stream().map(SelenideElement::text)
               .map(Double::parseDouble).collect(Collectors.toList());
   }

   public boolean isGuestReviewRatingClearFilterLinkDisplayed()
   {
      return guestRatingClearLink.isDisplayed();
   }

   public boolean isClearAllFilterLinkDisplayed()
   {
      return clearAllLink.isDisplayed();
   }

   public void clickGuestReviewRatingClearFilterLink()
   {
      wait.forJSExecutionReadyLazy();
      guestRatingClearLink.click();
   }

   public boolean isRadioButtonUnSelected()
   {
      wait.forJSExecutionReadyLazy();
      SelenideElement radioButtonUnSelected =
               $(By.cssSelector(".Components__customerRatingBlock input[type='radio']:checked"));
      radioButtonUnSelected.shouldNotBe(visible);
      return true;
   }

   public boolean isGuestReviewRatingClearFilterLinkNotDisplayed()
   {
      SelenideElement guestRatingNotBeClearLink = $(By.cssSelector("span.BoardBasis__clearLink a"));
      guestRatingNotBeClearLink.shouldNotBe(visible);
      return true;
   }

   public boolean isDestinationClearFilterLinkDisplayed()
   {
      ElementsCollection clearLinks = $$("span.BoardBasis__clearLink a");
      SelenideElement destinationClearLink = clearLinks.get(1);
      destinationClearLink.shouldBe(visible);
      return true;
   }

   public void clickClearAllFilterLink()
   {
      clearAllLink.click();
   }

   public int getNoOfHolidaysCount()
   {
      return Integer.parseInt(WebElementTools.getElementText(noofHolidays));
   }
}
