package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.browse.homepage.searchPanel;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class SearchPanelDestinationAirportSelectionStepDefs
{
   private final FlightOnlyHomePage homepage;

   private String destinationAirport;

   public SearchPanelDestinationAirportSelectionStepDefs()
   {
      homepage = new FlightOnlyHomePage();
   }

   @Given("a customer is on a TUIfly homepage")
   public void a_customer_is_on_a_TUIfly_homepage()
   {
      homepage.visit();
   }

   @And("they have clicked in the {string} field in the TUIfly search panel")
   public void they_have_clicked_in_the_field_in_the_TUIfly_search_panel(String string)
   {
      homepage.clickDestinationAirportField();
   }

   @When("they view the airport options under {string}")
   public void they_view_the_airport_options_under(String string)
   {
      homepage.validateDestinationAirportsDropdown();
   }

   @Then("they will see the following all airports in alphabetical order")
   public void they_will_see_the_following_all_airports_in_alphabetical_order()
   {
      // Write code here that turns the phrase above into concrete actions
      homepage.validateOrderedListDestinationAirports();
   }

   @Then("they will see the {string} and {string} CTA's.")
   public void they_will_see_the_and_CTA_s(String string, String string2)
   {
      homepage.validateClearAllDoneForAirportsDropdown(string, string2);
   }

   @And("they have clicked in the Fly to field in the TUIfly search panel")
   public void they_have_clicked_in_the_Fly_to_field_in_the_TUIfly_search_panel()
   {
      homepage.clickDestinationAirportField();
   }

   @When("a customer clicks on an available airport within the Fly to panel")
   public void a_customer_clicks_on_an_available_airport_within_the_Fly_to_panel()
   {
      destinationAirport = homepage.clickDestinationAirport(0);
   }

   @Then("the name of the selected destination airport will appear in the Fly to field")
   public void the_name_of_the_selected_airport_will_appear_in_the_Fly_to_field()
   {
      assertThat("Text in airport Field is the same as selected airport",
               homepage.validateDestinationAirportFieldValue(destinationAirport), is(true));
   }

   @And("a customer has already selected an airport in the Fly To field")
   public void a_customer_has_already_selected_an_airport_in_the_fly_to_field()
   {
      homepage.clickDestinationAirportField();
      destinationAirport = homepage.clickDestinationAirport(0);
   }

   @When("a customer clicks on a different available airport within the Fly To panel")
   public void a_customer_clicks_on_a_different_available_airport_within_the_panel()
   {
      destinationAirport = homepage.clickDestinationAirport(0);
   }

   @Then("the name of the selected airport will replace the previous airport name in the Fly To field")
   public void the_name_of_the_selected_airport_will_replace_the_previous_airport_name_in_the_fly_to_field()
   {
      assertThat("Text in airport Field is the same as selected airport",
               homepage.validateDestinationAirportFieldValue(destinationAirport), is(true));
   }

   @When("a customer clicks on a disabled destination airport")
   public void a_customer_clicks_on_a_disabled_destination_airport()
   {
      homepage.clickDisabledDestinationAirport();
   }

   @Then("the customer will be unable to click on that selection but the destination airport will be visible")
   public void the_customer_will_be_unable_to_click_on_that_selection_but_the_destination_airport_will_be_visible()
   {
      assertThat("Disabled airport is not clickable",
               homepage.validateDestinationAirportsDropdown(), is(true));
   }

}
