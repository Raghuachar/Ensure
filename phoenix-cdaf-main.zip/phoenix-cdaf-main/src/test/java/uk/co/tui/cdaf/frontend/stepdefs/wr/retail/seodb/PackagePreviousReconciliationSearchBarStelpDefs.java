package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackagePreviousReconciliationsPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePreviousReconciliationSearchBarStelpDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final PackagePreviousReconciliationsPageComponents pkgPreviousReconPaymentPageComponents;

   public PackagePreviousReconciliationSearchBarStelpDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      pkgPreviousReconPaymentPageComponents = new PackagePreviousReconciliationsPageComponents();
   }

   @Given("that the agent has pressed the SEARCH CTA on the previous reconciliations page")
   public void that_the_agent_has_pressed_the_SEARCH_CTA_on_the_previous_reconciliations_page()
   {
      packagenavigation.retailLogin();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pkgPreviousReconPaymentPageComponents.navigateToPreviousReconciliationPage();
      pkgPreviousReconPaymentPageComponents.selectDates();
      pkgPreviousReconPaymentPageComponents.clickOnSearchCTA();
   }

   @When("they view the search bar")
   public void they_view_the_search_bar()
   {
      pkgPreviousReconPaymentPageComponents.searchBarDisplayed();
   }

   @Then("they can see the following information")
   public void they_can_see_the_following_information(io.cucumber.datatable.DataTable dataTable)
   {
      wait.forJSExecutionReadyLazy();
      assertThat("From date is visible",
               pkgPreviousReconPaymentPageComponents.isFromDateDisplayed(), is(true));
      assertThat("To date is visible", pkgPreviousReconPaymentPageComponents.isToDateDisplayed(),
               is(true));
      assertThat("Edit search CTA is visible",
               pkgPreviousReconPaymentPageComponents.isEditSearchCTADisplayed(), is(true));
   }
}
