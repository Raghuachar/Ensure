package uk.co.tui.cdaf.frontend.pom.wr.web.stay.book.yourholiday;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class NavigationComponent extends AbstractPage
{

   private final WebElementWait wait;

   @FindBy(css = "[class*='pricePanel']")
   private WebElement pricePanel;

   @FindBy(css = "[class*='progressBar']")
   private WebElement navigationPanel;

   @FindBy(css = "[aria-label='YOUR_HOLIDAY']")
   private WebElement yourHoliday;

   public NavigationComponent()
   {
      wait = new WebElementWait();
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getNavigationComponent()
   {
      return new HashMap<>()
      {
         {
            put("Navigation Panel", navigationPanel);
            put("Price Panel", pricePanel);
         }
      };
   }

   public WebElement getYourHoliday()
   {
      return wait.getWebElementWithLazyWait(yourHoliday);
   }

   public void selectYourHoliday()
   {
      WebElementTools.click(getYourHoliday());
   }

}
