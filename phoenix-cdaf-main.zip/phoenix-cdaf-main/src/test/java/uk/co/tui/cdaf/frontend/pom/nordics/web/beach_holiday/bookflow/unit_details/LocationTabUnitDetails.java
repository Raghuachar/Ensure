package uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.unit_details;

import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsTabDisplay;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import static com.codeborne.selenide.Selenide.$;

public class LocationTabUnitDetails extends AbstractPage
{
   UnitDetailsTabDisplay unitDetailsTabDisplay;

   public LocationTabUnitDetails()
   {
      unitDetailsTabDisplay = new UnitDetailsTabDisplay();
   }

   public void clickLocationTab()
   {
      unitDetailsTabDisplay.getLocationTab().scrollIntoView("{block: 'center'}").click();
   }

   public boolean isContainerExist()
   {
      return $("#FacilitiesComponentContainer").exists();
   }

   public boolean isLocationDescriptionDisplayed()
   {
      return $("#LocationComponentContainer").isDisplayed();
   }

   public boolean isMapComponentDisplayed()
   {
      return $("#sights__component").isDisplayed();
   }

}
