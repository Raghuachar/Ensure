package uk.co.tui.cdaf.frontend.pom.wr.retail;

import com.codeborne.selenide.Condition;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.TestDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.BookingAttributes;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;

import static com.codeborne.selenide.Condition.cssClass;
import static com.codeborne.selenide.Selenide.$;

public class PaymentTransferComponents extends AbstractPage
{
   public final WebDriverUtils utils;

   public WebElementWait wait = new WebElementWait();

   protected BookingAttributes testData;

   @FindBy(css = "input[id=\"transferBookingReference\"]")
   private WebElement transferBookingReferenceInput;

   @FindBy(css = ".UI__validateButton")
   private WebElement validateBookingReferenceButton;

   @FindBy(css = ".UI__bookingRefList")
   private WebElement bookingReferenceList;

   @FindBy(css = "#transferAmount")
   private WebElement transferAmountInput;

   @FindBy(css = ".UI__addPayment button")
   private WebElement addPaymentButton;

   @FindBy(css = ".UI__paymentRowLine .UI__paymentColLast")
   private WebElement priceBreakdownPaymentAmount;

   public PaymentTransferComponents()
   {
      utils = new WebDriverUtils();
   }

   public void waitForPaymentsOptionsPageLoad()
   {
      wait.forComplexPageLoad();
   }

   public void selectTransferPaymentTab()
   {
      $(".UI__typesList input[value=\"RTRAN\"] + .inputs__circle").scrollTo().hover().click();
   }

   public boolean isTransferPaymentTabSelected()
   {
      return $(".UI__typesList input[value=\"RTRAN\"]").isSelected();
   }

   public boolean isTransferBookingReferenceInputVisible()
   {
      return $(transferBookingReferenceInput).isDisplayed();
   }

   public boolean isBookingReferenceListPresent()
   {
      return $(bookingReferenceList).isDisplayed();
   }

   public boolean isTransferAmountInputPresent()
   {
      return $(transferAmountInput).isDisplayed();
   }

   public void enterTransferBookingReferenceNumber()
   {
      TestExecutionParams testParams = ExecParams.getTestExecutionParams();
      if (testParams.isBE())
         testData = TestDataHelper.getTripsBookingData().getPaymentTransferRTBE();
      else if (testParams.isNL())
         testData = TestDataHelper.getTripsBookingData().getPaymentTransferRTNL();
      else if (testParams.isMA())
         testData = TestDataHelper.getTripsBookingData().getPaymentTransferRTMA();
      WebElementTools.scrollToCenter(transferBookingReferenceInput);
      $(transferBookingReferenceInput).click();
      $(transferBookingReferenceInput).sendKeys(testData.getBookingReferenceNumber());
   }

   public void clickValidateBookingReferenceButton()
   {
      WebElementTools.scrollToCenter(validateBookingReferenceButton);
      $(validateBookingReferenceButton).hover().click();
   }

   public void checkThatBookingReferenceListPresent()
   {
      $(bookingReferenceList).shouldBe(Condition.visible, Duration.ofSeconds(30));
   }

   public boolean isPriceBreakdownPaymentAmountPresent()
   {
      return $(priceBreakdownPaymentAmount).isDisplayed();
   }

   public String getAmountToTransfer()
   {
      TestExecutionParams testParams = ExecParams.getTestExecutionParams();
      if (testParams.getAgent().isFlightPackageType())
      {
         if (testParams.isBE())
            testData = TestDataHelper.getTripsBookingData().getPaymentTransferRTBE();
         else if (testParams.isNL())
            testData = TestDataHelper.getTripsBookingData().getPaymentTransferRTNL();
         else if (testParams.isMA())
            testData = TestDataHelper.getTripsBookingData().getPaymentTransferRTMA();
      }
      return testData.getAmountToTransfer();
   }

   public void enterTransferAmount()
   {
      WebElementTools.scrollToCenter(transferAmountInput);
      $(transferAmountInput).shouldBe(Condition.visible, Duration.ofSeconds(5));
      $(transferAmountInput).click();
      $(transferAmountInput).sendKeys(getAmountToTransfer());
      $(transferAmountInput).pressTab();
   }

   public void clickAddPaymentButton()
   {
      WebElementTools.scrollToCenter(addPaymentButton);
      $(addPaymentButton).shouldNotHave(cssClass("buttons__disabled")).hover().click();
   }

   public void waitForAddPaymentButtonLoadingIsDone()
   {
      $(addPaymentButton).shouldNotHave(cssClass("buttons__loading"), Duration.ofSeconds(10));
   }

   public String getPriceBreakdownPaymentAmount()
   {
      WebElementTools.scrollToCenter(priceBreakdownPaymentAmount);
      return priceBreakdownPaymentAmount.getText();
   }

}
