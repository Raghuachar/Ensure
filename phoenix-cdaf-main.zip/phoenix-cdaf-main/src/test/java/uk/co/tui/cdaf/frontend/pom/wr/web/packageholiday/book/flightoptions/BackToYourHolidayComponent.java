package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.flightoptions;

import com.codeborne.selenide.Condition;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;

public class BackToYourHolidayComponent extends AbstractPage
{
   public static final Duration DURATION = Duration.ofSeconds(30);

   public void clickOnBackToYourHoliday()
   {
      $("[aria-label='your holiday back button'] button")
               .should(Condition.appear, DURATION)
               .scrollTo().click();
   }

   public boolean isFlightPageDisplayed()
   {
      return $("[aria-label='page heading']")
               .should(Condition.appear, DURATION).isDisplayed();
   }

}
