package uk.co.tui.cdaf.api.requests.search.parameters;

import lombok.Data;
import lombok.experimental.Accessors;
import uk.co.tui.cdaf.api.pojo.search.base.Airport;
import uk.co.tui.cdaf.api.pojo.search.mfe.Destination;
import uk.co.tui.cdaf.api.pojo.search.mfe.RoomManager;
import uk.co.tui.cdaf.api.requests.search.capabilities.AirportApi;
import uk.co.tui.cdaf.api.requests.search.capabilities.CalendarApi;
import uk.co.tui.cdaf.api.requests.search.capabilities.DestinationApi;
import uk.co.tui.cdaf.api.requests.search.capabilities.SuggestionApi;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.Brands;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import javax.annotation.Nullable;
import java.util.List;

@Data
@Accessors(chain = true)
public class SearchParameters
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchParameters.class);

   private Brands marketParams;

   private LegacyBrands brandParams; // legacy

   private String whenDateTime;

   private LanguageParams languageParams;

   private DurationParams durationParams;

   private int flexibleDays;

   private List<Destination> suggestion;

   private List<Airport> availableAirports;

   private List<Destination> availableDestinations;

   private RoomManager roomsManager = new RoomManager();

   public SearchParameters(@Nullable TestDataAttributes tda)
   {
      // parameters dependent on test environment
      this.marketParams = ExecParams.getTestExecutionParams().getBrand();
      this.brandParams = LegacyBrands.fromBrand(this.marketParams);
      this.languageParams = LanguageParams.fromString(ExecParams.getLanguageCode());
      // parameters dependent only on test data
      this.durationParams = DurationParams.getByText(tda);
      this.roomsManager.addRooms(tda);
      this.flexibleDays = tda != null ? tda.getFlexibleDays() : 3;
      // parameters dependent on backend capabilities
      this.availableAirports = new AirportApi().getAirportByNameOrCode(tda, this);
      this.availableDestinations = new DestinationApi().getAvailableDestinations(tda, this);
      this.suggestion = new SuggestionApi().getAvailableSuggestions(tda, this);
      this.whenDateTime = new CalendarApi().getWhenDateTime(tda, this);
   }

   public String baseApiUrl()
   {
      if (ExecParams.isSitEnv())
         return "https://sit.tuiprjuat.be";
      else
         return "https://mwa-nonprod.tui.com";
   }

   public String getApiVersion()
   {
      if (ExecParams.isSitEnv())
         return "/searchpanel/v1/packages/availability/";
      else
         return "/search/mwa/package-searchpanel-mfe-" + ExecParams.getTestExecutionParams()
                  .getEnvStr().toLowerCase() + "/api/v1.0/";
   }
}
