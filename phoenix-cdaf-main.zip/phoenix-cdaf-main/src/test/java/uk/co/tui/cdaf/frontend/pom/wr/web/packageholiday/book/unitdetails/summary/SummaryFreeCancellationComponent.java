package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import lombok.SneakyThrows;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.IntStream;

import static uk.co.tui.cdaf.utils.tools.WebElementTools.*;

public class SummaryFreeCancellationComponent extends AbstractPage
{
   private static final Map<Month, List<String>> monthsMap = new HashMap<>()
   {
      {
         put(Month.JANUARY, Collections.singletonList("jan"));
         put(Month.FEBRUARY, Collections.singletonList("feb"));
         put(Month.MARCH, Arrays.asList("mar", "mrt", "maa"));
         put(Month.APRIL, Collections.singletonList("apr"));
         put(Month.MAY, Arrays.asList("may", "mei"));
         put(Month.JUNE, Collections.singletonList("jun"));
         put(Month.JULY, Collections.singletonList("jul"));
         put(Month.AUGUST, Collections.singletonList("aug"));
         put(Month.SEPTEMBER, Arrays.asList("sept", "sep"));
         put(Month.OCTOBER, Arrays.asList("oct", "okt"));
         put(Month.NOVEMBER, Collections.singletonList("nov"));
         put(Month.DECEMBER, Collections.singletonList("dec"));
      }
   };

   private final WebElementWait wait;

   @FindBy(css = "[class*='PriceDiscountBreakDownV2__cancellationWrapper']")
   private WebElement freeCancellationComponent;

   @FindBy(css = "[class*='PriceDiscountBreakDownV2__cancellationContent'] b")
   private WebElement freeCancellationMessage;

   @FindBy(css = "[class*='PriceDiscountBreakDownV2__link']")
   private WebElement freeCancellationModalLink;

   @FindBy(css = "[class*='components__modal']")
   private WebElement freeCancellationModal;

   @FindBy(css = "[class*='components__modalTitle']")
   private WebElement freeCancellationModalTitle;

   @FindBy(css = "[class*='PriceDiscountBreakDownV2__cancellationModal']")
   private WebElement freeCancellationModalContent;

   @FindBy(css = "[class*='components__close ']")
   private WebElement freeCancellationModalCloseButton;

   public SummaryFreeCancellationComponent()
   {
      wait = new WebElementWait();
   }

   public boolean isFreeCancellationComponentDisplayed()
   {
      wait.forComplexPageLoad();
      return isPresent(freeCancellationComponent);
   }

   public boolean isIconDisplayed()
   {
      return isPresent(getWebElementByCss(freeCancellationComponent, "svg"));
   }

   public boolean isMessageDisplayed()
   {
      return isPresent(freeCancellationMessage) &&
               isTextNotContainsUA(freeCancellationMessage.getText());
   }

   public boolean isLinkDisplayed()
   {
      return isPresent(freeCancellationModalLink) &&
               isTextNotContainsUA(freeCancellationModalLink.getText());
   }

   public void clickModalLink()
   {
      mouseOverAndClick(freeCancellationModalLink);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isModalExpanded()
   {
      return isPresent(freeCancellationModal);
   }

   public boolean isModalTitleDisplayed()
   {
      return isPresent(freeCancellationModalTitle) &&
               isTextNotContainsUA(freeCancellationModalTitle.getText());
   }

   public boolean isModalContentDisplayed()
   {
      return isPresent(freeCancellationModalContent) &&
               isTextNotContainsUA(freeCancellationModalContent.getText());
   }

   public void clickModalCloseButton()
   {
      mouseOverAndClick(freeCancellationModalCloseButton);
      wait.forJSExecutionReadyLazy();
   }

   public String getMessageEndDate()
   {
      String message = getElementText(freeCancellationMessage);
      String[] arr = message.split(" ");
      String messageMonth = arr[arr.length - 2];
      String month = null;

      for (Map.Entry<Month, List<String>> entry : monthsMap.entrySet())
      {
         if (entry.getValue().toString().contains(messageMonth.toLowerCase()))
         {
            month = entry.getKey().toString();
         }
      }

      if (Objects.isNull(month))
      {
         throw new RuntimeException("Component not found in Months map");
      }

      return new StringJoiner(" ")
               .add(arr[arr.length - 3])
               .add(month)
               .add(arr[arr.length - 1])
               .toString();
   }

   @SneakyThrows
   public boolean isNumberOfDaysEqual(int numberOfDays)
   {
      Date endDate = new SimpleDateFormat("dd MMM yyyy").parse(getMessageEndDate());
      LocalDate endDateLocal = endDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

      LocalDate todayPlusDays = LocalDate.now().plusDays(numberOfDays);

      return IntStream.range(0, numberOfDays)
               .anyMatch(i -> endDateLocal.equals(todayPlusDays.minusDays(i)));
   }

}
