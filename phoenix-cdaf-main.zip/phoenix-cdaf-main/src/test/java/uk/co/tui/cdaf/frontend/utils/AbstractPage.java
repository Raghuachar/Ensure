package uk.co.tui.cdaf.frontend.utils;

import org.openqa.selenium.support.PageFactory;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;

import java.net.URL;

import static com.codeborne.selenide.Selenide.open;
import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public abstract class AbstractPage
{
   private static final AutomationLogManager LOGGER = new AutomationLogManager(AbstractPage.class);

   public AbstractPage()
   {
      LOGGER.log(LogLevel.TRACE, "Initializing lazy elements for object: " + this);
      PageFactory.initElements(getDriver(), this);
   }

   public void visit()
   {
      final URL pageUrl = ExecParams.getTestExecutionParams().getUrl();
      LOGGER.log(LogLevel.INFO, "Getting page from " + pageUrl);
      open(pageUrl);
      BrowserCookies.closePrivacyPopUp();
   }

}
