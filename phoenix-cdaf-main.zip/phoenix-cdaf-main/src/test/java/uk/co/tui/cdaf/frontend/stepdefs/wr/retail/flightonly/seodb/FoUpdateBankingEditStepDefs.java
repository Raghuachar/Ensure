package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;

public class FoUpdateBankingEditStepDefs
{
   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final FOReconcilationPaymentPageComponents reconcilationPage;

   public FoUpdateBankingEditStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      reconcilationPage = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Agent is viewing the Update Banking Modal")
   public void that_the_Agent_is_viewing_the_Update_Banking_Modal()
   {
      retailflightNavigation.retailLoginFO();
      reconcilationPage.navigateToReconcilePaymentPage();
      reconcilationPage.clickOnUpdateBankingLink();
   }
}
