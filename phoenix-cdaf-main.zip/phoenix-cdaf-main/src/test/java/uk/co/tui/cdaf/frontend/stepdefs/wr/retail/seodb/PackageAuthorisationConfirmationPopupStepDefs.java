package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageAuthorisationConfirmationPopupStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageAuthorisationConfirmationPopupStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @When("the view the authorise EOD banking modal pop-up")
   public void the_view_the_authorise_EOD_banking_modal_pop_up()
   {
      pKgReconcilationPaymentPageComponents.clickSelectReason();
      pKgReconcilationPaymentPageComponents.selectOneReson();
      pKgReconcilationPaymentPageComponents.clickSelectReasonSubmitCTA();

      pKgReconcilationPaymentPageComponents.selectCashReson();
      pKgReconcilationPaymentPageComponents.clickSelectReasonSubmitCTA();

      pKgReconcilationPaymentPageComponents.clickAuthoriseCTA();
   }

   @When("the agent has reviewed the data displayed")
   public void the_agent_has_reviewed_the_data_displayed()
   {
      assertThat("AUTHORISE table is present",
               pKgReconcilationPaymentPageComponents.addedReasonsInReconciliationModalPresent(),
               is(true));
   }

   @When("has pressed the AUTHORISE CTA on the Authorise EOD banking modal")
   public void has_pressed_the_AUTHORISE_CTA_on_the_Authorise_EOD_banking_modal()
   {
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickAuthoriseModalCTA();
      wait.forJSExecutionReadyLazy();
   }

   @Then("the confirmation of authorisation pop up will appear once the authorise EOD banking modal has closed")
   public void the_confirmation_of_authorisation_pop_up_will_appear_once_the_authorise_EOD_banking_modal_has_closed()
   {
      assertThat("AUTHORISE confirmation modal is present",
               pKgReconcilationPaymentPageComponents.isAuthorisationConfirmationPopup(), is(true));
   }

   @Then("the Authorise confirmation will pop-up displaying the respective information")
   public void the_Authorise_confirmation_will_pop_up_displaying_the_information(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("AUTHORISE confirmation modal title is present",
               pKgReconcilationPaymentPageComponents.isAuthoriseConfModalTitle(), is(true));
      assertThat("AUTHORISE confirmation message is present",
               pKgReconcilationPaymentPageComponents.isAuthorisationMessage(), is(true));
      assertThat("AUTHORISE transction id is present",
               pKgReconcilationPaymentPageComponents.isAuthorisationTransctionId(), is(true));
      assertThat("AUTHORISE confirmation modal close CTA is present",
               pKgReconcilationPaymentPageComponents.isAuthoriseModalCloseCTA(), is(true));
   }

   @Then("the AUTHORISE CTA on the payments and reconciliations page will disabled")
   public void the_AUTHORISE_CTA_on_the_payments_and_reconciliations_page_will_disabled()
   {
      assertThat("AUTHORISE CTA button is disabled",
               pKgReconcilationPaymentPageComponents.isSeodbDisabledAuthoriseButton(), is(true));
   }

   @Then("the Agent cannot AUTHORISE that day again.")
   public void the_Agent_cannot_AUTHORISE_that_day_again()
   {
      assertThat("AUTHORISE CTA button is disabled",
               pKgReconcilationPaymentPageComponents.isSeodbDisabledAuthoriseButton(), is(true));
   }
}
