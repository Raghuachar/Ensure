package uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentOptionPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults.SearchResults;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.utils.Generic;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static com.codeborne.selenide.Selenide.open;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class RetailFlightOnlyPageNavigation
{
   public final SearchResults searchResults;

   public final PageErrorHandler errorHandler;

   public final FlightOptionsPage flightOptionsPage;

   public final WebElementWait wait;

   public final RetailPassengerDetailsPage retailpassengerdetailsPage;

   public final PackageNavigation packagenavigation;

   public final PaymentOptionPage paymentOptionPage;

   public final ExtraOptionsPage extraOptionsPage;

   public final SearchPanelComponent searchPanelComponent;

   public final RetailSearchPanelComponent retailsearchPanelComponent;

   public final WebDriverUtils utils;

   public final RetailPage retailPage;

   private final FOMFESearchPanelComponents fOMFESearchPanelComponents;

   public String flightSearch = StringUtils.EMPTY;

   private String adfsUrl = StringUtils.EMPTY;

   public RetailFlightOnlyPageNavigation()
   {
      searchResults = new SearchResults();
      errorHandler = new PageErrorHandler();
      wait = new WebElementWait();
      flightOptionsPage = new FlightOptionsPage();
      paymentOptionPage = new PaymentOptionPage();
      extraOptionsPage = new ExtraOptionsPage();
      searchPanelComponent = new SearchPanelComponent();
      utils = new WebDriverUtils();
      retailPage = new RetailPage();
      retailpassengerdetailsPage = new RetailPassengerDetailsPage();
      packagenavigation = new PackageNavigation();
      retailsearchPanelComponent = new RetailSearchPanelComponent();
      fOMFESearchPanelComponents = new FOMFESearchPanelComponents();
   }

   public void availableSearchResults()
   {
      searchPanelComponent.closePrivacyPopUp();
      if (!searchResults.isOutboundFlightButtonDisplyed())
      {
         if (searchResults.getOutboundDates().isEmpty())
         {
            do
            {
               WebElementTools.clickElementJavaScript(searchResults.getOutboundNextArrow());
               wait.forJSExecutionReadyLazy();
            } while (searchResults.getOutboundDates().isEmpty());
         }
         int incr = 0;
         while (incr < searchResults.getOutboundDates().size())
         {
            final WebElement element = searchResults.getOutboundDates().get(incr);
            WebElementTools.javaScriptScrollToElement(element);
            WebElementTools.clickElementJavaScript(element);
            if (WebElementTools.isPresent(searchResults.getInfoMessageModalElement()))
               WebElementTools.click(searchResults.getInfoMessageModalCloseElement());
            else
               break;
            WebElementTools.clickElementJavaScript(searchResults.getOutboundNextArrow());
            wait.forJSExecutionReadyLazy();
            incr++;
         }
      }
      if (!searchResults.isInboundFlightButtonDisplyed())
      {
         if (searchResults.getInboundDates().isEmpty())
         {
            do
            {
               WebElementTools.clickElementJavaScript(searchResults.getInboundNextArrow());
               wait.forJSExecutionReadyLazy();
            } while (searchResults.getInboundDates().isEmpty());
         }
         int incr = 0;
         while (incr < searchResults.getInboundDates().size())
         {
            final WebElement element = searchResults.getInboundDates().get(incr);

            WebElementTools.javaScriptScrollToElement(element);
            WebElementTools.clickElementJavaScript(element);

            if (WebElementTools.isPresent(searchResults.getInfoMessageModalElement()))
               WebElementTools.click(searchResults.getInfoMessageModalCloseElement());
            else
               break;
            WebElementTools.click(searchResults.getInboundNextArrow());
            wait.forJSExecutionReadyLazy();
            incr++;
         }
      }
   }

   public void oneWayAvailableSearchResults()
   {
      searchPanelComponent.closePrivacyPopUp();
      if (!searchResults.isOutboundFlightButtonDisplyed())
      {
         if (searchResults.getOutboundDates().isEmpty())
         {
            do
            {
               WebElementTools.clickElementJavaScript(searchResults.getOutboundNextArrow());
               wait.forJSExecutionReadyLazy();
            } while (searchResults.getOutboundDates().isEmpty());
         }
         int incr = 0;
         while (incr < searchResults.getOutboundDates().size())
         {
            final WebElement element = searchResults.getOutboundDates().get(incr);
            WebElementTools.javaScriptScrollToElement(element);
            WebElementTools.clickElementJavaScript(element);
            if (WebElementTools.isPresent(searchResults.getInfoMessageModalElement()))
               WebElementTools.click(searchResults.getInfoMessageModalCloseElement());
            else
               break;
            WebElementTools.clickElementJavaScript(searchResults.getOutboundNextArrow());
            wait.forJSExecutionReadyLazy();
            incr++;
         }
      }
   }

   public void navigateToFlightPage()
   {
      navigateToSearchResultPage();
      final WebElement outboundButton = searchResults.getOutboundFlightButton();
      WebElementTools.clickElementJavaScript(outboundButton);
      if (!flightSearch.equals("one way"))
      {
         final WebElement inboundButton = searchResults.getInboundFlightButton();
         WebElementTools.clickElementJavaScript(wait.getWebElementWithLazyWait(inboundButton));
      }
      WebElementTools
               .click(wait.getWebElementWithLazyWait(searchResults.getContinueToFlightButton()));
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public final void loginToRetailThirdParty()
   {
      if (!StringUtils.containsIgnoreCase(adfsUrl, "adfs") && retailPage.isRetailLoginPage())
      {
         retailPage.thirdPartyLogin();
      }
      else
         Generic.adfsLogin(adfsUrl);
   }

   public void retailLoginFO()
   {
      searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         loginToRetailThirdParty();
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
   }

   public void navigateToSearchResultPage()
   {
      searchPanelComponent.visit();
      searchPanelComponent.closePrivacyPopUp();
      adfsUrl = utils.getCurrentURL();
      if (ExecParams.getAgent().isThirdparty())
         loginToRetailThirdParty();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      String url = getTestExecutionParams().getUrlStr()
               .replace("sncuser:U2FsZXMmQ29udGVudERvbWFpbg==@", StringUtils.EMPTY);
      open(url);
      searchPanelComponent.closePrivacyPopUp();
      if (flightSearch.equalsIgnoreCase("one way"))
      {
         searchPanelComponent.wrFoOneWaySearch();
         oneWayAvailableSearchResults();
      }
      else
      {
         searchPanelComponent.wrFoTwoWaySearch();
         availableSearchResults();
      }
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToExtraPage()
   {
      navigateToFlightPage();
      flightOptionsPage.clickOnContinue();
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPassengerDetailsPage()
   {
      navigateToExtraPage();
      extraOptionsPage.clickOnContinue();
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPaymentOptionsPageFO()
   {
      navigateToPassengerDetailsPage();
      if (ExecParams.getAgent().isThirdparty())
         retailpassengerdetailsPage.fillThePassengerDetailsThirdparty();
      if (ExecParams.getAgent().isInhouse())
         retailpassengerdetailsPage.fillThePassengerDetailsInhouse();
      wait.forJSExecutionReadyLazy();
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public void enterPayerNameWithAccents()
   {
      wait.forJSExecutionReadyLazy();
      retailpassengerdetailsPage.enterPayernameWithAccents();
      wait.forJSExecutionReadyLazy();
   }

   public boolean isErrorMessageDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return retailpassengerdetailsPage.validatePayerName();
   }

   public void createOnewayBooking()
   {
      wrMFEFoOneWaySearch();
      retailsearchPanelComponent.selectFlight();
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();

   }

   public void extraOptionsPageOneway()
   {
      retailsearchPanelComponent.wrFoOneWaySearch();
      retailsearchPanelComponent.selectFlight();
      flightOptionsPage.clickOnContinue();
   }

   public final void wrMFEFoOneWaySearch()
   {
      fOMFESearchPanelComponents.selectOneWayMFE();
      fOMFESearchPanelComponents.selectOutboundAirport();
      fOMFESearchPanelComponents.selectAllOutboundAirport();
      fOMFESearchPanelComponents.selectSearchFieldAirportInbound();
      fOMFESearchPanelComponents.selectInboundAirport();
      fOMFESearchPanelComponents.searchFieldDateOutbound();
      fOMFESearchPanelComponents.searchBoxNext();
      fOMFESearchPanelComponents.selectAvailableDate();
      fOMFESearchPanelComponents.searchButton();
   }

}
