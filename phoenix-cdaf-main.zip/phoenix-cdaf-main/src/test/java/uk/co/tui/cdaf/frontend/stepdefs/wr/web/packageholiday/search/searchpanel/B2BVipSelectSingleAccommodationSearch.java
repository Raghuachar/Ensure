package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;

public class B2BVipSelectSingleAccommodationSearch
{
   public final PackageNavigation packageNavigation;

   public B2BVipSelectSingleAccommodationSearch()
   {
      packageNavigation = new PackageNavigation();
   }

   // TODO: cleanup, this step definition fully or partially duplicates step definitions from the list bellow:
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel.MFESearchPanelDepartureAirportStepDefs.java
   //        the_is_on_the_Belgium_Dutch_page(String, String)
   //        the_is_on_the_Belgium_French_page(String, String)
   //        the_is_on_the_Netherlands_page(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.RoomAndGuestAutoAllocationStepDefs.java
   //        is_on_the_page(String)
   //        they_re_on_the_page(String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.B2BVipSelectSingleAccommodationSearch.java
   //        the_is_on_the_page_VIP_Select_package(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage.B2BTUIVIPBrandToggleFlipStepDefs.java
   //        the_is_on_the_page(String, String)
   @Given("the {string} is on the {string} page VIP Select package")
   public void the_is_on_the_page_VIP_Select_package(String agent, String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Homepage"))
      {
         packageNavigation.navigateToHoldaySearchPage();
      }
      else if (respectivePage.equalsIgnoreCase("Search Results"))
      {
         packageNavigation.navigateToVipSearchResultPage();
      }
      else if (respectivePage.equalsIgnoreCase("Unit details"))
      {
         packageNavigation.navigateToVipUnitDetailsPage();
      }
   }
}
