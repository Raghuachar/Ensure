package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.search;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageB2BClearAgencyStepDefs
{

   private final PackageNavigation packageNavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final SearchResultsPage searchResultsPage;

   private final RetailPage retailPage = new RetailPage();

   public PackageB2BClearAgencyStepDefs()
   {
      packageNavigation = new PackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      searchResultsPage = new SearchResultsPage();
   }

   @Given("the agent completed a booking")
   public void the_agent_completed_a_booking()
   {
      packageNavigation.navigateToPassengerPage();
      retailpassengerdetailspage.fillThePassengerDetailsInhouse();
      retailpassengerdetailspage.skippayment();
   }

   @When("they select the next customer")
   public void they_select_the_next_customer()
   {
      retailpassengerdetailspage.nextCustomer();
   }

   @Then("the active agency will return to their default agency")
   public void the_active_agency_will_return_to_their_default_agency()
   {
      assertThat("the active agency is not return to their default agency",
               retailpassengerdetailspage.defaultAgency(), is(true));
   }

   @Given("the agent wants to select a new agency")
   public void the_agent_wants_to_select_a_new_agency()
   {
      searchResultsPage.searchPanelComponent.visit();
      retailPage.inhouseAgentLogin();
   }

   @When("they search for and select a new agency")
   public void they_search_for_and_select_a_new_agency()
   {
      retailpassengerdetailspage.addTPagent();
   }

   @Then("the active agency will update to what they have selected")
   public void the_active_agency_will_update_to_what_they_have_selected()
   {
      String getAgentCode = retailpassengerdetailspage.getTPagent().getText();
      String[] agentCode = getAgentCode.split(" ");
      assertThat("the active agency is NOT updated to what they have selected",
               agentCode[5].trim().contains("605502"), is(true));
   }

}
