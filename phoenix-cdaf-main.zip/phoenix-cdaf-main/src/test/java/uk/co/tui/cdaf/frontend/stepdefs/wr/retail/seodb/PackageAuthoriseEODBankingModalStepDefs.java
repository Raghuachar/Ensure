package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageSEODBComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageAuthoriseEODBankingModalStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final PackageSEODBComponents pkgPackageSEODBComponents;

   public PackageAuthoriseEODBankingModalStepDefs()
   {
      wait = new WebElementWait();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      packagenavigation = new PackageNavigation();
      pkgPackageSEODBComponents = new PackageSEODBComponents();
   }

   @Then("they will see the respective headers")
   public void they_will_see_the_respective_headers(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("AUTHORISE RECONCILIATION displayed on the screen",
               pkgPackageSEODBComponents.isModalHeading(), is(true));
      assertThat("Date/ Time table heading displayed on the screen",
               pkgPackageSEODBComponents.isDateTime(), is(true));
      assertThat("Amount/ Method table heading displayed on the screen",
               pkgPackageSEODBComponents.isDiscrepancyAmountMethod(), is(true));
      assertThat("Reason table heading displayed on the screen",
               pkgPackageSEODBComponents.isReason(), is(true));
      retailpassengerdetailspage.userLogout();
   }

   @Then("they will see the respective table information")
   public void they_will_see_the_respective_table_information(
            io.cucumber.datatable.DataTable dataTable)
   {

      assertThat("Date & Timestamp displayed on the screen",
               pkgPackageSEODBComponents.isReconDateTimestamp(), is(true));
      assertThat("Recon amount/ method displayed on the screen",
               pkgPackageSEODBComponents.isReconAmountMethod(), is(true));
      assertThat("Recon reason displayed on the screen", pkgPackageSEODBComponents.isReconReason(),
               is(true));
      assertThat("Show more reason displayed on the screen",
               pkgPackageSEODBComponents.isReconReasonShowMore(), is(true));
      retailpassengerdetailspage.userLogout();
   }

   @And("they will see the CTAs for CANCEL & AUTHORISE")
   public void they_will_see_the_CTAs_for_CANCEL_AUTHORISE()
   {
      assertThat("Authorise modal close button displayed on the screen",
               pkgPackageSEODBComponents.isAuthoriseModalCloseButton(), is(true));
      assertThat("Authorise modal submit button displayed on the screen",
               pkgPackageSEODBComponents.isAuthoriseModalSubmitButton(), is(true));
      retailpassengerdetailspage.userLogout();
   }
}
