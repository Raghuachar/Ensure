package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class DateFilterComponent extends AbstractPage
{

   public final WebElementWait wait;

   private final Map<String, WebElement> dateFilterMap;

   @FindBy(css = "[class='DatesAndDuration__datesList']")
   public WebElement allDates;

   @FindBy(css = "[class*='DatesAndDuration__cardContainer']")
   private WebElement dateFilterComponent;

   @FindBy(xpath = "//li[@aria-label='availabledate0']/label/span[1]")
   private WebElement dateFilterDefaultSelected;

   @FindBy(xpath = "//li[@aria-label='availabledate1']/label/span[1]")
   private WebElement selectAnyDateFilter;

   @FindBy(css = "[aria-label='duration']")
   private WebElement selectedDateFilterDisplayed;

   @FindBy(css = "[class='DatesAndDuration__datesList']")
   private WebElement dateFilterDatesDisplayed;

   @FindBy(css = "[class*='DatesAndDuration__showMore']")
   private WebElement showMoreLink;

   @FindBy(css = "[aria-label='availabledate5']")
   private WebElement additionalDateDisplayed;

   @FindBy(css = "[class*='DatesAndDuration__showMore']")
   private WebElement showLessLink;

   @FindBy(css = "[aria-label='availabledate0']")
   private WebElement dateFilterNotDisplayed;

   private String anyDate = StringUtils.EMPTY;

   public DateFilterComponent()
   {
      wait = new WebElementWait();
      dateFilterMap = new HashMap<>();
   }

   public boolean isDateFilterDisplayed()
   {
      return !WebElementTools.isPresent(dateFilterComponent);
   }

   public WebElement isDateFilterDefaultSelected()
   {

      return wait.getWebElementWithLazyWait(dateFilterDefaultSelected);
   }

   public void clickAnyDateFilter()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(selectAnyDateFilter);
      anyDate = selectAnyDateFilter.getText();
   }

   public boolean isDisplayedSelectedDateFilter()
   {
      wait.forJSExecutionReadyLazy();
      boolean dateDisplay = false;
      try
      {
         if (anyDate.contains(selectedDateFilterDisplayed.getText()))
            dateDisplay = WebElementTools.isPresent(selectedDateFilterDisplayed);
      }
      catch (Exception e)
      {
         dateDisplay = false;
      }
      return dateDisplay;

   }

   public boolean isDisplayedDates()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(dateFilterDatesDisplayed);
   }

   public Map<String, WebElement> getDateFilterComponents()
   {
      dateFilterMap.put("All Dates", allDates);
      dateFilterMap.put("Show More Link", showMoreLink);
      return dateFilterMap;
   }

   public void clickShowMoreLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(showMoreLink);
   }

   public boolean isAdditionalDateDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(additionalDateDisplayed);
   }

   public boolean isShowLessLinkDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(showLessLink);
   }

   public void clickShowLessLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(showLessLink);
   }

   public boolean isDateFilterNotDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(dateFilterNotDisplayed);
   }

}
