package uk.co.tui.cdaf.frontend.stepdefs.uk.web.beach_holiday.browse.homepage.globalheader;

import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.flight_only.browse.homepage.Footer;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * GlobalFlagFooterStepDefs
 */
public class GlobalFlagFooterStepDefs
{
   private final Footer footer = new Footer();

   @When("they view the Footer")
   public void they_view_the_Footer()
   {
      footer.scrollToFooter();
      assertThat("Footer not displayed", footer.isFooterDisplayed(), is(true));
   }

}
