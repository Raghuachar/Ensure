package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOGlobalHeaderReconcilePaymentPageStepDefs
{
   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final FOReconcilationPaymentPageComponents reconcilationPage;

   public FOGlobalHeaderReconcilePaymentPageStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      reconcilationPage = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the agent is viewing the Reconcile payments page")
   public void that_the_agent_is_viewing_the_Reconcile_payments_page()
   {
      retailflightNavigation.retailLoginFO();
      reconcilationPage.navigateToReconcilePaymentPage();
   }

   @When("they view the header at the top of the page")
   public void they_view_the_header_at_the_top_of_the_page()
   {
      assertThat("Global Header is not present ", reconcilationPage.isSubmenuePresent(), is(true));

   }

   @Then("they can see the TUI global header")
   public void they_can_see_the_TUI_global_header()
   {
      assertThat(" Global Header is not present", reconcilationPage.isGlobalHeaderIsPresent(),
               is(true));

   }

}
