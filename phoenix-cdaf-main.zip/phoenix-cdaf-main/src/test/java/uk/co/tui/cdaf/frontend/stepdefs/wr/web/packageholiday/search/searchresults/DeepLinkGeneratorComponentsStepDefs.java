package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class DeepLinkGeneratorComponentsStepDefs
{

   public final SearchResultsPage searchResultsPage;

   public DeepLinkGeneratorComponentsStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
   }

   @And("they have been redirected to the {string} page")
   public void they_have_been_redirected_to_the_page(String accom)
   {
      searchResultsPage.singleAccommodationComponent.alternativeMonthsInDeeplink("10-02-2022");
      searchResultsPage.singleAccommodationComponent.deeplinkGenerator("&deeplinkbuilder=true");
   }

   @When("they review the bottom of the filters component")
   public void they_review_the_bottom_of_the_filters_component()
   {
      assertThat("deep Link is not displayed",
               searchResultsPage.singleAccommodationComponent.isDeepLinkComponentIsnotDisplayed(),
               is(false));
   }

   @Then("they cannot see the deeplink generator component")
   public void they_cannot_see_the_deeplink_generator_component()
   {
      assertThat("deep Link is not displayed",
               searchResultsPage.singleAccommodationComponent.isDeepLinkComponentIsnotDisplayed(),
               is(false));
   }

}
