package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.roomoptions.RoomOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.PriceBreakDownComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.book.extraoptions.MultiSelectInsuranceComponent;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class PriceBreakdownStepDefs
{
   private static final double DELTA = 0.01;

   private final SummaryPage summaryPage;

   private final PriceBreakDownComponent priceBreakComponent;

   private final PackageNavigation packageNavigation;

   public PriceBreakdownStepDefs(PriceBreakDownComponent priceBreakDownComponent)
   {
      summaryPage = new SummaryPage();
      priceBreakComponent = summaryPage.priceBreakComponent;
      packageNavigation = new PackageNavigation();
   }

   @Then("within the Booking Charges section they will be able able to see the line item in Price Breakdown component")
   public void within_the_section_they_will_be_able_able_to_see_the_line_item_in_Price_Breakdown_component()
   {
      summaryPage.BookingFee();
   }

   @And("user expands Options & Extras list in the Price Breakdown component")
   public void user_expands_options_extras_list_in_the_price_breakdown_component()
   {
      priceBreakComponent.clickShowMoreOfOptionsExtras();
   }

   @And("insurance price is displayed in Price Breakdown of Summary page")
   public void insurance_price_is_displayed_in_price_breakdown_of_summary_page()
   {
      Double priceBreakDownInsurancePrice =
               priceBreakComponent.getInsurancePriceDouble();
      assertTrue("Insurance price in Price Breakdown should be displayed", priceBreakDownInsurancePrice > 0);
      assertEquals("Insurance total prices in Extras page and Price Breakdown are different",
               MultiSelectInsuranceComponent.selectedInsurancesPrice.get(),
               priceBreakDownInsurancePrice, DELTA);
   }

   @And("updated insurance price is displayed in Price Breakdown of Summary page")
   public void updated_insurance_price_is_displayed_in_price_breakdown_of_summary_page()
   {
      Double priceBreakDownInsurancePrice =
               priceBreakComponent.getInsurancePriceDouble();
      assertTrue("Insurance price in Price Breakdown should be displayed",
               priceBreakDownInsurancePrice > 0);
      assertEquals("Updated Insurance total price and initial insurance price should be different",
               RoomOptionsPage.insPriceDiffDouble.get(),
               MultiSelectInsuranceComponent.selectedInsurancesPrice.get() - priceBreakDownInsurancePrice, DELTA);
   }

   @Given("user is on the Summary page of the package with discount applied")
   public void user_is_on_the_summary_page_of_the_package_with_discount_applied()
   {
      packageNavigation.navigateToSummaryWithDiscount();
   }

   @And("user expands discounts list in the Price Breakdown component")
   public void user_expands_discounts_list_in_the_price_breakdown_component()
   {
      priceBreakComponent.clickShowMoreOfDiscounts();
   }

   @And("user remembers discount types applied to the booking")
   public void user_remembers_discount_types_applied_to_the_booking()
   {
      PriceBreakDownComponent.discountsTypesApplied.set(priceBreakComponent.getDiscountsAppliedToBooking());
   }

   @When("user navigates to Detailed Price Breakdown page")
   public void user_navigates_to_detailed_price_breakdown_page()
   {
      summaryPage.priceBreakComponent.clickOnDetailedBreakdownLink();
   }
}
