package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;

import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search.enums.StayDuration;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;

import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class MFESearchPanelRetentionStepDefs
{

   private final PackageNavigation packageNavigation = new PackageNavigation();

   private final SearchPanel searchPanel = getSearchPanel();

   private List<String> selectedAirports;

   private String selectedDate;

   private String selectedDestination;

   private String selectedDuration;

   private String selectedPaxAndRooms;

   @Given("the Customer or Agent is viewing the {string} page")
   public void theCustomerOrAgentIsViewingTheRespectivePage(String pageName)
   {
      switch (pageName)
      {
         case "Search Results":
            packageNavigation.navigateToSearchResultPage();
            break;
         case "Unit Details":
            packageNavigation.navigateToUnitDetailsPage();
         case "Single Accommodation Search Results":
            packageNavigation.navigateToSingleAccomSearchResultPage();
         default:
            fail(String.format("Invalid Page Name : %s", pageName));
      }
   }

   @Given("they have changed any of the details in the Search Panel")
   public void theyHaveChangedAnyOfTheDetailsInTheSearchPanel()
   {
      if (packageNavigation.unitPage.isSearchPanelMFEHidden())
      {
         packageNavigation.unitPage.clickEditSearch();
      }
      searchPanel.airport().selectRandomAirport().confirmSelection();
      searchPanel.departure().selectRandomMonth().selectRandomDate().confirmSelection();
      searchPanel.selectDuration(StayDuration.NIGHTS_8);
      searchPanel.paxAndRooms().selectNumberOfRooms(2).confirmSelection();
      selectedAirports = searchPanel.airport().getSelectedAirports();
      selectedDestination = searchPanel.getSelectedDestination();
      selectedDate = searchPanel.getSelectedDate();
      selectedDuration = searchPanel.getSelectedDuration();
      selectedPaxAndRooms = searchPanel.getSelectedPaxAndRooms();
   }

   @Given("they have conducted a new search")
   public void theyHaveConductedANewSearch()
   {
      searchPanel.doSearch();
   }

   @Given("they have progressed in the book flow \\(e.g. Customise Holiday page, Passenger Details page, etc...)")
   public void theyHaveProgressedInTheBookFlow()
   {
      if (packageNavigation.searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed())
      {
         packageNavigation.searchResultsPage.singleAccommodationComponent.selectDateCell();
      }
      else
      {
         assertTrue("Search Results are not displayed",
                  packageNavigation.searchResultsPage.isHoildayCountDisplayed());
         packageNavigation.searchResultsPage.searchResultComponent.selectRandomResultCard();
      }
      assertTrue("Unit details page is not displayed",
               packageNavigation.unitPage.isHotelDetailsPageDisplayed());
      packageNavigation.unitPage.progressbarComponent.clickOnContinueButton();
      assertTrue("Summary page is not displayed",
               packageNavigation.summaryPage.navigationComponent.isPageDisplayed());
   }

   @When("they navigate back to the {string} page")
   public void theyNavigateBackToTheRespective(String pageName)
   {
      packageNavigation.unitPage.progressbarComponent.ClickOnBackToUnitDetailspage();
      assertTrue("Unit details page is not displayed",
               packageNavigation.unitPage.isHotelDetailsPageDisplayed());
      if (StringUtils.contains(pageName, "Search Results"))
      {
         packageNavigation.searchResultsPage.searchResultComponent.clickOnBackToSearchResults();
         if (StringUtils.equals(pageName, "Search Results"))
         {
            assertTrue("Search Results are not displayed",
                     packageNavigation.searchResultsPage.isHoildayCountDisplayed());
         }
         else if (StringUtils.equals("Single Accommodation Search Results", pageName))
         {
            assertTrue("Single Accom Page is not displayed",
                     packageNavigation.searchResultsPage.isAvailabilityCalendarPresent());
         }
      }
      if (packageNavigation.unitPage.isSearchPanelMFEHidden())
      {
         packageNavigation.unitPage.clickEditSearch();
      }
   }

   @Then("the previous entered Search Panel details are retained")
   public void thePreviousEnteredSearchPanelDetailsAreRetained()
   {
      final List<String> displayedAirports = searchPanel.airport().getSelectedAirports();
      final String displayedDestination = searchPanel.getSelectedDestination();
      final String displayedDate = searchPanel.getSelectedDate();
      final String displayedDuration = searchPanel.getSelectedDuration();
      final String displayedPaxAndRooms = searchPanel.getSelectedPaxAndRooms();
      SoftAssertions softAssertions = new SoftAssertions();
      softAssertions.assertThat(displayedAirports)
               .withFailMessage("Airport selection not retained, selected airports")
               .isEqualTo(selectedAirports);
      softAssertions.assertThat(displayedDestination)
               .withFailMessage("Destination selection not retained, selected destination")
               .isEqualTo(selectedDestination);
      softAssertions.assertThat(displayedDate)
               .withFailMessage("Date selection not retained, selected date")
               .isEqualTo(selectedDate);
      softAssertions.assertThat(displayedDuration)
               .withFailMessage("Duration selection not retained, selected duration")
               .isEqualTo(selectedDuration);
      softAssertions.assertThat(displayedPaxAndRooms)
               .withFailMessage("Pax and Rooms selection not retained, selected pax and rooms")
               .isEqualTo(selectedPaxAndRooms);
      softAssertions.assertAll();

   }

}
