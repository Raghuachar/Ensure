package uk.co.tui.cdaf.frontend.pom.wr.web.stay.book.yourholiday;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;
import java.util.Map;

public class YourAccommodationComponent extends AbstractPage
{
   @FindBy(css = "[aria-label='Your accommodation']")
   private WebElement yourAccomodation;

   public YourAccommodationComponent()
   {
      super();
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getYourAccommodationComponent()
   {
      return new HashMap<>()
      {
         {
            put("Room and Board", yourAccomodation);
         }
      };
   }
}
