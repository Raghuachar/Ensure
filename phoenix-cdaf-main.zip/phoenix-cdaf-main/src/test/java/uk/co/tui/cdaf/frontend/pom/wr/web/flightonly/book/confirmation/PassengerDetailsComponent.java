package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;
import java.util.regex.Pattern;

public class PassengerDetailsComponent extends AbstractPage
{
   private static final String LEAD_PATTERN =
            "^[a-zA-ZéäãçÀ'-]+\\s+[a-zA-ZéäãçÀ'-]+\\s+\\(Lead (passenger|Passenger)\\)$";

   private static final String NON_LEAD_PATTERN = "^[a-zA-ZéäãçÀ'-]+\\s+[a-zA-ZéäãçÀ'-]+$";

   private final WebElementWait wait;

   public boolean matched = true;

   public String passengerInfo = StringUtils.EMPTY;

   @FindBy(css = "[aria-label='passenger Details']")
   private WebElement passengerDetails;

   @FindBy(css = "[class*='passengerDetails'] p")
   private List<WebElement> passengersInfo;

   public PassengerDetailsComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getPassengerDetailsElement()
   {
      return passengerDetails;
   }

   public List<WebElement> getPassengersInfoElement()
   {
      return wait.getWebElementWithLazyWait(passengersInfo);
   }

   public void passengerLeadInfoVerification()
   {
      List<WebElement> passengers = getPassengersInfoElement();
      String passengerName = WebElementTools.getElementText(passengers.get(0)).trim();
      if (!Pattern.matches(LEAD_PATTERN, passengerName))
      {
         matched = false;
         passengerInfo = passengerName;
      }
   }

   public void passengerNonLeadInfoVerification()
   {
      try
      {
         List<WebElement> passengers = getPassengersInfoElement();
         for (int index = 1; index < passengers.size(); index++)
         {
            String passengerName = WebElementTools.getElementText(passengers.get(index)).trim();
            if (!Pattern.matches(NON_LEAD_PATTERN, passengerName))
            {
               matched = false;
               passengerInfo = passengerName;
            }
         }
      }
      catch (Exception e)
      {
         matched = false;
      }
   }

   public String getLeadPassengrLastName()
   {
      wait.forJSExecutionReadyLazy();
      wait.waitForAWhile(2000);
      wait.waitForElementToBePresent(getPassengersInfoElement());
      List<WebElement> passengers = getPassengersInfoElement();
      String passengerName = WebElementTools.getElementText(passengers.get(0)).trim();
      if (!Pattern.matches(LEAD_PATTERN, passengerName))
      {
         matched = false;
         passengerInfo = passengerName;
      }
      String[] lastName;
      lastName = passengerName.split(" ");
      return lastName[1];
   }

}
