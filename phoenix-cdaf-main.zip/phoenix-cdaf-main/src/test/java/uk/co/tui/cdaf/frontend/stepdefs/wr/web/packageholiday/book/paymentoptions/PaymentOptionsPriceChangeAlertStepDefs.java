package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.paymentoptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PaymentOptionsPriceChangeAlertStepDefs
{

   public final PackageNavigation packageNavigation;

   public final SummaryPage summaryPage;

   public PaymentOptionsPriceChangeAlertStepDefs()
   {
      packageNavigation = new PackageNavigation();
      summaryPage = new SummaryPage();
   }

   @Given("that the customer is on Passenger Details page")
   public void that_the_customer_is_on_Passenger_Details_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @When("they navigate to Payments page")
   public void they_navigate_to_Payments_page()
   {
      packageNavigation.navigateToPaymentPage();
   }

   @When("there has been a price increase in the unit price or flight price")
   public void there_has_been_a_price_increase_in_the_unit_price_or_flight_price()
   {
      // Will implement this step once it is available
   }

   @Then("they will be presented with the Price Increase  Message")
   public void they_will_be_presented_with_the_Price_Increase_Message()
   {
      boolean actual = summaryPage.priceChangeAlertComponent.isPriceChangeComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Price change alert component wasnt displayed", actual, true), actual, is(true));
   }

   @Given("that the customer is on Customise page")
   public void that_the_customer_is_on_Customise_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they navigate to Passenger Details page")
   public void they_navigate_to_Passenger_Details_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @Then("they will be presented with the Price Decrease  Message")
   public void they_will_be_presented_with_the_Price_Decrease_Message()
   {
      boolean actual = summaryPage.priceChangeAlertComponent.isPriceChangeComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Price change alert component wasnt displayed", actual, true), actual, is(true));
   }
}
