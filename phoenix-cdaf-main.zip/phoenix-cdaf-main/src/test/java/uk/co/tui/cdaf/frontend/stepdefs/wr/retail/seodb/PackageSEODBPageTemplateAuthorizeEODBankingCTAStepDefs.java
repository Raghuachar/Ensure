package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSEODBPageTemplateAuthorizeEODBankingCTAStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageSEODBPageTemplateAuthorizeEODBankingCTAStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent is viewing the payments and reconciliation page")
   public void that_the_agent_is_viewing_the_payments_and_reconciliation_page()
   {
      packagenavigation.retailLoginChangeagent();
      pKgReconcilationPaymentPageComponents.clickPrivacyPopupClose();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

   @When("they have clicked the AUTHORISE CTA")
   public void they_have_clicked_the_AUTHORISE_CTA()
   {
      pKgReconcilationPaymentPageComponents.selectReasonSelectBoxOption();
      pKgReconcilationPaymentPageComponents.enterRegionTextSubmitRegionModal();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickAuthoriseCTA();
   }

   @Then("the authorise reconciliations modal pop-up will appear on the screen")
   public void the_authorise_reconciliations_modal_pop_up_will_appear_on_the_screen()
   {
      assertThat("The authorise reconciliations modal pop-up will appear on the screen",
               pKgReconcilationPaymentPageComponents.authoriseReconciliationModalIsPresent(),
               is(true));
   }

   @And("the reasons that have been chosen will be displayed here")
   public void the_reasons_that_have_been_chosen_will_be_displayed_here()
   {
      assertThat("The reasons that have been chosen will be displayed here",
               pKgReconcilationPaymentPageComponents.addedReasonsInReconciliationModalPresent(),
               is(true));
   }

   @And("click confirm CTA on reconciliations modal popup")
   public void click_confirm_CTA_on_reconciliations_modal_popup()
   {
      throw new PendingException();
   }

   @Then("confirmation pop up will be displayed")
   public void confirmation_popup_will_be_displayed()
   {
      throw new PendingException();
   }
}
