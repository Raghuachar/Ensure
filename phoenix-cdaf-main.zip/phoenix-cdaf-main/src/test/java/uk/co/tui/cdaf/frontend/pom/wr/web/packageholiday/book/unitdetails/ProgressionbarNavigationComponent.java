package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import com.codeborne.selenide.Condition;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class ProgressionbarNavigationComponent extends AbstractPage
{
   private final Map<String, WebElement> pricePanelMap;

   private final WebElementWait wait;

   @FindBy(css = ".Header__headerTitle h1 > span")
   public WebElement hotelName;

   public Map<String, WebElement> progressionBarComponents;

   @FindBy(css = "[class*='pricePanel']")
   private WebElement pricePanel;

   @FindBy(css = "[aria-label='price per person']")
   private WebElement ppPrice;

   @FindBy(css = "[aria-label*='total price']")
   private WebElement totalPrice;

   @FindBy(css = ".ProgressbarNavigation__pricePanelWrapper button")
   private WebElement continueButton;

   @FindBy(css = "[class*='progressBarNavigation']")
   private WebElement navigationPanel;

   @FindBy(css = ".ProgressbarNavigation__disountTooltip")
   private WebElement discount;

   @FindBy(css = "[aria-label='PASSENGER_DETAILS']")
   private WebElement checkoutBreadCrumb;

   @FindBy(css = "[aria-label='HOTEL_DETAILS']")
   private WebElement hotelDetailsBreadCrumb;

   @FindBy(css = "[aria-label='YOUR_HOLIDAY']")
   private WebElement customiseHolidayBreadCrumb;

   @FindBy(css = "[aria-label='page heading']")
   private WebElement pageHeading;

   @FindBy(xpath = "//*[text()='Wijzig verzekering']")
   private WebElement Extraoptionslink;

   @FindBy(xpath = "//*[@class='ProgressbarNavigation__steps']//li[3]//a")
   private WebElement navigationbuttontopaxpage;

   @FindBy(xpath = "//*[@class='ProgressbarNavigation__steps']//li[1]//a")
   private WebElement navigationbuttontoUnitDetailspaxpage;

   public ProgressionbarNavigationComponent()
   {
      progressionBarComponents = new HashMap<>();
      pricePanelMap = new HashMap<>();
      wait = new WebElementWait();
   }

   public void clickOnContinueButton()
   {
      $(".ProgressbarNavigation__pricePanelWrapper button").should(Condition.appear,
               Duration.ofSeconds(60)).click();
   }

   public WebElement getTotalPriceElement()
   {
      return wait.getWebElementWithLazyWait(totalPrice);
   }

   public String getTotalPriceValue()
   {
      return WebElementTools.getElementText(getTotalPriceElement());
   }

   public Double getTotalPriceDoubleValue()
   {
      String[] splitedValue = getTotalPriceValue().split(" ");
      return Double.valueOf(splitedValue[splitedValue.length - 1].substring(1));
   }

   public WebElement getPricePanelElement()
   {
      return pricePanel;
   }

   public WebElement getNavigationPanelElement()
   {
      return navigationPanel;
   }

   public Map<String, WebElement> getProgressionBarComponents()
   {
      progressionBarComponents.put("Progression bar", navigationPanel);
      progressionBarComponents.put("Per person price", ppPrice);
      progressionBarComponents.put("Total price", totalPrice);
      progressionBarComponents.put("Continue button", continueButton);
      progressionBarComponents.put("Navigation Panel", navigationPanel);
      return progressionBarComponents;
   }

   public Map<String, WebElement> getPricePanelComponentsOfSummary()
   {
      pricePanelMap.put("PP Price of Booking", ppPrice);
      pricePanelMap.put("Total Price of Booking", totalPrice);
      pricePanelMap.put("Book Now CTA", continueButton);
      pricePanelMap.put("Discount", discount);
      return pricePanelMap;
   }

   public String getPerPersonPriceElement()
   {
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(ppPrice));
   }

   public String getHotelNameElement()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(hotelName);
   }

   public void clickOnCheckoutBreadCrumb()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(checkoutBreadCrumb);
   }

   public void clickOnHotelDetailsBreadCrumb()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(hotelDetailsBreadCrumb);
   }

   public void clickOnCustomiseHolidayBreadCrumb()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(customiseHolidayBreadCrumb);
   }

   public boolean isPageDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forComplexPageLoad();
      wait.fluentWaitForWebElement(pageHeading);
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(pageHeading));
   }

   public void ClickonExtras()
   {
      wait.forJSExecutionReadyLazy();
      Extraoptionslink.click();
      wait.forJSExecutionReadyLazy();
   }

   public void ClickOnBackToPaxpage()
   {
      wait.forJSExecutionReadyLazy();
      wait.fluentWaitForWebElement(navigationbuttontopaxpage);
      WebElementTools.click(navigationbuttontopaxpage);
   }

   public void ClickOnBackToUnitDetailspage()
   {
      wait.forJSExecutionReadyLazy();
      wait.fluentWaitForWebElement(navigationbuttontoUnitDetailspaxpage);
      WebElementTools.click(navigationbuttontoUnitDetailspaxpage);
   }
}
