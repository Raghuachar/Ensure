package uk.co.tui.cdaf.frontend.pom.wr.search.components.departure;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import java.text.DateFormatSymbols;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static org.assertj.core.api.Assumptions.assumeThat;
import static uk.co.tui.cdaf.frontend.utils.logger.LogLevel.ERROR;

public class DepartureMfe implements Departure
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(DepartureMfe.class);
   protected static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   @Override
   public boolean isOpen()
   {
      return container().isDisplayed();
   }

   public void selectMonth(String month)
   {
      SelenideElement monthSelectContainer = getMonthSelector();
      assumeThat(month).isNotEmpty().isNotNull();
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
      assumeThat(YearMonth.parse(getFirstAvailableMonth(), formatter)).isNotNull()
               .isLessThanOrEqualTo(YearMonth.parse(month, formatter));
      monthSelectContainer.selectOptionByValue(month);
      LOGGER.log(monthSelectContainer.getSelectedOptionText() + " month was selected");
   }

   protected String getFirstAvailableMonth() {
      return getMonthSelector()
               .getOptions()
               .asDynamicIterable()
               .stream()
               .skip(1)
               .findFirst()
               .map(SelenideElement::getValue)
               .orElse("");
   }


   @Override
   public SelenideElement getMonthSelector()
   {
      return container().$("select[aria-label='selectMonth']")
               .shouldBe(Condition.visible, WAIT_TIMEOUT);
   }

   @Override
   public SelenideElement getFlexDateSelector()
   {
      return container().$("ul.flexibleOptions").shouldBe(Condition.visible, WAIT_TIMEOUT);
   }

   @Override
   public boolean isDateAvailable(LocalDateTime expectedDate)
   {
      return !Objects.requireNonNull(getSpecificDateElement(expectedDate).getAttribute("class"))
               .contains("passive");
   }

   @Override
   public @NotNull SelenideElement getSpecificDateElement(LocalDateTime expectedDate)
   {
      String departureMonth = getDepartureMonth(expectedDate);
      selectMonth(departureMonth);
      String string = Integer.toString(expectedDate.getDayOfMonth());
      return getCalendarSelector().$(byText(string));
   }

   @Override
   public Departure selectDate(TestDataAttributes parameter)
   {
      String departureInNumberOfDays = parameter.getNumberOfDays();
      String departureInNumberOfMonths = parameter.getNumberOfMonths();
      if (departureInNumberOfDays != null)
      {
         LocalDateTime expectedDate =
                  LocalDateTime.now().plusDays(Integer.parseInt(departureInNumberOfDays));
         selectDate(expectedDate);
      }
      else if (departureInNumberOfMonths != null)
      {
         LocalDateTime expectedDate =
                  LocalDateTime.now().plusMonths(Integer.parseInt(departureInNumberOfMonths));
         selectDate(expectedDate);
      }
      else
      {
         String departureDay = parameter.getDepartureDay();
         if (departureDay != null && !departureDay.isEmpty())
         {
            String departureMonth = translateMonthToNumber(parameter.getDepartureMonth());
            if (departureMonth != null && !departureMonth.isEmpty())
            {
               departureMonth = getCurrentYear() + "-" + departureMonth;
            }
            selectDate(departureDay, departureMonth);
         }
         else
         {
            selectFirstAvailableDate();
         }
      }
      return this;
   }

   public Departure selectDate(String day, String month)
   {
      selectMonth(month);
      selectDay(day);
      LOGGER.log("Following date was selected: " + day + " " + month);
      return this;
   }

   @Override
   public Departure selectDate(LocalDateTime expectedDate)
   {
      return selectDate(Integer.toString(expectedDate.getDayOfMonth()),
               getDepartureMonth(expectedDate));
   }

   @Override
   public Departure selectRandomDate()
   {
      getCalendarSelector();
      ElementsCollection dates = getAvailableDays();
      int totalCount = dates.size();
      int randomIndex = (int) (Math.random() * (totalCount - 1));
      SelenideElement randomDay = dates.get(randomIndex);
      selectDay(randomDay.getText());
      return this;
   }

   @NotNull
   public SelenideElement getCalendarSelector()
   {
      return container().$(".calendar").shouldBe(Condition.visible, WAIT_TIMEOUT);
   }

   @Override
   public Departure selectFirstAvailableDate()
   {
      selectDay(null);
      return this;
   }

   @Override
   public Departure clearSelection()
   {
      container().$("a.clear").click();
      return this;
   }

   @Override
   public void confirmSelection()
   {
      container().$("button.primary").click();
   }

   private void selectDay(String day)
   {
      getCalendarSelector();
      ElementsCollection availableDays = getAvailableDays();
      if (day == null)
      {
         availableDays.first().click();
      }
      else if (!availableDays.filterBy(Condition.exactText(day)).isEmpty())
      {
         container().$(byText(day)).click();
      }
      else
      {
         LOGGER.log(ERROR, "Day " + day + " is not available, selecting next available day");
         availableDays.asDynamicIterable().stream()
                  .filter(element -> element.getText().compareTo(day) > 0).findFirst().orElseThrow()
                  .click();
      }
      LOGGER.log(
               container().$("time.SelectLegacyDate__selected").getText() + " day was selected");
   }

   @NotNull
   private ElementsCollection getAvailableDays()
   {
      return container().$$(".SelectLegacyDate__available");
   }

   @Override
   public Departure selectRandomMonth()
   {
      final ElementsCollection monthsOptions = container().$("select[aria-label='selectMonth']")
               .shouldBe(Condition.visible, WAIT_TIMEOUT).$$("option");
      List<SelenideElement> selectableMonths = monthsOptions.asDynamicIterable().stream()
               .filter(selenideElement -> !(StringUtils.equals(monthsOptions.get(0).getText(),
                        selenideElement.getText()) || StringUtils.equals(
                        monthsOptions.get(1).getText(), selenideElement.getText())))
               .collect(Collectors.toList());
      int totalCount = selectableMonths.size();
      int randomIndex = (int) (Math.random() * (totalCount - 1));
      SelenideElement randomMonth = selectableMonths.get(randomIndex);
      selectMonth(Objects.requireNonNull(randomMonth.getValue()));
      return this;
   }

   String getDepartureMonth(LocalDateTime expectedDate)
   {
      String departureMonth;
      if (expectedDate.getMonth().getValue() < 10)
      {
         departureMonth = expectedDate.getYear() + "-0" + expectedDate.getMonth().getValue();
      }
      else
      {
         departureMonth = expectedDate.getYear() + "-" + expectedDate.getMonth().getValue();
      }
      return departureMonth;
   }

   private String translateMonthToNumber(String monthAbbreviation)
   {
      if (monthAbbreviation == null || monthAbbreviation.isEmpty())
         return null;
      DateFormatSymbols symbols = new DateFormatSymbols(Locale.ENGLISH);
      String[] shortMonthNames = symbols.getShortMonths();

      int monthIndex = -1;
      for (int i = 0; i < shortMonthNames.length; i++)
      {
         if (shortMonthNames[i].equalsIgnoreCase(monthAbbreviation))
         {
            monthIndex = i;
            break;
         }
      }

      if (monthIndex >= 0 && monthIndex <= 11)
      {
         return String.format("%02d", monthIndex + 1);
      }
      else
      {
         return null;
      }
   }

   private String getCurrentYear()
   {
      return Integer.toString(LocalDate.now().getYear());
   }

   private SelenideElement container()
   {
      return $(shadowDeepCss("div.DepartureDate")).should(appear, WAIT_TIMEOUT);
   }
}
