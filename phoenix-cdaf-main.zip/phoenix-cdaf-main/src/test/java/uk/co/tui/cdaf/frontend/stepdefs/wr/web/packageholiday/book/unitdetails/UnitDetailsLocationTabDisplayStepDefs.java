package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.unitdetails;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.unit_details.LocationTabUnitDetails;

import java.util.List;

public class UnitDetailsLocationTabDisplayStepDefs
{

   private final LocationTabUnitDetails locationTabUnitDetails;

   public UnitDetailsLocationTabDisplayStepDefs()
   {

      locationTabUnitDetails = new LocationTabUnitDetails();

   }

   @When("I click on the location tab")

   public void i_click_on_the_location_tab()
   {
      locationTabUnitDetails.clickLocationTab();
   }

   @Then("the following components will be shown as per design:")
   public void the_following_components_will_be_shown_as_per_design(List<String> ignore)
   {
      SoftAssertions softly = new SoftAssertions();
      locationTabUnitDetails.clickLocationTab();
      softly.assertThat(locationTabUnitDetails.isLocationDescriptionDisplayed())
               .as("Location description is not displayed")
               .isTrue();
      softly.assertThat(locationTabUnitDetails.isMapComponentDisplayed())
               .as("Location map is not displayed")
               .isTrue();
      softly.assertAll();

   }

}
