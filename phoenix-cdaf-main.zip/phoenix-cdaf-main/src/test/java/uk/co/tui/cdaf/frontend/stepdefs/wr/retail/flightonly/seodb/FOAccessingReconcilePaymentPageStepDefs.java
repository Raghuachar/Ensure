package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOAccessingReconcilePaymentPageStepDefs extends AbstractPage
{

   public final WebElementWait wait;

   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents;

   public FOAccessingReconcilePaymentPageStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      wait = new WebElementWait();
      foReconcilationPaymentPageComponents = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the agent is on the FO retail homepage")
   public void that_the_agent_is_on_the_FO_retail_homepage()
   {
      retailflightNavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
   }

   @Given("that the agent is viewing the FO TUI Global header")
   public void that_the_agent_is_viewing_the_FO_TUI_Global_header()
   {
      retailflightNavigation.retailLoginFO();
      assertThat(" Global Header is not present",
               foReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
   }

   @Given("that the Agent is on the FO retail homepage")
   public void that_the_Agent_is_on_the_FO_retail_homepage()
   {
      retailflightNavigation.retailLoginFO();
      foReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }
}
