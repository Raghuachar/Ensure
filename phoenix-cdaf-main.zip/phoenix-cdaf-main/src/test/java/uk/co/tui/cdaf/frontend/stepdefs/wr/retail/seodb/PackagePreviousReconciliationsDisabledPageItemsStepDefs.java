package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackagePreviousReconciliationsPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePreviousReconciliationsDisabledPageItemsStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final PackagePreviousReconciliationsPageComponents pkgPreviousReconPaymentPageComponents;

   public PackagePreviousReconciliationsDisabledPageItemsStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      pkgPreviousReconPaymentPageComponents = new PackagePreviousReconciliationsPageComponents();
   }

   @When("the agent views the select a reason dropdown")
   public void the_agent_views_the_select_a_reason_dropdown()
   {
      pkgPreviousReconPaymentPageComponents.selectDates();
      pkgPreviousReconPaymentPageComponents.clickOnSearchCTA();
      assertThat("Select a reason dropdown present",
               pKgReconcilationPaymentPageComponents.isDisabledReasonSelectBox(), is(true));
   }

   @Then("it cannot be ammended and will display the reasons previously selected")
   public void it_cannot_be_ammended_and_will_display_the_reasons_previously_selected()
   {
      assertThat("Previously selected reason present",
               pKgReconcilationPaymentPageComponents.isSelctReasonMessagePresent(), is(false));
   }

   @When("the agent views the card accordions")
   public void the_agent_views_the_card_accordions()
   {
      pkgPreviousReconPaymentPageComponents.selectDates();
      pkgPreviousReconPaymentPageComponents.clickOnSearchCTA();
      assertThat("Card accordions present",
               pKgReconcilationPaymentPageComponents.isPaymentMethodTypeAccordion(), is(true));
      pKgReconcilationPaymentPageComponents.clickPaymentMethodTypeAccordion();
   }

   @Then("they will see the banking now column is empty for each entry")
   public void they_will_see_the_banking_now_column_is_empty_for_each_entry()
   {
      assertThat("Previously selected reason present",
               pKgReconcilationPaymentPageComponents.isDiscrepancyAmountInputCreditCardPresent(),
               is(false));
   }

}
