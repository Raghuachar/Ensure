package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SeatTypePage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class SeatTypeStepDefs
{

   public final PackageNavigation packageNavigation;

   private final SeatTypePage seatTypePage;

   public SeatTypeStepDefs()
   {
      seatTypePage = new SeatTypePage();
      packageNavigation = new PackageNavigation();
   }

   @Given("that the customer is on the customise holiday page")
   public void that_the_customer_is_on_the_customise_holiday_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they view the seat type component")
   public void they_view_the_seat_type_component()
   {
      assertThat("Seat Type Component is Not Displayed",
               seatTypePage.isSeatTypeComponentDisplayed(), is(true));
   }

   @Then("they can view the standard and comfort seat information")
   public void they_can_view_the_standard_and_comfort_seat_information()
   {
      assertThat("Seat Information is Not Displayed", seatTypePage.isSeatInformationDisplayed(),
               is(true));
   }

   @Given("that the customer is viewing the seat type component")
   public void that_the_customer_is_viewing_the_seat_type_component()
   {
      packageNavigation.navigateToSummaryPage();
      assertThat("Seat Type Component is Not Displayed",
               seatTypePage.isSeatTypeComponentDisplayed(), is(true));
   }

   @When("they select the comfort seat radio button")
   public void they_select_the_comfort_seat_radio_button()
   {
      seatTypePage.clickOnRadioButton();
   }

   @Then("the seat type will be upgraded and added to the booking")
   public void the_seat_type_will_be_upgraded_and_added_to_the_booking()
   {
      seatTypePage.clickOnShowMoreLink();
   }

   @Then("this is reflected in the price breakdown")
   public void this_is_reflected_in_the_price_breakdown()
   {
      assertThat("Price Brekaodwn Text is Not Displayed",
               seatTypePage.isPriceBrekadownTextDisplayed(), is(true));
   }

}
