package uk.co.tui.cdaf.frontend.pom.wr.search;

import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.airport.Airport;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.departure.Departure;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.Destination;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.pad_and_rooms.PaxAndRooms;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion.DestinationSuggestion;
import uk.co.tui.cdaf.frontend.pom.wr.search.enums.StayDuration;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

public interface SearchPanel
{
   default boolean isSearchPanelMfe()
   {
      return false;
   }

   default boolean isCompactView()
   {
      return false;
   }

   default boolean isFullView()
   {
      return true;
   }

   default SelenideElement legacyLink()
   {
      return null;
   }

   boolean isSearchPanelDisplayed();

   Airport airport();

   Destination destination();

   DestinationSuggestion destinationSuggestions(String destination);

   Departure departure();

   PaxAndRooms paxAndRooms();

   void selectDuration(StayDuration duration);

   void selectDuration(String durationString);

   SelenideElement getDurationSelector();

   void selectRandomDuration();

   boolean isSearchButtonEnabled();

   void doSearch();

   SearchPanel selectDefaults();

   SearchPanel selectWithParameters();

   SearchPanel selectWithParameters(TestDataAttributes parameter);

   void searchDefaults();

   void searchWithParameters();

   void searchWithParameters(TestDataAttributes parameter);

   String[] getErrorMessages();

   String getSelectedAirtports();

   String getSelectedDuration();

   String getSelectedDate();

   String getSelectedDestination();

   String getSelectedPaxAndRooms();

   String getDestinationComponentLable();

   String getDepartureComponentLable();

   String getDurationComponentLable();

   String getPaxAndRoomsdurationComponentLable();

   String getAirportComponentLable();

   String getSearchButtonLable();

    void clickClearAll();

   SelenideElement getClearAllBtn();

    void openFromUnitDetails();
}

