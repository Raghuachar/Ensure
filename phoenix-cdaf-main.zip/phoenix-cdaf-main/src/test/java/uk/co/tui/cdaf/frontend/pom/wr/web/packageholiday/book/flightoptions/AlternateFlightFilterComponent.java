package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.flightoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class AlternateFlightFilterComponent extends AbstractPage
{
   public final WebElementWait wait;

   @FindBy(css = "[#alternativeFlights__component > div > section > div:nth-child(2) > div:nth-child(2) > div > div > button]")
   private WebElement filterButton;

   @FindBy(css = "[body > div:nth-child(11) > section > div > div > div]")
   private WebElement filterComponent;

   @FindBy(css = "[body > div:nth-child(11) > section > div > div > div > section]")
   private WebElement alternateFlightsTimings;

   @FindBy(css = "[body > div:nth-child(11) > section > div > div > div > section > div > div > div > div > div > div:nth-child(1) > ul > li:nth-child(2) > label > span.inputs__box]")
   private WebElement timingsCheckbox;

   @FindBy(css = "[#selectedFlightRef]")
   private WebElement goingOutTimingFlight;

   public AlternateFlightFilterComponent()
   {
      wait = new WebElementWait();
   }

   public void clickOnFilterIcon()
   {
      WebElementTools.click(filterButton);
   }

   public boolean isFilterComponentDisplayed()
   {
      return WebElementTools.isPresent(filterComponent);
   }

   public boolean isAlternateFlightsTimingsDisplayed()
   {
      return WebElementTools.isPresent(alternateFlightsTimings);
   }

   public void clickOnTimingsCheckbox()
   {
      WebElementTools.click(timingsCheckbox);
   }

   public boolean isGoingOutTimingFLightDisplayed()
   {
      return WebElementTools.isPresent(goingOutTimingFlight);
   }

   public void clearAllLink()
   {
      WebElementTools.click(timingsCheckbox);
   }
}
