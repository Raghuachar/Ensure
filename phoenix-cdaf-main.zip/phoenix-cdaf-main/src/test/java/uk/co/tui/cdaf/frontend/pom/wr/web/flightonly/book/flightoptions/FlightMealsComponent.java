package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlightMealsComponent extends AbstractPage
{

   static AutomationLogManager LOGGER = new AutomationLogManager(FlightMealsComponent.class);

   private final WebElementWait wait;

   @FindBy(css = "[aria-label='flight meals']")
   private WebElement flightMealsSection;

   @FindBy(css = "[aria-label='flight meals'] [aria-label*='title']")
   private WebElement flightMealsTitle;

   @FindBy(css = "[aria-label='Accordian Section']")
   private WebElement flightMealsDescription;

   @FindBy(css = "[aria-label='flight meals'] [class*='ReadMore'] a")
   private WebElement readMoreLink;

   @FindBy(css = "[class*='FlightMeals__mealDropDown'] span:first-child")
   private List<WebElement> flightMealsSelectedText;

   @FindBy(css = "[class*='FlightMeals__mealDropDown'] select")
   private List<WebElement> flightMealsDropdownSelect;

   public FlightMealsComponent()
   {
      wait = new WebElementWait();
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getFlightMealsComponent()
   {
      return new HashMap<>()
      {
         {
            put("Meals Title", flightMealsTitle);
            put("Meals Description", flightMealsDescription);
            put("Meals Read More Link", readMoreLink);
            put("Flight Meals DropDown", flightMealsSelectedText.get(0));
         }
      };
   }

   public void selectMeal(String mealType, int index)
   {
      WebDriverUtils.executeScript("arguments[0].scrollIntoView(true);",
               flightMealsDropdownSelect.get(0));
      wait.forJSExecutionReadyLazy();
      try
      {
         if (StringUtils.isEmpty(mealType))
            WebElementTools.selectDropDownByIndex(flightMealsDropdownSelect.get(0), index);
         else
            WebElementTools.selectDropDownByVisibleText(flightMealsDropdownSelect.get(0), mealType);
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR,
                  "Error in selecting the meals:" + Arrays.asList(e.getStackTrace()));
      }
   }

   public WebElement getFlightMealsSection()
   {
      return wait.getWebElementWithLazyWait(flightMealsSection);
   }

   public boolean isFlightMealsDisplayed()
   {
      return WebElementTools.isPresent(getFlightMealsSection());
   }

   public List<WebElement> getFlightMealSelecetdElement()
   {
      return wait.getWebElementWithLazyWait(flightMealsSelectedText);
   }

   public boolean isChooseMealAtTopOfDropdown()
   {
      for (WebElement element : flightMealsDropdownSelect)
      {
         try
         {
            WebElementTools.click(element);
            List<WebElement> dropdownOptions =
                     wait.getWebElementWithLazyWait(element.findElements(By.tagName("option")));
            String defaultText = WebElementTools.getElementText(dropdownOptions.get(0));
            boolean matched = StringUtils.containsIgnoreCase(defaultText, "Choose meal");
            if (!matched)
               return false;
         }
         catch (Exception e)
         {
            return false;
         }
      }
      return true;
   }

}
