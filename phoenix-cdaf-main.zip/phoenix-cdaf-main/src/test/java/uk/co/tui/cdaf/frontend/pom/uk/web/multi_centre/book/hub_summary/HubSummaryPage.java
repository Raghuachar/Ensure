package uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.hub_summary;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class HubSummaryPage extends AbstractPage
{

   @FindBy(css = ".NordicCancelInsurance__insuranceOptions .NordicCancelInsurance__widthWraper div")
   public List<WebElement> cancellationPaxList;

   WebElementWait wait;

   WebDriverUtils utils;

   SelenideHelper selenide;

   @FindAll({
            @FindBy(css = ".HubAndSpokeNavigation__priceBlock .HubAndSpokeNavigation__ppPart1"),
            @FindBy(css = ".ProgressbarNavigation__pricePanelWrapper .Nordics__main")
   })
   private WebElement pricePanel;

   //Cancellation Insurance Card
   @FindBy(css = ".NordicCancelInsurance__insuranceOptions")
   private WebElement cancellationInsuranceComp;

   @FindBy(xpath = "//*[@id='cancellationInsuranceSummary_component']//a[@class='ReadMore__link']")
   private WebElement showMoreLink;

   public HubSummaryPage()
   {
      super();
      wait = new WebElementWait();
      utils = new WebDriverUtils();
      selenide = new SelenideHelper();
   }

   public boolean isElementDisplayed(WebElement element)
   {
      return WebElementTools.isPresent(element);
   }

   public int getPricePanelPrice()
   {
      return utils.getNumberFromString(pricePanel.getText());
   }

   public boolean isShowMoreLinkDisplayed()
   {
      WebElementTools.scrollTo(cancellationInsuranceComp);
      wait.waitForElementToBePresent(cancellationInsuranceComp);
      return isElementDisplayed(showMoreLink);
   }

   public String stripSpace(String txt)
   {
      return StringUtils.replaceAll(txt, "\\s", "").trim();
   }

   public void selectCancellationAdult()
   {
      int beforeUpdatePrice = utils.getNumberFromString(stripSpace(pricePanel.getText()));
      WebElementTools.click(
               cancellationPaxList.get(0).findElement(By.cssSelector("[role='checkbox']")));
   }

}
