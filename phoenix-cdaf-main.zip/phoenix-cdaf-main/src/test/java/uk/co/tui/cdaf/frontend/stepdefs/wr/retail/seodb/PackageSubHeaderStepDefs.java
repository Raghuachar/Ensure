package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSubHeaderStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageSubHeaderStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the Agent has navigated to the banking & reconciliation page")
   public void that_the_Agent_has_navigated_to_the_banking_reconciliation_page()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

   @When("they view the subheader above the banking table")
   public void they_view_the_subheader_above_the_banking_table()
   {
      pKgReconcilationPaymentPageComponents.isPageSubHeaderPresent();
   }

   @Then("they can see the links as following")
   public void they_can_see_the_links_as_following(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Update banking icon displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isUpdateBankingIconPresent(), is(true));
      assertThat("Update banking link displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isUpdateBankingLinkPresent(), is(true));
   }

}
