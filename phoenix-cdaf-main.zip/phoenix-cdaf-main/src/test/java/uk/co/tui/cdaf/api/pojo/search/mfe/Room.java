package uk.co.tui.cdaf.api.pojo.search.mfe;

import lombok.Getter;

@Getter
public class Room
{
   private final int number;

   private final String adults;

   private final String kids;

   private final String kidsAges;

   public Room(int number, String adults, String kids, String kidsAges)
   {
      this.number = number;
      this.adults = adults;
      this.kids = kids;
      this.kidsAges = kidsAges;
   }
}
