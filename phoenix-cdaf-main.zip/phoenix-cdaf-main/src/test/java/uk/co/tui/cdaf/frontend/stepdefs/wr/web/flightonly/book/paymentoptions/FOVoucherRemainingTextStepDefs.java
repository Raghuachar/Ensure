package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.paymentoptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentOptionPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOVoucherRemainingTextStepDefs
{

   private final FlightOnlyPageNavigation pageNavigation;

   private final PaymentOptionPage foPaymentOptionPage;

   public FOVoucherRemainingTextStepDefs()
   {

      pageNavigation = new FlightOnlyPageNavigation();

      foPaymentOptionPage = new PaymentOptionPage();
   }

   @Given("that a customer is on the Payment options Page")
   public void that_a_customer_is_on_the_Payment_options_Page()
   {
      pageNavigation.navigateToPaymentOptionsPage();
   }

   @Given("is making a Flight Only Booking")
   public void is_making_a_Flight_Only_Booking()
   {
      pageNavigation.navigateToPaymentOptionsPage();
   }

   @When("they have applied a voucher that exceeds the total amount to be paid")
   public void they_have_applied_a_voucher_that_exceeds_the_total_amount_to_be_paid()
   {
      foPaymentOptionPage.voucherRemove.getAppliedVoucherCodeElement();
   }

   @Then("they will be provided and presented with new voucher details")
   public void they_will_be_provided_and_presented_with_new_voucher_details()
   {
      boolean actual =
               foPaymentOptionPage.voucherRemainingTextComponent.isVoucherRemainingTextDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Voucher Remaining Text Message wasn't displayed", actual, true), actual, is(true));
   }
}
