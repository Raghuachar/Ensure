package uk.co.tui.cdaf.frontend.utils.logger;

public enum LogLevel
{
   DEBUG, WARN, ERROR, INFO, TRACE, FATAL
}
