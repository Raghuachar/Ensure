package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.EditSearchPackages;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.stay.search.searchresults.SearchResults;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults.SearchResultsFiltersStepDefs;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PackageSearchPanelDestinationorHotelAndDepartureDateStepDefs
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchResultsFiltersStepDefs.class);

   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   public final SearchResults searchResults;

   public final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent;

   private final SearchPanelComponent searchPanelComponent;

   EditSearchPackages esp;

   public PackageSearchPanelDestinationorHotelAndDepartureDateStepDefs()
   {
      departureAirportOrDestinationComponent =
               new DepartureAirportAndDestinationAndDatesComponent();
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      esp = new EditSearchPackages();
      searchResults = new SearchResults();
      searchPanelComponent = new SearchPanelComponent();
   }

   private static boolean isDateSelected()
   {
      return getSearchPanel().departure().getCalendarSelector().$(".SelectLegacyDate__selected")
               .exists();
   }

   @When("they select the Destination or hotel list")
   public void they_select_the_Destination_or_hotel_list()
   {
      getSearchPanel().destination();
   }

   @Then("the countries are in alphabetical order")
   public void the_countries_are_in_alphabetical_order()
   {
      assertThat("Countris not in alphabetical order ",
               departureAirportOrDestinationComponent.isCountriesInAlphabeticalOrder(), is(true));
   }

   @When("they select a country from the list")
   public void they_select_a_country_from_the_list()
   {
      departureAirportOrDestinationComponent.clickOnCountries();
   }

   @When("they view the list of countries")
   public void they_view_the_list_of_countries()
   {
      assertThat("list of countries are not dispalyed",
               getSearchPanel().destination().getAllCountryDestinations().size(), greaterThan(0));
   }

   @Then("the unavailable countries will be greyed out")
   public void the_unavailable_countries_will_be_greyed_out()
   {
      assertThat("unavailable countries greyed out not displayed   ",
               departureAirportOrDestinationComponent.isCountriesGreyedOutPresent(), is(true));
   }

   @Then("the customer will not be able to select them")
   public void the_customer_will_not_be_able_to_select_them()
   {
      try
      {
         departureAirportOrDestinationComponent.clickCountryGreyedOut();
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.INFO, "Unable to click Greyed Out element");
      }
   }

   @When("they have selected destinations within that country")
   public void they_have_selected_destinations_within_that_country()
   {
      departureAirportOrDestinationComponent.clickOnCountries();
   }

   @And("the selections will clear")
   public void the_selections_will_clear()
   {
      assertThat("the selected Destination not clear  ",
               departureAirportOrDestinationComponent.checked(), is(false));
   }

   @Then("the customer will remain on the destinations within country list")
   public void the_customer_will_remain_on_the_destinations_within_country_list()
   {
      assertThat("the destinations within country list not open  ",
               departureAirportOrDestinationComponent.dropdownWindowOpened(), is(true));
   }

   @Then("they will be shown the destinations within that country for selection")
   public void they_will_be_shown_the_destinations_within_that_country_for_selection()
   {
      List<String> namesOfCountries =
               getSearchPanel().destination().getAllCountryDestinations().asDynamicIterable()
                        .stream()
                        .map(SelenideElement::getText)
                        .map(String::trim)
                        .collect(Collectors.toList());
      String selectedDestination = getSearchPanel().getSelectedDestination().trim();
      assertThat("the destinations within the country not displayed",
               namesOfCountries, hasItem(selectedDestination));
   }

   @Then("they will see the departure date Calendar")
   public void they_will_see_the_departure_date_Calendar()
   {
      assertThat("departure date Calendar is not displayed   ",
               departureAirportOrDestinationComponent.isCalenderDisplayed(), is(true));
   }

   @When("they select the Departure Date Field")
   public void they_select_the_Departure_Date_Field()
   {
      getSearchPanel().departure();
   }

   @When("they view the current month")
   @Then("the current month will show by default")
   @Then("the calendar will return to the current month or first month where there is availability")
   public void they_view_the_current_month()
   {
      LocalDateTime expectedDate = LocalDateTime.now();
      assertThat("not current month is shown",
               getSearchPanel().departure().getMonthSelector().getSelectedOptionValue(),
               equalTo(expectedDate.format(DateTimeFormatter.ofPattern("yyyy-MM"))));
   }

   @Then("they will see the following options: Month selector, Flexibility options, Calendar")
   public void they_will_see_the_following_options()
   {
      assertTrue("monthSelector is not displayed   ",
               getSearchPanel().departure().getMonthSelector().parent().isDisplayed());
      assertTrue("departure date Calendar is not displayed   ",
               getSearchPanel().departure().getCalendarSelector().isDisplayed());
      assertTrue("flexibilityoptions are not displayed   ",
               getSearchPanel().departure().getFlexDateSelector().isDisplayed());
   }

   @Then("the dates that have already passed will be greyed out")
   public void the_dates_that_have_already_passed_will_be_greyed_out()
   {
      LocalDateTime expectedDate = LocalDateTime.now().minusDays(1);
      // TODO: update to get available dates from API call, since at the end of the month - it can be false negative
      assertFalse("the dates that have already passed will be greyed out not displayed",
               getSearchPanel().departure().isDateAvailable(expectedDate));
   }

   @When("they select to change the month")
   public void they_select_to_change_the_month()
   {
      departureAirportOrDestinationComponent.selectFutureMonth();
   }

   @Then("they will be able to select a month in the future")
   public void they_will_be_able_to_select_a_month_in_the_future()
   {
      assertThat("not reflected the month chosen   ",
               departureAirportOrDestinationComponent.isVerifyingFutureMonth(), is(true));
   }

   @Then("the calendar will change to reflect the month chosen")
   public void the_calendar_will_change_to_reflect_the_month_chosen()
   {
      assertThat("not reflected the month chosen   ",
               departureAirportOrDestinationComponent.isVerifyingFutureMonth(), is(true));
   }

   @Then("they will not be able to select those dates")
   public void they_will_not_be_able_to_select_those_dates()
   {
      LocalDateTime expectedDate = LocalDateTime.now().minusDays(1);
      getSearchPanel().departure().clearSelection().getSpecificDateElement(expectedDate).click();
      assertFalse("Disabled date was clickable",
               isDateSelected());
   }

   @When("the date selected")
   public void the_date_selected()
   {
      getSearchPanel().departure().selectFirstAvailableDate();
      assertThat(isDateSelected(), is(true));
   }

   @Then("the calendar will remain open")
   public void the_calendar_will_remain_open()
   {
      assertThat("Calender remains not open  ",
               getSearchPanel().departure().isOpen(), is(true));
   }

   @Given("they re interacting with the Destination field")
   public void they_re_interacting_with_the_Destination_field()
   {
      getSearchPanel().destinationSuggestions("Spa");
   }

   @Given("they have opened the List of countries")
   public void they_have_opened_the_List_of_countries()
   {
      searchPanelComponent.selectDestinationList();
   }

   @Given("the {string} has selected at least {int} regions\\/child destinations in the destination input field")
   public void the_has_selected_at_least_regions_child_destinations_in_the_destination_input_field(
            String string, Integer int1)
   {
      packageNavigation.navigateToHoldaySearchPage();
      departureAirportOrDestinationComponent.enterAndClickTheDestination();
   }

   @When("they review the destination field")
   public void they_review_the_destination_field()
   {
      assertThat("they are not review the destination ",
               departureAirportOrDestinationComponent.viewTheDestination(), is(true));
   }

   @Given("the {string} has selected a region\\/child destination in the destination input field")
   public void the_has_selected_a_region_child_destination_in_the_destination_input_field(
            String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
      departureAirportOrDestinationComponent.enterTheDestination();
   }

   @When("they select the destination field")
   public void they_select_the_destination_field()
   {
      departureAirportOrDestinationComponent.clickOnDestinationFieldText();
   }

   @Given("the Destination or Hotel W{int} switch is set to {string}")
   public void the_Destination_or_Hotel_W_switch_is_set_to(Integer int1, String string)
   {
      if (string.equals("On"))
      {
         assertThat("Destination and Hotel switch not set to on  ",
                  departureAirportOrDestinationComponent.verifyingDestinationReadOnly(), is(true));
      }
      else if (string.equals("Off"))
      {
         assertThat("Destination and Hotel switch not set to off  ",
                  !(departureAirportOrDestinationComponent.verifyingDestinationReadOnly()),
                  is(true));
      }
   }

   @When("they view the Search Panel Destination or Hotel field")
   public void they_view_the_Search_Panel_Destination_or_Hotel_field()
   {
      assertThat("not view the Destination or Hotel field",
               departureAirportOrDestinationComponent.verifyingDestinationField(), is(true));
   }

   @Then("they shall not be able to manually enter characters in the Search Panel Destination or Hotel field")
   public void they_shall_not_be_able_to_manually_enter_characters_in_the_Search_Panel_Destination_or_Hotel_field()
   {
      assertThat("able to manually enter characters in the Search Panel Destination or Hotel field",
               departureAirportOrDestinationComponent.verifyingDestinationReadOnly(), is(true));
   }

   @Then("the Destinations Modal shall be displayed")
   public void the_Destinations_Modal_shall_be_displayed()
   {
      assertThat("the Destination or Hotel Modal shall be not displayed",
               departureAirportOrDestinationComponent.dropdownWindowOpened(), is(true));
   }

   @Then("they shall be able to manually enter characters in the Search Panel Destination or Hotel field")
   public void they_shall_be_able_to_manually_enter_characters_in_the_Search_Panel_Destination_or_Hotel_field()
   {
      departureAirportOrDestinationComponent.clickOnDestinationFieldText();
      departureAirportOrDestinationComponent.enterTheDestination();
   }

   @Then("The following legacy messaging message should be displayed:")
   public void the_following_legacy_messaging_message_should_be_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = map.get(BDDSiteIdResolver.getSiteRTId().toLowerCase());
         actual = departureAirportOrDestinationComponent.getLegacyMessage();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           expected + " is not matched",
                           actual, expected),
                  StringUtils.equalsIgnoreCase(expected.toLowerCase(), actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Then("The following legacy website link should be displayed:")
   public void the_following_legacy_website_link_should_be_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = map.get(BDDSiteIdResolver.getSiteRTId().toLowerCase());
         actual = departureAirportOrDestinationComponent.getLegacyMessageLink();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           expected + " is not matched",
                           actual, expected),
                  StringUtils.equalsIgnoreCase(expected.toLowerCase(), actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Given("the Customer is viewing the Destinations modal")
   public void the_Customer_is_viewing_the_Destinations_modal()
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectDestinationList();
      assertThat("the Destination or Hotel Modal shall be not displayed",
               departureAirportOrDestinationComponent.dropdownWindowOpened(), is(true));
   }

   @Then("the countries that have availability shall be selectable")
   public void the_countries_that_have_availability_shall_be_selectable()
   {
      departureAirportOrDestinationComponent.clickOnAvaiableCountry();
   }

   @Then("the countries that have no availability shall be greyed out and not selectable")
   public void the_countries_that_have_no_availability_shall_be_greyed_out_and_not_selectable()
   {
      assertThat("the countries that have no availability shall not greyed out and not selectable",
               departureAirportOrDestinationComponent.isCountriesGreyedOutLegacy(), is(true));
      try
      {
         departureAirportOrDestinationComponent.clickCountryGreyedOut();
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.INFO, "Unable to click Greyed Out element");
      }
   }

   @Given("the legacy messaging is displayed")
   public void the_legacy_messaging_is_displayed()
   {
      assertThat("the legacy messaging is not displayed",
               departureAirportOrDestinationComponent.verifyingLegacyMessageDispalyed(), is(true));
   }

   @When("they select the Find more holiday destinations on tui.be link")
   public void they_select_the_Find_more_holiday_destinations_on_tui_be_link()
   {
      departureAirportOrDestinationComponent.clickOnLegacyMessageLink();
   }

   @Then("they shall be directed to the WR legacy website, which will opened in a new browser tab")
   public void they_shall_be_directed_to_the_WR_legacy_website_which_will_opened_in_a_new_browser_tab()
   {
      assertThat("the WR legacy website, Not opened in a new browser tab",
               departureAirportOrDestinationComponent.isLegacyWebSitePresent(), is(true));
   }

   @Then("the Destinations Modal shall no longer display the legacy messaging")
   public void the_Destinations_Modal_shall_no_longer_display_the_legacy_messaging()
   {
      assertThat("the Destination or Hotel Modal shall be not displayed",
               !(departureAirportOrDestinationComponent.verifyingLegacyMessageDispalyed()),
               is(true));
   }

   @Then("the Destinations Modal shall no longer display the \"VISIT <legacy website URL>\" CTA link")
   public void the_Destinations_Modal_shall_no_longer_display_the_CTA_link()
   {
      assertThat("the Destination or Hotel Modal shall be not displayed",
               !(departureAirportOrDestinationComponent.verifyingLegacyMsgLinkDispalyed()),
               is(true));
   }

   @Then("the Destinations Modal shall display all the countries that WR travel to, as per existing functionality")
   public void the_Destinations_Modal_shall_display_all_the_countries_that_WR_travel_to_as_per_existing_functionality()
   {
      assertThat("all the countries that WR travel to,not dispalying existing functionality",
               departureAirportOrDestinationComponent.isCountriesDispalyed(), is(true));
   }

   @When("they select to change to legacy option")
   public void they_select_to_change_to_legacy_option()
   {
      departureAirportOrDestinationComponent.selectLegacyDropdown(0);
   }

   @When("they will see the following legacy messages")
   public void they_will_see_the_following_legacy_messages(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId;
      String expectedCrossOverMessageText = "";
      String expectedCrossOverLinkText = "";
      String actualCrossOverMessageText;
      String actualCrossOverLinkText = "";
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      actualCrossOverMessageText =
               departureAirportOrDestinationComponent.getDatesCrossOverMessageElementText()
                        .getText();

      for (Map<String, String> dataMap : dataTableTemp)
      {
         siteId = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
                  ? (BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
                  + (BDDSiteIdResolver.getSiteRTId().toLowerCase())
                  : (getTestExecutionParams().getLocaleStr().toLowerCase().contains("fr"))
                  ? getTestExecutionParams().getLocaleStr().toLowerCase()
                  : BDDSiteIdResolver.getSiteRTId().toLowerCase();
         if (siteId.equals(dataMap.get("site")))
         {
            if (siteId.equals("inhouse_rt_be") || siteId.equals("inhouse_rt_nl"))
               actualCrossOverLinkText =
                        departureAirportOrDestinationComponent.getDatesCrossOverLinkElementText1()
                                 .get(0).getText() + " " +
                                 departureAirportOrDestinationComponent.getDatesCrossOverLinkElementText1()
                                          .get(1).getText();
            else
               actualCrossOverLinkText =
                        departureAirportOrDestinationComponent.getDatesCrossOverLinkElementText()
                                 .getText();
            expectedCrossOverMessageText = dataMap.get("legacyLookingToFlyText");
            expectedCrossOverLinkText = dataMap.get("legacySiteLinkText");
         }
      }
      assertThat("Legacy cross over message text is not matched ",
               StringUtils.equalsIgnoreCase(expectedCrossOverMessageText,
                        actualCrossOverMessageText),
               is(true));
      assertThat("Legacy cross over link message text is not matched ",
               StringUtils.equalsIgnoreCase(expectedCrossOverLinkText, actualCrossOverLinkText),
               is(true));
   }

   @When("they select the Destination or Hotel field")
   public void they_select_the_Destination_or_Hotel_field()
   {
      departureAirportOrDestinationComponent.clickOnDestinationFieldText();
   }

   @And("the accommodation is available on the legacy website")
   public void the_accommodation_is_available_on_the_legacy_website()
   {
      assertTrue(departureAirportOrDestinationComponent.accomadationDisplayed());
   }

   @When("they select the Find more holiday destinations hyper link")
   public void they_select_the_Find_more_holiday_destinations_hyper_link()
   {
      Set<String> initialHandles = WebDriverUtils.getDriver().getWindowHandles();
      departureAirportOrDestinationComponent.clickOnLegacyMessageHyperLink();
      Set<String> currentHandles = WebDriverUtils.getDriver().getWindowHandles();
      assertThat("Website did not open in the existing tab",
               (currentHandles.containsAll(initialHandles)), is(true));
   }

   @Then("the date selected will clear")
   public void the_date_selected_will_clear()
   {
      assertThat("the date selected not clear", isDateSelected(), is(false));
   }
}
