package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class PackageReconcilationPaymentPageComponents extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageReconcilationPaymentPageComponents.class);

   public final WebElementWait wait;

   @FindAll({ @FindBy(css = ".GlobalHeader__siteHeader"),
            @FindBy(css = "#globalHeader__component") })
   private WebElement tuiGlobalHeader;

   @FindBy(css = "[aria-label='menu-Admin']")
   private WebElement adminTab;

   @FindBy(css = "[aria-label='subMenuListLink-Betalingen & verwerking']")
   private WebElement bankingLink;

   @FindAll({ @FindBy(css = ".GlobalFooter__sections component"),
            @FindBy(css = "#seodbPageHeaderAndLinks__component") })
   private WebElement pageHeaderAndLinks;

   @FindBy(css = "[aria-label='insertPayment']")
   private WebElement insertPayment;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper ")
   private WebElement bankingTablePresent;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper tr th:nth-child(1)")
   private WebElement bankingTableColumnTypes;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper tr th:nth-child(2)")
   private WebElement bankingTableColumnPaymentTotals;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper tr th:nth-child(3)")
   private WebElement bankingTableColumnBankingNow;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper tr th:nth-child(4)")
   private WebElement bankingTableColumnDiscrepancy;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper tr th:nth-child(5)")
   private WebElement bankingTableColumnCurrency;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper tr th:nth-child(6)")
   private WebElement bankingTableColumnReason;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper tr th:nth-child(7)")
   private WebElement bankingTableColumnBlankSpace;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper")
   private WebElement paymentType;

   @FindBy(css = ".ReconcilePaymentTable__totalDiscrepancies")
   private WebElement bankingTable;

   @FindBy(css = ".ReconcilePaymentTable__totalDiscrepancies")
   private WebElement PaymentTypeRecievedPayment;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableContent")
   private WebElement paymentTypeCard;

   @FindBy(css = ".ReconcilePaymentTable__seodbArrow")
   private WebElement cardTypeChevron;

   @FindBy(css = ".Links__SEODBTertiaryLinksWrapper li:last-child")
   private WebElement updateBankingLink;

   @FindBy(css = ".Modal__modalOverlay.Modal__opened")
   private WebElement updateBankingModel;

   @FindBy(css = ".Modal__modalOverlay header h4")
   private WebElement updateBankingTitle;

   @FindBy(css = ".UI__addPaymentMethod p")
   private WebElement paymentMethodTitle;

   @FindBy(css = ".UI__addBankingAmount:nth-child(1n)")
   private WebElement addBankingAmount;

   @FindBy(css = ".UI__addSlipNumber:nth-child(1n)")
   private WebElement sealBagNumber;

   @FindBy(css = ".UI__addSlip a")
   private WebElement saveIcon;

   @FindBy(css = ".Modal__secondry")
   private WebElement cancelIcon;

   @FindBy(xpath = "//button[text()='SLUITEN']")
   private WebElement closeIcon;

   @FindBy(xpath = "//button[@aria-label='action apply']")
   private WebElement bottomCTAIcon;

   @FindBy(css = ".UI__paymentDetail")
   private WebElement addedSealBags;

   @FindAll({ @FindBy(css = ".UI__paymentDetail"), @FindBy(css = ".UI__paymentMethod p") })
   private WebElement paymentMethod;

   @FindAll({ @FindBy(css = ".UI__paymentDetail"),
            @FindBy(css = ".UI__bankingAmount p:first-child") })
   private WebElement bankingAmount;

   @FindAll({ @FindBy(css = ".UI__paymentDetail"), @FindBy(css = ".UI__slipNumber p:first-child") })
   private WebElement sealBagNum;

   @FindAll({ @FindBy(css = ".UI__paymentDetail"), @FindBy(css = ".UI__editSlip") })
   private WebElement editSealBagIcon;

   @FindBy(css = ".Modal__primary")
   private WebElement saveButton;

   @FindBy(css = "[aria-label='insert amount input field'] input")
   private WebElement amountInputField;

   @FindBy(css = "[aria-label='insert payment reason'] textarea")
   private WebElement reasonInputField;

   @FindBy(css = "[aria-label='insert payment validation error']")
   private WebElement insertPaymentValidationError;

   @FindBy(css = ".UI__amountInputBox.UI__error")
   private WebElement isPaymentAmountInputHaveErrorCss;

   @FindBy(css = "[aria-label='insert payment reason'] .UI__textarea.UI__error")
   private WebElement isReasonInputHaveErrorCss;

   @FindBy(xpath = "//div[@class=\"UI__addBankingAmount\"]/div/div/input")
   private WebElement addUpdateBankingAmount;

   @FindBy(xpath = "//div[@class=\"UI__addSlipNumber\"]/div/div/input")
   private WebElement addSlipNumber;

   @FindAll({ @FindBy(css = "[aria-label='payment detail']"), @FindBy(css = ".UI__paymentDetail") })
   private WebElement paymentDetail;

   @FindAll({ @FindBy(css = "[aria-label='edit slip']"), @FindBy(css = ".UI__editSlip") })
   private WebElement editSlip;

   @FindAll({ @FindBy(css = "[aria-label='updateBankingSaveLabel']"),
            @FindBy(css = ".UI__saveSlip") })
   private WebElement editSave;

   @FindBy(css = ".UI__addBankingAmount .inputs__textInput div input")
   private WebElement detailBankingAmount;

   @FindBy(css = ".UI__addSlipNumber .inputs__textInput div input")
   private WebElement detailSealBagNumber;

   @FindBy(xpath = "//*[@id=\"seodb__component\"]/div/div/div/div[1]/table/tbody/tr[1]/td[6]/div[1]/div/select/option[2]")
   private WebElement overOrUnderReason;

   @FindBy(xpath = "//*[@id=\"seodb__component\"]/div/div/div/div[1]/table/tbody/tr[1]/td[6]/div[2]/div")
   private WebElement authoriseDiscrepancyModal;

   @FindBy(css = ".Modal__modalOverlay header h4")
   private WebElement authorizeDiscrepancyTitle;

   @FindBy(xpath = "//*[@id=\"seodb__component\"]/div/div/div/div[1]/table/tbody/tr[1]/td[6]/div[2]/div/div/div/div/div/div/p[1]/span[1]")
   private WebElement selectReasonAmountAndReason;

   @FindBy(css = ".SelectAReason__textarea")
   private WebElement selectReasonTextArea;

   @FindBy(css = ".Modal__secondry")
   private WebElement selectReasonCancelCTA;

   @FindBy(css = ".Modal__modalOverlay footer .Modal__primary")
   private WebElement selectReasonSubmitCTA;

   @FindBy(xpath = "//*[@id=\"seodb__component\"]/div/div/div/div[1]/table/tbody/tr[1]/td[6]/div[1]")
   private WebElement reasonShowMoreLink;

   @FindAll({ @FindBy(css = "[aria-label='select a reason selectBox']"),
            @FindBy(css = "[aria-label='Select'] disabled") })
   private WebElement disabledReasonSelectBox;

   @FindBy(css = ".inputs__selectList > div > select > option:nth-child(3)")
   private WebElement shopLossReason;

   @FindBy(css = "[aria-label='please explain here']")
   private WebElement modalReasonTextarea;

   @FindBy(css = ".Modal__primary")
   private WebElement modalReasonSubmit;

   @FindBy(css = ".ReconcilePaymentTable__seodbArrowUp")
   private WebElement paymentMethodTypeAccordion;

   @FindBy(css = "[aria-label='select a reason selectBox']")
   private WebElement reasonDetailContent;

   @FindBy(css = "[aria-label='selected reason type']")
   private WebElement reasonTypeAdded;

   @FindAll({ @FindBy(css = ".SelectAReason__autoShowMore"),
            @FindBy(css = "[aria-label='reasonShowAccordion Card']") })
   private WebElement showReasonDetailLink;

   @FindBy(css = ".SelectAReason__autoShowMore")
   private WebElement reasonContentCard;

   @FindAll({ @FindBy(css = ".SelectAReason__autoShowMore"),
            @FindBy(css = "[aria-label='reasonHideAccordion Card']") })
   private WebElement clickHideDetailLink;

   @FindAll({ @FindBy(css = ".inputs__selectList span"), @FindBy(css = ".inputs__selectList"),
            @FindBy(css = ".inputs__arrowIcon"),
            @FindBy(css = "[aria-label='select a reason selectBox'] .inputs__selectList"),
            @FindBy(css = ".inputs__select") })
   private WebElement clickselectareason;

   @FindBy(css = ".Modal__modalOverlay header .Modal__close")
   private WebElement closeupdatebankingmodal;

   @FindBy(css = ".inputs__selectList select option")
   private List<WebElement> selectareasonlist;

   @FindAll({ @FindBy(css = "[aria-label='add banking amount']"),
            @FindBy(css = ".inputs__errorMessage") })
   private WebElement addBankingAmountValidationError;

   @FindAll({ @FindBy(css = "[aria-label='add seal bag number']"),
            @FindBy(css = ".inputs__errorMessage") })
   private WebElement addSealBagValidationError;

   @FindBy(css = ".Links__navigate")
   private WebElement previousReconLink;

   @FindBy(css = ".desktop-static-global-header")
   private WebElement previousReconGlobalHeader;

   @FindAll({ @FindBy(css = "[aria-label='page sub menu']"), @FindBy(css = ".Links__navigate a") })
   private WebElement previousReconciliationLink;

   @FindBy(xpath = "//div[@class='ReconcilePaymentTable__paymentAmtInput']/div/div/input")
   private WebElement discrepancyAmountInputCreditCard;

   @FindBy(css = ".inputs__selectList .inputs__select select")
   private WebElement selectReasonDropDown;

   @FindBy(css = ".Modal__primary")
   private WebElement selectReasonCTA;

   @FindBy(css = ".alerts__alertText")
   private WebElement selectReasonMessage;

   @FindBy(css = ".SEODBContent__seodbAuthoriseButton")
   private WebElement seodbAuthoriseButton;

   @FindBy(css = ".AuthoriseReconciliation__modalContent")
   private WebElement authoriseReconciliationModal;

   @FindBy(css = "[aria-label='authorise recon table body']")
   private WebElement addedReasonsInReconciliationModal;

   @FindAll({ @FindBy(css = "[aria-label='button']"),
            @FindBy(css = ".buttons__button buttons__search buttons__fill Search__seodbSectionSplit") })
   private WebElement seodbSearchButton;

   @FindBy(css = ".ReconcilePaymentTable__dateHeadingIcon")
   private WebElement previousReconciliationCalenderIcon;

   @FindBy(css = ".ReconcilePaymentTable__dateHeading span:first-of-type")
   private WebElement previousReconciliationDate;

   @FindBy(css = ".ReconcilePaymentTable__SeodbreconId")
   private WebElement previousReconiliationId;

   @FindAll({ @FindBy(css = "[aria-label='error message']") })
   private WebElement previousDateSearchErrorMessages;

   @FindAll({ @FindBy(css = "[aria-label='error text']") })
   private WebElement previousReconciliationDateSearchErrorsBOX;

   @FindBy(css = "th[aria-label='date']")
   private WebElement cardTypeDate;

   @FindBy(css = "th[aria-label='time']")
   private WebElement cardTypeTime;

   @FindBy(css = "th[aria-label='reference']")
   private WebElement cardTypeReference;

   @FindBy(css = "th[aria-label='amount']")
   private WebElement cardTypeAmount;

   @FindBy(css = "th[aria-label='cardDigits']")
   private WebElement cardTypeCardDigits;

   @FindBy(css = "th[aria-label='system']")
   private WebElement cardTypeSystem;

   @FindAll({ @FindBy(css = "tr[aria-label='cardsDetailsDataRow-0'] td") })
   private List<WebElement> cardTypeColumnData;

   @FindBy(css = "a[aria-label='Update banking link'] svg")
   private WebElement updateBankingIcon;

   @FindBy(css = "#globalHeader__component > div > div > div > div.TopBar__topBar > div > div > ul > li:nth-child(2) > ul > li:nth-child(2) > span > div > a")
   private WebElement agentlink;

   @FindBy(css = ".SearchModal__modalContent input")
   private WebElement agentAbtaCredentials;

   @FindBy(css = "body > div:nth-child(17) > div > section > section > div > div:nth-child(2) > div.Column__col.Column__col-3 > button")
   private WebElement clickOnAgentCredentailsSerachButton;

   @FindBy(css = ".Modal__modalOverlay footer .Modal__secondry")
   private WebElement authoriseModalCTA;

   @FindBy(css = ".Modal__modal header")
   private WebElement authoriseConfModalTitle;

   @FindBy(css = ".AuthorisationConfirmation__loadDiaryPopHeading")
   private WebElement authorisationMessage;

   @FindBy(css = ".AuthorisationConfirmation__loadDiaryPop > p")
   private WebElement authorisationTransctionId;

   @FindBy(css = ".AuthorisationConfirmation__loadDiaryPop")
   private WebElement authorisationConfirmationPopup;

   @FindBy(css = ".Modal__modalOverlay footer .Modal__primary")
   private WebElement authoriseModalCloseCTA;

   @FindBy(css = ".SEODBContent__seodbAuthoriseButtonDisable")
   private WebElement seodbDisabledAuthoriseButton;

   @FindBy(css = "#cmCloseBanner")
   private WebElement cmCloseBanner;

   @FindBy(css = ".SearchModal__modalContent a")
   private WebElement clickOnlineTravelAgent;

   public PackageReconcilationPaymentPageComponents()
   {
      wait = new WebElementWait();
   }

   public void navigateToReconcilePaymentPage()
   {
      WebElementTools.isPresent(adminTab);
      WebElementTools.mouseOverAndClick(adminTab);
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(bankingLink);
   }

   public boolean isGlobalHeaderIsPresent()
   {
      LOGGER.log(LogLevel.INFO, "GlobalHeader is present in Reconcilation Page:");
      return WebElementTools.isPresent(tuiGlobalHeader);
   }

   public boolean isAdminTabPresent()
   {
      LOGGER.log(LogLevel.INFO, "Banking Link is present in Header:");
      return WebElementTools.isPresent(adminTab);
   }

   public void clickAdminTab()
   {
      WebElementTools.mouseOverAndClick(adminTab);
   }

   public void clickAgentLink()
   {
      WebElementTools.mouseOverAndClick(agentlink);
   }

   public void enterAgentAbtaCredentailsTuiShopAgent()
   {
      WebElementTools.click(agentAbtaCredentials);
      WebElementTools.enterText(agentAbtaCredentials, "118570");
   }

   public void enterAgentAbtaCredentailsDirectBilling()
   {
      WebElementTools.click(agentAbtaCredentials);
      WebElementTools.enterText(agentAbtaCredentials, "120198");
   }

   public void enterAgentAbtaCredentailsCsc()
   {
      WebElementTools.click(agentAbtaCredentials);
      WebElementTools.enterText(agentAbtaCredentials, "118501");
   }

   public void enterAgentAbtaCredentailsThreePA()
   {
      WebElementTools.click(agentAbtaCredentials);
      WebElementTools.enterText(agentAbtaCredentials, "605502");
   }

   public void clickOnAgentSearchButton()
   {
      WebElementTools.mouseOverAndClick(clickOnAgentCredentailsSerachButton);
   }

   public void clickOnOnlineTravelAgent()
   {
      WebElementTools.mouseOverAndClick(clickOnlineTravelAgent);
   }

   public boolean isBankingLinkPresent()
   {
      LOGGER.log(LogLevel.INFO, "Banking Link is present in Header:");
      return WebElementTools.isPresent(bankingLink);
   }

   public void clickBankingLink()
   {
      LOGGER.log(LogLevel.INFO, "Banking Link is present in Header:");
      WebElementTools.mouseOverAndClick(bankingLink);
   }

   public boolean isPageHeaderAndLinksPresent()
   {
      LOGGER.log(LogLevel.INFO, "pageHeaderAndLinks is present in Reconcilation Page:");
      return WebElementTools.isPresent(pageHeaderAndLinks);
   }

   public boolean isBankingAndReconciliationLinkPresent()
   {
      LOGGER.log(LogLevel.INFO, "pageHeaderAndLinks is present in Reconcilation Page:");
      return WebElementTools.isPresent(pageHeaderAndLinks);
   }

   public boolean isPageSubHeaderPresent()
   {
      LOGGER.log(LogLevel.INFO, "Sub Header is present in Reconcilation Page:");
      return WebElementTools.isPresent(pageHeaderAndLinks);
   }

   public void clickInsertPayment()
   {
      LOGGER.log(LogLevel.INFO, "Insert Payment Link is present:");
      WebElementTools.isPresent(insertPayment);
      WebElementTools.mouseOverAndClick(insertPayment);
   }

   public boolean isBankingTablePresent()
   {
      LOGGER.log(LogLevel.INFO, "Page template Table header in Reconcilation Page:");
      return WebElementTools.isPresent(bankingTablePresent);
   }

   public boolean isTypesColumnHeaderDisplayed()
   {
      return WebElementTools.isPresent(bankingTableColumnTypes);
   }

   public boolean isPaymentTotalsColumnHeaderDisplayed()
   {
      return WebElementTools.isPresent(bankingTableColumnPaymentTotals);
   }

   public boolean isBankingNowColumnHeaderDisplayed()
   {
      return WebElementTools.isPresent(bankingTableColumnBankingNow);
   }

   public boolean isDiscrepancyColumnHeaderDisplayed()
   {
      return WebElementTools.isPresent(bankingTableColumnDiscrepancy);
   }

   public boolean isCurrencyColumnHeaderDisplayed()
   {
      return WebElementTools.isPresent(bankingTableColumnCurrency);
   }

   public boolean isReasonColumnHeaderDisplayed()
   {
      return WebElementTools.isPresent(bankingTableColumnReason);
   }

   public boolean isBlankSpaceColumnHeaderDisplayed()
   {
      return WebElementTools.isPresent(bankingTableColumnBlankSpace);
   }

   public boolean isDiscrepanciesBeneathBankingTable()
   {
      LOGGER.log(LogLevel.INFO, "Is Present:");
      return WebElementTools.isPresent(bankingTable);
   }

   public boolean isPaymentTypeRecievedPayments()
   {
      LOGGER.log(LogLevel.INFO, "Is Present:");
      return WebElementTools.isPresent(PaymentTypeRecievedPayment);
   }

   public boolean isCardPaymentTypeDisplayed()
   {
      return WebElementTools.isPresent(paymentTypeCard);
   }

   public void clickOnCardTypeChevron()
   {
      WebElementTools.isPresent(cardTypeChevron);
      LOGGER.log(LogLevel.INFO, "Card type chevron is present.");
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(cardTypeChevron);
   }

   public void clickOnUpdateBankingLink()
   {
      WebElementTools.isPresent(updateBankingLink);
      WebElementTools.mouseOverAndClick(updateBankingLink);
   }

   public boolean isUpdateBankingModelOpened()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(updateBankingModel);
   }

   public boolean isUpdateBankingTitleDisplayed()
   {
      return WebElementTools.isPresent(updateBankingTitle);
   }

   public boolean isPaymentMethodTitleDisplayed()
   {
      return WebElementTools.isPresent(paymentMethodTitle);
   }

   public boolean isBankingAmountBoxDisplayed()
   {
      return WebElementTools.isPresent(addBankingAmount);
   }

   public boolean isSealBagNumberBoxDisplayed()
   {
      return WebElementTools.isPresent(sealBagNumber);
   }

   public boolean isSaveIconDisplayed()
   {
      return WebElementTools.isPresent(saveIcon);
   }

   public boolean isCancelCTADisplayed()
   {
      return WebElementTools.isPresent(cancelIcon);
   }

   public boolean isCloseCTADisplayed()
   {
      return WebElementTools.isPresent(closeIcon);
   }

   public boolean isCTAAtBottomDisplayed()
   {
      return WebElementTools.isPresent(bottomCTAIcon);
   }

   public void clickOnCancelCTA()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(cancelIcon);
   }

   public void clickOnCLoseCTA()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(closeIcon);
   }

   public boolean isAddedSealBagDisplayed()
   {
      wait.forJQueryReadyLazy();
      return WebElementTools.isDisplayed(addedSealBags);
   }

   public boolean isPaymentMethodDisplayed()
   {
      wait.forJQueryReadyLazy();
      return WebElementTools.isDisplayed(paymentMethod);
   }

   public boolean isBankingAmountDisplayed()
   {
      wait.forJQueryReadyLazy();
      return WebElementTools.isDisplayed(bankingAmount);
   }

   public boolean isSealBagNumberDisplayed()
   {
      wait.forJQueryReadyLazy();
      return WebElementTools.isDisplayed(sealBagNum);
   }

   public boolean isEditSealBagIconDisplayed()
   {
      wait.forJQueryReadyLazy();
      return WebElementTools.isDisplayed(editSealBagIcon);
   }

   public boolean isSaveCTADisplayed()
   {
      return WebElementTools.isPresent(saveButton);
   }

   public void clickOnSaveCTA()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(saveButton);
   }

   public boolean isPaymentAmountInputField()
   {
      return WebElementTools.isPresent(amountInputField);
   }

   public boolean isReasonInputField()
   {
      return WebElementTools.isPresent(reasonInputField);
   }

   public boolean insertPaymentValidationMessage()
   {
      return WebElementTools.isPresent(insertPaymentValidationError);
   }

   public boolean isPaymentAmountInputFieldHaveErrorCss()
   {
      return WebElementTools.isPresent(isPaymentAmountInputHaveErrorCss);
   }

   public boolean isReasonInputFieldHaveErrorCss()
   {
      return WebElementTools.isPresent(isReasonInputHaveErrorCss);
   }

   public void enterUpdateBankingAmount()
   {
      WebElementTools.enterText(addUpdateBankingAmount, "150");
      wait.forJSExecutionReadyLazy();
   }

   public void enterUpdateBankingSlipNumber()
   {
      WebElementTools.enterText(addSlipNumber, "6788");
      wait.forJSExecutionReadyLazy();
   }

   public void clickUpdateBankingSave()
   {
      WebElementTools.mouseHover(saveIcon);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(saveIcon);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isUpdatePaymentDetails()
   {
      return WebElementTools.isPresent(paymentDetail);
   }

   public void clickUpdatePaymentDetailsEdit()
   {
      WebElementTools.mouseOverAndClick(editSlip);
   }

   public void enterDetailUpdateBankingAmount()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(detailBankingAmount, "200");
      wait.forJSExecutionReadyLazy();
   }

   public void enterDetailSealBagNumber()
   {
      WebElementTools.enterText(detailSealBagNumber, "987643");
      wait.forJSExecutionReadyLazy();
   }

   public void clickEditSave()
   {
      WebElementTools.mouseOverAndClick(editSave);
      wait.forJSExecutionReadyLazy();
   }

   public void clickOverOrUnderReason()
   {
      WebElementTools.click(overOrUnderReason);
   }

   public boolean isAauthoriseDiscrepancyModalAppeared()
   {
      return WebElementTools.isDisplayed(authoriseDiscrepancyModal);
   }

   public boolean isSelectReasonAmountReasonDisplayed()
   {
      return WebElementTools.isDisplayed(selectReasonAmountAndReason);
   }

   public boolean isAuthorizeDiscrepancyTitleDisplayed()
   {
      return WebElementTools.isDisplayed(authorizeDiscrepancyTitle);
   }

   public boolean isSelectReasonTextAreaDisplayed()
   {
      return WebElementTools.isDisplayed(selectReasonTextArea);
   }

   public boolean isSelectReasonCancelCTADisplayed()
   {
      return WebElementTools.isDisplayed(selectReasonCancelCTA);
   }

   public boolean isSelectReasonSubmitCTADisplayed()
   {
      return WebElementTools.isDisplayed(selectReasonSubmitCTA);
   }

   public void clickSelectReasonCancelCTA()
   {
      WebElementTools.mouseOverAndClick(selectReasonCancelCTA);
   }

   public boolean isReasonContentCardDisplayed()
   {
      return WebElementTools.isDisplayed(reasonShowMoreLink);
   }

   public void clickSelectReasonSubmitCTA()
   {
      WebElementTools.enterText(selectReasonTextArea, "Test");
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(selectReasonSubmitCTA);
   }

   public void selectReasonSelectBoxOption()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(shopLossReason);
   }

   public void enterRegionTextSubmitRegionModal()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(modalReasonTextarea, "Test");
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(modalReasonSubmit);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isPaymentMethodTypeAccordion()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(paymentMethodTypeAccordion);
   }

   public boolean isReasonTypeAdded()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(reasonTypeAdded);
   }

   public boolean isShowReasonDetailLinkPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(showReasonDetailLink);
   }

   public boolean isReasonDetailContent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(reasonDetailContent);
   }

   public void clickShowReasonDetailLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(clickHideDetailLink);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(clickHideDetailLink);
   }

   public boolean isRegionContentPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(reasonContentCard);
   }

   public boolean isHideReasonDetailLinkPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(clickHideDetailLink);
   }

   public void clickHideReasonDetailLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(clickHideDetailLink);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(clickHideDetailLink);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isSelectReasonDisplayed()
   {
      return WebElementTools.isPresent(clickselectareason);
   }

   public void clickSelectReason()
   {
      wait.forJSExecutionReadyLazy();

   }

   public boolean isSelectReasonListDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(clickselectareason);
      wait.forJSExecutionReadyLazy();
      LOGGER.log(LogLevel.INFO, "selectreason is present in Reconcilation Page:");
      int i = 0;
      i = i + 1;
      boolean selectreason = WebElementTools.isPresent(selectareasonlist.get(i));
      i++;
      return selectreason;
   }

   public void selectOneReson()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(selectareasonlist.get(1));
   }

   public boolean isAddBankingAmountValidationError()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(addBankingAmountValidationError);
   }

   public boolean isAddSealBagValidationError()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(addSealBagValidationError);
   }

   public void enterBlankUpdateBankingAmount()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(detailBankingAmount, "");
      wait.forJSExecutionReadyLazy();
   }

   public void enterBlankSealBagNumber()
   {
      WebElementTools.enterText(detailSealBagNumber, "");
      wait.forJSExecutionReadyLazy();
   }

   public void clickPreviousReconPageLink()
   {
      WebElementTools.mouseOverAndClick(previousReconLink);
   }

   public boolean isPreviousReconGlobalHeaderAvailable()
   {
      return WebElementTools.isPresent(previousReconGlobalHeader);
   }

   public boolean isPreviousReconciliationLinkPresent()
   {
      return WebElementTools.isPresent(previousReconciliationLink);
   }

   public void clickPaymentMethodTypeAccordion()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(paymentMethodTypeAccordion);
   }

   public boolean isDiscrepancyAmountInputCreditCardPresent()
   {
      return WebElementTools.isPresent(discrepancyAmountInputCreditCard);
   }

   public void enterDiscrepancyAmountInputCreditCard()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(discrepancyAmountInputCreditCard, "200");
      wait.forJSExecutionReadyLazy();
   }

   public void clickSelectReasonListDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(selectReasonDropDown);
      Select dropdown = new Select(selectReasonDropDown);
      dropdown.selectByIndex(3);
   }

   public void clickSelectReasonCTA()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(selectReasonCTA);
   }

   public boolean isSelctReasonMessagePresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(selectReasonMessage);
   }

   public void clickAuthoriseCTA()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(seodbAuthoriseButton);
   }

   public boolean authoriseReconciliationModalIsPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(authoriseReconciliationModal);
   }

   public boolean addedReasonsInReconciliationModalPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(addedReasonsInReconciliationModal);
   }

   public void clickOnSearchCTA()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(seodbSearchButton);
   }

   public boolean isSearchResultCalenderIconViewd()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(previousReconciliationCalenderIcon);
   }

   public boolean isSearchResultDateView()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(previousReconciliationDate);
   }

   public boolean isSearchResultReconiliationId()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(previousReconiliationId);
   }

   public void closeUpdateBankingModal()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(closeupdatebankingmodal);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isSeodbDateSearchErrorMeassgaes()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(previousDateSearchErrorMessages);
   }

   public boolean isSeodbDateSearchErrorsBox()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(previousReconciliationDateSearchErrorsBOX);
   }

   public boolean isDisabledReasonSelectBox()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(disabledReasonSelectBox);
   }

   public boolean isDateTableHeaderPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(cardTypeDate);
   }

   public boolean isTimeTableHeaderPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(cardTypeTime);
   }

   public boolean isReferenceTableHeaderPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(cardTypeReference);
   }

   public boolean isAmountTableHeaderPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(cardTypeAmount);
   }

   public boolean isCardDigitsTableHeaderPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(cardTypeCardDigits);
   }

   public boolean isSystemTableHeaderPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(cardTypeSystem);
   }

   public boolean isCardTypeColumnDataPresent()
   {
      wait.forJSExecutionReadyLazy();
      boolean flag = true;
      for (int i = 0; i <= 5; i++)
      {
         String text = WebElementTools.getElementText(cardTypeColumnData.get(i));
         LOGGER.log(LogLevel.INFO, "my text:" + text);
         if (text.isEmpty())
         {
            flag = false;
            break;
         }

      }
      return flag;

   }

   public boolean isUpdateBankingIconPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(updateBankingIcon);
   }

   public boolean isUpdateBankingLinkPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(updateBankingLink);
   }

   public void selectCashReson()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(selectareasonlist.get(2));
   }

   public void clickAuthoriseModalCTA()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(authoriseModalCTA);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isAuthoriseConfModalTitle()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(authoriseConfModalTitle);
   }

   public boolean isAuthorisationMessage()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(authorisationMessage);
   }

   public boolean isAuthorisationTransctionId()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(authorisationTransctionId);
   }

   public boolean isAuthorisationConfirmationPopup()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(authorisationConfirmationPopup);
   }

   public boolean isAuthoriseModalCloseCTA()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(authoriseModalCloseCTA);
   }

   public boolean isSeodbDisabledAuthoriseButton()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(seodbDisabledAuthoriseButton);
   }

   public void clickPrivacyPopupClose()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(cmCloseBanner);
   }
}
