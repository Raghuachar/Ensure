package uk.co.tui.cdaf.frontend.stepdefs.uk.web.multi_centre.book.hubsummary;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.hub_summary.HubSummaryPage;
import uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.room_options.hotel_list.HotelListPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class HubSummaryStepDefs
{

   private final HotelListPage hotelListPage = new HotelListPage();

   HubSummaryPage hubSummaryPage = new HubSummaryPage();

   @Then("they navigate to the Unit Details page")
   public void they_will_be_navigated_to_the_Unit_Details_page()
   {
      assertThat("Not navigated to Unit Details page", hotelListPage.isOverviewDisplayed(),
               is(true));
   }

   @And("they select cancellation insurance")
   public void they_select_cancellation_insurance()
   {
      if (hubSummaryPage.cancellationPaxList.size() > 1)
      {
         int pricePanelPrice = hubSummaryPage.getPricePanelPrice();
         hubSummaryPage.selectCancellationAdult();
      }
      else
      {
         assertThat("Adults not available", false,
                  is(true));
      }
   }

   @When("they select show more on the cancellation insurance component")
   public void they_select_show_more_on_the_cancellation_insurance_component()
   {
      assertThat("cancellation insurance show more content link is not displayed",
               hubSummaryPage.isShowMoreLinkDisplayed(), is(true));
   }

}
