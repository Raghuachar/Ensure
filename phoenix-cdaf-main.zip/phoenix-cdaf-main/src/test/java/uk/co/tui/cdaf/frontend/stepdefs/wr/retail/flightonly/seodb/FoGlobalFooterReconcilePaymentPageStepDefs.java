package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FoGlobalFooterReconcilePaymentPageStepDefs
{
   private final RetailPackageNavigation retailpackagennaviagtion;

   private final FOReconcilationPaymentPageComponents reconcilationPage;

   public FoGlobalFooterReconcilePaymentPageStepDefs()
   {
      retailpackagennaviagtion = new RetailPackageNavigation();
      reconcilationPage = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Agent is viewing the reconcile payments page")
   public void that_the_Agent_is_viewing_the_reconcile_payments_page()
   {
      retailpackagennaviagtion.retailLoginChangeagent();
      reconcilationPage.navigateToReconcilePaymentPage();
   }

   @When("they view the footer at the bottom of the page")
   public void they_view_the_footer_at_the_bottom_of_the_page()
   {
      assertThat("Global footer is not present ", reconcilationPage.globalFooter(), is(true));
   }

   @Then("they can see the TUI Global footer")
   public void they_can_see_the_TUI_Global_footer()
   {
      assertThat(" Global footer is not present", reconcilationPage.isGlobalFooterPresent(),
               is(true));
   }

}
