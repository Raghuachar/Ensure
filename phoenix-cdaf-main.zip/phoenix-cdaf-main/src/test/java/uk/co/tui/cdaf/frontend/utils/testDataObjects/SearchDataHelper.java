package uk.co.tui.cdaf.frontend.utils.testDataObjects;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import net.minidev.json.writer.JsonReader;
import org.apache.commons.lang.StringUtils;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchCustom;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import java.io.File;
import java.net.URL;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * @author Dhananjaye.Prakash
 */
public class SearchDataHelper
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchDataHelper.class);

   private static final SearchCustom searchCustom = new SearchCustom();

   private static final String BOOKING_DATA = "booking_data/%s/%s.json";

   private static final String SEARCH_PARAM = "search_parameter/%s.json";

   public TestDataAttributes getSearchParameters()
   {
      return getSearchParameters(searchCustom.getScenarioId());
   }

   public TestDataAttributes getSearchParameters(String scenario)
   {
      String fileName = String.format(SEARCH_PARAM,
               ExecParams.getTestExecutionParams().getBrandStr().toLowerCase());
      return getSearchParameter(scenario, fileName);
   }

   public TestDataAttributes getBookingData(String scenario, String brand)
   {
      assertTrue("Impossible to build json file path without Brand",
               StringUtils.isNotEmpty(brand));
      String siteId = ExecParams.getTestExecutionParams().getBrandStr().toLowerCase();
      assertTrue("Impossible to build json file path without Site ID",
               StringUtils.isNotEmpty(siteId));
      String fileName = String.format(BOOKING_DATA, siteId, brand.toUpperCase());
      return getSearchParameter(scenario, fileName);
   }

   private TestDataAttributes getSearchParameter(String scenario, String fileName)
   {
      if (StringUtils.isEmpty(scenario))
      {
         LOGGER.log(LogLevel.INFO,
                  "Scenario name was not provided, trying to find correct json file with \"default\" value");
         scenario = "default";
      }

      List<TestDataAttributes> myPojos = loadTestDataFromJson(fileName);
      TestDataAttributes jsonSearchParam = findTestDataByScenario(scenario, myPojos);

      if (jsonSearchParam == null)
      {
         LOGGER.log(LogLevel.ERROR,
                  "Test parameters are empty. Cannot find scenario '" + scenario + "' in file: " + fileName);
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "All parameters:\n" + jsonSearchParam);
      }

      return updateWithScenarioParameters(jsonSearchParam);
   }

   @SneakyThrows
   private List<TestDataAttributes> loadTestDataFromJson(String fileName)
   {
      String filePath = "json/" + fileName;
      URL jsonFileUrl = JsonReader.class.getClassLoader().getResource(filePath);
      assertNotNull("File " + filePath + " does not exist.", jsonFileUrl);

      File jsonFile = Paths.get(jsonFileUrl.toURI()).toFile();
      ObjectMapper objectMapper = new ObjectMapper();
      return objectMapper.readValue(jsonFile, new TypeReference<>()
      {
      });
   }

   private TestDataAttributes findTestDataByScenario(String scenario,
            List<TestDataAttributes> testDataList)
   {
      return testDataList.stream()
               .filter(x -> StringUtils.equalsIgnoreCase(x.getScenario(), scenario))
               .findAny()
               .orElse(null);
   }

   private TestDataAttributes updateWithScenarioParameters(TestDataAttributes jsonSearchParam)
   {
      SearchCustom searchCustom = new SearchCustom();
      Integer numberOfDays = searchCustom.getNumberOfDays();
      Integer numberOfMonths = searchCustom.getNumberOfMonths();
      if (numberOfDays != null && numberOfDays > 0)
      {
         jsonSearchParam.setNumberOfDays(String.valueOf(numberOfDays));
      }
      else if (numberOfMonths != null && numberOfMonths > 0)
      {
         jsonSearchParam.setNumberOfMonths(String.valueOf(numberOfMonths));
      }
      return jsonSearchParam;
   }
}
