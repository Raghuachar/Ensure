package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class DetailPriceBreakDown extends AbstractPage
{

   public final WebDriverUtils utils;

   private final WebElementWait wait;

   @FindBy(css = ".UI__priceDetailsSection span a")
   private WebElement priceDescription;

   @FindAll({
            @FindBy(css = "[aria-label='Aanvullende kortingen (totaal) items']"),
            @FindBy(css = ".PriceBlockHeader__title") })
   private WebElement PriceBlockDiscountHeader;

   @FindAll({ @FindBy(css = "[aria-label='Wijzigingskosten']"),
            @FindBy(css = ".PriceBlockHeader__title"),
            @FindBy(css = "[aria-label='Korting voor agenten']") })
   private WebElement PriceBlockFeeHeader;

   public DetailPriceBreakDown()
   {
      wait = new WebElementWait();
      utils = new WebDriverUtils();
   }

   public void priceDescriptionLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(priceDescription);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(priceDescription);
   }

   public void priceDescriptionDiscountisDisplayed()
   {
      WebElementTools.mouseHover(PriceBlockFeeHeader);
      assertThat("Fee isDisplayed", WebElementTools.isPresent(PriceBlockFeeHeader), is(true));
   }

   public void priceDescriptionFeeisDisplayed()
   {
      assertThat("DiscountisDisplayed dispalyed",
               WebElementTools.isPresent(PriceBlockDiscountHeader), is(true));
   }

}
