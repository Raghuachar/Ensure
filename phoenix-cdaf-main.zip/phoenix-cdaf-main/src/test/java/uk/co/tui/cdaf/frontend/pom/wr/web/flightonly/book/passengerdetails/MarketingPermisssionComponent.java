package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MarketingPermisssionComponent extends AbstractPage
{
   @FindBy(css = "div[class*='marketingPermissions'] [class*='infoTextHeading']")
   private WebElement marektPermissionHeading;

   @FindBy(css = "div[class*='marketingPermissions'] [class*='infoText'] p")
   private WebElement marketPermissionDesc;

   @FindBy(css = "div[class*='marketingPermissions'] [aria-label='checkbox'] ")
   private List<WebElement> marketPermissionCheckbox;

   @SuppressWarnings("serial")
   public Map<String, WebElement> getMarketPermissionComponents()
   {
      return new HashMap<>()
      {
         {
            put("Market permission heading", marektPermissionHeading);
            put("Market permission desc", marketPermissionDesc);
            put("Market permission checbox", marketPermissionCheckbox.get(0));
         }
      };
   }

}
