package uk.co.tui.cdaf.frontend.stepdefs.uk.web.beach_holiday.search.search_results;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.EditSearchPackages;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

public class EditSearchPackagesStepDefs
{
   EditSearchPackages esp = new EditSearchPackages();

   @Then("they can see the search summary component")
   public void they_can_see_the_search_summary_component()
   {
      assertThat("Search summary component is visible.", esp.isSearchPanelSummaryComp(), is(true));
   }

   @When("they review the search summary component")
   public void they_review_the_search_summary_component()
   {
      assertThat("Search summary component is loaded.", esp.isSearchPanelSummaryComp(), is(true));
   }

   @Then("the search panel opens")
   public void the_search_panel_opens()
   {
      assertThat("Search Panel displayed ", esp.isSearchPanelDisplayed(), is(true));
   }

   @Then("the following fields become editable:")
   public void the_following_fields_become_editable(io.cucumber.datatable.DataTable dataTable)
   {
      assertTrue(esp.isSearchPanelSummaryComp());
   }

   @Then("the Clear search cta becomes available")
   public void the_Clear_search_cta_becomes_available()
   {
      assertThat("Clear search link displayed ", esp.clearSearchLink(), is(true));
   }

   @Then("the button changes to read Search")
   public void the_button_changes_to_read_Search()
   {
      esp.editSearchButtonAfterEdit();
   }

   @Given("they have modified at least one of the {string} fields")
   public void they_have_modified_at_least_one_of_the_fields(String ignored)
   {
      esp.modifySearch();
   }

   @Then("the returned list of package results updates to reflect their new search criteria")
   public void the_returned_list_of_package_results_updates_to_reflect_their_new_search_criteria()
   {
      throw new PendingException();
   }

}
