package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.flightoptions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class FlightMealsSelectionStepDefs
{

   static AutomationLogManager LOGGER =
            new AutomationLogManager(FlightMealsSelectionStepDefs.class);

   private final WebElementWait wait;

   private final FlightOptionsPage flightOptionsPage;

   private String totalPrice;

   public FlightMealsSelectionStepDefs()
   {
      wait = new WebElementWait();
      flightOptionsPage = new FlightOptionsPage();
   }

   @When("there are multiple matching meal options available for all flight segments")
   public void there_are_multiple_matching_meal_options_available_for_all_flight_segments()
   {
      LOGGER.log(LogLevel.INFO, "Implementation not required");
   }

   @Then("the following meals components should be displayed on the Flight Options page")
   public void the_following_meals_components_should_be_displayed_on_the_Flight_Options_page(
            List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = flightOptionsPage.mealsComponent.getFlightMealsComponent()
                     .get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });

   }

   @Given("there are matching meal options available for all flight segments")
   public void there_are_matching_meal_options_available_for_all_flight_segments()
   {
      LOGGER.log(LogLevel.INFO, "Implementation not required");
   }

   @When("they select the available meals from dropdown")
   public void they_select_the_available_meals_from_dropdown()
   {
      totalPrice = flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
      flightOptionsPage.mealsComponent.selectMeal(StringUtils.EMPTY, 1);
   }

   @And("total price of WR FO package should be updated on price summary panel")
   public void total_price_of_WR_FO_package_should_be_updated_on_price_summary_panel()
   {
      wait.forJSExecutionReadyLazy();
      String totalPriceAfterMealSelection =
               flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
      assertThat(
               ReportFormatter.generateReportStatement("TotalPrice",
                        "values are same after meal selection", totalPriceAfterMealSelection,
                        totalPrice),
               StringUtils.equalsIgnoreCase(totalPriceAfterMealSelection, totalPrice), is(false));
   }

   @Then("the meal selected should be all flight segments")
   public void the_meal_selected_should_be_all_flight_segments()
   {
      LOGGER.log(LogLevel.INFO, "Implementation not required");
   }

   @When("the customer selects a seat option without matching meal options for all flight segments")
   public void the_customer_selects_a_seat_option_without_matching_meal_options_for_all_flight_segments()
   {
      throw new PendingException();
   }

   @Then("those meal options that do not match should not display as available")
   public void those_meal_options_that_do_not_match_should_not_display_as_available()
   {
      throw new PendingException();
   }

   @When("the meal options component shall not display")
   public void the_meal_options_component_shall_not_display()
   {
      boolean isMealsDisplayed = flightOptionsPage.mealsComponent.isFlightMealsDisplayed();
      assertThat(ReportFormatter.generateReportStatement("Flight Meals", "component is displayed",
               isMealsDisplayed, false), isMealsDisplayed, is(false));
   }

}
