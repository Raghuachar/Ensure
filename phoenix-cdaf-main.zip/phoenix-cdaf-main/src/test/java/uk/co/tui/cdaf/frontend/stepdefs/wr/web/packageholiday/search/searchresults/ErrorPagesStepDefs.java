package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;

import java.util.Map;

import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;

import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class ErrorPagesStepDefs
{
   private final SearchResultsPage searchResultsPage;

   private final SearchPanel searchPanel = getSearchPanel();

   public ErrorPagesStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
   }

   @When("the error page gets generated with {string} & {string}")
   public void theErrorPageGetsGeneratedWith(String arg0, String arg1)
   {
      searchResultsPage.searchResultComponent.changeURL(arg0, arg1);
   }

   @And("the Search Panel MFE shall appear at the top of the page")
   public void theSearchPanelMFEShallAppearAtTheTopOfThePage() {
      assertTrue("Search Panel MFE is not displayed", searchPanel.isSearchPanelDisplayed());
   }

   @And("All gone page translation as follows:")
   public void allGonePageTranslationAsFollows(DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertTrue(searchResultsPage.allGoneBanner().getText().contains(expected));
   }

   @And("Page not found translation as follows:")
   public void pageNotFoundTranslationAsFollows(DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertEquals(expected, searchResultsPage.errorPageHeader());
   }

   @When("they complete a search that gives technical difficulties page")
   public void theyCompleteASearchThatGivesTechnicalDifficultiesPage()
   {
      searchResultsPage.searchResultComponent.changeURL("AMS123", "airports\\[\\]=(.+?)&");
   }

   @And("Technical Difficulties page translation as follows:")
   public void technicalDifficultiesPageTranslationAsFollows(DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertEquals(expected, searchResultsPage.errorPageHeader());
   }

   @And("sold out page translation as follows:")
   public void soldOutPageTranslationAsFollows(DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertEquals(expected, searchResultsPage.errorPageHeader());
   }
}
