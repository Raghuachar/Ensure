package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.api.requests.search.PackageSearchApi;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import static org.junit.Assert.assertTrue;

public class SingleAccommodationEditSearchStepDefs
{
   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   public final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent;

   private final SearchResultsComponent searchResultsComponent;

   private final SearchPanelComponent searchPanelComponent;

   private final SearchPanel searchPanel;

   public SingleAccommodationEditSearchStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      searchResultsComponent = new SearchResultsComponent();
      departureAirportOrDestinationComponent =
               new DepartureAirportAndDestinationAndDatesComponent();
      searchPanelComponent = new SearchPanelComponent();
      searchPanel = SearchPanelFactory.getSearchPanel();
   }

   @Given("the Customer or Agent is on the package single accom Search results page")
   public void the_is_on_the_package_single_accom_Search_results_page()
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
   }

   @Given("the Customer or Agent is on the package single accom Search results page via API")
   public void the_is_on_the_package_single_accom_Search_results_page_via_api()
   {
      TestDataAttributes parameter = new SearchDataHelper().getSearchParameters();
      parameter.setSuggestion("Hotel Riu Don Miguels");
      PackageSearchApi.openSearchResultsPage(parameter);
   }

   @When("they review the single accom top section in search results page")
   public void they_review_the_single_accom_top_section_in_search_results_page()
   {
      assertTrue("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed());
   }

   @And("selected edit search button")
   public void selected_edit_search_button()
   {
      searchResultsPage.searchResultComponent.clickEditSearchButton();
   }

   @When("they select the browser back button")
   public void they_select_the_browser_back_button()
   {
      searchResultsPage.singleAccommodationComponent.browserBack();
   }

   @Then("they are redirected to the previous page in their session")
   public void they_are_redirected_to_the_previous_page_in_their_session()
   {
      assertTrue("Re-directed to Home page",
               searchResultsPage.singleAccommodationComponent.isHomePageDisplayed());
   }

   @And("they have modified at least one of the {string} field")
   public void they_have_modified_at_least_one_of_the_fields(String respective)
   {
      if (StringUtils.containsIgnoreCase(respective, "Departure Airport"))
         searchPanel.airport().selectRandomAirport().confirmSelection();

   }

   @When("they select the edit Search CTA")
   public void they_select_the_edit_Search_CTA()
   {
      searchResultsPage.searchPanelComponent.searchPanel.doSearch();
   }

   @When("they review the edit search panel")
   public void they_review_the_edit_search_panel()
   {
      assertTrue("Expandable edit search panel is not displayed",
               searchPanel.isSearchPanelDisplayed());
   }

   @Then("it is open by default")
   public void it_is_open_by_default()
   {
      assertTrue("Open default is not displayed",
               searchResultsComponent.isExpandableOpenDefaultDisplayed());
   }

   @And("it s populated with the search request data")
   public void it_s_populated_with_the_search_request_data()
   {
      searchPanel.selectDefaults();
   }

   @And("they are on the single accom search result page with hotel that include a region with a child destination")
   public void they_are_on_the_single_accom_search_result_page_with_hotel_that_include_a_region_with_a_child_destination()
   {
      assertTrue("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed());
   }

   @Then("they review the hotel detail card")
   public void they_review_the_hotel_detail_card()
   {
      assertTrue("the selected destinations are not in order ",
               searchResultsPage.singleAccommodationComponent.verifyingSingleAccomSearchCard());
   }

   @Then("they can see the region child destination names displayed in the geo-tree:")
   public void they_can_see_the_region_child_destination_names_displayed_in_the_geo_tree(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertTrue("Region is not displayed", searchResultsPage.singleAccommodationComponent
               .verifySingleAccomRegionInLocation(dataTable));
   }

   @Given("the Customer is viewing the Search Panel Departure Date modal legacy message on the TRIPS single accom Search results page")
   public void the_Customer_is_viewing_the_Search_Panel_Departure_Date_modal_legacy_message_on_the_TRIPS_single_accom_Search_results_page()
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
      searchPanelComponent.selectWhenField();
      departureAirportOrDestinationComponent.selectLegacyDropdown(0);
   }
}
