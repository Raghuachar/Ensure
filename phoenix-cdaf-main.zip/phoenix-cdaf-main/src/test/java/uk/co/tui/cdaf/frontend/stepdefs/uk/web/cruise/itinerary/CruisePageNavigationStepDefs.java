package uk.co.tui.cdaf.frontend.stepdefs.uk.web.cruise.itinerary;

public class CruisePageNavigationStepDefs
{
   public static String durationHotelStay;
}
