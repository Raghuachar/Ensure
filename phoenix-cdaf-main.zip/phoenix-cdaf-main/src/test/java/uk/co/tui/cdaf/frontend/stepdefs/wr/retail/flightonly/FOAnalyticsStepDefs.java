package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOB2BAnalytics;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

public class FOAnalyticsStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(FOAnalyticsStepDefs.class);

   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailFlightOnlyPageNavigation retailflightonlypagenavigation;

   private final RetailSearchPanelComponent retailsearchPanelComponent;

   private final FlightOptionsPage flightOptionsPage;

   private final RetailPassengerDetailsPage retailpassengeretailsPage;

   private final ExtraOptionsPage extraOptionsPage;

   private final FOB2BAnalytics fob2banalytics;

   private final RetailFlightOnlyPageNavigation retailFlightOnlyPageNavigation;

   public FOAnalyticsStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailflightonlypagenavigation = new RetailFlightOnlyPageNavigation();
      retailsearchPanelComponent = new RetailSearchPanelComponent();
      flightOptionsPage = new FlightOptionsPage();
      retailpassengeretailsPage = new RetailPassengerDetailsPage();
      fob2banalytics = new FOB2BAnalytics();
      extraOptionsPage = new ExtraOptionsPage();
      retailFlightOnlyPageNavigation = new RetailFlightOnlyPageNavigation();
   }

   @Given("the agent is on passenger details page")
   public void the_agent_is_on_passenger_details_page()
   {
      retailpackagenavigation.retailLogin();
   }

   @When("they fetch page analytics on passenger details page")
   public void they_fetch_page_analytics_on_passenger_details_page()
   {
      retailflightonlypagenavigation.createOnewayBooking();
   }

   @Then("the they should see analtics data")
   public void the_they_should_see_analtics_data()
   {
      fob2banalytics.analyticsPaxPage();
      fob2banalytics.itemAnalyticsPaxPage();
      fob2banalytics.priceAnalyticsPaxPage();
      LOGGER.log("pax page Analytics:" + fob2banalytics.analyticsPaxPage());
      LOGGER.log("pax page item Analytics:" + fob2banalytics.itemAnalyticsPaxPage());
      LOGGER.log("pax page price Analytics:" + fob2banalytics.priceAnalyticsPaxPage());
      retailpassengeretailsPage.fillRetailPassengerDetails();
      retailpackagenavigation.retailPayment();
   }

   @Given("the agent is on flight options page")
   public void the_agent_is_on_flight_options_page()
   {
      retailpackagenavigation.retailLogin();
   }

   @When("they fetch page analytics on flight options page")
   public void they_fetch_page_analytics_on_flight_options_page()
   {
      retailsearchPanelComponent.wrFoOneWaySearch();
      retailsearchPanelComponent.selectFlight();

   }

   @Then("the they should see flight options analytics data")
   public void the_they_should_see_flight_options_analytics_data()
   {
      fob2banalytics.analyticsPaxPage();
      fob2banalytics.itemAnalyticsPaxPage();
      fob2banalytics.priceAnalyticsPaxPage();
      LOGGER.log("flight page Analytics:" + fob2banalytics.analyticsPaxPage());
      LOGGER.log("flight page item Analytics:" + fob2banalytics.itemAnalyticsPaxPage());
      LOGGER.log("flight page price Analytics:" + fob2banalytics.priceAnalyticsPaxPage());
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
      retailpassengeretailsPage.fillRetailPassengerDetails();
      retailpackagenavigation.retailPayment();
   }

   @Given("the agent is on extra options page")
   public void the_agent_is_on_extra_options_page()
   {
      retailpackagenavigation.retailLogin();
   }

   @When("they fetch page analytics on extra option page")
   public void they_fetch_page_analytics_on_extra_option_page()
   {
      retailFlightOnlyPageNavigation.wrMFEFoOneWaySearch();
      retailsearchPanelComponent.selectFlight();
      flightOptionsPage.clickOnContinue();
   }

   @Then("the they should see extra option analytics data")
   public void the_they_should_see_extra_option_analytics_data()
   {
      fob2banalytics.analyticsPaxPage();
      fob2banalytics.itemAnalyticsPaxPage();
      fob2banalytics.priceAnalyticsPaxPage();
      LOGGER.log("extra page Analytics:" + fob2banalytics.analyticsPaxPage());
      LOGGER.log("extra page item Analytics:" + fob2banalytics.itemAnalyticsPaxPage());
      LOGGER.log("extra page price Analytics:" + fob2banalytics.priceAnalyticsPaxPage());
      extraOptionsPage.clickOnContinue();
      retailpassengeretailsPage.fillRetailPassengerDetails();
      retailpackagenavigation.retailPayment();
   }

   @Given("the agent is on confirmation page")
   public void the_agent_is_on_confirmation_page()
   {
      retailpackagenavigation.retailLogin();
   }

   @When("they fetch page analytics on confirmation page")
   public void they_fetch_page_analytics_on_confirmation_page()
   {
      retailflightonlypagenavigation.createOnewayBooking();
   }

   @Then("the they should see confirmation analytics data")
   public void the_they_should_see_confirmation_analytics_data()
   {
      fob2banalytics.analyticsPaxPage();
      fob2banalytics.itemAnalyticsPaxPage();
      fob2banalytics.priceAnalyticsPaxPage();
      LOGGER.log("confirmation Analytics:" + fob2banalytics.analyticsPaxPage());
      LOGGER.log("confirmation item Analytics:" + fob2banalytics.itemAnalyticsPaxPage());
      LOGGER.log("confirmation price Analytics:" + fob2banalytics.priceAnalyticsPaxPage());
      retailpassengeretailsPage.fillRetailPassengerDetails();
      retailpackagenavigation.retailPayment();
   }

}
