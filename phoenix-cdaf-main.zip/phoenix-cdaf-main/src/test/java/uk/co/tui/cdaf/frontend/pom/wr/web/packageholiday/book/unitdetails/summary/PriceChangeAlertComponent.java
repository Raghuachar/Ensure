package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class PriceChangeAlertComponent extends AbstractPage
{
   @FindBy(css = "[class*='PriceChangeComponent__priceBanner']")
   private WebElement priceChangeMessage;

   public boolean isPriceChangeComponentDisplayed()
   {
      return WebElementTools.isPresent(priceChangeMessage);
   }
}
