package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class PackageInsertPaymetModelStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageInsertPaymetModelStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @When("they click the link to {string}")
   public void they_click_the_link_to(String string)
   {
      pKgReconcilationPaymentPageComponents.isPageSubHeaderPresent();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickInsertPayment();
   }

   @Then("the Insert payment modal will open on the screen")
   public void the_Insert_payment_modal_will_open_on_the_screen()
   {
      wait.forJSExecutionReadyLazy();
   }

   @Then("will display the  information as following")
   public void will_display_the_information_as_following(io.cucumber.datatable.DataTable dataTable)
   {
      wait.forJSExecutionReadyLazy();
   }

}
