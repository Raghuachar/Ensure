package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class ImportantInformationComponent
{
   public SelenideElement getImpInfoComp()
   {
      return $(".UI__importantInfoWrap").shouldBe(Condition.visible);
   }

   public String getImpInfoCompTitle()
   {
      return getImpInfoComp().$(".Column__col > h3").shouldBe(Condition.visible).getText();
   }

   public String getDiscountSectionTitle()
   {
      return getImpInfoComp().$(".UI__imp_info > h4").shouldBe(Condition.visible).getText();
   }

   public List<String> getDiscountsMessages()
   {
      return getImpInfoComp().$$(".UI__imp_info > ul > li").filter(Condition.visible).texts();
   }
}
