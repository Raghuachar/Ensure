package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class FOPartialPaymentsStepDefs
{
   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final RetailPassengerDetailsPage retailPassengerDetailsPage;

   public FOPartialPaymentsStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      retailPassengerDetailsPage = new RetailPassengerDetailsPage();
   }

   @Given("I have applied payments to an FO booking that reach the amount due today")
   public void i_have_applied_payments_to_an_FO_booking_that_reach_the_amount_due_today()
   {
      retailflightNavigation.retailLoginFO();
   }

   @When("I want to continue to book")
   public void i_want_to_continue_to_book()
   {
      retailflightNavigation.createOnewayBooking();
   }

   @Then("the continue button is enabled")
   public void the_continue_button_is_enabled()
   {
      retailPassengerDetailsPage.fillRetailPassengerDetails();
      retailPassengerDetailsPage.retailPartialPayment();
      retailPassengerDetailsPage.userLogout();
   }

}
