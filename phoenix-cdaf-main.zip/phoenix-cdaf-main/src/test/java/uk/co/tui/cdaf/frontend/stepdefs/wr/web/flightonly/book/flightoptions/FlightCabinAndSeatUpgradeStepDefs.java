package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.flightoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FlightCabinAndSeatUpgradeStepDefs
{
   static AutomationLogManager LOGGER =
            new AutomationLogManager(FlightCabinAndSeatUpgradeStepDefs.class);

   private final FlightOptionsPage flightPage;

   private String totPriceBeforeUpgrade, cabinTypeDiffPrice, seatTypeDiffPrice;

   public FlightCabinAndSeatUpgradeStepDefs()
   {
      flightPage = new FlightOptionsPage();
   }

   @And("the default CABIN CLASS highlighted is Economy Class")
   public void the_default_CABIN_CLASS_highlighted_is_Economy_Class()
   {
      WebElement element = flightPage.seatTypeComponent.getEcoCabinTypeSignMarkElement();
      boolean signMarkDispalyed = WebElementTools.isPresent(element);
      assertThat(
               ReportFormatter.generateReportStatementForComponentCheck(
                        "Economy cabin type is not higlihted", signMarkDispalyed, true),
               signMarkDispalyed, is(true));
   }

   @And("the default SEAT TYPE highlighted is Standard Seats")
   public void the_default_SEAT_TYPE_highlighted_is_Standard_Seats()
   {
      WebElement element = flightPage.seatTypeComponent.getSeatTypeSignElement().get(0);
      boolean signMarkDispalyed = WebElementTools.isPresent(element);
      assertThat(ReportFormatter.generateReportStatementForComponentCheck(
                        "Standard type is not higlihted", signMarkDispalyed, true), signMarkDispalyed,
               is(true));
   }

   @And("the default luggage allowance included and highlighted is the minimum allowance offered as part of the Economy Cabin Class 0kg")
   public void the_default_luggage_allowance_included_and_highlighted_is_the_minimum_allowance_offered_as_part_of_the_Economy_Cabin_Class_kg()
   {
      boolean selected = flightPage.luggageComponent.isZeroKgLuggageCardSelected();
      assertThat(ReportFormatter.generateReportStatementForComponentCheck(
               "Zero kg luggage card is not higlihted", selected, true), selected, is(true));
   }

   @And("they select the Terms & Conditions within the Cabin Class component")
   public void they_select_the_Terms_Conditions_within_the_Cabin_Class_component()
   {
      flightPage.seatTypeComponent.clickOnCabinTermsAndCondition();
   }

   @And("they will be presented with a modal with the appropriate T&C content")
   public void they_will_be_presented_with_a_modal_with_the_appropriate_T_C_content()
   {
      boolean overlayDisplayed = flightPage.seatTypeComponent.isCabinTCOverlayDisplayed();
      assertThat(
               ReportFormatter.generateReportStatementForComponentCheck(
                        "Cabin type TC overlay is not displayed", overlayDisplayed, true),
               overlayDisplayed, is(true));
      flightPage.seatTypeComponent.closeCabinTCOverlay();
   }

   @And("they select Deluxe as their CABIN CLASS")
   public void they_select_Deluxe_as_their_CABIN_CLASS()
   {
      totPriceBeforeUpgrade = flightPage.summaryPanelComponent.getTotalPriceValue();
      cabinTypeDiffPrice = flightPage.seatTypeComponent.getDeluxeCabinDifferencePrice();
      LOGGER.log(LogLevel.INFO,
               "total price and difference price of cabin:" + totPriceBeforeUpgrade + " "
                        + cabinTypeDiffPrice);
      flightPage.seatTypeComponent.selectDeluxeCabinType();
   }

   @And("the default luggage allowance included and highlighted is changed to the minimum allowance offered as part of the Deluxe Class 40kg")
   public void the_default_luggage_allowance_included_and_highlighted_is_changed_to_the_minimum_allowance_offered_as_part_of_the_Deluxe_Class_kg()
   {
      boolean selected = flightPage.luggageComponent.isFourtyKgLuggageCardSelected();
      assertThat(ReportFormatter.generateReportStatementForComponentCheck(
               "Fourty kg luggage card is not higlihted", selected, true), selected, is(true));
   }

   @And("any price increase is reflected in the Flight Summary panel")
   public void any_price_increase_is_reflected_in_the_Flight_Summary_panel()
   {
      flightPage.wait.forJSExecutionReadyLazy();
      double calculatedPrc = flightPage.seatTypeComponent
               .priceAfterCabinUpgrade(totPriceBeforeUpgrade, cabinTypeDiffPrice);
      String totPriceAfterUpgrade = flightPage.summaryPanelComponent.getTotalPriceValue();
      totPriceAfterUpgrade = totPriceAfterUpgrade.replaceAll("[€]", StringUtils.EMPTY);
      boolean flag = String.valueOf(calculatedPrc).equalsIgnoreCase(totPriceAfterUpgrade);
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Price increase is not reflected in summary panel", totPriceAfterUpgrade,
                        calculatedPrc),
               flag, is(false));
   }

   @Given("the SEAT TYPE component is no longer presented")
   public void the_SEAT_TYPE_component_is_no_longer_presented()
   {
      boolean displayed = flightPage.seatTypeComponent.isSeatTypeComponetDisplayed();
      assertThat(
               ReportFormatter.generateReportStatement("Seat type ",
                        "component is dispalying after deluxe cabin selection", displayed, true),
               displayed, is(false));
   }

   @When("they have selected Economy Class as their Cabin Class")
   public void they_have_selected_Economy_Class_as_their_Cabin_Class()
   {
      flightPage.seatTypeComponent.selectEconomyCabinType();
   }

   @And("they select Comfort Seats as their SEAT TYPE")
   public void they_select_Comfort_Seats_as_their_SEAT_TYPE()
   {
      totPriceBeforeUpgrade = flightPage.summaryPanelComponent.getTotalPriceValue();
      seatTypeDiffPrice = flightPage.seatTypeComponent.getComfortSeatDifferencePrice();
      LOGGER.log(LogLevel.INFO,
               "total price and difference price of cabin:" + totPriceBeforeUpgrade + " "
                        + seatTypeDiffPrice);
      boolean selected = flightPage.seatTypeComponent.selectComfortSeat();
      assertThat(
               ReportFormatter.generateReportStatementForComponentCheck("Comfort seat", selected,
                        true),
               selected, is(true));
   }

   @Then("the additional price is added and updated to the booking in the Flight Summary panel")
   public void the_additional_price_is_added_and_updated_to_the_booking_in_the_Flight_Summary_panel()
   {
      flightPage.wait.forJSExecutionReadyLazy();
      double calculatedPrc = flightPage.seatTypeComponent
               .priceAfterSeatUpgrade(totPriceBeforeUpgrade, seatTypeDiffPrice);
      String totPriceAfterUpgrade = flightPage.summaryPanelComponent.getTotalPriceValue();
      totPriceAfterUpgrade = totPriceAfterUpgrade.replaceAll("[€]", StringUtils.EMPTY);
      boolean flag = String.valueOf(calculatedPrc).equalsIgnoreCase(totPriceAfterUpgrade);
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Additional price is not updated in flight summay panel", totPriceAfterUpgrade,
               calculatedPrc), flag, is(true));
   }

   @And("they are presented with the Seat & Baggage components")
   public void they_are_presented_with_the_Seat_Baggage_components()
   {
      boolean seatDisplayed = flightPage.seatTypeComponent.isSeatTypeComponetDisplayed();
      assertThat(
               ReportFormatter.generateReportStatementForComponentCheck("Seat type", seatDisplayed,
                        true),
               seatDisplayed, is(true));

      boolean luggageDisplayed = flightPage.luggageComponent.isLuggageSectionDisplayed();
      assertThat(ReportFormatter.generateReportStatementForComponentCheck("Luggage",
               luggageDisplayed, true), luggageDisplayed, is(true));
   }

   @And("they select Fly Deluxe as their CABIN CLASS")
   public void they_select_Fly_Deluxe_as_their_CABIN_CLASS()
   {
      totPriceBeforeUpgrade = flightPage.summaryPanelComponent.getTotalPriceValue();
      cabinTypeDiffPrice = flightPage.seatTypeComponent.getFlyCabinDifferencePrice();
      LOGGER.log(LogLevel.INFO,
               "total price and difference price of cabin:" + totPriceBeforeUpgrade + " "
                        + cabinTypeDiffPrice);
      flightPage.seatTypeComponent.selectFlyCabinType();
   }

   @And("the default luggage allowance included and highlighted is changed to the minimum allowance offered as part of the Fly Deluxe Cabin Class 25kg")
   public void the_default_luggage_allowance_included_and_highlighted_is_changed_to_the_minimum_allowance_offered_as_part_of_the_Fly_Deluxe_Cabin_Class_25kg()
   {
      flightPage.wait.forJSExecutionReadyLazy();
      boolean selected = flightPage.luggageComponent.isTwentyFiveLuggageCardSelected();
      assertThat(ReportFormatter.generateReportStatementForComponentCheck(
               "twenty five luggage card is not higlihted", selected, true), selected, is(true));
   }

   @And("deluxe cabin class should not be displayed")
   public void deluxe_cabin_class_should_not_be_displayed()
   {
      boolean displayed = flightPage.seatTypeComponent.isDlecuxeCabinTypeDisplayed();
      assertThat(ReportFormatter.generateReportStatementForComponentCheck(
               "twenty five luggage card is not higlihted", displayed, true), displayed, is(true));
   }

}
