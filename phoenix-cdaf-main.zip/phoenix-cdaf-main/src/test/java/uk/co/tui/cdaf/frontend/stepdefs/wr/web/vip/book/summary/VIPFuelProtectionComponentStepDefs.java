package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.summary.VipSummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class VIPFuelProtectionComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public final VipSummaryPage vipSummaryPage;

   public VIPFuelProtectionComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      vipSummaryPage = new VipSummaryPage();
   }

   @Given("that that the customer is on the Unit Details Page")
   public void that_that_the_customer_is_on_the_Unit_Details_Page()
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @Given("the associated flight for their VIP package is VMH")
   public void the_associated_flight_for_their_VIP_package_is_VMH_Short_Medium_Haul()
   {
      // will implement this step once it is available
   }

   @When("they navigate to the VIP Customise Page")
   public void they_navigate_to_the_VIP_Customise_Page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @Then("they are presented with following VIP components:")
   public void they_are_presented_with_following_VIP_components()
   {
      boolean actual = vipSummaryPage.fuelProtection.isFuelProtectionDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Fuel Protection component wasnt displayed", actual, true), actual, is(true));
      vipSummaryPage.fuelProtection.scrollToFuelProtection();
   }
}
