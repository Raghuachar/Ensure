package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.room_options.hotel_list.NordicsLazyLoadingPage;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class SearchResultsStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchResultsStepDefs.class);

   public final SearchResultsPage searchResultsPage;

   private final PackageNavigation packageNavigation;

   private final Map<String, WebElement> sessionTimeOutComponent;

   private final Map<String, WebElement> searchMap;

   private final WebElementWait wait;

   private final UnitDetailsPage unitDetailsPage;

   public SearchPanel searchPanel;

   NordicsLazyLoadingPage NordicsLazyLoading;

   public SearchResultsStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
      packageNavigation = new PackageNavigation();
      NordicsLazyLoading = new NordicsLazyLoadingPage();
      wait = new WebElementWait();
      sessionTimeOutComponent = new HashMap<>();
      searchPanel = SearchPanelFactory.getSearchPanel();
      unitDetailsPage = new UnitDetailsPage();
      searchMap = new HashMap<>();
   }

   @And("the search results page should be displayed")
   public void the_search_results_page_should_be_displayed()
   {
      boolean isDisplayed = searchResultsPage.searchResultComponent.isHolidayCountDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Search Results page wasn't displayed", isDisplayed, true), isDisplayed, is(true));
   }

   @Given("the customer is on the WR Package edit search panel")
   public void the_customer_is_on_the_WR_Package_edit_search_panel()
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @And("click on on clear all link")
   public void click_on_on_clear_all_link()
   {
      getSearchPanel().clickClearAll();
   }

   @When("they select the Departure Airport field")
   public void they_select_the_Departure_Airport_field()
   {
      getSearchPanel().airport();
   }

   @Given("MORE than {int} results have been returned from the back-end")
   public void more_than_results_have_been_returned_from_the_back_end(Integer ten)
   {
      assertThat("there are less than {int} results", NordicsLazyLoading.getNoOfResult() > ten,
               is(true));
   }

   @When("they scroll down to the {int} result")
   public void they_scroll_down_to_the_result(Integer ten)
   {
      NordicsLazyLoading.scrollToLast();
   }

   @Then("they can see the next group of results automatically load")
   public void they_can_see_the_next_group_of_results_automatically_load()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("results are not loaded incrementally in groups of {int} as I scroll",
               NordicsLazyLoading.hotelsSize.size() > 10, is(true));
      wait.forJSExecutionReadyLazy();
   }

   @And("they can momentarily see the following:")
   public void they_can_momentarily_see_the_following(List<String> hotelList)
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      NordicsLazyLoading.scrollToLast();
      for (String hotelItems : hotelList)
      {
         WebElement hotelElement = NordicsLazyLoading.getHotelWebElement(hotelItems);
         assertThat(hotelItems + " is not displayed",
                  NordicsLazyLoading.isElementDisplayed(hotelElement), is(true));
      }
   }

   @And("LESS than {int} results have been returned from the back-End")
   public void less_than_results_have_been_returned_from_the_back_End(Integer eleven)
   {
      assertThat("there are less than {int} results", NordicsLazyLoading.getNoOfResult() < eleven,
               is(true));
   }

   @When("they Scroll down to the last result card")
   public void they_Scroll_down_to_the_last_result_card()
   {
      NordicsLazyLoading.scrollToLast();
   }

   @Then("No more results load")
   public void no_more_results_load()
   {
      NordicsLazyLoading.noMoreResult();
   }

   @And("they have been inactive for {int} minutes or more")
   public void they_have_been_inactive_for_minutes_or_more(int timer)
   {
      searchResultsPage.inActiveForCertainAmountOfTime(timer);
   }

   @When("they select a filter item and including sort by")
   public void they_select_a_filter_item_and_including_sort_by()
   {
      searchResultsPage.facilitiesFilterComponent.clickFacilitiesFilterOptions();
   }

   @Then("the error modal for {string} will display.")
   public void the_error_modal_for_will_display(String timeOut)
   {
      assertThat("{timeOut} pop up is not displayed", searchResultsPage.isSessionTimeOutPopUp(),
               is(true));
   }

   @And("the following message will be visible:")
   public void the_following_message_will_be_visible(List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      sessionTimeOutComponent.putAll(searchResultsPage.getSessionTimeOutComponent());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = sessionTimeOutComponent.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they click on {string} CTA")
   public void they_click_on_CTA(String continueButton)
   {
      assertThat("{continueButton} is not displayed", searchResultsPage.isCTAButtonDisplayed(),
               is(true));
      searchResultsPage.clickCTAButton();
   }

   @And("the search results page is refreshed")
   public void the_search_results_page_is_refreshed()
   {
      assertThat("the search results page is not refreshed",
               searchResultsPage.isHoildayCountDisplayed(), is(true));
   }

   @And("Search results are available")
   public void search_results_are_available()
   {
      assertTrue("Search Panel is not present", searchPanel.isSearchPanelDisplayed());
   }

   @When("they view the search results page")
   public void they_view_the_search_results_page()
   {
      boolean isDisplayed = searchResultsPage.searchResultComponent.isHolidayCountDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Search Results page wasn't displayed", isDisplayed, true), isDisplayed, is(true));
   }

   @Then("the following title will appear at the top of the search results card to show the number of search results:")
   public void the_following_title_will_appear_at_the_top_of_the_search_results_card_to_show_the_number_of_search_results(
            String components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      String getHolidatText = searchResultsPage.searchResultComponent.holidayCountText().getText();
      String[] holidayText = getHolidatText.split(" ");
      assertThat("Holiday count text is not correct", "vakanties gevonden".contains(holidayText[1]),
               is(true));
   }

   @When("they view the search results cards")
   public void they_view_the_search_results_cards()
   {
      assertThat("Search Result card component AccommInfo is present",
               searchResultsPage.searchResultComponent.visibileAccomInfoComponent(), is(true));
   }

   @Then("the following information will be displayed in each card:")
   public void the_following_information_will_be_displayed_in_each_card(List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchResultComponent.getSearchCardResults());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            LOGGER.log(LogLevel.INFO, element);
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("they click on {string} in one of the search results cards")
   public void they_click_on_in_one_of_the_search_results_cards(String string)
   {
      searchResultsPage.searchResultComponent.selectRandomResultCard();
   }

   @Then("the will be taken to the Package Unit Details page")
   public void the_will_be_taken_to_the_Package_Unit_Details_page()
   {
      assertThat("unit details page is not displayed",
               unitDetailsPage.isHotelDetailsPageDisplayed(), is(true));
   }

   @When("they complete a search that gives no results")
   public void they_complete_a_search_that_gives_no_results()
   {
      searchResultsPage.searchResultComponent.changeURL("10-02-2090", "when=(.+?)&until");
   }

}
