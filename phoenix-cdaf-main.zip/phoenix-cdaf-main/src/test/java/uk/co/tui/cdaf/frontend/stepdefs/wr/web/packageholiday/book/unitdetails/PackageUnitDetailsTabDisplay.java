package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.unitdetails;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;
import org.hamcrest.MatcherAssert;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.unit_details.LocationTabUnitDetails;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsTabDisplay;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.mmb.UnitDetailsComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PackageUnitDetailsTabDisplay
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(UnitDetailStepDefs.class);

   public final PackageNavigation packageNavigation;

   public final UnitDetailsPage unitDetailsPage;

   public final UnitDetailsTabDisplay unitDetailsTabDisplay;

   public final SearchResultsPage searchResultsPage;

   private final LocationTabUnitDetails LocationTabUnitDetails;

   private final UnitDetailsComponent unitDetailsComponent;

   private final PageErrorHandler errorHandler;

   private String siteId;

   public PackageUnitDetailsTabDisplay()
   {
      packageNavigation = new PackageNavigation();
      unitDetailsComponent = new UnitDetailsComponent();
      unitDetailsPage = new UnitDetailsPage();
      unitDetailsTabDisplay = new UnitDetailsTabDisplay();
      LocationTabUnitDetails = new LocationTabUnitDetails();
      searchResultsPage = new SearchResultsPage();
      errorHandler = new PageErrorHandler();
   }

   @When("they view the unit details tabs")
   public void they_view_the_unit_details_tabs()
   {
      // TODO: soft assert that each of the ocmponent isDisplayed
      unitDetailsComponent.getAccomDetailsComponents();
   }

   @Then("the respective tab will be opened when clicked")
   public void the_respective_tab_will_be_opened()
   {
      SoftAssertions softly = new SoftAssertions();

      unitDetailsTabDisplay.getLocationTab().scrollIntoView("{block: 'center'}").click();
      softly.assertThat(LocationTabUnitDetails.isContainerExist())
               .as("Location tab container is not displayed")
               .isTrue();

      unitDetailsTabDisplay.getFacilitiesTab().scrollIntoView("{block: 'center'}").click();
      softly.assertThat(unitDetailsTabDisplay.isFacilitiesTabDisplayed())
               .as("Facilities tab is not displayed")
               .isTrue();

      unitDetailsTabDisplay.getGuestReviewTab().scrollIntoView("{block: 'center'}").click();
      softly.assertThat(unitDetailsTabDisplay.isGuestReviewsTabDisplayed())
               .as("Guest Review tab is not displayed")
               .isTrue();

      unitDetailsTabDisplay.getOverviewTab().scrollIntoView("{block: 'center'}").click();
      softly.assertThat(unitDetailsTabDisplay.isAboutTheHotelTabDisplayed())
               .as("Overview tab is not displayed")
               .isTrue();

      softly.assertAll();
   }

   @And("About the hotel tab will be displayed")
   public void about_the_hotel_tab_will_be_displayed()
   {
      unitDetailsTabDisplay.isAboutTheHotelTabDisplayed();
   }

   @And("they click on the Facilities tab")
   public void they_click_on_the_Facilities_tab()
   {
      unitDetailsTabDisplay.clickOnFacilitiesTab();
   }

   @And("Facilities tab will be displayed")
   public void facilities_tab_will_be_displayed()
   {
      assertTrue(unitDetailsTabDisplay.getFacilitiesTab().isDisplayed());
   }

   @And("they click on the Location tab")
   public void they_click_on_the_Location_tab()
   {
      unitDetailsTabDisplay.clickOnLocationTab();
   }

   @And("Location tab will be displayed")
   public void location_tab_will_be_displayed()
   {
      assertTrue(unitDetailsTabDisplay.getLocationTab().isDisplayed());
   }

   @Then("the following options will be displayed in this order:")
   public void the_following_options_will_be_displayed_in_this_order(DataTable ignore)
   {
      assertTrue("Overview tab is not displayed",
               unitDetailsTabDisplay.getOverviewTab().isDisplayed());
      assertTrue("FACILITIES tab is not displayed",
               unitDetailsTabDisplay.getFacilitiesTab().isDisplayed());
      assertTrue("LOCATION tab is not displayed",
               unitDetailsTabDisplay.getLocationTab().isDisplayed());
      assertTrue("GUEST REVIEW tab is not displayed",
               unitDetailsTabDisplay.getGuestReviewTab().isDisplayed());
   }

   @Given("the {string} has conducted a search for a holiday")
   public void the_has_conducted_a_search_for_a_holiday(String ignore)
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @When("they are on the Unit Details page")
   public void they_are_on_the_Unit_Details_page()
   {
      assertTrue("Unit details page is not displayed",
               searchResultsPage.singleAccommodationComponent.isNavigatedToUnitDetailsPage());
   }

   @Then("they should see the following tabs in order")
   public void they_should_see_the_following_tabs_in_order(List<String> tabs)
   {
      for (int i = 0; i < tabs.size(); i++)
      {
         assertThat(String.format("%s tab is not displayed", tabs.get(i)),
                  unitDetailsTabDisplay.getTabIdByIndex(i), equalToIgnoringCase(tabs.get(i)));
      }
   }

   @Then("by default, {string} tab is selected")
   public void by_default_tab_is_selected(String aboutTheHotelTab)
   {
      assertTrue(String.format("%s tab is not selected by default", aboutTheHotelTab),
               unitDetailsTabDisplay.isAboutTheHotelTabDisplayed());
   }

   @Then("by the Guest Reviews tab shall be translated into the language of the website they are viewing")
   public void by_the_Guest_Reviews_tab_shall_be_translated_into_the_language_of_the_website_they_are_viewing(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> dataMap = dataTable.asMap(String.class, String.class);
      expected = dataMap.get(getTestExecutionParams().getLocaleStr());
      actual = unitDetailsTabDisplay.guestReviewsTabText();
      assertThat("Tab has incorrect translation:", actual, equalToIgnoringCase(expected));
   }

   @When("they select the Guest Reviews tab")
   public void they_select_the_Guest_Reviews_tab()
   {
      unitDetailsTabDisplay.selectGuestReviewsTab();
   }

   @Then("the Guest Reviews tab shall turn to selected state")
   public void the_Guest_Reviews_tab_shall_turn_to_selected_state()
   {
      assertTrue("Guest Reviews is not selected",
               unitDetailsTabDisplay.isGuestReviewsTabSelected());
   }

   @Then("the Guest Reviews tab shall expand to display the customer reviews content as per the attached UI")
   public void the_Guest_Reviews_tab_shall_expand_to_display_the_customer_reviews_content_as_per_the_attached_UI()
   {
      assertTrue("Guest Reviews MFE is not visible",
               unitDetailsTabDisplay.isGuestReviewsMFEVisible());
   }

   @Then("they should see the following components in order")
   public void they_should_see_the_following_components_in_order(List<String> expectedComponents)
   {
      Map<String, SelenideElement> guestComponents =
               new HashMap<>(unitDetailsTabDisplay.getGuestReviewComponentsMFE());
      expectedComponents.forEach(componentIdentifier ->
      {
         final SelenideElement element = guestComponents.get(componentIdentifier.trim());
         boolean actual = element.isDisplayed();
         assertTrue(componentIdentifier + "component not found", actual);
      });
   }

   @And("the TUI Reviews section with the listed filters")
   public void the_TUI_Reviews_section_with_the_listed_filters(List<String> expectedFilters)
   {
      Map<String, SelenideElement> guestFilters =
               new HashMap<>(unitDetailsTabDisplay.getGuestReviewFiltersMFE());
      expectedFilters.forEach(componentIdentifier ->
      {
         final SelenideElement element = guestFilters.get(componentIdentifier.trim());
         boolean actual = element.isDisplayed();
         assertTrue(componentIdentifier + "component not found", actual);
      });
   }

   @And("the Customer review section consists of")
   public void the_Customer_review_section_consists_of(List<String> expectedFilters)
   {
      Map<String, SelenideElement> guestFilters =
               new HashMap<>(unitDetailsTabDisplay.getCustomerReviewsectionsMFE());
      expectedFilters.forEach(componentIdentifier ->
      {
         final SelenideElement element = guestFilters.get(componentIdentifier.trim());
         boolean actual = element.isDisplayed();
         assertTrue(componentIdentifier + "component not found", actual);
      });
   }

   @When("the customer selects blue show more")
   public void the_customer_selects_blue_show_more()
   {
      unitDetailsTabDisplay.clickOnshowMoreLink();
   }

   @Then("the Score section is expanded")
   public void the_Score_section_is_expanded()
   {
      assertTrue("the Score section is Not expanded",
               unitDetailsTabDisplay.isScoreSectionExpanded());
   }

   @When("the Filter by travel party contains:")
   public void the_Filter_by_travel_party_contains(List<String> expectedFilters)
   {
      Map<String, SelenideElement> guestFilters =
               new HashMap<>(unitDetailsTabDisplay.getTravelPartyFiltersMFE());
      expectedFilters.forEach(componentIdentifier ->
      {
         final SelenideElement element = guestFilters.get(componentIdentifier.trim());
         boolean actual = element.isDisplayed();
         assertTrue(componentIdentifier + "component not found", actual);
      });
   }

   @When("select the filter from Filter by travel party")
   public void select_the_filter_from_Filter_by_travel_party()
   {
      unitDetailsTabDisplay.selectTravelpartyFilter();
   }

   @When("the Customer reviews filter results are displayed according to selected group")
   public void the_Customer_reviews_filter_results_are_displayed_according_to_selected_group()
   {
      unitDetailsTabDisplay.isTravelFilterDisplayed();
   }

   @When("the Filter by season contains:")
   public void the_Filter_by_season_contains(List<String> expectedSeasonFilters)
   {
      Map<String, SelenideElement> guestFilters =
               new HashMap<>(unitDetailsTabDisplay.getSeasonFiltersMFE());
      expectedSeasonFilters.forEach(componentIdentifier ->
      {
         final SelenideElement element = guestFilters.get(componentIdentifier.trim());
         boolean actual = element.isDisplayed();
         assertTrue(componentIdentifier + "component not found", actual);
      });
   }

   @When("select the filter from Filter by season")
   public void select_the_filter_from_Filter_by_season()
   {
      unitDetailsTabDisplay.selectSeasonFilter();
   }

   @When("the Customer reviews season filter results are displayed according to selected season")
   public void the_Customer_reviews_season_filter_results_are_displayed_according_to_selected_season()
   {
      unitDetailsTabDisplay.isSeasonFilterDisplayed();
   }

   @When("the language contains:")
   public void the_language_contains(List<String> expectedLanguageFilters)
   {
      Map<String, SelenideElement> guestFilters =
               new HashMap<>(unitDetailsTabDisplay.getLanguageFiltersMFE());
      expectedLanguageFilters.forEach(componentIdentifier ->
      {
         final SelenideElement element = guestFilters.get(componentIdentifier.trim());
         boolean actual = element.isDisplayed();
         assertTrue(componentIdentifier + "component not found", actual);
      });
   }

   @When("select the filter from language")
   public void select_the_filter_from_language()
   {
      unitDetailsTabDisplay.selectLanguageFilter();
   }

   @When("the Customer reviews language filter results are displayed according to selected language")
   public void the_Customer_reviews_language_filter_results_are_displayed_according_to_selected_language()
   {
      unitDetailsTabDisplay.isLanguageFilterDisplayed();
   }

   @When("the sort by Filter contains:")
   public void the_sort_by_Filter_contains(List<String> expectedSortByFilters)
   {
      Map<String, SelenideElement> guestFilters =
               new HashMap<>(unitDetailsTabDisplay.getSortByFiltersMFE());
      expectedSortByFilters.forEach(componentIdentifier ->
      {
         final SelenideElement element = guestFilters.get(componentIdentifier.trim());
         boolean actual = element.isDisplayed();
         assertTrue(componentIdentifier + "component not found", actual);
      });
   }

   @When("select the filter from sort by")
   public void select_the_filter_from_sort_by()
   {
      unitDetailsTabDisplay.selectSortByFilter();
   }

   @When("the Customer reviews results are displayed according to selected sorting option")
   public void the_Customer_reviews_results_are_displayed_according_to_selected_sorting_option()
   {
      unitDetailsTabDisplay.isSortFilterDisplayed();
   }

   @And("Scroll down the page, and verify the review section, {int} post reviews should be displayed on one page")
   public void scroll_down_the_page_and_verify_the_review_section_post_reviews_should_be_displayed_on_one_page(
            Integer int1)
   {
      assertTrue("review section" + int1 + "is not displayed",
               unitDetailsTabDisplay.getPostReviews());
   }

   @Then("Verify the pagination message Displayed reviews {string} of X text message should be displayed if more that {int} review records are existing")
   public void verify_the_pagination_message_Displayed_reviews_of_X_text_message_should_be_displayed_if_more_that_review_records_are_existing(
            String string, Integer int1)
   {
      assertTrue("the pagination text message is not displayed",
               unitDetailsTabDisplay.isPaginationMFE());
   }

   @When("Click on the {int}nd page of the review section, verify that next new {int} review records are displayed")
   public void click_on_the_nd_page_of_the_review_section_verify_that_next_new_review_records_are_displayed(
            Integer int1, Integer int2)
   {
      unitDetailsTabDisplay.clickOnpaginationMfeBtn();
   }

   @When("Click on the last page in the list, verify the displayed review records")
   public void click_on_the_last_page_in_the_list_verify_the_displayed_review_records()
   {
      unitDetailsTabDisplay.clickOnLastpaginationMfeBtn();
   }

   @When("Verify the listed filters shall be translated into the language of the website they are viewing:")
   public void verify_the_listed_filters_shall_be_translated_into_the_language_of_the_website_they_are_viewing(
            io.cucumber.datatable.DataTable dataTable)
   {

      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      siteId = getTestExecutionParams().getBrandStr();

      Map<String, String> matchingRow = dataTableTemp.stream()
               .filter(row -> row.get("Site").equals(siteId)).findFirst().orElseThrow(
                        () -> new IllegalArgumentException(
                                 "Cannot find expected strings for " + siteId));
      String expectedtravelgroup = matchingRow.get("travel group");
      String actualtravelgroup = unitDetailsTabDisplay.getTravelGroupFilter();
      assertThat("travelgroup filter not translated", actualtravelgroup,
               equalToIgnoringCase(expectedtravelgroup));
      String expectedseason = matchingRow.get("season");
      String actualseason = unitDetailsTabDisplay.getSeasonFilter();
      assertThat("season filter not translated", actualseason, equalToIgnoringCase(expectedseason));
      String expectedLanguage = matchingRow.get("Language");
      String actualLanguage = unitDetailsTabDisplay.getLanguageFilter();
      assertThat("Language filter not translated", actualLanguage,
               equalToIgnoringCase(expectedLanguage));
      String expectedSortBy = matchingRow.get("Sort By");
      String actualSortBy = unitDetailsTabDisplay.getsortByFilter();
      assertThat("SortBy filter not translated", actualSortBy, equalToIgnoringCase(expectedSortBy));
      String expectedGuestReviews = matchingRow.get("Guest reviews");
      String actualGuestReviews = unitDetailsTabDisplay.guestReviewsTabText();
      assertThat("", actualGuestReviews, equalToIgnoringCase(expectedGuestReviews));
      String expectedShowMore = matchingRow.get("Show more");
      String actualShowMore = unitDetailsTabDisplay.getShowMore();
      assertThat("", actualShowMore, equalToIgnoringCase(expectedShowMore));
      String expectedshowless = matchingRow.get("Show less");
      String actualshowless = unitDetailsTabDisplay.getShowLess();
      assertThat("", actualshowless, equalToIgnoringCase(expectedshowless));
      String expectedrecommended = matchingRow.get("Recommended");
      String actualrecommended = unitDetailsTabDisplay.getrecommendedBannerMFE();
      assertThat("", actualrecommended, equalToIgnoringCase(expectedrecommended));
      String expectedReviews = matchingRow.get("Displayed reviews");
      String actualReviews = unitDetailsTabDisplay.getDisplayedReviews();
      assertThat("", actualReviews, containsString(expectedReviews));
   }

   @Given("a Agent is on the Unit Details page")
   public void a_Agent_is_on_the_Unit_Details_page()
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   @Then("the Guest Reviews tab shall expand to display the new no reviews yet message")
   public void the_Guest_Reviews_tab_shall_expand_to_display_the_new_no_reviews_yet_message(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      siteId = getTestExecutionParams().getBrandStr();

      Map<String, String> matchingRow = dataTableTemp.stream()
               .filter(row -> row.get("Site").equals(siteId)).findFirst().orElseThrow(
                        () -> new IllegalArgumentException(
                                 "Cannot find expected strings for " + siteId));
      String expectedFirstError = matchingRow.get("headingError");
      String actualheadingError = unitDetailsTabDisplay.getHeadingErrorMFE();
      assertThat("", actualheadingError, equalToIgnoringCase(expectedFirstError));
      String expectedSeconderror = matchingRow.get("subError");
      String actualsubError = unitDetailsTabDisplay.geterroeSectonMFE();
      assertThat("", actualsubError, equalToIgnoringCase(expectedSeconderror));
      String expectedlasterror = matchingRow.get("lastErrormessage");
      String actuallastErrormessage = unitDetailsTabDisplay.getlastErrorSectionMFE();
      assertThat("", actuallastErrormessage, equalToIgnoringCase(expectedlasterror));
   }

   @When("the backend has returned guest review data for the package accommodation")
   public void the_backend_has_returned_guest_review_data_for_the_package_accommodation()
   {
      assertTrue("Guest review is not displayed in unit details page",
               unitDetailsTabDisplay.isGuestReviewDisplayed());
   }

   @And("the guest reviews score components shall display the following:")
   public void the_guest_reviews_score_components_shall_display_the_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertTrue("Guest review is not displayed in unit details page",
               unitDetailsTabDisplay.isGuestReviewDisplayed());
   }

   @When("total number of reviews shall be a Hyperlink")
   public void total_number_of_reviews_shall_be_a_Hyperlink()
   {
      assertTrue("Guest review link not found on unit details page",
               unitDetailsTabDisplay.isGuestReviewHyperLinkDisplayed());
   }

   @When("they view the guest reviews score component")
   public void they_view_the_guest_reviews_score_component()
   {
      assertTrue("Guest review is not displayed in unit details page",
               unitDetailsTabDisplay.isGuestReviewDisplayed());
   }

   @Given("the guest review rating description is greater than or equal to {double}")
   public void the_guest_review_rating_description_is_greater_than_or_equal_to(
            double expectedRating)
   {
      double actualRating = unitDetailsTabDisplay.getGuestReviewRatingOnHotelPage();
      MatcherAssert.assertThat("guest rating description is smaller than expected", actualRating,
               greaterThanOrEqualTo(expectedRating));
   }

   @Then("the Guest review rating description shall be populated as follows:")
   public void the_Guest_review_rating_description_shall_be_populated_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedRatingExcellent = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("9")).findFirst().orElse(null);
      String expectedRatingVeryGood = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("7.5")).findFirst().orElse(null);
      String expectedRatingAverage = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("6")).findFirst().orElse(null);
      String expectedRatingMediocre = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("4")).findFirst().orElse(null);
      String expectedRatingHorrible = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("0")).findFirst().orElse(null);

      Double actualRating = unitDetailsTabDisplay.getGuestReviewRatingOnHotelPage();
      if (actualRating >= 9)
      {
         assertEquals("guest rating translations is not matched ",
                  unitDetailsTabDisplay.getGuestReviewDescription(), expectedRatingExcellent);
      }
      else if (actualRating >= 7.5)
      {
         assertEquals("guest rating translations is not matched ",
                  unitDetailsTabDisplay.getGuestReviewDescription(), expectedRatingVeryGood);
      }
      else if (actualRating >= 6)
      {
         assertEquals("guest rating translations is not matched ",
                  unitDetailsTabDisplay.getGuestReviewDescription(), expectedRatingAverage);
      }
      else if (actualRating >= 4)
      {
         assertEquals("guest rating translations is not matched ",
                  unitDetailsTabDisplay.getGuestReviewDescription(), expectedRatingMediocre);
      }
      else if (actualRating >= 0)
      {
         assertEquals("guest rating translations is not matched ",
                  unitDetailsTabDisplay.getGuestReviewDescription(), expectedRatingHorrible);
      }
   }

   @And("the Guest Reviews tab shall expand to display the customer reviews content")
   public void the_Guest_Reviews_tab_shall_expand_to_display_the_customer_reviews_content()
   {
      assertTrue("The Guest Reviews tab Not expanded to display the customer reviews content",
               unitDetailsPage.isGuestReviewDataDisplayed());
   }

   @And("the customer will be positioned to the top of the Guest Reviews tab section")
   public void the_customer_will_be_positioned_to_the_top_of_the_Guest_Reviews_tab_section()
   {
      assertTrue("The customer is not positioned at the top of the section",
               unitDetailsTabDisplay.isCustomerPositionedAtTop());
   }
}
