package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class SpecialAssistancePage extends AbstractPage
{
   @FindBy(css = "[class='YourFlights__tncLuggageWrapper']")
   public WebElement isDynamic;

   @FindBy(css = "[id='SpecialAssistance_component']")
   public WebElement specialAssistanceComponent;

   @FindBy(css = "[class='SummarySpecialAssistance__description']")
   public WebElement specialAssistanceDescription;

   public boolean isDynamicFlight()
   {
      return WebElementTools.isPresent(isDynamic);
   }

   public boolean isSpecialAssistanceComponentPresent()
   {
      return WebElementTools.isPresent(specialAssistanceComponent);
   }

   public boolean isSpecialAssistanceDescriptionPresent()
   {
      return WebElementTools.isPresent(specialAssistanceDescription);
   }
}
