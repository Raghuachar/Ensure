package uk.co.tui.cdaf.frontend.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.Calendar;
import java.util.Date;

import static com.codeborne.selenide.Selenide.open;

public class Generic
{

   private static final String HTTPS_PROTOCOL = "https";

   private static final String USER_NAME = "ananth.reddy";

   private static final String PASSWORD = "Anantmay2021";

   /**
    * Adds a specified number of days to the current date and returns the resulting date.
    *
    * @param ndays The number of days to add to the current date.
    * @return A Date object representing the date after adding the specified number of days.
    * @author Omar.Farooq
    */
   public static Date addnDaystoCurrentDate(int ndays)
   {
      Calendar cal = Calendar.getInstance();
      Date currDate = cal.getTime();
      cal.setTime(currDate);
      cal.add(Calendar.DATE, ndays);
      currDate = cal.getTime();
      return currDate;
   }

   public static void adfsLogin(String adfsUrl)
   {
      adfsUrl = StringUtils.replace(adfsUrl, HTTPS_PROTOCOL + "://",
               HTTPS_PROTOCOL + "://" + USER_NAME + ":" + PASSWORD + "@");
      open(adfsUrl);
      BrowserCookies.closePrivacyPopUp();
      BrowserCookies.closePrivacyPopUp();
   }

}
