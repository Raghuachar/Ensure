package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class NoCreditDebitcardPaymentStepDefs
{

   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   public NoCreditDebitcardPaymentStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @Given("that the inhouse agent is on the payment page")
   public void that_the_inhouse_agent_is_on_the_payment_page()
   {
      retailpackagenavigation.retailLogin();
      retailpackagenavigation.navigateToPassengerPage();
      retailpassengerdetailspage.fillRetailPassengerDetails();
   }

   @When("they view the payment component")
   public void they_view_the_payment_component()
   {
      retailpassengerdetailspage.CreditDebitTypeNotPresent();
   }

   @Then("there is no option for Debit Credit Card available to be selected")
   public void there_is_no_option_for_Debit_Credit_Card_available_to_be_selected()
   {
      retailpassengerdetailspage.skippayment();
      retailpassengerdetailspage.userLogout();
   }
}
