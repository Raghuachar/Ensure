package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.confirmation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class TDABannerPage extends AbstractPage
{
   @FindBy(css = "[id='myThomsonApp__component']")
   public WebElement tdaBannerComponent;

   @FindBy(css = "[class='MyWrApp__myThomsonapp contentWidth']")
   public WebElement tdaBanner;

   @FindBy(css = "[class='MyWrApp__textContent']")
   public WebElement textContent;

   @FindBy(css = "[class='MyWrApp__imageContainer']")
   public WebElement image;

   @FindBy(css = "[class='MyWrApp__qrContainer']")
   public WebElement QRCode;

   @FindBy(css = "[class='MyWrApp__appButtons']")
   public WebElement icons;

   public boolean isTDABannerComponentDisplayed()
   {
      return WebElementTools.isPresent(tdaBannerComponent);
   }

   public boolean isTDABannerDisplayed()
   {
      return WebElementTools.isPresent(tdaBanner);
   }

   public boolean isTextContentPresent()
   {
      return WebElementTools.isPresent(textContent);
   }

   public boolean isImagePresent()
   {
      return WebElementTools.isPresent(image);
   }

   public boolean isQRPresent()
   {
      return WebElementTools.isPresent(QRCode);
   }

   public boolean isIconsPresent()
   {
      return WebElementTools.isPresent(icons);
   }
}
