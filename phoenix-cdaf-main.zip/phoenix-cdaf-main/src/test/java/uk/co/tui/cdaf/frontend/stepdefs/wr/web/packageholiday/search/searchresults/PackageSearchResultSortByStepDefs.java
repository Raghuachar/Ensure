package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SortByComponent;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PackageSearchResultSortByStepDefs
{
   public final SortByComponent searchResultsSortBy;

   private final PackageNavigation packageNavigation;

   private final WebElementWait wait;

   private final Map<String, WebElement> searchMap;

   public PackageSearchResultSortByStepDefs()
   {
      wait = new WebElementWait();
      searchResultsSortBy = new SortByComponent();
      packageNavigation = new PackageNavigation();
      searchMap = new HashMap<>();
   }

   @Given("the {string} is on the WR search results page")
   public void the_is_on_the_WR_search_results_page(String customer)
   {
      packageNavigation.navigateToflexibileSearchResultPage("+/- 14");
      searchResultsSortBy.selectSortBy();
   }

   @When("a SORT BY component will display above the search results cards")
   public void a_SORT_BY_component_will_display_above_the_search_results_cards()
   {
      searchResultsSortBy.isSortByDisplayed();
   }

   @Then("the default option in the SORT BY drop down box will display: {string}")
   public void the_default_option_in_the_SORT_BY_drop_down_box_will_display_Total_Price_low_to_high(
            String sortBy)
   {
      searchResultsSortBy.clickOnSortByDropdown(sortBy);
   }

   @When("they click on the {string} component drop down menu")
   public void they_click_on_the_component_drop_down_menu(String sortOption)
   {
      searchResultsSortBy.selectSortBy();
   }

   @Then("the following options will display in this order:")
   public void the_following_options_will_display_in_this_order(List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsSortBy.searchResultComponent.getSortByComponents());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("they select {string} within the sort by drop down menu")
   public void they_select_within_the_sort_by_drop_down_menu(String sortBy)
   {
      searchResultsSortBy.clickOnSortByDropdown(sortBy);
   }

   @Then("the search results will re order to display the cheapest holidays by total price first")
   public void the_search_results_will_re_order_to_display_the_cheapest_holidays_by_total_price_first()
   {
      assertThat("not in low to high results for totalpricePerson",
               searchResultsSortBy.doTotalPersonLowToHighResult(), is(true));
   }

   @Then("the search results will re order to display the most expensive holidays by total price first")
   public void the_search_results_will_re_order_to_display_the_expensive_holidays_by_total_price_first()
   {
      assertThat("not in high to low results for totalpricePerson",
               searchResultsSortBy.doTotalPersonHighToLowResult(), is(true));
   }

   @Then("the search results will re order to display the cheapest holidays by per person price first")
   public void the_search_results_will_re_order_to_display_the_cheapest_holidays_by_person_price_first()
   {
      assertThat("not in low to high results for pricePerPerson",
               searchResultsSortBy.doLowtoHighResult(), is(true));
   }

   @Then("the search results will re order to display the most expensive holidays by per person price first")
   public void the_search_results_will_re_order_to_display_the_expensive_holidays_by_perperson_price_first()
   {
      assertThat("not in high to low results for pricePerPerson",
               searchResultsSortBy.doHighToLowResult(), is(true));
   }

   @Then("the search results will re order to display the by per person high discount amount holidays first")
   public void the_search_results_will_re_order_to_display_the_by_per_person_high_discount_amount_holidays_first()
   {
      assertThat("not in high to low results for per person discount",
               searchResultsSortBy.doDiscountPersonHighToLowResult(), is(true));
   }

   @Then("the Sort By options should include the {string} sorting option")
   public void the_Sort_By_options_should_include_the_sorting_option(String sortOption,
            io.cucumber.datatable.DataTable dataTable)
   {
      wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsSortBy.searchResultComponent.getSortByComponents());
      Map<String, String> expectedValueMap = dataTable.asMap(String.class, String.class);
      try
      {
         String actual =
                  searchMap.get(sortOption) != null ? searchMap.get(sortOption).getText() : "";
         if (!actual.isEmpty())
         {
            String expected = expectedValueMap.get(getTestExecutionParams().getBrandStr());
            assertThat(
                     ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                              expected + " is not matched", actual, expected),
                     StringUtils.equalsIgnoreCase(expected.toLowerCase(), actual), is(true));
         }
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Given("the {string} has conducted a package search")
   public void the_has_conducted_a_package_search(String string)
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @And("they are on the search results page")
   public void they_are_on_the_search_results_page()
   {
      boolean isDisplayed = searchResultsSortBy.isHolidayCountDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Search Results page wasn't displayed", isDisplayed, true), isDisplayed, is(true));
   }

   @When("they review the {string} dropdown")
   public void they_review_the_dropdown(String string)
   {
      boolean isDisplayed = searchResultsSortBy.isSortByDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Sort By is not displayed", isDisplayed, true), isDisplayed, is(true));
   }

   @Then("the default option is {string}")
   public void the_default_option_is(String string)
   {
      if (ExecParams.getTestExecutionParams().isBE())
      {
         boolean isOurRecommendedDefaultSelection =
                  searchResultsSortBy.isDefaultSelection("Meest geboekt");
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Our Recommended is not default selection",
                           isOurRecommendedDefaultSelection, true),
                  isOurRecommendedDefaultSelection, is(true));
      }
      else if (ExecParams.getTestExecutionParams().isNL())
      {
         boolean isOurRecommendedDefaultSelection =
                  searchResultsSortBy.isDefaultSelection("Meest geboekt");
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Our Recommended is not default selection",
                           isOurRecommendedDefaultSelection, true),
                  isOurRecommendedDefaultSelection, is(true));
      }
      else if (ExecParams.getTestExecutionParams().isFR())
      {
         boolean isOurRecommendedDefaultSelection =
                  searchResultsSortBy.isDefaultSelection("Recommandé");
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Our Recommended is not default selection",
                           isOurRecommendedDefaultSelection, true),
                  isOurRecommendedDefaultSelection, is(true));
      }
   }

   @Then("the search results are sorted by CSP values")
   public void the_search_results_are_sorted_by_CSP_values()
   {
      boolean sortedByCSP = searchResultsSortBy.sortCust();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Results are not sorted by CSP", sortedByCSP, true), sortedByCSP, is(true));
   }

   @Given("any sort by option other than {string} is selected")
   public void any_sort_by_option_other_than_is_selected(String string)
   {
      searchResultsSortBy.clickSortoptions(2);
   }

   @Then("the search results will re order to display holidays by CSP values")
   public void the_search_results_will_re_order_to_display_holidays_by_CSP_values()
   {
      searchResultsSortBy.clickSortoptions(0);
      boolean sortedByCSP = searchResultsSortBy.sortCust();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Results are not sorted by CSP", sortedByCSP, true), sortedByCSP, is(true));
   }

   @When("two or more accommodations have the same CSP score")
   public void two_or_more_accommodations_have_the_same_CSP_score()
   {
      searchResultsSortBy.twoOrMoreCSPComparision();
   }

   @Then("they are ordered by total price, high to low")
   public void they_are_ordered_by_total_price_high_to_low_TBC()
   {
      boolean twoOrMoreCSPMatched = searchResultsSortBy.twoOrMoreCSPComparision();
      if (twoOrMoreCSPMatched)
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Results are not sorted by CSP", searchResultsSortBy.isFilteredByPrice(),
                           true),
                  searchResultsSortBy.isFilteredByPrice(), is(true));
   }

   @When("they review any search result card")
   public void they_review_any_search_result_card()
   {
      boolean isDisplayed = searchResultsSortBy.isHolidayCountDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Search Results page wasn't displayed", isDisplayed, true), isDisplayed, is(true));
   }
}
