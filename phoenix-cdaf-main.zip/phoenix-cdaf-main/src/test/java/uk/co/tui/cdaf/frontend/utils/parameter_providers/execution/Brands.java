package uk.co.tui.cdaf.frontend.utils.parameter_providers.execution;

public enum Brands
{
   BE,
   NL,
   FR,
   MA,
   VIP;

   public static Brands fromString(String value)
   {
      for (Brands brand : Brands.values())
      {
         if (brand.name().equalsIgnoreCase(value))
         {
            return brand;
         }
      }
      throw new IllegalArgumentException("Invalid Brand: " + value);
   }
}

