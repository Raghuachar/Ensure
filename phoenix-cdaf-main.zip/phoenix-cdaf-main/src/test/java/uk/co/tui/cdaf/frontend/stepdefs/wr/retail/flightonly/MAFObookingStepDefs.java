package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.retail.FOSpecialBaggage;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.MAFObookingComponenets;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.ConfirmationPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class MAFObookingStepDefs
{
   public final FlightOptionsPage flightOptionsPage;

   public final ExtraOptionsPage extraOptionsPage;

   private final PackageNavigation packagenavigation;

   private final RetailPackageNavigation retailpackagenavigation;

   private final FlightOnlyHomePage homepage;

   private final ConfirmationPage confirmationPage;

   private final MAFObookingComponenets mafobookingComponenets;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final RetailFlightOnlyPageNavigation retailflightonlypagenavigation;

   private final RetailSearchPanelComponent retailsearchpanelcomponent;

   private final FOSpecialBaggage specialbaggage;

   private final RetailFlightOnlyPageNavigation retailFlightOnlyPageNavigation;

   public MAFObookingStepDefs()
   {
      packagenavigation = new PackageNavigation();
      retailpackagenavigation = new RetailPackageNavigation();
      homepage = new FlightOnlyHomePage();
      confirmationPage = new ConfirmationPage();
      mafobookingComponenets = new MAFObookingComponenets();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      retailflightonlypagenavigation = new RetailFlightOnlyPageNavigation();
      retailsearchpanelcomponent = new RetailSearchPanelComponent();
      flightOptionsPage = new FlightOptionsPage();
      extraOptionsPage = new ExtraOptionsPage();
      specialbaggage = new FOSpecialBaggage();
      retailFlightOnlyPageNavigation = new RetailFlightOnlyPageNavigation();
   }

   @Given("the Moroccan agent is on the TUI Maroc Storefront")
   public void the_Moroccan_agent_is_on_the_TUI_Maroc_Storefront()
   {
      packagenavigation.retailLoginFO();
      retailpackagenavigation.relaunchMAFO();

   }

   @When("they go to the searchbar")
   public void they_go_to_the_searchbar()
   {
      homepage.clickDepartureAirportField();
      homepage.validateDepartureAirportsDropdown();
   }

   @Then("the Nearby Airports should default to Moroccan airports")
   public void the_Nearby_Airports_should_default_to_Moroccan_airports()
   {
      homepage.validateOrderListDepartureNearbyAirports();
      retailpassengerdetailspage.userLogout();
   }

   @When("they complete the booflow")
   public void they_complete_the_booflow()
   {
      throw new PendingException();
   }

   @Then("the Confirmation page will dislayed")
   public void the_Confirmation_page_will_dislayed()
   {
      boolean isDisplayed = confirmationPage.isBookingRefTitleDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Booking Ref Title is not displayed", isDisplayed, true), isDisplayed, is(true));
      retailpassengerdetailspage.userLogout();
   }

   @When("they are viewing the Maroc page header")
   public void they_are_viewing_the_Maroc_page_header()
   {
      throw new PendingException();
   }

   @Then("they should see the TUI Maroc global header")
   public void they_should_see_the_TUI_Maroc_global_header()
   {
      assertThat("Error Header is not present ", mafobookingComponenets.isHeaderPresent(),
               is(true));
   }

   @When("they are viewing the bottom of Maroc page")
   public void they_are_viewing_the_bottom_of_Maroc_page()
   {
      throw new PendingException();
   }

   @Then("they should see the TUI Maroc global Footer")
   public void they_should_see_the_TUI_Maroc_global_Footer()
   {
      assertThat("Error Footer is not present ", mafobookingComponenets.isFooterPresent(),
               is(true));
   }

   @When("they are viewing the Maroc extra option page")
   public void they_are_viewing_the_Maroc_extra_option_page()
   {
      retailflightonlypagenavigation.navigateToExtraPage();
   }

   @Then("they should not see the insurance component")
   public void they_should_not_see_the_insurance_component()
   {
      assertThat("Error Footer is not present ", mafobookingComponenets.isInsurancePresent(),
               is(true));

   }

   @When("they are viewing the Maroc page")
   public void they_are_viewing_the_Maroc_page()
   {
      assertThat("Error Footer is not present ",
               mafobookingComponenets.isSearchPanelConatinerPresent(), is(true));
   }

   @And("they should not see the insurance component on extra option page")
   public void they_should_not_see_the_insurance_component_on_extra_option_page()
   {
      flightOptionsPage.clickOnContinue();
      assertThat("No insurance for MAFO", mafobookingComponenets.isInsurancePresent(), is(false));
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();

   }

   @And("Confirmation page will dislayed")
   public void confirmation_page_will_dislayed()
   {
      retailpassengerdetailspage.userLogout();
   }

   @Given("the agent is on flights option pages")
   public void the_agent_is_on_flights_option_pages()
   {
      packagenavigation.retailLoginFO();
      retailpackagenavigation.relaunchMAFO();
   }

   @When("they view flight baggage section")
   public void they_view_flight_baggage_section()
   {
      retailFlightOnlyPageNavigation.wrMFEFoOneWaySearch();
      retailsearchpanelcomponent.selectFlight();
      specialbaggage.clickOnUpgardeSeats();
   }

   @Then("they should able to upgarde baggage")
   public void they_able_should_to_upgarde_baggage()
   {
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
   }

}
