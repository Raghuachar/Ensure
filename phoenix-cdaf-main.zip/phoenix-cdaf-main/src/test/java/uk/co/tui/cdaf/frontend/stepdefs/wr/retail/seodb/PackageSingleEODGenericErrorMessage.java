package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageSEODBComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSingleEODGenericErrorMessage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageSingleEODGenericErrorMessage.class);

   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageSEODBComponents pKgSEODBComponents;

   public PackageSingleEODGenericErrorMessage()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgSEODBComponents = new PackageSEODBComponents();

   }

   @When("there is an issue with the EOD Banking page")
   public void there_is_an_issue_with_the_EOD_Banking_page()
   {
      LOGGER.log(LogLevel.INFO, "Issue with the EOD Banking page");
   }

   @Then("the generic error message will appear")
   public void the_generic_error_message_will_appear()
   {
      assertThat("Add banking amount error is present",
               pKgSEODBComponents.isSeodbGenericErrorPresent(), is(true));
   }

   @Then("the phone number will differ for each website \\(see translations in comments)")
   public void the_phone_number_will_differ_for_each_website_see_translations_in_comments(
            io.cucumber.datatable.DataTable dataTable)
   {
      wait.forJSExecutionReadyLazy();

   }

}
