package uk.co.tui.cdaf.frontend.stepdefs.uk.web.cruise.itinerary;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.cruise.itinerary.ExcursionModalPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class ExcursionModalStepDefs
{

   private final ExcursionModalPage excursionModal = new ExcursionModalPage();

   @Then("the gallery modal should close")
   public void the_gallery_modal_should_close()
   {
      assertThat("pop up not closed ", excursionModal.isModalClosed(), is(true));
   }

   @When("they select Show Less")
   public void they_select_Show_Less()
   {
      assertThat("show less button not clicked ",
               WebElementTools.isPresent(excursionModal.getShowLessButton()), is(true));
      WebElementTools.click(excursionModal.getShowLessButton());
   }

}
