package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.Agents;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.agent_types.PackageType;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.net.URL;
import java.util.*;

import static com.codeborne.selenide.Selenide.open;

public class FlightOnlyHomePage extends AbstractPage
{
   private static final LinkedHashMap<String, String> countryNamesMap;

   private static final LinkedHashMap<String, String> langNamesMap;

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(FlightOnlyHomePage.class);

   static
   {
      countryNamesMap = new LinkedHashMap<>();
      countryNamesMap.put("be", "België/Belgique");
      countryNamesMap.put("fr", "France");
      countryNamesMap.put("ma", "Maroc");
      countryNamesMap.put("nl", "Nederland");

      langNamesMap = new LinkedHashMap<>();
      langNamesMap.put("english", "English");
      langNamesMap.put("spanish", "Español");
      langNamesMap.put("french", "Français");
      langNamesMap.put("dutch", "Dutch");

   }

   public final WebDriverUtils utils;

   private final HeaderComponent headercomp;

   private final HashMap<String, String> wrHeaderCompLabelMap;

   private final HashMap<String, WebElement> wrHeaderCompMap;

   private final WebElementWait wait;

   private List<String> sortedAirports;

   public FlightOnlyHomePage()
   {
      wait = new WebElementWait();
      headercomp = new HeaderComponent();
      wrHeaderCompLabelMap = new HashMap<>();
      wrHeaderCompMap = new HashMap<>();
      utils = new WebDriverUtils();
   }

   public void setHeaderLabelMap()
   {
      try
      {
         wrHeaderCompLabelMap.put("flights", headercomp.getFlightsLabel().getText());
         wrHeaderCompLabelMap.put("stay", headercomp.getStayLabel().getText());
         wrHeaderCompLabelMap.put("promotions", headercomp.getPromotionsLabel().getText());
         wrHeaderCompLabelMap.put("destinations", headercomp.getDestinationsLabel().getText());
         wrHeaderCompLabelMap.put("extras", headercomp.getExtrasLabel().getText());

         wrHeaderCompLabelMap.put("questions", headercomp.getQuestionsLabel().getText());
         wrHeaderCompLabelMap.put("checkin", headercomp.getCheckinLabel().getText());
         wrHeaderCompLabelMap.put("tui fly app",
                  headercomp.getFlyAppLabel().getText().split("\\(")[0].trim());
         wrHeaderCompLabelMap.put("travel information",
                  headercomp.getTravelInformationLabel().getText());
         wrHeaderCompLabelMap.put("account & bookings",
                  headercomp.getAccountBookingLabel().getText());
      }
      catch (Exception ignored)
      {

      }
   }

   public void setHeaderCompMap()
   {
      try
      {

         wrHeaderCompMap.put("headerComp", headercomp.getHeaderComp());
         wrHeaderCompMap.put("Shortlist", headercomp.getShortlistIcon());
         wrHeaderCompMap.put("Account & bookings", headercomp.getAccountBookingIcon());
      }
      catch (Exception ignored)
      {

      }

   }

   public void changeCountryLanguage(String langCode, String countryCode)
   {
      WebElementTools.clickElementJavaScript(headercomp.getCountrySwitcherLink());
      WebElementTools.click(wait
               .getWebElementWithLazyWait(
                        headercomp.getCountryLangSelectorComp().getSelectedCountry()));
      WebElementTools.clickElementJavaScript(
               headercomp.getCountryLangSelectorComp().getAvailableCountriesInDropdown().stream()
                        .filter(countryLabel -> countryLabel.getText()
                                 .equals(countryNamesMap.get(countryCode)))
                        .findAny().orElse(null));
      WebElementTools.click(wait
               .getWebElementWithLazyWait(
                        headercomp.getCountryLangSelectorComp().getSelectedlanguage()));
      WebElementTools.clickElementJavaScript(
               headercomp.getCountryLangSelectorComp().getAvailableLanguagesInDropdown().stream()
                        .filter(langLabel -> langLabel.getText().equals(langNamesMap.get(langCode)))
                        .findAny()
                        .orElse(null));
      WebElementTools
               .clickElementJavaScript(
                        headercomp.getCountryLangSelectorComp().getChangeSiteButton());

   }

   public String getHeaderLabel(String component)
   {
      return getHeaderLabelMap().get(component);
   }

   public boolean checkHeaderLabel(String actual, String expectedvalue)
   {
      return StringUtils.equalsIgnoreCase(actual, expectedvalue);
   }

   private HashMap<String, String> getHeaderLabelMap()
   {
      return wrHeaderCompLabelMap;
   }

   public HashMap<String, WebElement> getHeaderPageMap()
   {
      return wrHeaderCompMap;
   }

   public void viewHeader()
   {
      WebElementTools.scrollToCenter(headercomp.getHeaderComp());
   }

   public void clickBurgerMenu()
   {
      WebElementTools
               .clickElementJavaScript(wait.getWebElementWithLazyWait(headercomp.getBurgerMenu()));
      wait.forJSExecutionReadyLazy();
   }

   public boolean checkTUIFLYLogo()
   {
      return StringUtils.containsIgnoreCase(headercomp.getTuiFlyLogoIcon().getAttribute("src"),
               "TUI-fly-Logo.svg");
   }

   public HeaderComponent getHeaderComponent()
   {
      return headercomp;
   }

   public void clickCountryChangeLink()
   {
      WebElementTools.clickElementJavaScript(headercomp.getCountrySwitcherLink());
      wait.forJSExecutionReadyLazy();
   }

   public void getCountrySelectorInView()
   {
      WebElementTools.scrollToCenter(headercomp.getCountryLangSelectorComp().getLangSelctorModal());
   }

   public boolean defaultSearchPanelState()
   {
      return headercomp.isSearchPanelDefaultState().isEmpty();
   }

   public boolean validateCountriesInDropdown()
   {
      WebElementTools.click(wait
               .getWebElementWithLazyWait(
                        headercomp.getCountryLangSelectorComp().getSelectedCountry()));
      return headercomp.getCountryLangSelectorComp().getAvailableCountriesTextInDropdown()
               .equals(new ArrayList<>(countryNamesMap.values()));
   }

   public void clickCountryInDropdown()
   {
      WebElementTools.click(wait
               .getWebElementWithLazyWait(
                        headercomp.getCountryLangSelectorComp().getSelectedCountry()));
   }

   public void clickLanguageInDropdown()
   {
      WebElementTools.click(wait
               .getWebElementWithLazyWait(
                        headercomp.getCountryLangSelectorComp().getSelectedlanguage()));
   }

   public boolean validateLanguagesInDropdown()
   {
      WebElementTools.click(wait
               .getWebElementWithLazyWait(
                        headercomp.getCountryLangSelectorComp().getSelectedlanguage()));
      return headercomp.getCountryLangSelectorComp().getAvailableLanguagesTextInDropdown()
               .equals(new ArrayList<>(langNamesMap.values()));
   }

   public void clickDestinationAirportField()
   {
      WebElementTools.click(headercomp.getDestinationAirportTextInput());

      wait.waitForAWhile(5000);
   }

   public void clickDepartureAirportField()
   {
      WebElement getDepartureAirportTextInput = headercomp.getDepartureAirportTextInput();
      WebElementTools.clickElementJavaScript(getDepartureAirportTextInput);
   }

   public void setDefaultSearchPanelFieldState(String fieldName)
   {
      WebElement inputField = WebElementTools.getWebElementByName(fieldName);
      WebElementTools.clickElementJavaScript(inputField);
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(headercomp.getCurrentVisibleClearAllButton());
   }

   public void submitSearchPanel()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(headercomp.getSearchPanelSubmitButton());
   }

   public boolean errorMessagesAreShown()
   {
      wait.forJSExecutionReadyLazy();
      return !headercomp.geterrorMessages().isEmpty();
   }

   public boolean searchPanelFieldColor(String elementName)
   {
      WebElement inputField = WebElementTools.getWebElementByName(elementName);
      return inputField.getAttribute("class").contains("inputs__error");
   }

   public boolean validateSearchPanelSubmitButton()
   {
      return !headercomp.getSearchPanelSubmitButton().getAttribute("class")
               .contains("SearchPanel__disabled");
   }

   public void clickDisabledDepartureAirport()
   {
      WebElementTools.clickElementJavaScript(headercomp.getFirstDisabledDestinationAirport());
   }

   public void clickDisabledDestinationAirport()
   {
      WebElementTools.clickElementJavaScript(headercomp.getFirstDisabledDestinationAirport());
   }

   public String clickDepartureAirport(Integer elementPosition)
   {
      wait.forJSExecutionReadyLazy();
      WebElement departureAirport = headercomp.getDepartureAirportBasedOnPosition(elementPosition);
      WebElementTools.javaScriptScrollToElement(departureAirport);
      WebElementTools.clickElementJavaScript(departureAirport);
      return WebElementTools.getElementText(departureAirport);
   }

   public String clickDestinationAirport(Integer elementPosition)
   {
      wait.forJSExecutionReadyLazy();
      WebElement destinationAirport =
               headercomp.getDestinationAirportBasedOnPosition(elementPosition);
      WebElementTools.javaScriptScrollToElement(destinationAirport);
      WebElementTools.clickElementJavaScript(destinationAirport);
      return WebElementTools.getElementText(destinationAirport);
   }

   public void clickSearchPanelPassengerField()
   {
      WebElementTools.click(wait.getWebElementWithLazyWait(headercomp.getPassengerTextInput()));
   }

   public String validateAdultsPassengerSelectionField()
   {
      WebElementTools.javaScriptScrollToElement(headercomp.getPassangerAdultSelectInput());
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(headercomp.getPassangerAdultSelectInput());
   }

   public String validateChildrenPassengerSelectionField()
   {
      return WebElementTools.getElementText(headercomp.getPassangerChildrenSelectInput());
   }

   public boolean validateDestinationAirportsDropdown()
   {
      return WebElementTools.isPresent(
               wait.getWebElementWithLazyWait(headercomp.getDestinationAirportsDropdownModal()));
   }

   public boolean validateTitlePassengerDropdown()
   {
      return WebElementTools.isPresent(headercomp.getPassengerTitleDropdownModal());
   }

   public boolean validateDepartureAirportsDropdown()
   {
      return WebElementTools.isPresent(headercomp.getDepartureAirportsDropdownModal());
   }

   public boolean validateOrderedListDestinationAirports()
   {
      sortedAirports = headercomp.getDepartureAirportsInDropdownModal();
      List<String> defaultDepartureAirports = headercomp.getDepartureAirportsInDropdownModal();
      Collections.sort(defaultDepartureAirports);
      return sortedAirports.equals(defaultDepartureAirports);
   }

   public boolean validateOrderListDepartureNearbyAirports()
   {
      sortedAirports = headercomp.getNearbyAirportsInDropdownModal();
      List<String> defaultNearbyAirports = headercomp.getNearbyAirportsInDropdownModal();
      Collections.sort(defaultNearbyAirports);
      return sortedAirports.equals(defaultNearbyAirports);
   }

   public boolean validateClearAllDoneForAirportsDropdown(String string, String string2)
   {
      WebDriverUtils.executeScript("arguments[0].scrollIntoView(true);",
               headercomp.getDepartureAirportsDropdownModalClearAllButton());
      return (WebElementTools
               .isPresent(headercomp.getDepartureAirportsDropdownModalClearAllButton())
               && WebElementTools.isPresent(
               headercomp.getDepartureAirportsDropdownModalDoneButton()));
   }

   public boolean validateDepartureAirportFieldValue(String selectedDepartureAirport)
   {
      WebElement departureAirport = headercomp.getDepartureAirportTextInput();
      WebElementTools.scrollTo(departureAirport);
      return StringUtils.containsIgnoreCase(selectedDepartureAirport,
               departureAirport.getAttribute("placeholder"));
   }

   public boolean validateDestinationAirportFieldValue(String selectedDestinationAirport)
   {
      WebElement destinationAirport = headercomp.getDestinationAirportTextInput();
      WebElementTools.scrollTo(destinationAirport);

      return StringUtils.containsIgnoreCase(selectedDestinationAirport,
               destinationAirport.getAttribute("placeholder"));
   }

   public void navigateToHolidayPage()
   {
      if (ExecParams.getAgent().isFlightPackageType())
      {
         LOGGER.log(LogLevel.ERROR,
                  "Test was executed with FLIGHT package, but dynamicly changes to HOLIDAY package");
         TestExecutionParams tempParams = ExecParams.getTestExecutionParams();
         Agents tempAgent = new Agents();
         tempAgent.setBussinessType(ExecParams.getAgent().getBussinessType());
         tempAgent.setPackageType(PackageType.H);
         tempParams.setAgent(tempAgent);
         URL temporaryUrl = ExecParams.getTemporaryUrl(tempParams);
         open(temporaryUrl);
      }
      else
      {
         URL url = ExecParams.getTestExecutionParams().getUrl();
         open(url);
      }
      BrowserCookies.closePrivacyPopUp();
   }

}
