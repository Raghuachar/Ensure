package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageAccessingReconcilePaymentPageStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageAccessingReconcilePaymentPageStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent is on the retail homepage")
   public void that_the_agent_is_on_the_retail_homepage()
   {
      packagenavigation.retailLoginChangeagent();
   }

   @When("they navigate to the TUI Global header")
   public void they_navigate_to_the_TUI_Global_header()
   {
      assertThat(" Global Header is not present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
   }

   @Then("they can see a tab for {string}")
   public void they_can_see_a_tab_for(String string)
   {
      pKgReconcilationPaymentPageComponents.isAdminTabPresent();
   }

   @Given("that the agent is viewing the TUI Global header")
   public void that_the_agent_is_viewing_the_TUI_Global_header()
   {
      packagenavigation.retailLoginFO();
      assertThat(" Global Header is not present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
   }

   @When("they hover on the {string} link")
   public void they_hover_on_the_link(String string)
   {
      pKgReconcilationPaymentPageComponents.clickAdminTab();
   }

   @Then("the admin section will expand and show the information as following")
   public void the_admin_section_will_expand_and_show_the_information_as_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      pKgReconcilationPaymentPageComponents.clickAdminTab();
   }

   @When("they navigate to the {string} link in the page header")
   public void they_navigate_to_the_link_in_the_page_header(String string)
   {
      pKgReconcilationPaymentPageComponents.clickAdminTab();
   }

   @Then("they can see a link for {string}")
   public void they_can_see_a_link_for(String string)
   {
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.isBankingLinkPresent();
   }

   @Given("that the Agent is on the Retail homepage")
   public void that_the_Agent_is_on_the_Retail_homepage()
   {
      packagenavigation.retailLoginFO();
   }

   @When("they navigate to the {string} section on the header")
   public void they_navigate_to_the_section_on_the_header(String string)
   {
      assertThat(" Global Header is not present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
   }

   @When("click the link for {string}")
   public void click_the_link_for(String string)
   {
      pKgReconcilationPaymentPageComponents.clickAdminTab();
   }

   @Then("the Banking & Reconciliation page will open")
   public void the_Banking_Reconciliation_page_will_open()
   {
      pKgReconcilationPaymentPageComponents.clickBankingLink();
   }

   @Then("it will be in the same tab window")
   public void it_will_be_in_the_same_tab_window()
   {
      wait.forJSExecutionReadyLazy();
   }

}
