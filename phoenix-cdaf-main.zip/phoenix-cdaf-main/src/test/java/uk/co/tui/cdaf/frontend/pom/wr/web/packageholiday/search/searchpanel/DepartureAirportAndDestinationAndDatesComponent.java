package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion.DestinationSuggestion;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.*;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class DepartureAirportAndDestinationAndDatesComponent extends AbstractPage
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageNavigation.class);

   public final SearchResultsPage searchResultsPage = new SearchResultsPage();

   private final WebDriverUtils utils = new WebDriverUtils();

   private final Map<String, WebElement> searchCardMap = new HashMap<>();

   private final SearchPanel searchPanel = getSearchPanel();

   private final String mfeParentElemnt = "tui-search-panel-mfe";

   private final String mfeDestinationX = "[aria-label='Departure Airport close']";

   private final String mfeDurationDefaultvalue = "span[aria-label='undefined input-selectedText']";

   private final String mfeDurationList = ".durationWrapper select option";

   private final String mfeAllAirport = "[class='input input-checkbox']";

   private final String mfeDone = "span[aria-label='undefined Departure Airport']";

   private final String allAirportsBoxUnCheckedMFE = ".airportListContainer input:not(:checked)";

   private final String getMFEClearAll = "[class='clear']";

   private final String getMFEDone = "[class='button primary septenary medium']";

   private final String mfeToolTip = ".destinationWrapper .toolTip > span:nth-child(2)";

   private final String defaultAirportTextMFE;

   private final WebElementWait wait = new WebElementWait();

    private final String mfeAirportsGreyedout = "input[type='checkbox']:disabled";

   private final String allAirportsBoxEnabledMFE = "input[type='checkbox']:enabled";

   private final String mfeDepartureListField = "input.readOnlyText";

   private final String mfeDepartureAirportsList = ".airportList span[class='label-inline']";

   private final Random random = new Random();

   @FindBy(css = "[aria-label*='accomodation name']")
   public List<WebElement> hotelName;

   @FindBy(xpath = "//input[@name='Destination or Hotel' and @readonly]")
   public WebElement destinationReadOnly;

   @FindBy(css = "div.DestinationsList__legacyMsgTitle")
   public WebElement legacyMsg;

   @FindBy(css = "p[class*='location']")
   public List<WebElement> hotelLoction;

   int noofwindows = 0;

   String value = null;

   @FindBy(css = ".SelectAirports__listStyle")
   private WebElement airportList;

   @FindBy(css = "label.inputs__CheckboxTextAligned input:checked")
   private List<WebElement> allairportsSelected;

   @FindBy(css = "[class='SelectAirports__childrenGroup'] input:not(:disabled)+span")
   private List<WebElement> singleAirportCheckbox;

   @FindBy(xpath = "(//span[@class='inputs__box'])[4]")
   private WebElement secondAirportCheckbox;

   @FindBy(xpath = "//div[@class='SelectAirports__childrenGroup']//input[@disabled]/..")
   private WebElement airportDisabled;

   @FindBy(css = "[aria-label='Departure date header']")
   private WebElement dropdownWindowopen;

   @FindBy(css = "div[aria-hidden='true']")
   private List<WebElement> dropdownWindowclosed;

   @FindBy(css = "div.SelectAirports__childrenGroup input +span +span")
   private List<WebElement> listOfAirportNames;

   @FindBy(css = " label.inputs__CheckboxTextAligned input:checked +span +span")
   private List<WebElement> getcheckedairportNames;

   @FindBy(css = ".DestinationsList__destinationListStyle a")
   private List<WebElement> listofCountries;

   @FindBy(css = "a.DestinationsList__link.DestinationsList__disabled")
   private List<WebElement> countriesDisabled;

   @FindBy(xpath = "//a[@class='DestinationsList__link ']")
   private List<WebElement> selectCountries;

   @FindBy(css = "[class='DestinationsList__droplistContainer']")
   private List<WebElement> selectdestination;

   @FindBy(xpath = "//div[@class='DestinationsList__parentCheckbox'])[1]/label/input")
   private WebElement checkedDestination;

   @FindBy(css = "div[aria-hidden=false] div.SelectLegacyDate__calendar")
   private WebElement calendarpresent;

   @FindBy(css = "[name='flexibleOptions']+span+span")
   private List<WebElement> flexibleOptions;

   @FindBy(css = "div[arialabel='select month'] select")
   private WebElement calenderselectMonth;

   @FindBy(css = "[arialabel='select month']>div>select")
   private WebElement calendarMonthValueSelect;

   @FindBy(xpath = "//div[@class='Crossover__wrapper']//h4")
   private WebElement datesCrossOverMessageElementText;

   @FindAll({ @FindBy(xpath = "//div[@class='Crossover__linkContent']"),
            @FindBy(css = "[class='Crossover__wrapper'] p") })
   private WebElement datesCrossOverLinkElementText;

   @FindBy(css = "[class='Crossover__wrapper'] span")
   private List<WebElement> datesCrossOverLinkElementText1;

   @FindBy(css = "div[arialabel='select month'] span.inputs__selectText")
   private WebElement getMonth;

   @FindBy(xpath = "//div[@aria-hidden='false']//a[@class='DropModal__clear']")
   private WebElement clearAll;

   @FindBy(css = "td[class*='SelectLegacyDate__cell'][class*='available'][class*='selected']")
   private WebElement selecteddate;

   @FindBy(xpath = "//label[@aria-label='select destinations'] /..//div// input")
   private WebElement destinationstextfield;

   @FindAll({
            @FindBy(css = "div.AutoComplete__autoComplete > div > div:nth-child(1) > div > ul > li:nth-child(2) > span") })
   private WebElement selectDestionationOrRegion;

   @FindBy(css = "div.AutoComplete__autoComplete > div > div:nth-child(1) > div > ul > li:nth-child(2) > span > strong")
   private WebElement selectDestination;

   @FindBy(css = "div[aria-label='search panel container'] input[name='Destination or Hotel']")
   private WebElement destinationSelectedValue;

   @FindBy(css = "div.DestinationsList__childrenGroup")
   private List<WebElement> childdestinations;

   @FindBy(css = "input[aria-label='select destinations']")
   private WebElement selectedDestination;

   @FindBy(xpath = "//span[text()='Verwijder alles']/../../../..//span[@class='inputs__text']/span")
   private List<WebElement> selectedListOfDestinations;

   @FindBy(css = "div.ResultListItemV2__detailsWrapper")
   private List<WebElement> searchcard;

   @FindBy(css = "p.ResultListItemV2__location span")
   private List<WebElement> regionInsearchcard;

   @FindAll({ @FindBy(css = "span.DestinationsList__legacyMsgText"),
            @FindBy(css = "div.DestinationsList__linkText") })
   private List<WebElement> legacyMsgLink;

   @FindBy(css = "a.DestinationsList__link.DestinationsList__disabled")
   private WebElement countriesDisabledLegacy;

   @FindBy(xpath = "//a[@class='DestinationsList__link ']")
   private WebElement selectCountriesLegacy;

   @FindBy(xpath = "//input[@name='Destination or Hotel']")
   private WebElement destinationField;

   @FindBy(css = "span.HighlightedLink__icon")
   private WebElement legacyMsgIcon;

   @FindBy(css = "[id='setLanguage']")
   private WebElement setLanguage;

   @FindBy(css = "[id='setSiteId']")
   private WebElement setSiteId;

   @FindBy(css = "[id='set3pa']")
   private WebElement set3PATrue;

   @FindBy(css = "[class='UI__mediaBannerWrapper']")
   private WebElement selection;

   @FindBy(css = "[legacymessagingswitch='true']")
   private WebElement legacyMessageSwitch;

   @FindBy(css = "[class='hotelpage-name'] h1")
   private WebElement accomadation;

   @FindBy(css = "[id='headerContainer__component']")
   private WebElement accomadationName;

   private String currentmonth;

   private String futureMonth;

   private String selectedDestination1;

   private String selectedDestination2;

   public DepartureAirportAndDestinationAndDatesComponent()
   {
      defaultAirportTextMFE = "[placeholder='Kies luchthaven(s)']";
   }

   public void selectedSingleAirport()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(singleAirportCheckbox.get(0));
      wait.forJSExecutionReadyLazy();
   }

   public boolean selectedSecondAirport()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(secondAirportCheckbox);
      wait.forJSExecutionReadyLazy();
      return allairportsSelected.size() == 2;
   }

   public boolean isAirportsGreyedOutPresent()
   {
      boolean flag = false;
      wait.forJSExecutionReadyLazy();
      if (WebDriverUtils.getDriver().getCurrentUrl().contains("be")
               || WebDriverUtils.getDriver().getCurrentUrl().contains("nl"))
      {
         flag = WebElementTools.isPresent(airportDisabled)
                  || (!WebElementTools.isPresent(airportDisabled));

      }
      return flag;
   }

   public void clickAirportsGreyedOut()
   {
      if (WebDriverUtils.getDriver().getCurrentUrl().contains("be")
               || WebDriverUtils.getDriver().getCurrentUrl().contains("nl"))
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.click(airportDisabled);
      }
   }

   public boolean airportsUnSelected()
   {
      wait.forJSExecutionReadyLazy();
      return allairportsSelected.isEmpty();
   }

   public boolean dropdownWindowOpened()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(dropdownWindowopen);
   }

   public boolean dropdownWindowClosed()
   {
      return dropdownWindowclosed.size() >= 3;
   }

   public boolean isVerifyingAirportsInAlphabeticalOrder()
   {
      List<String> listOfAirport = new ArrayList<>();
      List<String> beforeSortlistOfAirports = new ArrayList<>();
      List<SelenideElement> allAirports = getSearchPanel().airport().getEnabledAirports();
      for (SelenideElement listOfAirportName : allAirports)
      {
         listOfAirport.add(listOfAirportName.getText());
         beforeSortlistOfAirports.add(listOfAirportName.getText());
      }
      Collections.sort(listOfAirport);
      return beforeSortlistOfAirports.equals(listOfAirport);
   }

   public List<String> getcheckedAirtportNames()
   {
      List<String> checkedairportnames = new ArrayList<>();
      for (WebElement getcheckedairportName : getcheckedairportNames)
      {
         checkedairportnames.add(getcheckedairportName.getText());
      }
      return checkedairportnames;
   }

   public boolean isCountriesInAlphabeticalOrder()
   {
      List<String> listOfAirport = new ArrayList<>();
      List<String> beforeSortlistOfAirports = new ArrayList<>();
      List<SelenideElement> allAirports =
               getSearchPanel().destination().getAllCountryDestinations();
      for (SelenideElement listOfDestinationName : allAirports)
      {
         listOfAirport.add(listOfDestinationName.getText());
         beforeSortlistOfAirports.add(listOfDestinationName.getText());
      }
      Collections.sort(listOfAirport);
      return beforeSortlistOfAirports.equals(listOfAirport);
   }

   public void clickOnCountries()
   {
      String firstCountryName =
               getSearchPanel().destination().getAllCountryDestinations().first().getText();
      getSearchPanel().destination().clearSelection()
               .selectDestinationFromList(firstCountryName, null).confirmSelection();
   }

   public boolean isCountriesDispalyed()
   {
      wait.forJSExecutionReadyLazy();
      return !listofCountries.isEmpty();
   }

   public boolean isCountriesGreyedOutPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(countriesDisabled.get(0));
   }

   public void clickCountryGreyedOut()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(countriesDisabled.get(0));
   }

   public boolean isCalenderDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(calendarpresent);
   }

   public void selectLegacyDropdown(int index)
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.selectDropDownByIndex(calendarMonthValueSelect, index);
      wait.forJSExecutionReadyLazy();
   }

   public void selectFutureMonth()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.selectDropDownByIndex(calenderselectMonth, 2);
      wait.forJSExecutionReadyLazy();
      futureMonth = WebElementTools.getElementText(getMonth);
   }

   public boolean isVerifyingFutureMonth()
   {
      wait.forJSExecutionReadyLazy();
      return !currentmonth.equals(futureMonth);
   }

   public boolean checked()
   {
      return WebElementTools.isChecked(checkedDestination);
   }

   public boolean searchPanelDropDownCloseBy(String name)
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(0, 0);
      WebDriverUtils.getDriver().findElement(By.xpath("//*[@aria-label='" + name + "']")).click();
      wait.forJSExecutionReadyLazy();
      return dropdownWindowClosed();
   }

   public void clickOnDestinationFieldText()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(destinationstextfield);
      wait.forJSExecutionReadyLazy();
   }

   public boolean viewTheDestination()
   {
      return WebElementTools.isDisplayed(destinationstextfield);
   }

   public DestinationSuggestion enterTheDestination()
   {
       return getSearchPanel().destinationSuggestions("Can");
   }

   public boolean veriyingRegions()
   {
      return !enterTheDestination().getAllSuggestionElements().isEmpty();
   }

   public void enterAndClickTheDestination()
   {
      WebElementTools.click(destinationstextfield);
      enterTheDestination();
      wait.forJSExecutionReadyLazy();
      selectedDestination1 = WebElementTools.getElementText(selectDestionationOrRegion);
      WebElementTools.click(selectDestionationOrRegion);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(destinationstextfield);
      wait.forJSExecutionReadyLazy();
      String destination1 = "Val";
      WebElementTools.enterText(destinationstextfield, destination1);
      wait.forJSExecutionReadyLazy();
      selectedDestination2 = WebElementTools.getElementText(selectDestionationOrRegion);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(selectDestionationOrRegion);
      wait.forJSExecutionReadyLazy();
   }

   public boolean verifyingDesionations()
   {

      wait.forJSExecutionReadyLazy();

      return destinationSelectedValue.getAttribute("placeholder").contains("+");
   }

   public void clickOnCountry()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(selectCountries.get(2));
      WebElementTools.click(selectCountries.get(2));
      wait.forJSExecutionReadyLazy();
   }

   public boolean verifyingGeoTree()
   {

      wait.forJSExecutionReadyLazy();
      WebElementTools.click(childdestinations.get(0));
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(childdestinations.get(0));
   }

   public boolean verifyingSelectedDestination()
   {
      return WebElementTools.getElementAttribute(selectedDestination, "placeholder").trim()
               .equals("Tenerife");
   }

   public boolean verifySelectedListOfDestinations()
   {
      wait.forJSExecutionReadyLazy();
      return selectedListOfDestinations.get(0).getText().equals(selectedDestination1)
               && selectedListOfDestinations.get(1).getText().equals(selectedDestination2);
   }

   public boolean verifyingSearchCard()
   {
      boolean flag = false;
      for (int i = 0; i < searchcard.size(); i++)
      {
         flag = regionInsearchcard.get(i).isDisplayed();
         if (!flag)
            break;
      }
      return flag;
   }

   public boolean verifyingRegionDestination()
   {
      return regionInsearchcard.get(0).isDisplayed();
   }

   public boolean verifyingDestinationReadOnly()
   {
      return WebElementTools.isDisplayed(destinationReadOnly);
   }

   public boolean verifyingLegacyMessageDispalyed()
   {
      return WebElementTools.isDisplayed(legacyMsg);
   }

   public boolean verifyingLegacyMsgLinkDispalyed()
   {
      return WebElementTools.isDisplayed(legacyMsgLink.get(0));
   }

   public boolean verifyingDestinationField()
   {
      return WebElementTools.isDisplayed(destinationField);
   }

   public String getLegacyMessage()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      try
      {
         return WebElementTools.getElementText(legacyMsg).trim();
      }
      catch (Exception e)
      {
         return StringUtils.EMPTY;
      }
   }

   public String getLegacyMessageLink()
   {
      try
      {
         return WebElementTools.getElementText(legacyMsgLink.get(0)).trim();
      }
      catch (Exception e)
      {
         return StringUtils.EMPTY;
      }
   }

   public void clickOnLegacyMessageLink()
   {
      wait.forJSExecutionReadyLazy();
      String parentwindow = utils.getCurrentWindowHandle();
      if (WebElementTools.isPresent(legacyMsgIcon))
      {
         WebElementTools.click(legacyMsgLink.get(0));
         wait.forJSExecutionReadyLazy();
         wait.forJSExecutionReadyLazy(2000);

         Set<String> avaiablewindows = WebDriverUtils.getAvailableWindowsHandles();
         noofwindows = avaiablewindows.size();
         for (String child_window : avaiablewindows)
         {
            if (!parentwindow.equals(child_window))
            {
               Selenide.switchTo().window(child_window);
               String legacyPageUrl = WebDriverUtils.getDriver().getCurrentUrl();
               LOGGER.log(LogLevel.INFO, " Legacy page is disaplying :" + legacyPageUrl);
            }
         }

         BrowserCookies.closePrivacyPopUp();
         WebDriverUtils.close();
         Selenide.switchTo().window(parentwindow);
      }
      else
      {
         WebElementTools.isPresent(legacyMsgLink.get(0));

      }
   }

   public boolean isCountriesGreyedOutLegacy()
   {
      if (WebElementTools.isPresent(countriesDisabledLegacy))
      {
         return WebElementTools.isPresent(countriesDisabledLegacy);
      }
      else
      {
         LOGGER.log(LogLevel.INFO,
                  "No contries are disabled in the destination field in Legacy  :");
         return true;
      }
   }

   public void clickOnAvaiableCountry()
   {
      if (WebElementTools.isPresent(selectCountriesLegacy))
      {
         WebElementTools.click(selectCountriesLegacy);
      }
   }

   public boolean isLegacyWebSitePresent()
   {
      if (noofwindows == 2)
         return true;
      return true;
   }

   public WebElement getDatesCrossOverMessageElementText()
   {
      return datesCrossOverMessageElementText;
   }

   public WebElement getDatesCrossOverLinkElementText()
   {
      return datesCrossOverLinkElementText;
   }

   public List<WebElement> getDatesCrossOverLinkElementText1()
   {
      return datesCrossOverLinkElementText1;
   }

   public boolean isCalenderDisplayedMFE()
   {
      wait.forJSExecutionReadyLazy();
      String calendarpresentMFE = "div[class='dropModal DepartureDate']";
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(calendarpresentMFE, mfeParentElemnt));
   }

   public boolean isVerifyingMonthSelector()
   {
      String currentMonthMFE = "div[arialabel='select month']";
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(currentMonthMFE, mfeParentElemnt));
   }

   public void selectLegacyDropdownMFE(int index)
   {
      $$(shadowDeepCss(".monthSelector select option")).get(index).click();
   }

   public String selectLegacyDropdownTextMFE()
   {
      String leaveEarlierMFE = "select[aria-label='selectMonth'] option:nth-child(1)";
      return SelenideHelper.getShadowRootElement(leaveEarlierMFE, mfeParentElemnt).getText();
   }

   public void selectMFEDestinationListIcon()
   {
      WebElementTools.clickElementJavaScript(getMFEDestinationIcon());
   }

   public void selectMFEDestinationListText()
   {
      getMFEDestinationText().click();
   }

   public String getMFEDestinationHeaderText()
   {
      return WebElementTools.getElementText(getMFEDestinationModelView());
   }

   public String getMFEDestinationCloseText()
   {
      return WebElementTools.getElementText(getMFEDestinationClearAll());
   }

   public String getMFEDestinationDoneText()
   {
      return WebElementTools.getElementText(getMFEDestinationDone());
   }

   public WebElement getMFEDestinationIcon()
   {
      String mfeDestinationsListIcon = "[class=\"destination-list\"]";
      wait.forAppear(SelenideHelper.getShadowRootElement(mfeDestinationsListIcon, mfeParentElemnt));
      WebElement destinationsList =
               SelenideHelper.getShadowRootElement(mfeDestinationsListIcon, mfeParentElemnt);
      WebElementTools.scrollTo(destinationsList);
      return destinationsList;
   }

   public WebElement getMFEDestinationText()
   {
      String mfeDestinationsListText = ".destinationWrapper input";
      WebElement destinationsText =
               SelenideHelper.getShadowRootElement(mfeDestinationsListText, mfeParentElemnt);
      wait.forAppear(destinationsText);
      WebElementTools.scrollTo(destinationsText);
      return destinationsText;
   }

   public WebElement getMFEDestinationModelView()
   {
      String mfeDestinationModelView = "[aria-label='Departure Airport header']";
      WebElement destinationsView =
               SelenideHelper.getShadowRootElement(mfeDestinationModelView, mfeParentElemnt);
      wait.forAppear(destinationsView);
      WebElementTools.scrollTo(destinationsView);
      return destinationsView;
   }

   public WebElement getMFEDestinationClearAll()
   {
      String mfeDestinationClearAll = "a[class='clear']";
      WebElement destinationsClearAll =
               SelenideHelper.getShadowRootElement(mfeDestinationClearAll, mfeParentElemnt);
      wait.forAppear(destinationsClearAll);
      return destinationsClearAll;
   }

   public WebElement getMFEDestinationDone()
   {
      String mfeDestinationDone = "[class='button primary septenary medium']";
      WebElement destinationsDone =
               SelenideHelper.getShadowRootElement(mfeDestinationDone, mfeParentElemnt);
      wait.forAppear(destinationsDone);
      return destinationsDone;
   }

   public void selectLanguage(String visibleText)
   {
      wait.forAppear(setLanguage);
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(setLanguage);
      wait.forJSExecutionReadyLazy();
      WebElementTools.selectDropDownByVisibleText(setLanguage, visibleText);
      wait.forJSExecutionReadyLazy();
   }

   public void selectSiteID(String visibleText)
   {
      wait.forAppear(setSiteId);
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(setSiteId);
      wait.forJSExecutionReadyLazy();
      WebElementTools.selectDropDownByVisibleText(setSiteId, visibleText);
   }

   public void set3PATrue(String visibleText)
   {
      wait.forAppear(set3PATrue);
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(set3PATrue);
      wait.forJSExecutionReadyLazy();
      WebElementTools.selectDropDownByVisibleText(set3PATrue, visibleText);
   }

   public void selectOutSide()
   {
      wait.forAppear(selection);
      WebElementTools.clickElementJavaScript(selection);
   }

   public boolean legacyMessageSwitchIsDisplayed()
   {
      return legacyMessageSwitch.isDisplayed();
   }

   public List<SelenideElement> getMFEDestinationCountryListDisabled()
   {
      wait.forJSExecutionReadyLazy();
      getMFEDestinationModelView();
      String mfeDestinationCountryDisabledList =
               ".destinationWrapper div[class='countryBlock hasChildren'] div[data-area='country'].disabled span";
      List<SelenideElement> destinationDisabledList =
               SelenideHelper.getShadowRootElements(mfeDestinationCountryDisabledList,
                        mfeParentElemnt);
      return destinationDisabledList;
   }

   public List<SelenideElement> getMFEDestinationCountryListEnabled()
   {
      wait.forJSExecutionReadyLazy();
      getMFEDestinationModelView();
      String mfeDestinationCountryEnabledList =
               ".destinationWrapper div[class='countryBlock hasChildren'] div[data-area='country'].enabled span";
      List<SelenideElement> destinationEnabledList =
               SelenideHelper.getShadowRootElements(mfeDestinationCountryEnabledList,
                        mfeParentElemnt);
      return destinationEnabledList;
   }

   public boolean mfeCloseDestinationModelIsPresent()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(mfeDestinationX, mfeParentElemnt));
   }

   public void mfeClickCloseDestinationX()
   {
      WebElementTools.click(SelenideHelper.getShadowRootElement(mfeDestinationX, mfeParentElemnt));
   }

   public void mfeClickDestinationDone()
   {
      wait.forAppear(getMFEDestinationDone());
      WebElementTools.click(getMFEDestinationDone());
   }

   public void isMFECountryalphabeticalOrder()
   {
      ArrayList<String> actualOrder = new ArrayList<>();
      ArrayList<String> expectedOrder = new ArrayList<>();
      String mfeDestinationCountryList =
               ".destinationWrapper div[class='countryBlock hasChildren'] div[data-area='country'] span";
      List<SelenideElement> alpha =
               SelenideHelper.getShadowRootElements(mfeDestinationCountryList, mfeParentElemnt);
      for (SelenideElement element : alpha)
      {
         actualOrder.add(element.getText());
         expectedOrder.add(element.getText());
      }
      Collections.sort(actualOrder);
      expectedOrder.equals(actualOrder);
   }

   public WebElement mfeGetDestinationLegacyText()
   {
      String mfeLegecyText = ".destinationWrapper div[class='legacy'] div p";
      WebElement legacyText = SelenideHelper.getShadowRootElement(mfeLegecyText, mfeParentElemnt);
      wait.forAppear(legacyText);
      WebElementTools.javaScriptScrollToElement(legacyText);
      return legacyText;
   }

   public WebElement mfeGetDestinationLegacyLinkText()
   {
      wait.forJSExecutionReadyLazy();
      String mfeLegecyLinkText = ".destinationWrapper div[class='legacy'] a";
      return SelenideHelper.getShadowRootElement(mfeLegecyLinkText, mfeParentElemnt);
   }

   public WebElement mfeGetDestinationLegacyAgentLinkText()
   {
      String mfeLegecyLinkAgentText = ".destinationWrapper div[class='legacy'] span";
      return SelenideHelper.getShadowRootElement(mfeLegecyLinkAgentText, mfeParentElemnt);
   }

   public WebElement mfeGetDestinationLegacyInhouseLinkText()
   {
      String mfeLegecyLinkInhouseText = ".destinationWrapper div[class='legacy'] a";
      return SelenideHelper.getShadowRootElement(mfeLegecyLinkInhouseText, mfeParentElemnt);
   }

   public WebElement getMfeDurationArrow()
   {
      String mfeDurationArrow = "div > div > div > label > svg";
      wait.forAppear(SelenideHelper.getShadowRootElement(mfeDurationArrow, mfeParentElemnt));
      WebElement durationArrow =
               SelenideHelper.getShadowRootElement(mfeDurationArrow, mfeParentElemnt);
      WebElementTools.scrollTo(durationArrow);
      return durationArrow;
   }

   public WebElement getMfeDurationField()
   {
      String mfeDurationfield = ".input-selectedText";
      WebElement durationText =
               SelenideHelper.getShadowRootElement(mfeDurationfield, mfeParentElemnt);
      wait.forAppear(durationText);
      WebElementTools.scrollTo(durationText);
      return durationText;
   }

   public void selectMfeDurationArrow()
   {
      wait.forAppear(getMfeDurationArrow());
      WebElementTools.mouseOverAndClick(getMfeDurationArrow());
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
   }

   public void selectMfeDurationField()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(getMfeDurationField());
      wait.forJSExecutionReadyLazy();
   }

   public String getMfeDefaultDurationValue()
   {
      return SelenideHelper.getShadowRootElement(mfeDurationDefaultvalue, mfeParentElemnt)
               .getText();
   }

   public boolean isMfeDurationValuesPresent(String duration)
   {
      String[] duration1 = duration.split(",");
      List<String> durationValues = Arrays.asList(duration1);
      for (int j = 0; j < durationValues.size(); j++)
      {

         if (!StringUtils.equalsIgnoreCase(durationValues.get(j), WebElementTools.getElementText(
                  SelenideHelper.getShadowRootElements(mfeDurationList, mfeParentElemnt).get(j))))
         {
            return false;
         }

      }
      return true;
   }

   public boolean isMfeDurationModalDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forAppear(SelenideHelper.getShadowRootElement(mfeDurationList, mfeParentElemnt));
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(mfeDurationList, mfeParentElemnt));
   }

   public String getMfeDurationDropdownFirstValue()
   {
      wait.forJSExecutionReadyLazy();
      try
      {
         WebElementTools
                  .click(SelenideHelper.getShadowRootElements(mfeDurationList, mfeParentElemnt)
                           .get(0));
         value = WebElementTools.getElementText(
                  SelenideHelper.getShadowRootElements(mfeDurationList, mfeParentElemnt).get(0));
         return WebElementTools.getElementText(
                  SelenideHelper.getShadowRootElements(mfeDurationList, mfeParentElemnt).get(0));
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getMfeDurationListValue()
   {
      String mfeDurationlistValue = "div > div > div > div > select > option:nth-child(6)";
      return SelenideHelper.getShadowRootElement(mfeDurationlistValue, mfeParentElemnt).getText();
   }

   public boolean getMfeDurationSelectdValue()
   {
      String selectedvalue =
               SelenideHelper.getShadowRootElement(mfeDurationDefaultvalue, mfeParentElemnt)
                        .getText();
      return selectedvalue.equals(value);
   }

   public boolean highlightedSelectedListValue()
   {
      WebElementTools.mouseOverAndClick(getMfeDurationField());
      return SelenideHelper.getShadowRootElement(mfeDurationList, mfeParentElemnt).isDisplayed();
   }

   public void selectAirportMFE()
   {
      WebElementTools.clickElementJavaScript(getMFEDepartureIcon());
   }

   public boolean mfeDepartureAirportsIsPresent()
   {
      return WebElementTools.isPresent(getMFEDepartureAirportModelView());
   }

   public WebElement getMFEDepartureIcon()
   {
      String mfeDepartureListIcon = ".icon-reset i";
      wait.forAppear(SelenideHelper.getShadowRootElement(mfeDepartureListIcon, mfeParentElemnt));
      WebElement departureList =
               SelenideHelper.getShadowRootElement(mfeDepartureListIcon, mfeParentElemnt);
      WebElementTools.scrollTo(departureList);
      return departureList;
   }

   public WebElement getMFEDepartureAirportModelView()
   {
      String mfeDepartureAirportModelView = "[aria-label='Departure Airport header']";
      WebElement departureView =
               SelenideHelper.getShadowRootElement(mfeDepartureAirportModelView, mfeParentElemnt);
      wait.forAppear(departureView);
      WebElementTools.scrollTo(departureView);
      return departureView;
   }

   public void isMFEDepartureAirportAlphabeticalOrder()
   {
      ArrayList<String> actualOrder = new ArrayList<>();
      ArrayList<String> expectedOrder = new ArrayList<>();
      String mfeDepartureAirportList = ".airportList span[class='label-inline']";
      List<SelenideElement> alpha =
               SelenideHelper.getShadowRootElements(mfeDepartureAirportList, mfeParentElemnt);
      wait.forAppear(alpha.get(0));
      for (SelenideElement element : alpha)
      {
         actualOrder.add(element.getText());
         expectedOrder.add(element.getText());
      }
      Collections.sort(actualOrder);
      expectedOrder.equals(actualOrder);
   }

   public Map<String, WebElement> getDepartureAiportComponentsMFE()
   {
      String departureAirportLabelMFE = "[aria-label='Departure Airport header']";
      searchCardMap.put("Airports (Select airports you can fly from)",
               SelenideHelper.getShadowRootElement(departureAirportLabelMFE, mfeParentElemnt));
      String mfeXModal = "[aria-label='Departure Airport close']";
      searchCardMap.put("X close modal",
               SelenideHelper.getShadowRootElement(mfeXModal, mfeParentElemnt));
      searchCardMap.put("All airports group option",
               SelenideHelper.getShadowRootElement(mfeAllAirport, mfeParentElemnt));
      String mfeClearAll = "[aria-label='undefined Departure Airport']";
      searchCardMap.put("CLEAR ALL",
               SelenideHelper.getShadowRootElement(mfeClearAll, mfeParentElemnt));
      searchCardMap.put("DONE", SelenideHelper.getShadowRootElement(mfeDone, mfeParentElemnt));
      return searchCardMap;
   }

   public boolean isAllAirportBoxByDefaultUncheckedMFE()
   {
      boolean flag = false;
      List<SelenideElement> defaultUnchecked =
               SelenideHelper.getShadowRootElements(allAirportsBoxUnCheckedMFE, mfeParentElemnt);
      for (int i = 0; i < defaultUnchecked.size(); i++)
      {
         flag = defaultUnchecked.get(0).isEnabled();
         if (flag)
            break;
      }
      return flag;
   }

   public boolean isEachAirportBoxByDefaultUncheckedMFE()
   {
      boolean flag = false;
      List<SelenideElement> defaultUnchecked =
               SelenideHelper.getShadowRootElements(allAirportsBoxUnCheckedMFE, mfeParentElemnt);
      for (SelenideElement element : defaultUnchecked)
      {
         flag = element.isEnabled();
      }
      return flag;
   }

   public WebElement getMFEAirportHeaderText()
   {
      String getMFEAirportHeader = "[aria-label='Departure Airport header']";
      WebElement legacyText =
               SelenideHelper.getShadowRootElement(getMFEAirportHeader, mfeParentElemnt);
      return legacyText;
   }

   public WebElement getMFEAllAirportText()
   {
      WebElement allAirportyText =
               SelenideHelper.getShadowRootElement(mfeAllAirport, mfeParentElemnt);
      return allAirportyText;
   }

   public WebElement getMFEClearAllText()
   {
      WebElement clearAllText =
               SelenideHelper.getShadowRootElement(getMFEClearAll, mfeParentElemnt);
      return clearAllText;
   }

   public WebElement getMFEDoneText()
   {
      WebElement doneText = SelenideHelper.getShadowRootElement(getMFEDone, mfeParentElemnt);
      wait.forAppear(doneText);
      return doneText;
   }

   public List<String> getMFEAirportText()
   {
      List<String> departureAirports = new ArrayList<>();
      String airportsTextMFE = ".airportListContainer [class='label-inline']";
      List<SelenideElement> allAirportyText =
               SelenideHelper.getShadowRootElements(airportsTextMFE, mfeParentElemnt);
      wait.forAppear(allAirportyText.get(1));
      for (int i = 1; i < allAirportyText.size(); i++)
      {
         departureAirports.add(allAirportyText.get(i).getText());
      }
      return departureAirports;
   }

   public boolean getMFEDonePrsent()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(getMFEDone, mfeParentElemnt));
   }

   public void closeDepartureAirportModalMFE()
   {
      WebElementTools
               .clickElementJavaScript(
                        SelenideHelper.getShadowRootElement(mfeDone, mfeParentElemnt));
   }

   public void clickOnAnyAirportMFE()
   {
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(allAirportsBoxUnCheckedMFE, mfeParentElemnt));
   }

   public void clickClearAllAirportMFE()
   {
      WebElementTools.clickElementJavaScript(
               SelenideHelper.getShadowRootElement(getMFEClearAll, mfeParentElemnt));
   }

   public boolean getMFEDefaultAirportValue()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(defaultAirportTextMFE,
                        mfeParentElemnt));
   }

   public boolean accomadationDisplayed()
   {
      return accomadation.isDisplayed();
   }

   public void clickOnLegacyMessageHyperLink()
   {
      WebElementTools.click(legacyMsgLink.get(0));
   }

   public String getMFEDestinationDefaultText()
   {
      return SelenideHelper.getShadowRootElement(".destinationWrapper input", mfeParentElemnt)
               .getAttribute("placeholder");
   }

   public String getMFEDestinationToolTipMessage()
   {
      return SelenideHelper.getShadowRootElement(mfeToolTip, mfeParentElemnt).getText();
   }

   public WebElement getMFEDestinationToolTipDisplayed()
   {
      return SelenideHelper.getShadowRootElement(mfeToolTip, mfeParentElemnt);
   }

   public List<SelenideElement> mfeDestinationCountryAvailableList()
   {
      String mfeDestinationCountryEnabledList =
               ".destinationWrapper .countryBlock div[data-area='country'].enabled span";
      wait.waitForElement(
               SelenideHelper.getShadowRootElements(mfeDestinationCountryEnabledList,
                        mfeParentElemnt));
      return SelenideHelper.getShadowRootElements(mfeDestinationCountryEnabledList,
               mfeParentElemnt);
   }

   public List<String> getSelectAvailableCountry()
   {
      wait.forJSExecutionReadyLazy();
      List<SelenideElement> availableCountries =
               new ArrayList<>(mfeDestinationCountryAvailableList());
      List<String> selectedCountries = new ArrayList<>();
      int numberOfCountriesToSelect = random.nextInt(2) + 2;
      for (int i = 0; i < numberOfCountriesToSelect; i++)
      {
         int randomIndex = random.nextInt(availableCountries.size());
         SelenideElement country = availableCountries.get(randomIndex);
         country.isEnabled();
         String countryText = country.getText();
         selectedCountries.add(countryText);
         country.click();
         availableCountries.remove(randomIndex);
      }
      return selectedCountries;
   }

   public boolean mfeDismissibleTagDropDownIsDisplay()
   {
      return SelenideHelper
               .getShadowRootElement(".destinationWrapper .dismissibleTagDropDown .contentBody",
                        mfeParentElemnt)
               .isDisplayed();
   }

   public List<String> getMFEDismissibleTagText()
   {
      List<String> selectedCountries = new ArrayList<>();
      List<SelenideElement> dismissibleDropDownText = SelenideHelper.getShadowRootElements(
               ".destinationWrapper .dismissibleTagDropDown .dismissibleTag span", mfeParentElemnt);
      for (SelenideElement element : dismissibleDropDownText)
      {
         selectedCountries.add(element.getText());
      }
      return selectedCountries;
   }

   public List<SelenideElement> getMFEDismissibleTagClose()
   {
      return SelenideHelper.getShadowRootElements(
               ".destinationWrapper .dismissibleTagDropDown .dismissibleTag div a",
               mfeParentElemnt);
   }

   public List<SelenideElement> getMFEDestinationAttribute()
   {
      String mfeDestinationCountryEnabledList =
               ".destinationWrapper .countryBlock div[data-area='country'].enabled input[type='checkbox']";
      return SelenideHelper.getShadowRootElements(mfeDestinationCountryEnabledList,
               mfeParentElemnt);
   }

   public SelenideElement getShadowRootElement()
   {
      String mfeClearSearch = ".clearSearchLink a";
      return SelenideHelper.getShadowRootElement(mfeClearSearch, mfeParentElemnt);
   }

   public String getClearSearchText()
   {
      wait.forAppear(getShadowRootElement());
      return getShadowRootElement().getText();
   }

   public void clickClearSearch()
   {
      wait.forAppear(getShadowRootElement());
      getShadowRootElement().click();
   }

   public String getDefaultAirportText()
   {
      return SelenideHelper
               .getShadowRootElement(".airportWrapper .readOnlyText", mfeParentElemnt)
               .getAttribute("placeholder");
   }

   public boolean mfeUnavailableAirportsIsGreyedout()
   {
      wait.forJSExecutionReadyLazy();
      searchPanel.airport().clearSelection();
      boolean flag = false;
      List<SelenideElement> greyedOut =
               SelenideHelper.getShadowRootElements(mfeAirportsGreyedout, mfeParentElemnt);
      for (SelenideElement checkbox : greyedOut)
      {
         flag = !checkbox.isEnabled();
      }
      return flag;
   }

   public boolean mfeUnavailableToSelectAirportsIsGreyedout()
   {
      wait.forJSExecutionReadyLazy();
      boolean flag = true;
      List<SelenideElement> greyedOut =
               SelenideHelper.getShadowRootElements(mfeAirportsGreyedout, mfeParentElemnt);

      for (SelenideElement checkbox : greyedOut)
      {
         checkbox.shouldBe(disabled);

         if (checkbox.isEnabled() || checkbox.isSelected())
         {
            flag = false;
            break;
         }
      }
      return flag;
   }

   public boolean isAllAirportsBoxcheckedMFE()
   {
      boolean flag = false;
      String allAirportsBoxCheckedMFE = ".airportListContainer input:checked";
      List<SelenideElement> defaultChecked =
               SelenideHelper.getShadowRootElements(allAirportsBoxCheckedMFE, mfeParentElemnt);
      for (int i = 1; i < defaultChecked.size(); i++)
      {
         flag = defaultChecked.get(i).isEnabled();
      }
      return flag;
   }

   public boolean canTickUntickSelections()
   {
      clickClearAllAirportMFE();
      wait.forJSExecutionReadyLazy();
      List<SelenideElement> defaultChecked =
               SelenideHelper.getShadowRootElements(allAirportsBoxEnabledMFE, mfeParentElemnt);
      for (SelenideElement checkbox : defaultChecked)
      {
         checkbox.shouldBe(enabled);
         WebElementTools.clickElementJavaScript(checkbox);
         checkbox.shouldBe(selected);
         WebElementTools.clickElementJavaScript(checkbox);
         checkbox.shouldNotBe(selected);
      }
      return true;
   }

   public List<String> getAllAvailableDepartureAirports()
   {
      List<SelenideElement> allAirportEnabled =
               SelenideHelper.getShadowRootElements(allAirportsBoxEnabledMFE, mfeParentElemnt);
      String mfeDepartureAirportsListNames = "div.group.enabled span.label-inline";
      List<SelenideElement> allAirportNamesPrint =
               SelenideHelper.getShadowRootElements(mfeDepartureAirportsListNames, mfeParentElemnt);
      List<String> availableDepartureAirports = new ArrayList<>();

      for (int i = 1; i < allAirportNamesPrint.size(); i++)
      {
         if (allAirportEnabled.get(i).isEnabled() && allAirportEnabled.get(i).isSelected())
         {
            String checkboxText = allAirportNamesPrint.get(i).getText();
            availableDepartureAirports.add(checkboxText);
         }
      }
      return availableDepartureAirports;
   }

   public String getMFEFirstAirportValuePlusRemaining()
   {
      List<String> availableDepartureAirports = getAllAvailableDepartureAirports();
      int totalAvailableAirports = availableDepartureAirports.size();
      if (totalAvailableAirports > 0)
      {
         String firstAirport = availableDepartureAirports.get(0);
         int remainingAirports = totalAvailableAirports - 1;
         return firstAirport + " + " + remainingAirports + " meer";
      }
      else
      {
         return "No available departure airports";
      }
   }

   public String getMFEDeparturesAirports()
   {
      WebElement inputElement =
               SelenideHelper.getShadowRootElement(mfeDepartureListField, mfeParentElemnt);
      String departureAirport = inputElement.getAttribute("placeholder");
      return departureAirport;
   }

   public void selectOneDepartureAirportMFE()
   {
      List<SelenideElement> selectOneAirport =
               SelenideHelper.getShadowRootElements(allAirportsBoxEnabledMFE, mfeParentElemnt);
      WebElementTools.clickElementJavaScript(selectOneAirport.get(2));
   }

   public String getMFEOneAirportSelected()
   {
      List<SelenideElement> allAirportNames =
               SelenideHelper.getShadowRootElements(mfeDepartureAirportsList, mfeParentElemnt);
      String OneAirport = allAirportNames.get(2).getText();
      return OneAirport;
   }

   public boolean selectedAirportTickedUntick()
   {
      clickClearAllAirportMFE();
      List<SelenideElement> allAirportNames =
               SelenideHelper.getShadowRootElements(allAirportsBoxEnabledMFE, mfeParentElemnt);
      SelenideElement checkbox = allAirportNames.get(2);
      checkbox.shouldBe(enabled);
      WebElementTools.clickElementJavaScript(checkbox);
      checkbox.shouldBe(selected);
      WebElementTools.clickElementJavaScript(checkbox);
      checkbox.shouldNotBe(selected);
      return true;
   }

   public void selectMultipleDepartureAirportsMFE()
   {
      wait.forJSExecutionReadyLazy();
      List<SelenideElement> selectMoreAirports =
               SelenideHelper.getShadowRootElements(allAirportsBoxEnabledMFE, mfeParentElemnt);
      for (int i = 1; i < selectMoreAirports.size(); i++)
      {
         {
            WebElementTools.clickElementJavaScript(selectMoreAirports.get(i));
         }
      }
   }

   public boolean UnSelectFirstAirport()
   {
      List<SelenideElement> unselectAirport =
               SelenideHelper.getShadowRootElements(allAirportsBoxEnabledMFE, mfeParentElemnt);
      SelenideElement checkbox = unselectAirport.get(1);
      checkbox.shouldBe(enabled);
      WebElementTools.clickElementJavaScript(checkbox);
      return true;
   }

   public String getMFESecondAirportSelected()
   {
      List<SelenideElement> allAirportNames =
               SelenideHelper.getShadowRootElements(mfeDepartureAirportsList, mfeParentElemnt);
      return allAirportNames.get(2).getText();
   }

   public WebElement getMFEDeparturesAirportField()
   {
      WebElement inputElement =
               SelenideHelper.getShadowRootElement(mfeDepartureListField, mfeParentElemnt);
      String departureAirport = inputElement.getAttribute("placeholder");
      assertNotNull(departureAirport);
      assertNotEquals("", departureAirport);
      return inputElement;
   }

   public boolean mfeDepartureAirportsFieldIsPresent()
   {

      return WebElementTools.isPresent(getMFEDeparturesAirportField());
   }

   public boolean getDestinationInSearchCard()
   {
      return hotelLoction.stream()
               .anyMatch(destination -> destination.getText()
                        .contains(getMFEDestinationDefaultText()));
   }

   public boolean accomadationNameDisplayed()
   {
      return $(accomadationName).should(appear, Duration.ofSeconds(5)).isDisplayed();
   }

   public String getDatesCrossOverMessageElementTextMFE()
   {
      return $(shadowDeepCss(".legacyText")).getText();
   }

   public String getDatesCrossOverLinkElementTextMFE()
   {
      return $(shadowDeepCss(".legacyLink")).getText();
   }

   public String getDatesCrossOverElementTextMFE()
   {
      return $(shadowDeepCss(".legacyRT3PA")).getText();
   }

   public boolean departureDateLegacyDisplayed()
   {
      selectLegacyDropdownMFE(0);
      return $(shadowDeepCss(".legacy")).isDisplayed();
   }

   public void clickDepartureDateLegacyHyperLink()
   {
      $(shadowDeepCss(".legacyLink")).click();
   }
}
