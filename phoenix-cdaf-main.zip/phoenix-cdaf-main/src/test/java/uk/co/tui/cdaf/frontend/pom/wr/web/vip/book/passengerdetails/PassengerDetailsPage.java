package uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.passengerdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;

public class PassengerDetailsPage extends AbstractPage
{

   private final HashMap<String, WebElement> vipPassengerPageComponentsMap;

   @FindBy(css = "[aria-label='promotional discount']")
   private WebElement discount;

   @FindBy(css = "[aria-label='Passenger form fields']")
   private WebElement passengerFormFields;

   @FindBy(css = "[aria-label='passenger details holiday summary']")
   private WebElement holidaySummary;

   @FindBy(css = "[aria-label='important information']")
   private WebElement importantInformation;

   @FindBy(css = "[#importantInformationV2__component > div > div.UI__important_info_wrap > div.UI__select_show_box]")
   private WebElement confirmCheckBox;

   @FindBy(css = "[#PassengerV2ContinueButton__component > div > div > div > div]")
   private WebElement continueButton;

   public PassengerDetailsPage()
   {
      WebElementWait wait = new WebElementWait();
      vipPassengerPageComponentsMap = new HashMap<>();
   }

   public HashMap<String, WebElement> getVipSummaryComponentsMap()
   {
      vipPassengerPageComponentsMap.put("DISCOUNT", discount);
      vipPassengerPageComponentsMap.put("YOUR INFORMATION", passengerFormFields);
      vipPassengerPageComponentsMap.put("HOLIDAY SUMMARY", holidaySummary);
      vipPassengerPageComponentsMap.put("IMPORTANT INFORMATION", importantInformation);
      vipPassengerPageComponentsMap.put("CONFIRMATION CHECK BOX", confirmCheckBox);
      vipPassengerPageComponentsMap.put("CONTINUE BUTTON", continueButton);
      return vipPassengerPageComponentsMap;
   }
}
