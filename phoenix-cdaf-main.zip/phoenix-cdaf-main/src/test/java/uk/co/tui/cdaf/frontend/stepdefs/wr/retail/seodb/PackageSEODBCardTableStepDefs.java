package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSEODBCardTableStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents;

   public PackageSEODBCardTableStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      foReconcilationPaymentPageComponents = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Banking & Reconciliation page is displaying Card payments")
   public void that_the_Banking_Reconciliation_page_is_displaying_Card_payments()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      assertThat("Card payment displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isCardPaymentTypeDisplayed(), is(true));
   }

   @Given("the Agent has Expanded the {string} accordion")
   public void the_Agent_has_Expanded_the_accordion(String string)
   {
      foReconcilationPaymentPageComponents.navigateToCardChevron();
   }

   @When("the card types are displayed")
   public void the_card_types_are_displayed()
   {
      wait.forJSExecutionReadyLazy();
      assertThat(" Card types are present",
               foReconcilationPaymentPageComponents.isCardTypesPresent(), is(true));
   }

   @When("the agent clicks on the accordion chevron")
   public void the_agent_clicks_on_the_accordion_chevron()
   {
      pKgReconcilationPaymentPageComponents.clickOnCardTypeChevron();
   }

   @Then("a table for that card type will be displayed including the information as following")
   public void a_table_for_that_card_type_will_be_displayed_including_the_information_as_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Date Header displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isDateTableHeaderPresent(), is(true));
      assertThat("Time Header displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isTimeTableHeaderPresent(), is(true));
      assertThat("Reference Header displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isReferenceTableHeaderPresent(), is(true));
      assertThat("Amount payment displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isAmountTableHeaderPresent(), is(true));
      assertThat("CardDigits payment displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isCardDigitsTableHeaderPresent(), is(true));
      assertThat("JumpTrips payment displayed on reconciliation page",
               pKgReconcilationPaymentPageComponents.isSystemTableHeaderPresent(), is(true));
      assertThat("Column data is displayed in card type table",
               pKgReconcilationPaymentPageComponents.isCardTypeColumnDataPresent(), is(true));
   }
}
