package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.confirmation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class BookingReferenceComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "span[class*='referenceID']")
   private WebElement bookingReferenceID;

   @FindBy(css = "div[class*='counters__timePiece']")
   private WebElement bookingCountDownID;

   @FindBy(css = ".HeroBanner__text")
   private WebElement bookingDestinationTextID;

   public BookingReferenceComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getBookingRefElement()
   {
      return wait.getWebElementWithLazyWait(bookingReferenceID);
   }

   public boolean isBookReferenceIdDisplayed()
   {
      return WebElementTools.isPresent(getBookingRefElement());
   }

   public String getBookingRefId()
   {
      return WebElementTools.getElementText(getBookingRefElement());
   }

   public boolean isBookingNumberDisplayed()
   {
      return WebElementTools.isPresent(bookingReferenceID);
   }

   public String getBookingNumber()
   {
      return WebElementTools.getElementText(bookingReferenceID);
   }

   public boolean isBookcountdownDisplayed()
   {
      return WebElementTools.isPresent(bookingCountDownID);
   }

   public boolean isBookDestinationTextDisplayed()
   {
      return WebElementTools.isPresent(bookingDestinationTextID);
   }

}
