package uk.co.tui.cdaf.api.requests.search.capabilities;

import lombok.SneakyThrows;
import org.jetbrains.annotations.Nullable;
import uk.co.tui.cdaf.api.pojo.search.legacy.CalendarResponse;
import uk.co.tui.cdaf.api.pojo.search.legacy.calendar.CheckIn;
import uk.co.tui.cdaf.api.pojo.search.mfe.DateData;
import uk.co.tui.cdaf.api.requests.search.parameters.SearchParameters;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class CalendarApi extends BaseApi
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(CalendarApi.class);

   private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

   public String getWhenDateTime(@javax.annotation.Nullable TestDataAttributes tda,
            SearchParameters searchParameters)
   {
      List<String> availableDates = getAvailableDates(searchParameters);

      if (tda == null)
         return availableDates.get(0);

      String when = getWhenParam(tda);
      if (availableDates.contains(when))
      {
         LOGGER.log(LogLevel.INFO, "Using predefined date: " + when);
         return when;
      }

      String localDate = getCalculatedDateFromNow(tda, availableDates);
      if (localDate != null)
         return localDate;

      LOGGER.log(LogLevel.WARN,
               "No predefined dates were found/available, using first available date");
      return availableDates.get(0);
   }

   @SneakyThrows
   public List<String> getAvailableDates(SearchParameters searchParameters)
   {
      String responseBody;
      if (ExecParams.isSitEnv())
      {
         responseBody = getCapabilitiesResponse(searchParameters, "check-ins").getBody().asString();
         return objectMapper.readValue(responseBody, CalendarResponse.class).getData()
                  .getCheckIns().stream().map(CheckIn::getDate).collect(Collectors.toList());
      }
      else
      {
         responseBody = getCapabilitiesResponse(searchParameters, "calendar").getBody().asString();
         return objectMapper.readValue(responseBody, DateData.class).getAvailableDates();
      }
   }

   @Nullable
   private String getCalculatedDateFromNow(TestDataAttributes tda,
            List<String> availableDates)
   {
      LocalDate finalCurrentDate = getLocalDate(tda);
      if (finalCurrentDate == null)
         return null;

      List<LocalDate> dateList = availableDates.stream()
               .map(dateStr -> LocalDate.parse(dateStr, formatter))
               .sorted()
               .collect(Collectors.toList());

      LocalDate localDate = dateList.stream()
               .filter(date -> date.isEqual(finalCurrentDate) || date.isAfter(finalCurrentDate))
               .findFirst()
               .orElse(null);

      if (localDate == null)
         return null;
      LOGGER.log(LogLevel.INFO,
               "Using first available date (" + localDate + ") after current date: " + finalCurrentDate);
      return localDate.format(formatter);
   }

   private String getWhenParam(TestDataAttributes tda)
   {
      if (tda == null)
         return null;

      LocalDate localDate = getLocalDate(tda);
      return getWhen(tda, localDate);
   }

   @Nullable
   private LocalDate getLocalDate(TestDataAttributes tda)
   {
      String numberOfDays = tda.getNumberOfDays();
      String numberOfMonths = tda.getNumberOfMonths();

      if (numberOfDays == null && numberOfMonths == null)
         return null;

      LocalDate currentDate = LocalDate.now();

      if (numberOfDays != null)
      {
         try
         {
            currentDate = currentDate.plusDays(Integer.parseInt(numberOfDays));
         }
         catch (NumberFormatException e)
         {
            LOGGER.log(LogLevel.ERROR, "Invalid number of days would be ignored: " + numberOfDays);
         }
      }
      if (numberOfMonths != null)
      {
         try
         {
            currentDate = currentDate.plusMonths(Integer.parseInt(numberOfMonths));
         }
         catch (NumberFormatException e)
         {
            LOGGER.log(LogLevel.ERROR,
                     "Invalid number of months would be ignored: " + numberOfMonths);
         }
      }

      LOGGER.log(LogLevel.INFO,
               "No `when` or `departureDay` were provided or available, trying to use days/months from current date");

      return currentDate;
   }

   private String getWhen(TestDataAttributes tda, LocalDate localDate)
   {
      if (tda.getWhen() != null)
      {
         return tda.getWhen();
      }
      else if (tda.getDepDate() != null)
      {
         return tda.getDepDate();
      }
      else if (tda.getDepartureDay() != null)
      {
         return tda.getDepartureDay();
      }
      else if (localDate != null)
      {
         return localDate.format(formatter);
      }
      else
      {
         return null;
      }
   }
}
