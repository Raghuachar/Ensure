package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.SearchResultsSingleAccomComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSingleAccomBoardBasisStepDefs extends AbstractPage
{

   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   private final SearchResultsSingleAccomComponent searchResultsSingleAccomComponent;

   public PackageSingleAccomBoardBasisStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      searchResultsSingleAccomComponent = new SearchResultsSingleAccomComponent();
   }

   @Then("they can see a Board Basis dropdown")
   public void they_can_see_a_Board_Basis_dropdown()
   {
      assertThat("board basis dropdown is not displayed",
               searchResultsPage.singleAccommodationComponent.isBoardBasisDisplayed(), is(true));
   }

   @Given("the backend has returned only one board option which is the the base package")
   public void the_backend_has_returned_only_one_board_option_which_is_the_the_base_package()
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
   }

   @When("they select {string} dropdown")
   public void they_select_dropdown(String string)
   {
      searchResultsPage.singleAccommodationComponent.selectBoardBasisDropdown();
   }

   @Then("they can only see one option")
   public void they_can_only_see_one_option()
   {
      assertThat("board basis dropdown is not displayed",
               searchResultsPage.singleAccommodationComponent.isBoardBasisDisplayed(), is(true));
   }

   @Then("it is in selected state")
   public void it_is_in_selected_state()
   {
      searchResultsPage.singleAccommodationComponent.selectBoardBasisDropdown();
   }

   @Given("the backend has returned more than one board option")
   public void the_backend_has_returned_more_than_one_board_option()
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
   }

   @Then("they can see that default selection is {string}")
   public void they_can_see_that_default_selection_is(String any)
   {
      assertThat("default selection Any is not displayed",
               searchResultsPage.singleAccommodationComponent.isDefaultSelectionAnyDisplayed(),
               is(true));
   }

   @Then("other board types are available to select")
   public void other_board_types_are_available_to_select()
   {
      searchResultsPage.singleAccommodationComponent.selectBoardBasisDropdown();
   }

   @Then("the price in each calendar cell represents the base package board basis price")
   public void the_price_in_each_calendar_cell_represents_the_base_package_board_basis_price()
   {
      assertThat("Customer seeing the calender",
               searchResultsSingleAccomComponent.singleAccomCalendar(), is(true));
   }

   @Given("they have opened the board basis dropdown")
   public void they_have_opened_the_board_basis_dropdown()
   {
      searchResultsPage.singleAccommodationComponent.selectBoardBasisDropdown();
   }

   @When("they select a board type")
   public void they_select_a_board_type()
   {
      searchResultsPage.singleAccommodationComponent.selectBoardBasis();
   }

   @Then("the selected board type is retained in the dropdown")
   public void the_selected_board_type_is_retained_in_the_dropdown()
   {
      searchResultsPage.singleAccommodationComponent.selectBoardBasisValue();
   }

   @Then("the price in the calendar updates to the selected board basis cost")
   public void the_price_in_the_calendar_updates_to_the_selected_board_basis_cost()
   {
      assertThat("Customer seeing the calender",
               searchResultsSingleAccomComponent.singleAccomCalendar(), is(true));
   }

}
