package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class HolidaySummaryComponent extends AbstractPage
{
   public final WebElementWait wait;

   public HolidaySummaryComponent()
   {
      wait = new WebElementWait();
   }

   public List<String> getElementsTexts(ElementsCollection collection)
   {
      List<String> list = new ArrayList<>();
      for (SelenideElement element : collection)
      {
         list.add(element.shouldBe(Condition.visible).getText());
      }
      return list;
   }

   private ElementsCollection getInsuranceProductTitle()
   {
      return $$(".PriceSummaryPanel__extraOption .PriceSummaryPanel__extraSummaryCategory");
   }

   public List<String> getInsuranceProductTitlesTexts()
   {
      return getElementsTexts(getInsuranceProductTitle());
   }

   private ElementsCollection getInsuranceProductTaxesFees()
   {
      return $$(".PriceSummaryPanel__extraOption + .PriceSummaryPanel__subtitle");
   }

   public List<String> getInsuranceProductTaxesFeesTexts()
   {
      return getElementsTexts(getInsuranceProductTaxesFees());
   }

   public Double getInsurancePriceDouble()
   {
      double doubleInsurancePrice = 0.0;
      ElementsCollection insurancePrice =
               $$(By.xpath("//div[@class='PriceSummaryPanel__subtitle']" +
                        "/preceding-sibling::div[@class='PriceSummaryPanel__extraOption']" +
                        "/span[@class='PriceSummaryPanel__extraSummaryPrice']"));
      for (SelenideElement element : insurancePrice)
      {
         doubleInsurancePrice += Double.parseDouble(element.getText().split("€")[1].trim());
      }
      return doubleInsurancePrice;
   }

   public boolean isReservationFeeDisplayed()
   {
      SelenideElement reservationFee = $(".PriceSummaryPanel__innerElement .PriceSummaryPanel__subtitle");
      return reservationFee.isDisplayed()
               && WebElementTools.isTextNotContainsUA(reservationFee.getText());
   }
}
