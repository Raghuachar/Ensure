package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;
import java.util.stream.IntStream;

public class PaymentOptionsComponent extends AbstractPage
{
   public final WebDriverUtils utils;

   private final WebElementWait wait;

   @FindBy(css = "[aria-label='payment details']")
   private WebElement paymentOptionsPanel;

   @FindBy(css = ".DiffPaymentType__title")
   private WebElement paymentOptionsTitle;

   @FindAll({ @FindBy(css = "[aria-label='select payment type'] [class*='circle']"),
            @FindBy(css = "[aria-label='payment details'] [class*='circle']") })
   private List<WebElement> paymentOptions;

   @FindBy(css = "[aria-label='payment details'] span[class*='inputs__text']")
   private List<WebElement> paymentOptionNames;

   @FindBy(css = "[aria-label='payment details'] button")
   private WebElement paymentMethodPayButton;

   public PaymentOptionsComponent()
   {
      wait = new WebElementWait();
      utils = new WebDriverUtils();
   }

   public boolean isPaymentMethodsTitleDisplayed()
   {
      return WebElementTools.isPresent(paymentOptionsTitle);
   }

   public int getPaymentOptionsLength()
   {
      return paymentOptions.size();
   }

   public boolean validatePaymentMethodsList()
   {
      return getPaymentOptionsLength() > 0;
   }

   public void clickPaymentMethod()
   {
      wait.forJSExecutionReadyLazy();
      String currentUrl = utils.getCurrentURL();
      if (currentUrl.contains(".nl"))
      {
         paymentMethodForNL();
      }
      else
      {
         int index = IntStream.range(0, paymentOptionNames.size())
                  .filter(p -> StringUtils.containsIgnoreCase(
                           WebElementTools.getElementText(paymentOptionNames.get(p)), "MasterCard"))
                  .findFirst().getAsInt();
         WebElement selectElement = paymentOptions.get(index);
         WebElementTools.scrollTo(selectElement);
         WebElementTools.clickElementJavaScript(selectElement);
      }
   }

   public WebElement getPaymentMethodPanel()
   {
      return paymentOptionsPanel;
   }

   public WebElement getContinueElement()
   {
      return wait.getWebElementWithLazyWait(paymentMethodPayButton);
   }

   public void clickOnPayButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.javaScriptScrollToElement(getContinueElement());
      WebElementTools.clickElementJavaScript(getContinueElement());
      wait.forJSExecutionReadyLazy();
   }

   public void paymentMethodForNL()
   {
      wait.forJSExecutionReadyLazy();
      int index = IntStream.range(0, paymentOptionNames.size())
               .filter(p -> StringUtils
                        .containsIgnoreCase(
                                 WebElementTools.getElementText(paymentOptionNames.get(p)),
                                 "iDeal"))
               .findFirst().getAsInt();
      WebElement selectElement = paymentOptions.get(index);
      WebElementTools.scrollTo(selectElement);
      WebElementTools.clickElementJavaScript(selectElement);
   }
}
