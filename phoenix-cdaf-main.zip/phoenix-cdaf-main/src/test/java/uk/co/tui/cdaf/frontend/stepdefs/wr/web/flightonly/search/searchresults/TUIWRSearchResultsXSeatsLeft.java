package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults.SearchResults;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TUIWRSearchResultsXSeatsLeft
{
   private final SearchResults searchresults;

   private Boolean availableSeatsThreshold;

   public TUIWRSearchResultsXSeatsLeft()
   {
      searchresults = new SearchResults();
      availableSeatsThreshold = false;
   }

   @Given("a flight is available where there are {int} or less seats remaining")
   public void a_flight_is_available_where_there_are_or_less_seats_remaining()
   {
      availableSeatsThreshold = searchresults.getLimitedAvailableSeatsThreshold();
   }

   @When("they view that search results card")
   public void they_view_that_search_results_card()
   {
      if (searchresults.isOutboundSearchResultsPresent() && searchresults.isReturnSearchResultsPresent())
      {
         assertThat("Outbound results are visible", searchresults.isOutboundSearchResultsPresent(),
                  is(true));
         assertThat("Return results are visible", searchresults.isReturnSearchResultsPresent(),
                  is(true));
      }
      else
      {
         availableSeatsThreshold = false;
      }
   }

   @Then("a {string} label will display")
   public void a_label_will_display()
   {
      assertThat("Label X seats left will display",
               searchresults.isVisibleSeatsAvailable(availableSeatsThreshold), is(true));
   }
}
