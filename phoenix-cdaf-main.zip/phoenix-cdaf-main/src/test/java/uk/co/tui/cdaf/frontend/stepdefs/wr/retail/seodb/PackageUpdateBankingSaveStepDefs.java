package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageUpdateBankingSaveStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageUpdateBankingSaveStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @When("they try to press the SAVE CTA without data")
   public void they_try_to_press_the_CTA_without_data()
   {
      pKgReconcilationPaymentPageComponents.clickUpdateBankingSave();
      pKgReconcilationPaymentPageComponents.enterBlankUpdateBankingAmount();
      pKgReconcilationPaymentPageComponents.enterBlankSealBagNumber();
      assertThat("Add banking amount error is present",
               pKgReconcilationPaymentPageComponents.isAddBankingAmountValidationError(), is(true));
      assertThat("Seal bag number error is present",
               pKgReconcilationPaymentPageComponents.isAddSealBagValidationError(), is(true));
   }

   @And("they click the {string} link")
   public void they_click_the_link(String string)
   {
      pKgReconcilationPaymentPageComponents.enterUpdateBankingAmount();
      pKgReconcilationPaymentPageComponents.enterUpdateBankingSlipNumber();
      pKgReconcilationPaymentPageComponents.clickUpdateBankingSave();
   }

   @Then("the cash payment type will be added to the modal")
   public void the_cash_payment_type_will_be_added_to_the_modal()
   {
      pKgReconcilationPaymentPageComponents.closeUpdateBankingModal();
   }

   @And("reconciliation table as a new payment type accordian or added to an existing one")
   public void reconciliation_table_as_a_new_payment_type_accordian_or_added_to_an_existing_one()
   {
      retailpassengerdetailspage.userLogout();
      retailpassengerdetailspage.userLogout();
   }
}
