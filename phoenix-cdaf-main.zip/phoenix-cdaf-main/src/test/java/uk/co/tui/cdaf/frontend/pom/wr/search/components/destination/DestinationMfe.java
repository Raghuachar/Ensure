package uk.co.tui.cdaf.frontend.pom.wr.search.components.destination;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

import java.time.Duration;
import java.util.List;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static org.junit.Assert.fail;

public class DestinationMfe implements Destination
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(DestinationMfe.class);

   private static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   private SelenideElement dropdown;

   private SelenideElement container()
   {
      if (dropdown == null)
      {
         dropdown = $(shadowDeepCss("div.dropModalContent"));
      }
      dropdown.should(appear, WAIT_TIMEOUT);
      return dropdown;
   }

   public DestinationMfe selectDestinationFromList(String regionName, String resortName)
   {
      container().$(byText(regionName))
               .should(Condition.visible, WAIT_TIMEOUT);
      if (resortName == null || resortName.isEmpty())
      {
         _selectFullRegion(regionName);
      }
      else
      {
         _selectResort(regionName, resortName);
      }
      return this;
   }

   @Override
   public boolean isOpen()
   {
      return container().isDisplayed();
   }

   public DestinationMfe clearSelection()
   {
      container().$("a.clear").click();
      return this;
   }

   public void confirmSelection()
   {
      container().$("button.primary").click();
   }

   private void _selectFullRegion(String regionName)
   {
      container().$(".bodyContainer").$(byText(regionName)).click();
   }

   private void _selectResort(String regionName, String resortName)
   {
      ElementsCollection allRegionsWithResorts = container().$$("div.hasChildren");
      ElementsCollection elements = allRegionsWithResorts.filterBy(Condition.text(regionName));
      if (!elements.isEmpty())
      {
         SelenideElement first = elements.first();
         first.$("a.moreIcon").click();
         container().$(byText(resortName))
                  .should(Condition.visible, WAIT_TIMEOUT);
         first.$(byText(resortName)).click();
      }
      else
      {
         for (SelenideElement region : allRegionsWithResorts)
         {
            LOGGER.log(region.getText());
         }
         fail("Impossible to find " + regionName + " from the " + allRegionsWithResorts.size() + " number of countries with resorts");
      }
   }

   public ElementsCollection getAllCountryDestinations()
   {
      container().$("div.countryBlock")
               .should(Condition.visible, WAIT_TIMEOUT);
      return container().$$("div.enabled[data-area='country']");
   }

   public Destination selectAllResort(String regionName, List<String> resortNames)
   {
      ElementsCollection allRegionsWithResorts = container().$$("div.hasChildren");
      ElementsCollection elements = allRegionsWithResorts.filterBy(Condition.text(regionName));
      if (!elements.isEmpty())
      {
         SelenideElement first = elements.first();
         first.$("a.moreIcon").click();
         for (String resortName : resortNames)
         {
            container().$(byText(resortName))
                     .should(Condition.visible, WAIT_TIMEOUT);
            container().$(byText(resortName)).click();
         }
      }
      return this;
   }

   public Destination selectRandomDestination()
   {
      ElementsCollection allCountryDestinations = getAllCountryDestinations();
      allCountryDestinations.get((int) (Math.random() * allCountryDestinations.size())).click();
      return this;
   }

   public SelenideElement getCheckBoxSelected()
   {
      return container().$("input:checked +[role=checkbox]")
               .should(Condition.visible, WAIT_TIMEOUT);
   }

   public ElementsCollection dismissibleTagsDestinations()
   {
      container().$(".dismissibleTag")
               .should(Condition.visible, WAIT_TIMEOUT);
      return container().$$(".dismissibleTag span");
   }
}
