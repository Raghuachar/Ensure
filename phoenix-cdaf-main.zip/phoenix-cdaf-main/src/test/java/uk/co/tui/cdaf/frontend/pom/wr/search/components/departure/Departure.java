package uk.co.tui.cdaf.frontend.pom.wr.search.components.departure;

import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import java.time.LocalDateTime;

public interface Departure
{
   boolean isOpen();

   Departure selectDate(String day, String month);

   Departure selectFirstAvailableDate();

   Departure clearSelection();

   Departure selectRandomMonth();

   Departure selectRandomDate();

   Departure selectDate(TestDataAttributes parameter);

   Departure selectDate(LocalDateTime expectedDate);

   void selectMonth(String month);

   void confirmSelection();

   SelenideElement getMonthSelector();

   SelenideElement getCalendarSelector();

   SelenideElement getFlexDateSelector();

   boolean isDateAvailable(LocalDateTime expectedDate);

   SelenideElement getSpecificDateElement(LocalDateTime expectedDate);
}
