package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.book.flightoptions;

import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import static com.codeborne.selenide.Selenide.$;

/**
 * SeatsDesignUpdatesPage
 */
public class FlightOptionsSeatsUpdatesComponent extends AbstractPage
{
   public boolean flightSeatAncillaryIsDisplayed()
   {
      return $("#FligtsSeatsAncillary_component").isDisplayed();
   }

   public boolean flightSeatAncillaryTypeIsDisplayed()
   {
      return $("#FligtsSeatsTypeAncillary_component").isDisplayed();
   }

}
