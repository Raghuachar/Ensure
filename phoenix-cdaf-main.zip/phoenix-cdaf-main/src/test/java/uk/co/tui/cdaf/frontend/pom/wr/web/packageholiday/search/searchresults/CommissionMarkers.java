package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.Condition;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class CommissionMarkers extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(CommissionMarkers.class);

   private final Map<String, WebElement> searchCardMap;

   @FindAll({ @FindBy(css = "[class='CommissionMarker__commissionMarkerListWraper'] span"),
            @FindBy(css = "[aria-label='commissionMarker filter'] span") })
   public WebElement commissionMarkerFilter;

   public WebElementWait wait;

   @FindBy(css = "[class='ResultListItemV2__commissionMarkers'] strong")
   private List<WebElement> commissionMarkersBand;

   @FindBy(css = "[class='ResultListItemV2__commissionMarkers']")
   private List<WebElement> commissionMarkersDescription;

   @FindAll({ @FindBy(css = "[class='FilterPanelV2__filterPanelContent']>div >div >span"),
            @FindBy(css = "[class='FilterPanelV2__mobile']>div >ul >li span") })
   private List<WebElement> commissionMarkerTitle;

   @FindBy(css = "[class*='CommissionMarker__commissionMarkerItem CommissionMarker__notChecked'] span")
   private List<WebElement> checkBoxCommission;

   @FindBy(css = "[class*='CommissionMarker__commissionMarkerItem CommissionMarker__notChecked'] div label")
   private List<WebElement> checkBoxCommissionSelection;

   @FindBy(css = "[class='FilterPanelV2__filterPanelContent'] [class*='CommissionMarker__commissionMarkerItem CommissionMarker__checked'] div label")
   private WebElement checkedCheckBoxCommissionSelection;

   @FindBy(css = "span[class='CommissionMarker__boardType']")
   private List<WebElement> commissionMarkerType;

   @FindBy(css = "span[class='CommissionMarker__count']")
   private List<WebElement> commissionMarkerCount;

   @FindBy(css = ".CommissionMarker__showMore a")
   private WebElement showMoreLink;

   @FindBy(css = "[class='LanguageCountrySelector__centered']")
   private List<WebElement> languageCountrySelector;

   @FindBy(css = "[class*='SelectDropdown__selectbox']")
   private List<WebElement> selectDropDown;

   @FindBy(css = "[class*='SelectDropdown__menuOpen'] ul li")
   private List<WebElement> selectDropDownOptions;

   @FindBy(css = "[class*='Modal__modalFooter Modal__center'] button")
   private WebElement changeSiteButton;

   @FindBy(css = "[class='FilterPanelV2__filterPanelContent'] span a")
   private WebElement markerClearLink;

   @FindBy(css = "[class='FilterPanelV2__holidayCounts'] span")
   private WebElement hoildayCount;

   @FindBy(css = "div[class='FilterPanelV2__mobile'] [aria-label='commissionMarker filter']")
   private WebElement mobileFilterCM;

   @FindBy(css = "[class='DropModal__filterModalWindow'] [class='FilterPanelV2__filterHeader']")
   private WebElement commissionMarkerTitleMobile;

   @FindBy(css = "[class='DropModal__filterModalWindow'] [class='DropModal__close']")
   private WebElement commissionMarkerCloseMobile;

   @FindBy(css = ".DropModal__dropModalContent:nth-child(1) .DropModal__footerContainer a")
   private List<WebElement> clearButtonCommissionMarker;

   @FindBy(css = ".DropModal__dropModalContent:nth-child(1) .DropModal__footerContainer button[role='button']")
   private List<WebElement> applyButtonCommissionMarker;

   public CommissionMarkers()
   {
      wait = new WebElementWait();
      searchCardMap = new HashMap<>();
   }

   public boolean verifyCommissionMarkersBand(io.cucumber.datatable.DataTable dataTable)
   {
      boolean value = true;
      for (String name : dataTable.asList())
      {
         for (WebElement commisionBand : commissionMarkersBand)
         {
            if (WebElementTools.getElementText(commisionBand).equalsIgnoreCase(name))
               value = true;
         }
      }
      return true;
   }

   public List<String> getCommissionMarkers()
   {
      List<String> markers = new ArrayList<>();
      for (WebElement commissionMarkers : commissionMarkersDescription)
      {
         markers.add(commissionMarkers.getText());
      }
      return markers;
   }

   public boolean verifyCommissionMarkers()
   {
      boolean value = false;
      for (WebElement markersDescription : commissionMarkersDescription)
      {
         if (markersDescription.isDisplayed())
            value = true;
      }
      return value;
   }

   public boolean isCommissionMarkerFilterIsDisplayed()
   {
      return commissionMarkerFilter.isDisplayed();
   }

   public String getCommissionMarkerFilterTitle()
   {
      return $(commissionMarkerFilter).should(Condition.appear).getText();
   }

   public String getFirstTitle()
   {
      return WebElementTools.getElementText(commissionMarkerTitle.get(0));
   }

   public Map<String, WebElement> getCommissionMarkerFilterComponents()
   {
      return new HashMap<>()
      {
         {
            put("Tick box (default of unticked)", checkBoxCommission.get(0));
            put("Commission marker code", commissionMarkerType.get(0));
            put("Commission marker description", commissionMarkerType.get(0));
            put("The number of accommodations that have been returned with that commission marker",
                     commissionMarkerCount.get(0));
         }
      };
   }

   public List<String> getCommissionMarkerCodeInAlpha()
   {
      return WebElementTools.getElemsTexts(commissionMarkerType);
   }

   public String getShowMoreLinkText()
   {
      return WebElementTools.getElementText(showMoreLink);
   }

   public int getMoreThanThreeCommission()
   {
      return commissionMarkerType.size();
   }

   public void clickOnShowMoreLink()
   {
      WebElementTools.click(showMoreLink);
   }

   public void clickOnLanguageCountrySelector()
   {
      WebElementTools.click(languageCountrySelector.get(0));
   }

   public void selectLanguageSelector()
   {
      WebElementTools.clickElementJavaScript(selectDropDown.get(1));
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(selectDropDownOptions.get(0));
      WebElementTools.clickElementJavaScript(changeSiteButton);
   }

   public String selectCheckBox()
   {
      String commissionMarkerDescription;
      if (!checkBoxCommissionSelection.isEmpty())
      {
         commissionMarkerDescription =
                  WebElementTools.getElementText(checkBoxCommissionSelection.get(1));
         WebElementTools.clickElementJavaScript(checkBoxCommissionSelection.get(1));
         wait.forShown(commissionMarkersBand.get(1), WebElementWait.DEFAULT_TIMEOUT);
      }
      else
      {
         commissionMarkerDescription =
                  WebElementTools.getElementText(checkBoxCommissionSelection.get(0));
         WebElementTools.javaScriptScrollToElement(checkBoxCommissionSelection.get(0));
         wait.forShown(commissionMarkersBand.get(0), WebElementWait.DEFAULT_TIMEOUT);
         LOGGER.log(LogLevel.INFO, "abc");
      }
      return commissionMarkerDescription;
   }

   public List<WebElement> commissionMarkerType()
   {
      return commissionMarkersBand;
   }

   public boolean isCommissionMarkerClearLinkIsDisplayed()
   {
      wait.forShown(markerClearLink, WebElementWait.DEFAULT_TIMEOUT);
      return markerClearLink.isDisplayed();
   }

   public String getClearLinkText()
   {
      return WebElementTools.getElementText(markerClearLink);
   }

   public void clikOnClearLink()
   {
      wait.forShown(markerClearLink, WebElementWait.DEFAULT_TIMEOUT);
      WebElementTools.clickElementJavaScript(markerClearLink);
   }

   public int deSelectedCount()
   {
      return checkBoxCommissionSelection.size();
   }

   public String hoildayCount()
   {
      wait.forShown(hoildayCount, WebElementWait.DEFAULT_TIMEOUT);
      return hoildayCount.getText();
   }

   public void checkedCheckbox()
   {
      wait.forShown(checkedCheckBoxCommissionSelection, WebElementWait.DEFAULT_TIMEOUT);
      WebElementTools.mouseOverAndClick(checkedCheckBoxCommissionSelection);
      wait.forShown(hoildayCount, WebElementWait.DEFAULT_TIMEOUT);
   }

   public Map<String, WebElement> getCommissionMarkerComponents()
   {
      searchCardMap.put("A 'Filter by Commission' title", commissionMarkerTitleMobile);
      searchCardMap.put("A X Close window option", commissionMarkerCloseMobile);
      searchCardMap.put(
               "A list of all different accommodation markers returned for the search criteria",
               checkBoxCommissionSelection.get(0));
      searchCardMap.put("A 'CLEAR' text link", clearButtonCommissionMarker.get(4));
      searchCardMap.put("An 'APPLY' button", applyButtonCommissionMarker.get(4));
      searchCardMap.put("Tick box (unticked by default)", checkBoxCommission.get(0));
      searchCardMap.put("Commission marker code", commissionMarkersBand.get(0));
      searchCardMap.put("Commission marker description", commissionMarkersDescription.get(0));
      searchCardMap.put(
               "The number of accommodations that have been returned with that commission marker",
               commissionMarkerCount.get(0));
      return searchCardMap;
   }

   public void clickOnMobileCommissionMarker()
   {
      WebElementTools.clickElementJavaScript(mobileFilterCM);
   }

   public void clickClearLink()
   {
      WebElementTools.clickElementJavaScript(clearButtonCommissionMarker.get(4));
   }

   public Object analyticsDetails(String analytics)
   {
      return ((JavascriptExecutor) WebDriverUtils.getDriver())
               .executeScript("return " + analytics);
   }
}
