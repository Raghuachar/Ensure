package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.paymentTransfers;

import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PaymentTransferComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class PaymentTransfersStepDefs
{
   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final RetailPassengerDetailsPage retailPassengerDetailsPage;

   private final PaymentTransferComponents paymentTransferComponents;

   public PaymentTransfersStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      retailPassengerDetailsPage = new RetailPassengerDetailsPage();
      paymentTransferComponents = new PaymentTransferComponents();
   }

   @Given("agent navigates to payment options page of the active booking")
   public void agent_navigates_to_payment_options_page_of_the_active_booking()
   {
      retailflightNavigation.retailLoginFO();
      retailflightNavigation.createOnewayBooking();
      retailPassengerDetailsPage.fillRetailPassengerDetails();
      paymentTransferComponents.waitForPaymentsOptionsPageLoad();
      String currentUrl = WebDriverRunner.getWebDriver().getCurrentUrl();
      assertThat(currentUrl, containsString("paymentoptions"));
   }

   @When("agent use Add Payment")
   public void agent_use_Add_Payment()
   {
      paymentTransferComponents.selectTransferPaymentTab();

      assertTrue("Transfer Booking Reference Input is not present",
               paymentTransferComponents.isTransferBookingReferenceInputVisible());
      assertFalse("Booking Reference List is present",
               paymentTransferComponents.isBookingReferenceListPresent());
      assertFalse("Transfer Amount Input is present",
               paymentTransferComponents.isTransferAmountInputPresent());
      assertTrue("Transfer Payment Tab is not active",
               paymentTransferComponents.isTransferPaymentTabSelected());
      paymentTransferComponents.enterTransferBookingReferenceNumber();

      paymentTransferComponents.clickValidateBookingReferenceButton();

      // data list here
      paymentTransferComponents.checkThatBookingReferenceListPresent();

      assertTrue("Transfer Amount Input is present",
               paymentTransferComponents.isTransferAmountInputPresent());
      paymentTransferComponents.enterTransferAmount();

      assertFalse("Price Breakdown PaymentAmount is present",
               paymentTransferComponents.isPriceBreakdownPaymentAmountPresent());

      paymentTransferComponents.clickAddPaymentButton();
      paymentTransferComponents.waitForAddPaymentButtonLoadingIsDone();

      assertTrue("Price Breakdown Payment Amount is not present",
               paymentTransferComponents.isPriceBreakdownPaymentAmountPresent());
   }

   @Then("the transferred amount will be displayed in the payments made today")
   public void the_transferred_amount_will_be_displayed_in_the_payments_made_today()
   {
      assertThat("Price Breakdown Payment Amount has incorrect amount",
               paymentTransferComponents.getPriceBreakdownPaymentAmount(),
               is("€" + paymentTransferComponents.getAmountToTransfer() + ".00"));

      retailPassengerDetailsPage.userLogout();
   }
}
