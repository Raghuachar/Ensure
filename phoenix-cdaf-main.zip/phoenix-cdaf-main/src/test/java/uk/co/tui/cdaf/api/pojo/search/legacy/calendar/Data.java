package uk.co.tui.cdaf.api.pojo.search.legacy.calendar;

import java.util.List;

@lombok.Data
public class Data
{
   private List<CheckIn> checkIns;
}
