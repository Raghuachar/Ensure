package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class PackageChoiceSearchDurationStepDefs
{

   public final PackageNavigation packageNavigation;

   public final WebElementWait wait;

   private SearchPanelComponent searchPanelComponent;

   public PackageChoiceSearchDurationStepDefs()
   {
      packageNavigation = new PackageNavigation();
      wait = new WebElementWait();
      searchPanelComponent = new SearchPanelComponent();
   }

   @Given("the customer is on the WR Package search panel")
   public void the_customer_is_on_the_WR_Package_search_panel()
   {
      searchPanelComponent.isSearchPanelContainerPresent();
   }

   @Given("the customer has selected duration in the search panel")
   public void the_customer_has_selected_duration_in_the_search_panel()
   {
      TestDataAttributes parameter = new SearchDataHelper().getSearchParameters();
      getSearchPanel().selectDuration(parameter.getDuration());
   }

   @Given("the customer has completed the fields on the package search panel")
   public void the_customer_has_completed_the_fields_on_the_package_search_panel()
   {
      getSearchPanel().searchWithParameters();
   }

   @When("they want to complete their search")
   public void they_want_to_complete_their_search()
   {
      getSearchPanel().doSearch();
   }

   @Then("search button is clicked")
   public void they_can_do_this_by_selecting_SEARCH()
   {
      getSearchPanel().doSearch();
   }

   @Given("the customer or agent is on the WR package Homepage")
   public void the_is_on_the_WR_package_Homepage()
   {
      packageNavigation.navigateToHoldaySearchPage();
   }

   @When("they can view the search panel")
   public void they_can_view_the_search_panel()
   {
      assertTrue("Search Panel is not present", getSearchPanel().isSearchPanelDisplayed());
   }

   @Given("the customer and agent is on the WR package multiple rooms")
   public void the_is_on_the_WR_package_Homepage_multiple_rooms()
   {
      packageNavigation.navigateToMultiRoomSearchResultPage();
   }
}
