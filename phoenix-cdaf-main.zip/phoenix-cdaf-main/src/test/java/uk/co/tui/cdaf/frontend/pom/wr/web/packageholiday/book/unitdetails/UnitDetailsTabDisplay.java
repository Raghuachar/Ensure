package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Year;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static org.junit.Assert.assertEquals;

public class UnitDetailsTabDisplay extends AbstractPage
{
   public final WebElementWait wait;

   private final Map<String, SelenideElement> searchCardMap;

   private final Random random = new Random();

   private final String mfeParentElemnt = "tui-customer-reviews";

   private final String overAllexperienceMFE = "[class='chart']";

   private final String recommendedBannerMFE = "[class='is-recommended']";

   private final String showMoreMFE = "[class='more-text']";

   private final String monthYearMFE = "[class='holiday-end-date']";

   private final String showLessMFE = "[class='less-text']";

   private final String travelPartyMFE =
            ".filter-sort-container__item [data-list-id='travelParties'] li";

   private final String travelSeasonMFE =
            ".filter-sort-container__item [data-list-id='travelSeasons'] li";

   private final String languageFilterMFE =
            ".filter-sort-container__item [data-list-id='languages'] li";

   private final String sortByFilterOptionsMFE = "[class='orderBy'] option";

   private final String mfePaginationText = ".pagination__text";

   private final String mfePaginationButton = ".pagination__button";

   private final String listOffiltersMFE =
            "[class='filter-sort-container__item'] div[class='filter-heading']";

   private String[] selectedTravelFilter;

   private String[] selectedSeasonFilter;

   private String[] selectedlanguageFilter;

   private String selectedSortFilter;

   @FindBy(css = "[aria-label='Card title']")
   private WebElement recommenedForYou;

   @FindBy(xpath = "//*[@id='facilities']")
   private WebElement facilitiesTab;

   @FindBy(xpath = "//*[@id='location']")
   private WebElement locationTab;

   @FindBy(css = ".NavigationTabsV2__wrapper li")
   private List<WebElement> navigationTabs;

   @FindBy(xpath = "//*[@id='guestreviews']")
   private WebElement guestReviewsTab;

   @FindBy(css = "#TCReviewsComponent_Container > div > tui-customer-reviews")
   private WebElement guestReviewsMFE;

   @FindBy(css = "div[class='Header__guestReviewContainer']")
   private WebElement guestReviewRating;

   @FindBy(css = "div[class='Header__guestReviewContainer'] a")
   private WebElement guestReviewHyperLink;

   @FindBy(css = "Span[class='Header__ratingNumber']")
   private WebElement guestReviewRatingNumber;

   @FindBy(css = "div[class='Header__guestReviewContainer'] span+span")
   private WebElement guestReviewDescription;

   public UnitDetailsTabDisplay()
   {
      wait = new WebElementWait();
      searchCardMap = new HashMap<>();
   }

   public boolean isAboutTheHotelTabDisplayed()
   {
      return $("#OverviewComponentContainer").isDisplayed();
   }

   public void clickOnFacilitiesTab()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(facilitiesTab);
   }

   public void clickOnLocationTab()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(locationTab);
   }

   public String getTabIdByIndex(int index)
   {
      return navigationTabs.get(index).getAttribute("id");
   }

   public String guestReviewsTabText()
   {
      return guestReviewsTab.getText();
   }

   public void selectGuestReviewsTab()
   {
      WebElementTools.scrollTo(guestReviewsTab);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(guestReviewsTab);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isGuestReviewsTabSelected()
   {
      String currentTab = "NavigationTabsV2__current";
      return StringUtils.equalsIgnoreCase(currentTab, guestReviewsTab.getAttribute("class"));
   }

   public boolean isGuestReviewsMFEVisible()
   {
      return WebElementTools.isVisible(guestReviewsMFE);
   }

   public Map<String, SelenideElement> getGuestReviewComponentsMFE()
   {
      searchCardMap.put("Overall Experience",
               SelenideHelper.getShadowRootElements(overAllexperienceMFE, mfeParentElemnt).get(0));
      searchCardMap.put("Recommended",
               SelenideHelper.getShadowRootElements(overAllexperienceMFE, mfeParentElemnt).get(1));
      String percentageMFE =
               ".chart-reviews-container .score-lists ul[class='score-list distribution']";
      searchCardMap.put("Percentage",
               SelenideHelper.getShadowRootElement(percentageMFE, mfeParentElemnt));
      String ratingMFE = ".chart-reviews-container .score-lists ul[class='score-list mt']";
      searchCardMap.put("Rating",
               SelenideHelper.getShadowRootElement(ratingMFE, mfeParentElemnt));
      return searchCardMap;
   }

   public Map<String, SelenideElement> getGuestReviewFiltersMFE()
   {
      String filtersMFE = "[class='filter-sort-container__item']";
      searchCardMap.put("Filter by travel group",
               SelenideHelper.getShadowRootElements(filtersMFE, mfeParentElemnt).get(0));
      searchCardMap.put("Filter by season",
               SelenideHelper.getShadowRootElements(filtersMFE, mfeParentElemnt).get(1));
      searchCardMap.put("Language",
               SelenideHelper.getShadowRootElements(filtersMFE, mfeParentElemnt).get(2));
      String sortByFilterMFE = "[class='filter-sort-container__item sort']";
      searchCardMap.put("Sort by",
               SelenideHelper.getShadowRootElement(sortByFilterMFE, mfeParentElemnt));
      return searchCardMap;
   }

   public Map<String, SelenideElement> getCustomerReviewsectionsMFE()
   {
      searchCardMap.put("Recommended Banner",
               SelenideHelper.getShadowRootElement(recommendedBannerMFE, mfeParentElemnt));
      String headlinesInQuotesMFE = "[class='review__heading']";
      searchCardMap.put("Headline in quotes",
               SelenideHelper.getShadowRootElement(headlinesInQuotesMFE, mfeParentElemnt));
      String reviewsMFE = "[class='review__text']";
      searchCardMap.put("Customer reviews comment",
               SelenideHelper.getShadowRootElement(reviewsMFE, mfeParentElemnt));
      searchCardMap.put("Show more",
               SelenideHelper.getShadowRootElement(showMoreMFE, mfeParentElemnt));
      String scoreMFE = "[class='overall-experience']";
      searchCardMap.put("Score",
               SelenideHelper.getShadowRootElement(scoreMFE, mfeParentElemnt));
      String familyAgeMFE = "[class='user-info']";
      searchCardMap.put("Average age of the family",
               SelenideHelper.getShadowRootElement(familyAgeMFE, mfeParentElemnt));
      searchCardMap.put("Month and Year of visiting",
               SelenideHelper.getShadowRootElement(monthYearMFE, mfeParentElemnt));
      return searchCardMap;
   }

   public void clickOnshowMoreLink()
   {
      SelenideHelper.getShadowRootElement(showMoreMFE, mfeParentElemnt).scrollTo();
      WebElementTools
               .clickElementJavaScript(
                        SelenideHelper.getShadowRootElement(showMoreMFE, mfeParentElemnt));
   }

   public boolean isScoreSectionExpanded()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(showLessMFE, mfeParentElemnt));
   }

   public Map<String, SelenideElement> getTravelPartyFiltersMFE()
   {
      searchCardMap.put("Family",
               SelenideHelper.getShadowRootElements(travelPartyMFE, mfeParentElemnt).get(0));
      searchCardMap.put("Friends",
               SelenideHelper.getShadowRootElements(travelPartyMFE, mfeParentElemnt).get(1));
      searchCardMap.put("Couples",
               SelenideHelper.getShadowRootElements(travelPartyMFE, mfeParentElemnt).get(2));
      searchCardMap.put("Solo",
               SelenideHelper.getShadowRootElements(travelPartyMFE, mfeParentElemnt).get(3));
      return searchCardMap;
   }

   public void selectTravelpartyFilter()
   {
      List<SelenideElement> travelFilter =
               SelenideHelper.getShadowRootElements(travelPartyMFE, mfeParentElemnt);
      int randomFilter = random.nextInt(travelFilter.size());
      travelFilter.get(randomFilter).hover().click();
      selectedTravelFilter = travelFilter.get(randomFilter).getText().split(" ");
   }

   public void isTravelFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      String travelPartyMFEText = "div.user-info > p:nth-child(3)";
      List<SelenideElement> travel =
               SelenideHelper.getShadowRootElements(travelPartyMFEText, mfeParentElemnt);
      for (SelenideElement travelText : travel)
      {
         assertEquals("Travel party do not match", selectedTravelFilter[0], travelText.getText());
      }
   }

   public Map<String, SelenideElement> getSeasonFiltersMFE()
   {
      searchCardMap.put("Spring",
               SelenideHelper.getShadowRootElements(travelSeasonMFE, mfeParentElemnt).get(0));
      searchCardMap.put("Summer",
               SelenideHelper.getShadowRootElements(travelSeasonMFE, mfeParentElemnt).get(1));
      searchCardMap.put("Autumn",
               SelenideHelper.getShadowRootElements(travelSeasonMFE, mfeParentElemnt).get(2));
      searchCardMap.put("Winter",
               SelenideHelper.getShadowRootElements(travelSeasonMFE, mfeParentElemnt).get(3));
      return searchCardMap;
   }

   public void selectSeasonFilter()
   {
      List<SelenideElement> seasonFilter =
               SelenideHelper.getShadowRootElements(travelSeasonMFE, mfeParentElemnt);
      int randomFilter = random.nextInt(seasonFilter.size());
      seasonFilter.get(randomFilter).hover().click();
      selectedSeasonFilter = seasonFilter.get(randomFilter).getText().split(" ");
   }

   public void isSeasonFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      List<SelenideElement> season =
               SelenideHelper.getShadowRootElements(monthYearMFE, mfeParentElemnt);
      for (SelenideElement seasonText : season)
      {
         String[] seasonTextValue = seasonText.getText().split(" ");
         boolean seasonFilterDisplayed;
         switch (seasonTextValue[0])
         {
            case "Dec":
            case "Jan":
            case "Feb":
               seasonFilterDisplayed = selectedSeasonFilter[0].equalsIgnoreCase("Winter");
               break;
            case "Mrt":
            case "Apr":
            case "Mei":
               seasonFilterDisplayed = selectedSeasonFilter[0].equalsIgnoreCase("Lente");
               break;
            case "Jun":
            case "Jul":
            case "Aug":
               seasonFilterDisplayed = selectedSeasonFilter[0].equalsIgnoreCase("Zomer");
               break;
            case "Sep":
            case "Okt":
            case "Nov":
               seasonFilterDisplayed = selectedSeasonFilter[0].equalsIgnoreCase("Herfst");
               break;
            default:
               seasonFilterDisplayed = selectedSeasonFilter[0].equalsIgnoreCase("Unknown");
               break;
         }
         if (!seasonFilterDisplayed)
         {
            throw new AssertionError("Filter by season not displayed");
         }
      }
   }

   public Map<String, SelenideElement> getLanguageFiltersMFE()
   {
      searchCardMap.put("English",
               SelenideHelper.getShadowRootElements(languageFilterMFE, mfeParentElemnt).get(0));
      searchCardMap.put("German",
               SelenideHelper.getShadowRootElements(languageFilterMFE, mfeParentElemnt).get(1));
      searchCardMap.put("French",
               SelenideHelper.getShadowRootElements(languageFilterMFE, mfeParentElemnt).get(2));
      searchCardMap.put("Dutch",
               SelenideHelper.getShadowRootElements(languageFilterMFE, mfeParentElemnt).get(3));
      return searchCardMap;
   }

   public void selectLanguageFilter()
   {
      List<SelenideElement> languageFilter =
               SelenideHelper.getShadowRootElements(languageFilterMFE, mfeParentElemnt);
      int randomFilter = random.nextInt(languageFilter.size());
      languageFilter.get(randomFilter).hover().click();
      selectedlanguageFilter = languageFilter.get(randomFilter).getText().split("\\D+");
   }

   public void isLanguageFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      String paginationMFEText = "[class='pagination__text']";
      SelenideElement pagination =
               SelenideHelper.getShadowRootElement(paginationMFEText, mfeParentElemnt);
      String[] paginationValue = pagination.getText().split(" ");
      assertEquals("Travel party do not match", selectedlanguageFilter[1], paginationValue[6]);
   }

   public Map<String, SelenideElement> getSortByFiltersMFE()
   {
      searchCardMap.put("Travel date",
               SelenideHelper.getShadowRootElements(sortByFilterOptionsMFE, mfeParentElemnt)
                        .get(0));
      searchCardMap.put("Overall experience",
               SelenideHelper.getShadowRootElements(sortByFilterOptionsMFE, mfeParentElemnt)
                        .get(1));
      return searchCardMap;
   }

   public void selectSortByFilter()
   {
      String sortByFilterSelectMFE = "[class='orderBy']";
      SelenideElement sortFilter = SelenideHelper
               .getShadowRootElement(sortByFilterSelectMFE, mfeParentElemnt).hover();
      sortFilter.click();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      List<SelenideElement> sortFilters =
               SelenideHelper.getShadowRootElements(sortByFilterOptionsMFE, mfeParentElemnt);
      int randomFilter = random.nextInt(sortFilters.size());
      sortFilters.get(randomFilter).click();
      selectedSortFilter = sortFilters.get(randomFilter).getText();
   }

   public void isSortFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      if (selectedSortFilter.equalsIgnoreCase("Algemene ervaring"))
      {
         String scoreMFEText = "[class='overall-experience__score']";
         List<SelenideElement> score =
                  SelenideHelper.getShadowRootElements(scoreMFEText, mfeParentElemnt);
         for (SelenideElement scoreText : score)
         {
            assertEquals("over all experience score do not match", "10", scoreText.getText());
         }
      }

      else if (selectedSortFilter.equalsIgnoreCase("Reisdatum"))
      {
         List<SelenideElement> currentYear =
                  SelenideHelper.getShadowRootElements(monthYearMFE, mfeParentElemnt);
         for (SelenideElement currentYearText : currentYear)
         {
            String[] currentYearTextValue = currentYearText.getText().split(" ");
            int currentYearvalue = Integer.parseInt(currentYearTextValue[1]);
            Year expectedYear = Year.now();
            int expectedYearValue = expectedYear.getValue();
            assertEquals("The year is not the current year", currentYearvalue, expectedYearValue);
         }
      }
   }

   public boolean getPostReviews()
   {
      String mfepostReview = ".review__base-info";
      List<SelenideElement> list =
               SelenideHelper.getShadowRootElements(mfepostReview, mfeParentElemnt);
      return list.size() == 5;
   }

   public boolean isPaginationMFE()
   {
      return WebElementTools
               .isPresent(SelenideHelper.getShadowRootElement(mfePaginationText, mfeParentElemnt));
   }

   public String getDisplayedReviews()
   {
      return SelenideHelper.getShadowRootElement(mfePaginationText, mfeParentElemnt).getText();
   }

   public void clickOnpaginationMfeBtn()
   {
      List<SelenideElement> navigationButton =
               SelenideHelper.getShadowRootElements(mfePaginationButton, mfeParentElemnt);
      navigationButton.get(1).click();
      wait.forAppear(SelenideHelper.getShadowRootElement(mfePaginationText, mfeParentElemnt));
   }

   public void clickOnLastpaginationMfeBtn()
   {
      $$(shadowDeepCss(mfePaginationButton)).last().click();
   }

   public String getTravelGroupFilter()
   {
      return SelenideHelper.getShadowRootElements(listOffiltersMFE, mfeParentElemnt).get(0)
               .getText();
   }

   public String getSeasonFilter()
   {
      return SelenideHelper.getShadowRootElements(listOffiltersMFE, mfeParentElemnt).get(1)
               .getText();
   }

   public String getLanguageFilter()
   {
      return SelenideHelper.getShadowRootElements(listOffiltersMFE, mfeParentElemnt).get(2)
               .getText();
   }

   public String getsortByFilter()
   {
      String sortByMFE = "[class='filter-sort-container__item sort'] label[class='select-label']";
      return SelenideHelper.getShadowRootElement(sortByMFE, mfeParentElemnt).getText();
   }

   public String getShowMore()
   {
      return SelenideHelper.getShadowRootElement(showMoreMFE, mfeParentElemnt).getText();
   }

   public String getShowLess()
   {
      WebElementTools.click(SelenideHelper.getShadowRootElement(showMoreMFE, mfeParentElemnt));
      return SelenideHelper.getShadowRootElement(showLessMFE, mfeParentElemnt).getText();
   }

   public String getHeadingErrorMFE()
   {
      String headingErrorMFE = "[class='heading error-heading']";
      return SelenideHelper.getShadowRootElement(headingErrorMFE, mfeParentElemnt).getText();
   }

   public String getrecommendedBannerMFE()
   {

      return SelenideHelper.getShadowRootElement(recommendedBannerMFE, mfeParentElemnt).getText();
   }

   public String geterroeSectonMFE()
   {
      String erroeSectonMFE = ".error-section__heading";
      return SelenideHelper.getShadowRootElement(erroeSectonMFE, mfeParentElemnt).getText();
   }

   public String getlastErrorSectionMFE()
   {
      String lastErrorSection = "[class='error-section'] p";
      return SelenideHelper.getShadowRootElement(lastErrorSection, mfeParentElemnt).getText();
   }

   public boolean isGuestReviewDisplayed()
   {
      return WebElementTools.isPresent(guestReviewRating);
   }

   public boolean isGuestReviewHyperLinkDisplayed()
   {
      return WebElementTools.isDisplayed(guestReviewHyperLink);
   }

   public Double getGuestReviewRatingOnHotelPage()
   {
      return Double.parseDouble(WebElementTools.getElementText(guestReviewRatingNumber));
   }

   public String getGuestReviewDescription()
   {
      return WebElementTools.getElementText(guestReviewDescription);
   }

   public boolean isCustomerPositionedAtTop()
   {
      return WebElementTools.isDisplayed(
               SelenideHelper.getShadowRootElement(overAllexperienceMFE, mfeParentElemnt));
   }

   public SelenideElement getOverviewTab()
   {
      return $("ul.NavigationTabsV2__wrapper").$("li[id='overview']");
   }

   public SelenideElement getFacilitiesTab()
   {
      return $("ul.NavigationTabsV2__wrapper").$("li[id='facilities']");
   }

   public SelenideElement getLocationTab()
   {
      return $("ul.NavigationTabsV2__wrapper").$("li[id='location']");
   }

   public SelenideElement getGuestReviewTab()
   {
      return $("ul.NavigationTabsV2__wrapper").$("li[id='guestreviews']");
   }

   public boolean isFacilitiesTabDisplayed()
   {
      return $("#facilitiesV4__component").isDisplayed();
   }

   public boolean isGuestReviewsTabDisplayed()
   {
      return $("tui-customer-reviews").isDisplayed();
   }
}

