package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class PassengerFormComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[aria-label='page heading']")
   private WebElement pageHeading;

   @FindBy(xpath = "//div[@aria-label='Passenger form fields'] [1]")
   private WebElement passengerForm;

   @FindAll({ @FindBy(css = "[name='email']"), @FindBy(css = "[name*='email']") })
   private WebElement email;

   @FindAll({ @FindBy(css = "[name='postCode']"), @FindBy(css = "[name*='postCode']") })
   private WebElement postcode;

   @FindAll({ @FindBy(css = "[name='houseNum']"), @FindBy(css = "[name*='postCode']") })
   private WebElement HouseNum;

   @FindAll({ @FindBy(css = "[aria-label='telephone number']"), @FindBy(css = "[name='mobileNum']"),
            @FindBy(css = "[name*='mobileNum']") })
   private WebElement telephone;

   @FindBy(css = "[name*='firstName']+span+span+span[class*='error']")
   private WebElement firstNameErrorMessage;

   @FindBy(css = "[name*='lastName']+span+span+span[class*='error']")
   private WebElement lastNameErrorMessage;

   @FindBy(css = "[name*='address1']+span+span+span[class*='error']")
   private WebElement addressErrorMessage;

   @FindBy(css = "[name*='address2']+span+span+span[class*='error']")
   private WebElement busAddressErrorMessage;

   @FindBy(css = "[name*='email']+span+span+span[class*='error']")
   private WebElement emailErrorMessage;

   @FindBy(css = "[name*='mobileNum']+span+span+span[class*='error']")
   private WebElement mobileErrorMessage;

   @FindBy(css = "[name*='postCode']+span+span+span[class*='error']")
   private WebElement postCodeErrorMessage;

   @FindBy(css = "[name*='houseNum']+span+span+span[class*='error']")
   private WebElement HouseNumErrorMessage;

   public PassengerFormComponent()
   {
      super();
      wait = new WebElementWait();
   }

   public WebElement getPageHeadingElement()
   {
      return pageHeading;
   }

   public WebElement getPassengerFormElement()
   {
      return wait.getWebElementWithLazyWait(passengerForm);
   }

   public boolean isPassengerFormDisplayed()
   {
      return WebElementTools.isPresent(getPassengerFormElement());
   }

   public void clikOnOutSideOfTheField()
   {
      WebElementTools.click(passengerForm);
   }

   public void enterInvalidEmailAddress(String data)
   {
      WebElementTools.enterText(email, data);
   }

   public void enterInvalidMobilePhone()
   {
      WebElementTools.enterText(telephone, RandomStringUtils.random(8, true, false));
   }

   public void enterInvalidPostCode()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(postcode, RandomStringUtils.random(8, true, false));
   }

   public void enterInvalidHousenumber()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.enterText(HouseNum, RandomStringUtils.random(11, true, false));
   }

   public String getFirstNameErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(firstNameErrorMessage);
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(firstNameErrorMessage));
   }

   public String getLastNameErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(lastNameErrorMessage);
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(lastNameErrorMessage));
   }

   public String getStreetErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(addressErrorMessage);
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(addressErrorMessage));
   }

   public String getBusAddressErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(busAddressErrorMessage);
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(busAddressErrorMessage));
   }

   public String getHouseNumErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(addressErrorMessage);
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(HouseNumErrorMessage));
   }

   public String getEmailAddressErrorMessage(String errorType)
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(emailErrorMessage);
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(emailErrorMessage));
   }

   public String getMobileErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(mobileErrorMessage);
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(mobileErrorMessage));
   }

   public String getPostCodeErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(postCodeErrorMessage);
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(postCodeErrorMessage));
   }

}
