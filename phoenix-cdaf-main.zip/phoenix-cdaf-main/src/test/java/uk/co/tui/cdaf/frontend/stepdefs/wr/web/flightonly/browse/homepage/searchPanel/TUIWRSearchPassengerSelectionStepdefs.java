package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.browse.homepage.searchPanel;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TUIWRSearchPassengerSelectionStepdefs
{
   private final FlightOnlyHomePage homepage;

   public TUIWRSearchPassengerSelectionStepdefs()
   {
      homepage = new FlightOnlyHomePage();
   }

   @Given("a {string} is on a TUIfly homepage for any domain")
   public void a_is_on_a_TUIfly_homepage_for_any_domain(String string)
   {
      homepage.visit();
   }

   @When("they click in the {string} field in the TUIfly search panel")
   public void they_click_in_the_field_in_the_TUIfly_search_panel(String string)
   {
      homepage.clickSearchPanelPassengerField();
   }

   @Then("they will see the following Title: Passengers")
   public void they_will_see_the_following_Title_Passengers()
   {
      assertThat(homepage.validateTitlePassengerDropdown(), is(true));
   }

   @Given("the search panel is in the default state")
   public void the_search_panel_is_in_the_default_state()
   {
      assertThat("Search panel is in default state",
               homepage.defaultSearchPanelState(), is(true));
   }

   @Then("they will see the {string} drop down fields with the a {string} passenger number:")
   public void they_will_see_the_drop_down_fields_with_the_a_passenger_number(String string,
            String string2, DataTable dataTable)
   {
      List<List<String>> list = dataTable.asLists(String.class);
      assertThat(homepage.validateAdultsPassengerSelectionField(), is(list.get(0).get(1)));
      assertThat(homepage.validateChildrenPassengerSelectionField(), is(list.get(1).get(1)));
   }

}
