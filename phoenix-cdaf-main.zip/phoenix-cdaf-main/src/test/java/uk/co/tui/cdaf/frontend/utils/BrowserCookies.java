package uk.co.tui.cdaf.frontend.utils;

import lombok.SneakyThrows;
import org.openqa.selenium.Cookie;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import java.net.URL;

public class BrowserCookies
{
   private static final String CONSENTMGR = "CONSENTMGR";

   public static void closePrivacyPopUp()
   {
      if (WebDriverUtils.getDriver().manage().getCookieNamed(CONSENTMGR) == null)
      {
         Cookie consentmgr =
                  new Cookie(CONSENTMGR, "ts:" + System.currentTimeMillis() + "%7Cconsent:true",
                           getHost(), "/", null);
         WebDriverUtils.getDriver().manage().addCookie(consentmgr);
         WebDriverUtils.getDriver().navigate().refresh();
      }
   }

   public static void feedbackPopUp()
   {
      if (WebDriverUtils.getDriver().manage().getCookieNamed(CONSENTMGR) == null)
      {
         Cookie consentmgr =
                  new Cookie(CONSENTMGR, "consent:false" + "%7Cts:" + System.currentTimeMillis());
         WebDriverUtils.getDriver().manage().addCookie(consentmgr);
         WebDriverUtils.getDriver().navigate().refresh();
      }
   }

   @SneakyThrows
   private static String getHost()
   {
      String currentUrl = WebDriverUtils.getDriver().getCurrentUrl();
      return new URL(currentUrl).getHost();
   }
}
