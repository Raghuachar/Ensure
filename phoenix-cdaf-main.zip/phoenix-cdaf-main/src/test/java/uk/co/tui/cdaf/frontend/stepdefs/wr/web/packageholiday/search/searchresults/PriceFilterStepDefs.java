package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPrice;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsTRatingFilter;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class PriceFilterStepDefs
{
   public final PackageNavigation packageNavigation;

   private final SearchResultsPrice searchResultsPrice;

   private final SearchResultsPage searchResultsPage;

   private final SearchResultsTRatingFilter searchResultsTRatingFilter;

   private final WebElementWait wait;

   public PriceFilterStepDefs()
   {
      searchResultsPrice = new SearchResultsPrice();
      searchResultsPage = new SearchResultsPage();
      searchResultsTRatingFilter = new SearchResultsTRatingFilter();
      wait = new WebElementWait();
      packageNavigation = new PackageNavigation();
   }

   @When("they are viewing the Price filter")
   public void they_are_viewing_the_Price_filter()
   {
      assertThat("Price component is not present", searchResultsPrice.isPriceFilterDisplayed(),
               is(true));
   }

   @Then("they will see a slider for price")
   public void they_will_see_a_slider_for_price()
   {
      assertThat("Slider for Price component is not present",
               searchResultsPrice.isSliderPriceDisplayed(), is(true));
   }

   @And("this will be set to the max price per person by default")
   public void this_will_be_set_to_the_max_price_per_person_by_default()
   {
      assertThat("price is not at maximum", searchResultsPrice.defaultPriceSliderValue(), is(true));
   }

   @When("they want to filter by price")
   public void they_want_to_filter_by_price()
   {
      assertThat("Slider for Price component is not present",
               searchResultsPrice.isSliderPriceDisplayed(), is(true));
   }

   @Then("they can do this using a price filter slider to filter by from highest price pp to lowest price pp")
   public void they_can_do_this_using_a_price_filter_slider_to_filter_by_from_highest_price_pp_to_lowest_price_pp()
   {
      searchResultsPrice.selectSlider();
   }

   @And("the results will filter to reflect the price range selected")
   public void the_results_will_filter_to_reflect_the_price_range_selected()
   {
      wait.forJSExecutionReadyLazy();
      searchResultsPrice.isFilteredByPrice();
   }

   @And("the clear link will show")
   public void the_clear_link_will_show()
   {
      searchResultsPrice.isClearFilterLinkDisplayed();
   }

   @And("they have selected the price slider to change the results")
   public void they_have_selected_the_price_slider_to_change_the_results()
   {
      searchResultsPrice.selectSlider();
      searchResultsPrice.isFilteredByPrice();
   }

   @When("items in the other filters become unavailable")
   public void items_in_the_other_filters_become_unavailable()
   {
      searchResultsPage.searchResultsFiltersComponent.clickOnDeparturePoint();
   }

   @Then("they will grey out")
   public void they_will_grey_out()
   {
      searchResultsPage.searchResultsFiltersComponent.isBoardBasisDisableState();
   }

   @And("they have filtered the Price")
   public void they_have_filtered_the_Price()
   {
      searchResultsPrice.selectSlider();
   }

   @When("they want to clear the selection")
   public void they_want_to_clear_the_selection()
   {
      assertThat("Clear All link is not present",
               searchResultsPrice.isClearAllFilterLinkDisplayed(), is(true));
   }

   @And("the customer can select the filters they wish to filter by including price")
   public void the_customer_can_select_the_filters_they_wish_to_filter_by_including_price()
   {
      searchResultsPrice.selectSlider();
   }

   @When("they are viewing the Price filter Modal")
   public void they_are_viewing_the_Price_filter_Modal()
   {
      searchResultsTRatingFilter.clickMoreFilters();
      assertThat("Price component is not present", searchResultsPrice.isPriceFilterDisplayed(),
               is(true));
   }

   @Then("they will see a slider for price Modal")
   public void they_will_see_a_slider_for_price_Modal()
   {
      assertThat("Slider for Price component is not present",
               searchResultsPrice.isSliderPriceDisplayedModal(), is(true));
   }

   @And("they have selected the price slider to change the results mode")
   public void they_have_selected_the_price_slider_to_change_the_results_mode()
   {
      searchResultsTRatingFilter.clickMoreFilters();
      searchResultsPrice.selectSlider();
      searchResultsPrice.isFilteredByPrice();
   }

   @Given("the customer has selected the {string} filter ")
   public void the_customer_has_selected_the_filter(String moreFilter)
   {
      packageNavigation.navigateToSearchResultPage();
      wait.forJSExecutionReadyLazy();
      searchResultsTRatingFilter.clickMoreFilters();
   }

   @And("they are viewing the more Filters Modal")
   public void they_are_viewing_the_more_filters_modal()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("Open in a model is not present",
               searchResultsPage.searchResultsFiltersComponent.isOpenmodelMoreisDisplayed(),
               is(true));
   }

   @When("they wish to close the modal price")
   public void they_wish_to_close_the_modal_price()
   {
      searchResultsPrice.selectSlider();
   }

   @And("they have filtered the Price using the {string} filter")
   public void they_have_filtered_the_Price_using_the_filter(String string)
   {
      searchResultsTRatingFilter.clickMoreFilters();
      wait.forJSExecutionReadyLazy();
      searchResultsPrice.selectSlider();
      wait.forJSExecutionReadyLazy();
   }

   @And("they have filtered the price modal")
   public void they_have_filtered_the_price_modal()
   {
      searchResultsTRatingFilter.clickMoreFilters();
      wait.forJSExecutionReadyLazy();
      searchResultsPrice.selectSlider();
      wait.forJSExecutionReadyLazy();
   }
}
