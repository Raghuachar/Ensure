package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class SearchResultsHolidayTypesFilterComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindAll({ @FindBy(css = "[class='HolidayType__filterOption'] span") })
   public List<WebElement> holidayTypesFilterList;

   @FindAll({ @FindBy(css = "[class='inputs__checkBox  undefined  '] input:disabled") })
   public List<WebElement> greyed;

   @FindBy(css = ".DropModal__filterModalWindow:nth-child(1) .DropModal__close")
   private WebElement xWindow;

   @FindBy(css = ".DropModal__dropModalContent:nth-child(1) .DropModal__footerContainer button[role='button']")
   private List<WebElement> applyButton;

   @FindAll({ @FindBy(css = "[class*='HolidayType__name']"),
            @FindBy(css = "[class*='HolidayType__filterTitle']") })
   private WebElement holidayTypeFilter;

   @FindBy(css = "[class*='HolidayType__filterType HolidayType__checked']")
   private WebElement isAnyOfTheHolidayTypesSelected;

   @FindBy(css = "[class*='HolidayType__filterType HolidayType__notChecked']")
   private WebElement isAnyOfTheHolidayTypeSelectable;

   @FindBy(css = "[class*='collectionsfilter4']")
   private WebElement holidayTypesSelection5thPosition;

   @FindBy(css = "[class*='collectionsfilter5']")
   private WebElement holidayTypesSelection6thPosition;

   @FindBy(css = "[class*='HolidayType__showLess']")
   private WebElement isShowLessButtonEnabled;

   @FindBy(css = "[class*='HolidayType__moreLess']")
   private WebElement isShowMoreButtonEnabled;

   @FindBy(css = "[class*='HolidayType__clearLink'] a")
   private WebElement holidayTypesClearLink;

   @FindAll({ @FindBy(css = "[class='HolidayType__filterType HolidayType__notChecked'] label") })
   private List<WebElement> holidayTypesUnSelectedFilterComponents;

   @FindBy(css = "[aria-label='More filter']")
   private WebElement moreFiltersModel;

   @FindBy(css = "[class='MoreFilters__contentAlign contentWidth'] div a[class='MoreFilters__clear']")
   private WebElement clearAllModel;

   @FindBy(css = "[class='buttons__button buttons__septenary undefined buttons__fill undefined undefined MoreFilters__apply']")
   private WebElement moreFilterApply;

   @FindBy(css = "[class*='HolidayType__name']")
   private WebElement holidayTypeFilterName;

   public SearchResultsHolidayTypesFilterComponent()
   {
      wait = new WebElementWait();
   }

   public boolean isHolidayTypePresent()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(holidayTypeFilter));
   }

   public boolean validateHolidayTypesTitleSameAsScenerio(String dataTable)
   {
      StringUtils.containsIgnoreCase(dataTable, "Vakantietype");
      return WebElementTools.isPresent(holidayTypeFilter);
   }

   public boolean closeModal(String component)
   {
      wait.forJSExecutionReadyLazy();
      if (StringUtils.containsIgnoreCase(component, "x"))
         return WebElementTools.isPresent(xWindow);
      if (StringUtils.containsIgnoreCase(component, "Apply"))
         return WebElementTools.isPresent(applyButton.get(4));
      return true;
   }

   public boolean isMoreFilterDisplayed()
   {
      return WebElementTools.isPresent(moreFiltersModel);
   }

   public boolean isMoreFilterApplyPresent()
   {
      return WebElementTools.isPresent(moreFilterApply);
   }

   public void applyMoreFilters()
   {
      if (WebElementTools.isPresent(moreFilterApply))
         WebElementTools.click(moreFilterApply);
      wait.forJSExecutionReadyLazy();

   }

   public boolean isAnyOfTheHolidayTypesSelectedPresent()
   {
      return WebElementTools
               .isPresent(wait.getWebElementWithLazyWait(isAnyOfTheHolidayTypesSelected));
   }

   public boolean isAnyOfTheHolidayTypeSelectablePresent()
   {
      return WebElementTools
               .isPresent(wait.getWebElementWithLazyWait(isAnyOfTheHolidayTypeSelectable));
   }

   public boolean isHolidayTypesCountMoreThan5()
   {
      return WebElementTools
               .isPresent(wait.getWebElementWithLazyWait(holidayTypesSelection5thPosition));
   }

   public boolean getMoreResultsWith6thPosition()
   {
      return WebElementTools
               .isPresent(wait.getWebElementWithLazyWait(holidayTypesSelection6thPosition));
   }

   public boolean isShowMoreButtonEnabled()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(isShowLessButtonEnabled));

   }

   public boolean verifyHolidayTypesNameList(io.cucumber.datatable.DataTable dataTable)
   {
      boolean value = false;
      final List<String> names = dataTable.asList();
      for (WebElement filedName : holidayTypesFilterList)
      {
         for (String name : names)
         {
            String finalName = WebElementTools.getElementText(filedName);
            if (finalName.equalsIgnoreCase(name))
            {
               value = true;
            }
         }

      }
      return value;
   }

   public void clickShowMoreButton()
   {
      WebElementTools.click(isShowLessButtonEnabled);
   }

   public boolean isShowLessButtonEnabled()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(isShowMoreButtonEnabled));

   }

   public void selectHolidayTypesFilter()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(holidayTypesUnSelectedFilterComponents.get(0));
   }

   public boolean holidayTypeClearLinkPresent()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(holidayTypesClearLink));
   }

   public boolean disabledHolidayTypes()
   {
      return !greyed.isEmpty();
   }

   public void selectSpecificHolidayTypes()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(holidayTypesUnSelectedFilterComponents.get(0));

   }

   public void deselectSpecificHolidayTypes()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(holidayTypesUnSelectedFilterComponents.get(0));

   }

   public boolean moreFiltersTextCompare(String moreFilter)
   {
      wait.waitForElementToBePresent(moreFiltersModel);
      return WebElementTools.getElementText(moreFiltersModel).equals(moreFilter);
   }

   public void clickMoreFilters()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(0, 0);
      WebElementTools.clickElementJavaScript(moreFiltersModel);
   }

   public void clearAllModel()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(clearAllModel);
   }

   public void holidayTypeClearLinkSelection()
   {
      WebElementTools.clickElementJavaScript(holidayTypesClearLink);
   }

}
