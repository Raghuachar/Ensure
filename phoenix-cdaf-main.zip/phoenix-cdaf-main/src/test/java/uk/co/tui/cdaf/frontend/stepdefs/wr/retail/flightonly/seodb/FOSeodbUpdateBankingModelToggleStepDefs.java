package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOSeodbUpdateBankingModelToggleStepDefs
{

   public final WebElementWait wait;

   private final FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents;

   public FOSeodbUpdateBankingModelToggleStepDefs()
   {
      wait = new WebElementWait();
      foReconcilationPaymentPageComponents = new FOReconcilationPaymentPageComponents();
   }

   @When("they view the payment methods")
   public void they_view_the_payment_methods()
   {
      assertThat("Update banking model opened",
               foReconcilationPaymentPageComponents.isPaymentMethodTitleDisplayed(), is(true));

   }

   @Then("the only radio button available will be CASH")
   public void the_only_radio_button_available_will_be_CASH()
   {
      assertThat("Update banking model opened",
               foReconcilationPaymentPageComponents.isCashBRadiobuttonPresent(), is(true));

   }

   @Then("this cannot be changed or unselected")
   public void this_cannot_be_changed_or_unselected()
   {
      wait.forJSExecutionReadyLazy();
   }
}
