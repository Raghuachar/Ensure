package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.confirmation;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.confirmation.ConfirmationPage;

public class RoomTypeinHolidayComponentConfirmationStepDefs
{
   public final PackageNavigation packageNavigation;

   public final ConfirmationPage confirmationPage;

   public RoomTypeinHolidayComponentConfirmationStepDefs()
   {
      packageNavigation = new PackageNavigation();
      confirmationPage = new ConfirmationPage();
   }

   @When("they are navigated to the Booking Confirmation page")
   public void they_are_navigated_to_the_Booking_Confirmation_page()
   {
      packageNavigation.navigateToConfirmationPage();
   }

   @Then("they will able to see their upgraded room type description within the Holiday Summary")
   public void they_will_able_to_see_their_upgraded_room_type_description_within_the_Holiday_Summary()
   {
      confirmationPage.confirmationHolidayComponent.getMultipleRoomTypeComps();
   }
}
