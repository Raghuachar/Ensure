package uk.co.tui.cdaf.frontend.pom.uk.web.hotel_only.search.search_results;

import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import static com.codeborne.selenide.Selenide.$;

public class HotelOnlyPage extends AbstractPage
{
   public boolean isSearchPanelDisplayed()
   {
      return $("[aria-label = 'search panel']").isDisplayed();
   }

}
