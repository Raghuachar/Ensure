package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.extraoptions;

import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.book.extraoptions.MultiSelectInsuranceComponent;

public class ExtraOptionsPage
{

   public final ProgressionbarNavigationComponent progressbarComponent;

   public final InsuranceComponent insuranceComponent;

   public final MultiSelectInsuranceComponent multiInsuranceComponent;

   public ExtraOptionsPage()
   {
      progressbarComponent = new ProgressionbarNavigationComponent();
      insuranceComponent = new InsuranceComponent();
      multiInsuranceComponent = new MultiSelectInsuranceComponent();
   }

}
