package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSingleAccomHolidayDurationStepDefs
{

   public final SearchResultsPage searchResultsPage;

   private final PackageNavigation packageNavigation;

   private final SearchPanelComponent searchPanel;

   private String defaultCheapestPrice;

   private String changedCheapestPrice;

   public PackageSingleAccomHolidayDurationStepDefs()
   {
      searchPanel = new SearchPanelComponent();
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
   }

   @Then("they can see a Holiday Duration component")
   public void they_can_see_a_Holiday_Duration_component()
   {
      Assert.assertTrue(searchPanel.validateAccommodationSingleAccomm());
   }

   @Given("the backend has returned additional alternative durations")
   public void the_backend_has_returned_additional_alternative_durations()
   {
      Assert.assertTrue(packageNavigation.searchResultsPage.validateAlternateDurationExists());
      defaultCheapestPrice =
               searchResultsPage.singleAccommodationComponent.getCheapestPriceForSingleAccomm();
   }

   @When("they select an alternative duration")
   public void they_select_an_alternative_duration()
   {
      packageNavigation.searchResultsPage.selectAlternativeDuration();
   }

   @Then("the package updates")
   public void the_package_updates()
   {
      changedCheapestPrice =
               searchResultsPage.singleAccommodationComponent.getCheapestPriceForSingleAccomm();
      assertThat("package is not updated", defaultCheapestPrice.equals(changedCheapestPrice),
               is(false));
   }

   @Then("the prices in the calendar increase or decrease depending on their selection")
   public void the_prices_in_the_calendar_increase_or_decrease_depending_on_their_selection()
   {
      assertThat("Price in the calendar is not changed",
               defaultCheapestPrice.equals(changedCheapestPrice), is(false));
   }

   @Then("the lowest price marker within the calendar updates to the cheapest price")
   public void the_lowest_price_marker_within_the_calendar_updates_to_the_cheapest_price()
   {
      assertThat("Lowest price is not displayed in green parameter",
               searchResultsPage.singleAccommodationComponent.isLowestPriceDisplayed(), is(true));
   }

}
