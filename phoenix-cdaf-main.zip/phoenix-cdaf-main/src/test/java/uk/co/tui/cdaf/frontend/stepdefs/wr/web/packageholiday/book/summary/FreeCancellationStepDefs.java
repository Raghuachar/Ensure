package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class FreeCancellationStepDefs
{

   private final PackageNavigation packageNavigation;

   private final SummaryPage summaryPage;

   public FreeCancellationStepDefs()
   {
      packageNavigation = new PackageNavigation();
      summaryPage = new SummaryPage();
   }

   @And("user is able to see Free Cancellation component")
   public void user_is_able_to_see_Free_Cancellation_component()
   {
      assertTrue("Free Cancellation message is not displayed",
               summaryPage.freeCancellationComponent.isFreeCancellationComponentDisplayed());
   }

   @And("component consists of icon, message and T&C's apply Link")
   public void component_consists_of_icon_message_and_link()
   {
      assertTrue("No Free cancellation icon displayed",
               summaryPage.freeCancellationComponent.isIconDisplayed());
      assertTrue("No Free cancellation message displayed",
               summaryPage.freeCancellationComponent.isMessageDisplayed());
      assertTrue("No Free cancellation T&C's apply link displayed",
               summaryPage.freeCancellationComponent.isLinkDisplayed());
   }

   @And("message contains date that is {int} days or less later then the current date")
   public void message_contains_date_that_is_later_then_today(Integer numberOfDays)
   {
      assertTrue("Date in Free Cancellation message is not as expected",
               summaryPage.freeCancellationComponent.isNumberOfDaysEqual(numberOfDays));
   }

   @And("user clicks Free Cancellation T&C apply link")
   public void user_clicks_free_cancellation_modal_link()
   {
      summaryPage.freeCancellationComponent.clickModalLink();
   }

   @And("Free Cancellation modal is expanded")
   public void free_cancellation_modal_is_expanded()
   {
      assertTrue("No Free Cancellation modal displayed",
               summaryPage.freeCancellationComponent.isModalExpanded());
   }

   @And("modal consists of title and a message")
   public void modal_consists_of_title_and_message()
   {
      assertTrue("No Free Cancellation modal title displayed",
               summaryPage.freeCancellationComponent.isModalTitleDisplayed());
      assertTrue("No Free Cancellation modal content displayed",
               summaryPage.freeCancellationComponent.isModalContentDisplayed());
   }

   @When("user clicks modal close button")
   public void user_clicks_modal_close_button()
   {
      summaryPage.freeCancellationComponent.clickModalCloseButton();
   }

   @Then("modal is closed")
   public void modal_is_closed()
   {
      assertFalse("Free Cancellation modal still displayed",
               summaryPage.freeCancellationComponent.isModalExpanded());
   }
}
