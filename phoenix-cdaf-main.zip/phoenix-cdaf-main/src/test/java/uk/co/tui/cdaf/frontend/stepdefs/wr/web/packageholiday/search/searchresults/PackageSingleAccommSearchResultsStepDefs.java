package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSingleAccommSearchResultsStepDefs
{

   static AutomationLogManager LOGGER =
            new AutomationLogManager(PackageSingleAccommSearchResultsStepDefs.class);

   public final SearchResultsPage searchResultsPage;

   private final PackageNavigation packageNavigation;

   public PackageSingleAccommSearchResultsStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
      packageNavigation = new PackageNavigation();
   }

   @When("the package search results page loads")
   public void the_package_search_results_page_loads()
   {
      assertThat("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed(), is(true));
   }

   @Then("only the unit the customer has searched for will be displayed in the search results")
   public void only_the_unit_or_units_the_customer_has_searched_for_will_be_displayed_in_the_search_results_design_as_per_normal_package_search_results()
   {
      assertThat("unit name is not displayed in the search results",
               searchResultsPage.singleAccommodationComponent.isUnitElementDisplayed(), is(true));
   }

   @Given("the {string} has conducted a VIP Selection single accommodation search")
   public void the_has_conducted_a_VIP_Selection_single_accommodation_search(String string)
   {
      packageNavigation.navigateToVipSingleAccomSearchResultPage();
   }

   @When("they review the search card on the single accom result page")
   public void they_review_the_search_card_on_the_single_accom_result_page()
   {
      assertThat("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed(), is(true));
   }

   @Then("they can see the V ratings icons")
   public void they_can_see_the_V_ratings_icons()
   {
      String getVRatingText = searchResultsPage.singleAccommodationComponent.getVRating();
      assertThat("V Rating is not displayed", "V".trim().contains(getVRatingText), is(true));
      LOGGER.log(LogLevel.INFO, "getVRatingText  : " + getVRatingText);
   }
}
