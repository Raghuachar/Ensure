package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagPreviousReconDateHeaderStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   public final PackageNavigation fonavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackagPreviousReconDateHeaderStepDefs()
   {
      fonavigation = new PackageNavigation();
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent has pressed the {string} CTA'")
   public void that_the_agent_has_pressed_the_CTA(String string)
   {
      fonavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pKgReconcilationPaymentPageComponents.clickPreviousReconPageLink();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnSearchCTA();
   }

   @When("they view the search result")
   public void they_view_the_search_result()
   {
      wait.forJSExecutionReadyLazy();
   }

   @Then("they can see the headers for each table within the search results")
   public void they_can_see_the_headers_for_each_table_within_the_search_results(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Reconcilation Banking Table Displayed",
               pKgReconcilationPaymentPageComponents.isSearchResultCalenderIconViewd(), is(true));

      assertThat("Reconcilation Banking Table Displayed",
               pKgReconcilationPaymentPageComponents.isSearchResultDateView(), is(true));

      assertThat("Reconcilation Banking Table Displayed",
               pKgReconcilationPaymentPageComponents.isSearchResultReconiliationId(), is(true));
   }

}
