package uk.co.tui.cdaf.frontend.pom.wr.search.enums;

import lombok.Getter;

@Getter
public enum StayDuration
{
   NIGHTS_2("2115"),
   NIGHTS_3("3115"),
   NIGHTS_4("4115"),
   NIGHTS_5("5115"),
   NIGHTS_6("6115"),
   NIGHTS_7("7115"),
   NIGHTS_8("8115"),
   NIGHTS_9("9115"),
   NIGHTS_10("1015"),
   NIGHTS_11("1115"),
   NIGHTS_14("1415"),
   MORE_THAN_14("1515");

   private final String numberOfNights;

   StayDuration(String numberOfNights)
   {
      this.numberOfNights = numberOfNights;
   }

}
