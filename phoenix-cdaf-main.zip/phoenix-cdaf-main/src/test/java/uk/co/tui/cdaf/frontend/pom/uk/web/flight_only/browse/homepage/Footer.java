package uk.co.tui.cdaf.frontend.pom.uk.web.flight_only.browse.homepage;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class Footer extends AbstractPage
{

   private static final AutomationLogManager LOGGER = new AutomationLogManager(Footer.class);

   @FindAll({ @FindBy(xpath = "(//footer|*[@id='utility'])[1]"), @FindBy(css = "#footer") })
   private WebElement footerSection;

   @FindAll({
            @FindBy(css = "#footer"),
            @FindBy(css = ".footerSection")
   })
   private WebElement footerNew;

   public Footer()
   {
      LOGGER.log(LogLevel.TRACE, "Initializing footer");
   }

   public void scrollToFooter()
   {
      LOGGER.log(LogLevel.INFO, "Scrolling to footer");
      int y = footerSection.getLocation().getY();
      JavascriptExecutor js = (JavascriptExecutor) getDriver();
      js.executeScript("window.scrollTo(0," + y + ")");
      LOGGER.log(LogLevel.INFO, "Scrolled to footer");
   }

   public boolean isFooterDisplayed()
   {
      return footerNew.isDisplayed();
   }

}
