package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSingleAccomHotelCardStepDefs extends AbstractPage
{

   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   public PackageSingleAccomHotelCardStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
   }

   @When("they review the top of the single accom page")
   public void they_review_the_top_of_the_single_accom_page()
   {
      assertThat("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed(), is(true));
   }

   @Then("they can see a hotel details card")
   public void they_can_see_a_hotel_details_card()
   {
      assertThat("Hotel details are not present in the card",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed(), is(true));
   }

   @Then("its contents are:")
   public void its_contents_are(List<String> componentNames)
   {
      Map<String, WebElement> AvailableHotelDetailsElement =
               searchResultsPage.singleAccommodationComponent
                        .getHotelCardDetailsWebElement(componentNames);
      for (Entry<String, WebElement> entry : AvailableHotelDetailsElement.entrySet())
      {
         assertThat(entry.getKey() + " is not displayed",
                  searchResultsPage.singleAccommodationComponent.isElementDisplayed(
                           entry.getValue()),
                  is(true));
      }
   }

}
