package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class PriceSummaryPanelComponent extends AbstractPage
{

   private final WebElementWait wait;

   @FindBy(xpath = "//div[contains(@class,'summaryButton')]/button")
   private WebElement continueButton;

   @FindBy(css = "div[class*='summaryDropdown']")
   private WebElement priceSummaryDropdown;

   @FindBy(css = "[class*='PriceSummaryPanel__title']+ul>li")
   private List<WebElement> flightExtras;

   @FindBy(css = "div[class*='PriceSummaryPanel__pricePanelWrapper'] [aria-label*='total price part-1']")
   private WebElement totalPrice;

   @FindBy(css = "div[class*='PriceSummaryPanel__summaryCloseBtn']")
   private WebElement priceSummaryCloseBtn;

   @FindBy(css = "[aria-label*='flightLuggage']")
   private List<WebElement> flightExtraType;

   public PriceSummaryPanelComponent()
   {
      wait = new WebElementWait();
   }

   public String getTotalPriceValue()
   {
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(totalPrice));
   }

   public WebElement getPriceSummaryDropdown()
   {
      return wait.getWebElementWithLazyWait(priceSummaryDropdown);
   }

   public void clickOnPriceSummary()
   {
      WebElementTools.click(getPriceSummaryDropdown());
   }

   public boolean isFlightExtrasDisplayed()
   {
      try
      {
         wait.forJSExecutionReadyLazy();
         return WebElementTools.isPresent(flightExtras.get(2));
      }
      catch (Exception e)
      {
         return false;
      }
   }

   public void clickOnPriceSummaryCloseBtn()
   {
      $(priceSummaryCloseBtn).click();
   }

   public List<WebElement> getFlightsExtrasElement()
   {
      return wait.getWebElementWithLazyWait(flightExtraType);
   }

}
