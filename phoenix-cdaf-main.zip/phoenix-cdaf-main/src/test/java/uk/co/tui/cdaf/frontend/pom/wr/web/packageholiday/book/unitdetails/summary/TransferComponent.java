package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;
import java.util.Map;

public class TransferComponent extends AbstractPage
{
   private final Map<String, WebElement> transferMap;

   @FindBy(css = "[aria-label*='transfers component'] h2")
   private WebElement transferTitle;

   @FindBy(css = "")
   private WebElement transferType;

   public TransferComponent()
   {
      transferMap = new HashMap<>();
   }

   public Map<String, WebElement> getTransferComponents()
   {
      transferMap.put("YOUR TRANSFERS", transferTitle);
      transferMap.put("Type of Transfer", transferType);
      return transferMap;
   }

}
