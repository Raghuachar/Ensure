package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.DynamicFlightComponent;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class DynamicFlightChangesStpeDef
{

   public final PackageNavigation packageNavigation;

   public final DynamicFlightComponent dynamicFlightComponent;

   public DynamicFlightChangesStpeDef()
   {
      packageNavigation = new PackageNavigation();
      dynamicFlightComponent = new DynamicFlightComponent();
   }

   @Given("that the customer is booking a package")
   public void that_the_customer_is_booking_a_package()
   {
      packageNavigation.navigateTosummaryPage();
   }

   @When("they navigate to the Customise page")
   public void they_navigate_to_the_Customise_page()
   {
      dynamicFlightComponent.isDynamicFlight();
   }

   @Then("the flight card should display the carrier information <Name>")
   public void the_flight_card_should_display_the_carrier_information_Name()
   {
      assertThat("The flight is not transavia", dynamicFlightComponent.isCareerInfoTransavia(),
               is(true));
   }

   @Given("that a customer is making a Booking with dynamic flight types \\(Transavia)")
   public void that_a_customer_is_making_a_Booking_with_dynamic_flight_types_Transavia()
   {
      packageNavigation.navigateTosummaryPage();
   }

   @When("they navigate to the summary Page")
   public void they_navigate_to_the_summary_Page()
   {
      dynamicFlightComponent.isDynamicFlight();
   }

   @Then("the flight card should display the text Direct for the respective inbound and outbound flight")
   public void the_flight_card_should_display_the_text_Direct_for_the_respective_inbound_and_outbound_flight()
   {
      assertThat("The inbound flight type is not direct",
               dynamicFlightComponent.isDirectInboundFlight(), is(true));
      assertThat("The outbound flight type is not direct",
               dynamicFlightComponent.isDirectOutboundFlight(), is(true));
   }

   @When("they navigate to the extras Page")
   public void they_navigate_to_the_extras_Page()
   {
      packageNavigation.navigateToExtrasPage();
      dynamicFlightComponent.isDynamicFlight();
   }

   @Then("they should not see the fuel protection insurance on the page")
   public void they_should_not_see_the_fuel_protection_insurance_on_the_page()
   {
      assertThat("The Fuel Fee component is not displayed",
               dynamicFlightComponent.isFuelFeeProtectionComponentPresent(), is(false));
   }

   @Then("they should see following details")
   public void they_should_see_following_details(List<String> stringList)
   {
      assertThat("The Insurance component is displayed",
               dynamicFlightComponent.isInsuranceComponentPresent(), is(false));
   }

   @When("they view their flight details on the flight cards")
   public void they_view_their_flight_details_on_the_flight_cards()
   {
      dynamicFlightComponent.isFlightDetailsPresent();
   }

   @Then("a link indicating there are Terms & Conditions for non-TU flights should be displayed on the flight card")
   public void a_link_indicating_there_are_Terms_Conditions_for_non_TU_flights_should_be_displayed_on_the_flight_card()
   {
      assertThat("The Terms and Conditions component is displayed",
               dynamicFlightComponent.isTermsAndConditionsPresent(), is(false));
   }
}
