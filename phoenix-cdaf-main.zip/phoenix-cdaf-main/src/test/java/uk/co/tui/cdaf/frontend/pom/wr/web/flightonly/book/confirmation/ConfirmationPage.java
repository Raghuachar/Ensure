package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class ConfirmationPage extends AbstractPage
{

   private static String departureDate;

   private static String date;

   public final WebDriverUtils utils;

   public final WebElementWait wait;

   public final ExcursionComponent excursionComponent;

   public final TUIAppComponent tuiAppComponent;

   public final PassengerDetailsComponent passengerDetailComponent;

   public final FlightSummaryComponent flightSummary;

   private final Map<String, WebElement> confirmationMap;

   @FindBy(css = "[title='Google Play Logo']")
   private WebElement googlePlayTitle;

   @FindBy(css = "[class*='title__product']")
   private WebElement appStoreTitle;

   @FindBy(css = "[class*='bookingReference']")
   private WebElement bookingReferenceTitle;

   @FindBy(css = "span[class*='referenceID']")
   private WebElement bookingReferenceID;

   @FindBy(css = "[aria-label*='pax composition']")
   private WebElement pax;

   public ConfirmationPage()
   {
      confirmationMap = new HashMap<>();
      utils = new WebDriverUtils();
      wait = new WebElementWait();
      excursionComponent = new ExcursionComponent();
      tuiAppComponent = new TUIAppComponent();
      passengerDetailComponent = new PassengerDetailsComponent();
      flightSummary = new FlightSummaryComponent();
   }

   public boolean isBookingRefTitleDisplayed()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(bookingReferenceTitle));
   }

   public boolean excursionUrlVerification(String url)
   {
      WebElementTools.switchToLastOpenBrowserTab();
      wait.forJSExecutionReadyLazy();
      return WebDriverUtils.checkSiteURL(url);
   }

   public boolean isGooglePlayDisplayed()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(googlePlayTitle));
   }

   public boolean isAppStoreDisplayed()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(appStoreTitle));
   }

   public Map<String, WebElement> getConfirmationComponents()
   {
      confirmationMap.put("Passenger Information",
               passengerDetailComponent.getPassengerDetailsElement());
      confirmationMap.putAll(flightSummary.getFlightSummaryComponents());
      confirmationMap.putAll(tuiAppComponent.getTuiAppComponents());
      confirmationMap.putAll(excursionComponent.getExursionComponents());
      return confirmationMap;
   }

   public WebElement getBookRefIdElement()
   {
      return wait.getWebElementWithLazyWait(bookingReferenceID);
   }

   public String getBookRefId()
   {
      return WebElementTools.getElementText(getBookRefIdElement());
   }

   public String confirmationPageComponents(String ignore)
   {
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(pax));
   }

}
