package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;
import java.util.Map;

public class HomeStayEmergencyComponent extends AbstractPage
{
   @FindBy(css = "[class*='emergencyContactinfo']")
   private WebElement emergencyContactInfo;

   @FindBy(css = "div[class*='EmergencyContact'] input[aria-label='ACHTERNAAM']")
   private WebElement emergencyContactSurnameField;

   @FindBy(css = "div[class*='EmergencyContact'] input[name*='stayHomemobileNum']")
   private WebElement emergencyContactMobileField;

   @FindBy(css = "div[class*='EmergencyContact'] [class*='tooltips']")
   private WebElement emergencyContactTooltip;

   @FindAll({ @FindBy(css = "select[name='stayHomephonecode']"),
            @FindBy(css = "div[class*='EmergencyContact'] div[class*='inputs__select'] select"),
            @FindBy(css = "div[class*='EmergencyContact'] select[aria-label='Mobile Phone']") })
   private WebElement emergencyContactCtryDropdown;

   @SuppressWarnings("serial")
   public Map<String, WebElement> getEmergencyContactComponents()
   {
      return new HashMap<>()
      {
         {
            put("Emergency contact info", emergencyContactInfo);
            put("Emergency contact surname", emergencyContactSurnameField);
            put("Emergency contact mobilenum", emergencyContactMobileField);
            put("Emergency contact ctry code dropdown", emergencyContactCtryDropdown);
            put("Emergency contact tooltip", emergencyContactTooltip);
         }
      };
   }

}
