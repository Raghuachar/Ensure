package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsTRatingFilter;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class TRatingFilterStepDefs
{
   static AutomationLogManager LOGGER = new AutomationLogManager(TRatingFilterStepDefs.class);

   public final PackageNavigation packageNavigation;

   private final SearchResultsTRatingFilter searchResultsTRatingFilter;

   public TRatingFilterStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsTRatingFilter = new SearchResultsTRatingFilter();
   }

   @Given("the user is on the package search results page")
   public void the_user_is_on_the_package_search_results_page()
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @When("they are viewing the Rating Filter")
   public void they_are_viewing_the_Rating_Filter()
   {
      assertThat("Tui rating component is not present",
               searchResultsTRatingFilter.isTRatingDisplayed(), is(true));
   }

   @Then("they will see the following ratings that they can filter by")
   public void they_will_see_the_following_ratings_that_they_can_filter_by(
            List<String> ratingFilters)
   {
      for (String tRatingFilters : ratingFilters)
      {
         if (tRatingFilters.equalsIgnoreCase("T and over"))
            assertThat("T and over component is not present",
                     searchResultsTRatingFilter.getTRatingComponent(0), is(true));
         if (tRatingFilters.equalsIgnoreCase("TT and over"))
            assertThat("T and over component is not present",
                     searchResultsTRatingFilter.getTRatingComponent(1), is(true));
         if (tRatingFilters.equalsIgnoreCase("TTT and over"))
            assertThat("TTT and over component is not present",
                     searchResultsTRatingFilter.getTRatingComponent(2), is(true));
         if (tRatingFilters.equalsIgnoreCase("TTTT and over"))
            assertThat("TTTT and over component is not present",
                     searchResultsTRatingFilter.getTRatingComponent(3), is(true));
         if (tRatingFilters.equalsIgnoreCase("TTTTT"))
            assertThat("TTTTT component is not present",
                     searchResultsTRatingFilter.getTRatingComponent(4), is(true));
      }

   }

   @And("these will be in an unselected state by Default")
   public void these_will_be_in_an_unselected_state_by_Default()
   {
      assertThat("Tui rating component selected state by default",
               searchResultsTRatingFilter.isDefaultUnselected(), is(true));
   }

   @When("there are no results available for a specific filter\\(s)")
   public void there_are_no_results_available_for_a_specific_filter_s()
   {
      searchResultsTRatingFilter.disabledTRating();
   }

   @Then("the specific filter\\(s) will be greyed out")
   public void the_specific_filter_s_will_be_greyed_out()
   {
      searchResultsTRatingFilter.disabledTRating();
   }

   @Then("the customer will not be able to select this")
   public void the_customer_will_not_be_able_to_select_this()
   {
      assertThat("results are available for a specific filter",
               searchResultsTRatingFilter.clickTRating(), is(false));
   }

   @When("they select a rating")
   public void they_select_a_rating()
   {
      searchResultsTRatingFilter.selectTRating();
   }

   @Then("they can select {int} rating")
   public void they_can_select_rating(Integer int1)
   {
      searchResultsTRatingFilter.changeTRating();
   }

   @Then("the search results will Filter to reflect the selection")
   public void the_search_results_will_Filter_to_reflect_the_selection()
   {
      LOGGER.log(LogLevel.INFO, searchResultsTRatingFilter.tRatingText());
      assertThat("Filterpanel component is not present",
               searchResultsTRatingFilter.searchResultTRatingVerification(), is(true));
   }

   @Then("the clear filters links will show")
   public void the_clear_filters_links_will_show()
   {
      searchResultsTRatingFilter.isClearFilterLinkDisplayed();
   }

   @Given("they have filtered the ratings")
   public void they_have_filtered_the_ratings()
   {
      assertThat("Tui rating component is not present",
               searchResultsTRatingFilter.isTRatingDisplayed(), is(true));
      searchResultsTRatingFilter.changeTRating();
   }

   @When("they want to clear the ratings selection")
   public void they_want_to_clear_the_ratings_selection()
   {
      assertThat("Clear link is not present",
               searchResultsTRatingFilter.isClearFilterLinkDisplayed(), is(true));
   }

   @Then("they will be able select Clear all")
   public void they_will_be_able_select_Clear_all()
   {
      searchResultsTRatingFilter.isClearAllFilterLinkDisplayed();
   }

   @When("they select the Trating filter")
   public void they_select_the_Trating_filter()
   {
      searchResultsTRatingFilter.clickTRatingModal();
   }

   @Then("the filter options will open in a Modal")
   public void the_filter_options_will_open_in_a_Modal()
   {
      assertThat("Tui rating component is not present",
               searchResultsTRatingFilter.isTRatingDisplayed(), is(true));
   }

   @Then("the customer can select the ratings they wish to filter by")
   public void the_customer_can_select_the_ratings_they_wish_to_filter_by()
   {
      searchResultsTRatingFilter.changeTRating();
   }

   @Given("they are viewing the ratings Filter modal")
   public void they_are_viewing_the_ratings_Filter_modal()
   {
      assertThat("Tui rating component is not present",
               searchResultsTRatingFilter.isTRatingDisplayed(), is(true));
   }

   @When("they wish to close the Modal")
   public void they_wish_to_close_the_Modal()
   {
      assertThat("clear link is not present", searchResultsTRatingFilter.isClearFilterLinkModal(),
               is(true));
   }

   @Then("they can do this by Tratings selecting the following")
   public void they_can_do_this_by_Tratings_selecting_the_following(List<String> components)
   {
      components.forEach(component ->
               assertThat("close options not available:",
                        searchResultsTRatingFilter.closeModal(component), is(true)));
   }

   @Then("the search results will filter to reflect the selection mode")
   public void the_search_results_will_filter_to_reflect_the_selection_mode()
   {
      searchResultsTRatingFilter.clickApplyButton();
      assertThat("Filterpanel component is not present",
               searchResultsTRatingFilter.searchResultTRatingVerification(), is(true));
   }

   @Then("the filter will show in a selected state if selections have been made")
   public void the_filter_will_show_in_a_selected_state_if_selections_have_been_made()
   {
      assertThat("T Rating filter will not show as a selected state",
               searchResultsTRatingFilter.isTRatingDisplayed(), is(true));
   }

   @And("they have filtered the ratings the modal")
   public void they_have_filtered_the_ratings_the_modal()
   {
      assertThat("Tui rating component is not present",
               searchResultsTRatingFilter.isTRatingDisplayed(), is(true));
      searchResultsTRatingFilter.clickTRatingModal();
      searchResultsTRatingFilter.changeTRating();
   }

   @When("they want to clear the ratings selection Modal")
   public void they_want_to_clear_the_ratings_selection_Modal()
   {
      assertThat("Clear link is not present", searchResultsTRatingFilter.isClearFilterLinkModal(),
               is(true));
   }

   @Then("they will be able select clear from the ratings modal")
   public void they_will_be_able_select_clear_from_the_ratings_modal()
   {
      searchResultsTRatingFilter.clickClearModal();
   }

   @Given("they have filtered the results")
   public void they_have_filtered_the_results()
   {
      assertThat("Tui rating component is not present",
               searchResultsTRatingFilter.isTRatingDisplayed(), is(true));
      searchResultsTRatingFilter.clickTRatingModal();
      searchResultsTRatingFilter.changeTRating();
      searchResultsTRatingFilter.clickApplyButton();
   }

   @When("they want to clear the filter selections")
   public void they_want_to_clear_the_filter_selections()
   {
      assertThat("More Filter component is not present",
               searchResultsTRatingFilter.isMoreFilterDisplayed(), is(true));
   }

   @Then("they will be able select Clear all from the {string} Modal")
   public void they_will_be_able_select_Clear_all_from_the_Modal(String moreFilter)
   {
      assertThat("Compare moreFilter component on search results is not present",
               searchResultsTRatingFilter.moreFiltersTextCompare(moreFilter), is(true));
      searchResultsTRatingFilter.clickMoreFilters();
      searchResultsTRatingFilter.clearAllModel();
   }
}
