package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class MFESearchPanelDurationStepDefs
{

   private final PackageNavigation packageNavigation = new PackageNavigation();

   private final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent =
            new DepartureAirportAndDestinationAndDatesComponent();

   @When("they select one of the following {string} on the Search Panel Duration field")
   public void they_select_one_of_the_following_on_the_Search_Panel_Duration_field(String string)
   {
      if (string.equalsIgnoreCase("Duration field"))
         departureAirportOrDestinationComponent.selectMfeDurationField();

      if (string.equalsIgnoreCase("Duration Arrow"))
         departureAirportOrDestinationComponent.selectMfeDurationArrow();
   }

   @Given("the Duration field is set to its default value")
   public void the_Duration_field_is_set_to_its_default_value(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> dataMap : dataTableTemp)
      {
         if (dataMap.get("SiteID").equals("nl-BE"))
         {
            departureAirportOrDestinationComponent.selectLanguage("nl-BE");
            dataMap.get("Duration")
                     .contains(departureAirportOrDestinationComponent.getMfeDefaultDurationValue());
         }
      }
   }

   @Then("the Duration dropdown list shall be displayed")
   public void the_Duration_dropdown_list_shall_be_displayed()
   {
      assertThat("the Duration dropdown list shall not displayed",
               departureAirportOrDestinationComponent.isMfeDurationModalDisplayed(), is(true));
   }

   @Then("the Duration dropdown list shall display the following options:")
   public void the_Duration_dropdown_list_shall_display_the_following_options(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> dataMap : dataTableTemp)
      {
         if (dataMap.get("SiteID").equals("nl-BE"))
         {
            departureAirportOrDestinationComponent.selectLanguage("nl-BE");
            assertThat("the Duration dropdown list shall not display the following options:",
                     departureAirportOrDestinationComponent
                              .isMfeDurationValuesPresent(dataMap.get("Duration")),
                     is(true));
         }
      }

   }

   @Then("the Search Panel default duration shall be set to selected in the dropdown list \\(e.g. {string} shall be highlighted in blue)")
   public void the_Search_Panel_default_duration_shall_be_set_to_selected_in_the_dropdown_list_e_g_shall_be_highlighted_in_blue(
            String string)
   {
      assertThat(String.format(
                        "the Search Panel default duration shall be set to not selected in the dropdown list )",
                        string), departureAirportOrDestinationComponent.getMfeDurationListValue(),
               is(string));
   }

   @And("the {string} is viewing the duration dropdown list")
   public void the_is_viewing_the_duration_dropdown_list(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
      departureAirportOrDestinationComponent.selectMfeDurationField();
   }

   @When("the select a duration from the list")
   public void the_select_a_duration_from_the_list()
   {
      departureAirportOrDestinationComponent.getMfeDurationDropdownFirstValue();
   }

   @Then("the Search Panel Duration field shall be set to the selected Duration dropdown list value")
   public void the_Search_Panel_Duration_field_shall_be_set_to_the_selected_Duration_dropdown_list_value()
   {
      assertThat(
               "the Search Panel Duration field shall not set to the selected Duration dropdown list value",
               departureAirportOrDestinationComponent.getMfeDurationSelectdValue(), is(true));
   }

   @Then("the selected duration shall be retained on the Duration dropdown list \\(i.e. highlighted in blue next time the duration dropdown list is viewed)")
   public void the_selected_duration_shall_be_retained_on_the_Duration_dropdown_list_i_e_highlighted_in_blue_next_time_the_duration_dropdown_list_is_viewed()
   {
      assertThat("Not highlighted in blue next time the duration dropdown list is viewed",
               departureAirportOrDestinationComponent.highlightedSelectedListValue(), is(true));
   }
}
