package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class SearchResultsTRatingFilter extends AbstractPage
{
   public WebElementWait wait;

   @FindAll({ @FindBy(css = "[class='inputs__radioButton undefined  '] input:disabled") })
   public List<WebElement> greyed;

   @FindBy(css = "[class=BoardBasis__clearLink]")
   public List<WebElement> clearFilters;

   @FindBy(css = "[class=DropModal__clear]")
   public List<WebElement> clearFilterModal;

   private String value = "";

   @FindBy(css = ".Components__tRatingBlock label input:not(:disabled)+span+span span[aria-label='ratings']")
   private List<WebElement> tRatingComponents;

   @FindBy(css = "[class='Components__tRatingContainer Components__v2'] label")
   private List<WebElement> tRatingFilterComponents;

   @FindAll({ @FindBy(css = "[aria-label*='rating filter']"),
            @FindBy(css = "[class*='Components__tRatingContainer Components__v2']") })
   private WebElement tRating;

   @FindBy(css = ".FilterPanelV2__clearAll")
   private WebElement clearAllFilters;

   @FindAll({
            @FindBy(css = "[class='ratings__rating ratings__small ResultListItemV2__tuiRating ']"),
            @FindBy(css = "[class='ratings__rating ratings__small ResultListItemV2__tuiRating']") })
   private List<WebElement> tRatingInSearchResults;

   @FindBy(css = ".DropModal__filterModalWindow:nth-child(1) .DropModal__close")
   private WebElement xWindow;

   @FindBy(css = ".DropModal__dropModalContent:nth-child(1) .DropModal__footerContainer button[role='button']")
   private List<WebElement> applyButton;

   @FindBy(css = ".DropModal__dropModalContent:nth-child(1) .DropModal__footerContainer a")
   private List<WebElement> clearButtonTRatings;

   @FindBy(css = "[aria-label='More filter']")
   private WebElement moreFiltersModel;

   @FindBy(css = "[class='MoreFilters__contentAlign contentWidth'] div a[class='MoreFilters__clear']")
   private WebElement clearAllModel;

   public SearchResultsTRatingFilter()
   {
      wait = new WebElementWait();
   }

   public boolean isTRatingDisplayed()
   {
      return WebElementTools.isPresent(getTRatingFilter());
   }

   public WebElement getTRatingFilter()
   {
      return wait.getWebElementWithLazyWait(tRating);
   }

   public boolean getTRatingComponent(int rating)
   {
      return WebElementTools.isPresent(tRatingFilterComponents.get(rating));
   }

   public boolean isDefaultUnselected()
   {
      boolean filter = true;
      for (WebElement tRatingComponent : tRatingComponents)
      {
         filter = WebElementTools.isPresent(tRatingComponent);
      }
      return filter;
   }

   public boolean disabledTRating()
   {
      return !greyed.isEmpty();
   }

   public boolean clickTRating()
   {
      return WebElementTools.isPresent(greyed.get(0));
   }

   public void selectTRating()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(tRatingComponents.get(0));
   }

   public void changeTRating()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(tRatingComponents.get(0));
   }

   public String tRatingText()
   {
      setValue(tRatingComponents.get(0).getText());
      return tRatingComponents.get(0).getText();
   }

   public boolean searchResultTRatingVerification()
   {
      boolean value = false;
      for (WebElement tRatingName : tRatingInSearchResults)
      {
         String tuiRating = tRatingName.getText();
         if (getValue().equalsIgnoreCase(tuiRating))
         {
            value = true;
         }
      }
      return value;
   }

   public String getValue()
   {
      return value;
   }

   public void setValue(String value)
   {
      this.value = value;
   }

   public boolean isClearFilterLinkDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(clearFilters.get(0));
   }

   public boolean isClearFilterLinkModal()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(clearFilterModal.get(4));
   }

   public void isClearAllFilterLinkDisplayed()
   {
      WebElementTools.click(clearAllFilters);
   }

   public void clickTRatingModal()
   {
      WebElementTools.click(tRating);
   }

   public boolean closeModal(String component)
   {
      wait.forJSExecutionReadyLazy();
      if (StringUtils.containsIgnoreCase(component, "x"))
         return WebElementTools.isPresent(xWindow);
      if (StringUtils.containsIgnoreCase(component, "Apply"))
         return WebElementTools.isPresent(applyButton.get(4));
      return true;
   }

   public void clickApplyButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(applyButton.get(4));
   }

   public void clickClearModal()
   {
      wait.forJSExecutionReadyLazy();
      if (clearButtonTRatings.get(4) != null)
      {
         WebElementTools.clickElementJavaScript(clearButtonTRatings.get(4));
      }
   }

   public boolean isMoreFilterDisplayed()
   {
      return WebElementTools.isPresent(moreFiltersModel);
   }

   public boolean moreFiltersTextCompare(String moreFilter)
   {
      wait.waitForElementToBePresent(moreFiltersModel);
      return moreFiltersModel.getText().equals(moreFilter);
   }

   public void clickMoreFilters()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(0, 0);
      WebElementTools.clickElementJavaScript(moreFiltersModel);
   }

   public void clearAllModel()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(clearAllModel);
   }

   public void changeFiveTRating()
   {
      wait.forJSExecutionReadyLazy();
      if (tRatingComponents.size() > 2)
         WebElementTools.click(tRatingComponents.get(2));
      if (tRatingComponents.size() > 1)
         WebElementTools.click(tRatingComponents.get(1));
   }
}
