package uk.co.tui.cdaf.frontend.stepdefs.wr.retail;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;

public class RetailPackageSmokeStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(RetailPackageSmokeStepDefs.class);

   public final PackageNavigation packageNavigation;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   public final SummaryPage summaryPage;

   public RetailPackageSmokeStepDefs()
   {
      summaryPage = new SummaryPage();
      packageNavigation = new PackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @And("they navigate to the Passenger Page")
   public void they_navigate_to_the_Passenger_Page()
   {
      summaryPage.navigationComponent.clickOnContinueButton();
      if (ExecParams.getAgent().isThirdparty())
         retailpassengerdetailspage.fillThePassengerDetailsThirdparty();
      if (ExecParams.getAgent().isInhouse())
         retailpassengerdetailspage.fillThePassengerDetailsInhouse();
   }

   @When("Payment is done and continue to booking page")
   public void they_navigate_to_the_Payment_Page()
   {
      if (ExecParams.getAgent().isInhouse())
         retailpassengerdetailspage.skippayment();
      if (ExecParams.getAgent().isThirdparty())
         LOGGER.log(LogLevel.INFO, "thirdparty");
   }

}
