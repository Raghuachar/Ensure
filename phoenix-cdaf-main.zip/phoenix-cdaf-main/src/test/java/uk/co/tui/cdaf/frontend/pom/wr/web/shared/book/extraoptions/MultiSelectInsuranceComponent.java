package uk.co.tui.cdaf.frontend.pom.wr.web.shared.book.extraoptions;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchCustom;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class MultiSelectInsuranceComponent
         extends uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.InsuranceComponent
{

   private static final String PER_PERSON_PASSENGER_LABEL_CLASS =
            "PerPersonSelectList__passengerLabel";

   private static final String INSURANCE_CARD_CLASS = "InsuranceType__selectableCard";

   private static final String PER_PERSON_CHECKBOX_CLASS = "PerPersonSelectList__checkbox";

   private static final String PER_PERSON_CHECKBOX_INPUT_CLASS =
            "PerPersonSelectList__checkboxInput";

   private static final String MULTI_INSURANCE_SUMMARY_PASSENGER_NAME_CLASS =
            "MultiInsuranceSummary__passengerName";

   private static final String MULTI_INSURANCE_SUMMARY_INSURANCE_CLAS =
            "MultiInsuranceSummary__insurance";

   public final WebElementWait wait;

   private final SearchDataHelper searchDataHelper;

   private final SearchCustom searchCustom;

   public static final ThreadLocal<Double> selectedInsurancesPrice = new ThreadLocal<>();

   @FindBy(css = "[class*='expInsurance']")
   private WebElement insuranceComponent;

   @FindBy(css = "[aria-label=\"passenger checkbox\"] .inputs__box")
   private List<WebElement> passengerCheckbox;

   @FindBy(css = ".InfantCheckbox .inputs__box")
   private List<WebElement> infantCheckbox;

   @FindBy(xpath = "//div[@class='GetQuoteV2__passenger']/div[not(contains(@class, 'InfantCheckbox'))]" +
            "/div[@class='GetQuoteV2__checkboxField' and not(contains(@aria-label, 'passenger checkbox'))]" +
            "//span[@class='inputs__text']")
   private List<WebElement> childCheckbox;

   @FindBy(css = "[aria-label= 'day']")
   private List<WebElement> paxDOBDay;

   @FindBy(css = "[aria-label= 'month']")
   private List<WebElement> paxDOBMonth;

   @FindBy(css = "[aria-label= 'year']")
   private List<WebElement> paxDOBYear;

   @FindBy(xpath = "//span[@class='GetQuoteV2__age']" +
            "/parent::div[@class='GetQuoteV2__checkboxField']" +
            "/following-sibling::div[@class='GetQuoteV2__dobField']" +
            "//input[@aria-label= 'day']")
   private List<WebElement> childDOBDay;

   @FindBy(xpath = "//span[@class='GetQuoteV2__age']" +
            "/parent::div[@class='GetQuoteV2__checkboxField']" +
            "/following-sibling::div[@class='GetQuoteV2__dobField']" +
            "//input[@aria-label= 'month']")
   private List<WebElement> childDOBMonth;

   @FindBy(xpath = "//span[@class='GetQuoteV2__age']" +
            "/parent::div[@class='GetQuoteV2__checkboxField']" +
            "/following-sibling::div[@class='GetQuoteV2__dobField']" +
            "//input[@aria-label= 'year']")
   private List<WebElement> childDOBYear;

   @FindBy(css = ".InfantCheckbox input[aria-label='day']")
   private List<WebElement> infantDOBDay;

   @FindBy(css = ".InfantCheckbox input[aria-label='month']")
   private List<WebElement> infantDOBMonth;

   @FindBy(css = ".InfantCheckbox input[aria-label='year']")
   private List<WebElement> infantDOBYear;

   @FindBy(css = "[class*='GetQuoteV2__button']")
   private WebElement chooseInsuranceEnabledButton;

   @FindBy(css = ".InsuranceCoverV2__header span")
   private WebElement changeSelectionLink;

   @FindBy(css = "[class*='InsuranceType__insuranceCard']")
   private List<WebElement> insuranceTypeSections;

   @FindBy(css = "[class*='Selectable__selectableCard InsuranceType__selectableCard']")
   private List<WebElement> insuranceCards;

   @FindBy(css = "[class*='AccordionToggle__accordionToggle MultiInsuranceSummary__accordionTitle']")
   private WebElement selectedInsurancesAccordion;

   @FindBy(css = "[class*='MultiInsuranceSummary__accordionTitleIconCollapsed']")
   private WebElement selectedInsuranceAccordionCollapsed;

   @FindBy(xpath = "//div[@class='MultiInsuranceSummary__wrapper']//div[text()]")
   private WebElement noInsuranceSelected;

   @FindBy(css = "button[class*='ReviewInsurancePricesButtons__button']")
   private WebElement reviewConfirmButton;

   @FindBy(css = "[class*='ConfirmationPopup__popup'] [aria-label='modal title']")
   private WebElement reviewConfirmModalTitle;

   @FindBy(css = ".Modal__modalBody [class*='__passengerName']")
   private List<WebElement> reviewConfirmModalPassengersNames;

   @FindBy(css = ".Modal__modalBody [class*='MultiInsuranceSummary__insurance']")
   private List<WebElement> reviewConfirmModalInsuranceTitles;

   @FindBy(css = ".Modal__modalBody [class*='MultiInsuranceSummary__price']")
   private List<WebElement> reviewConfirmModalInsurancePrices;

   @FindBy(css = ".Modal__modalBody [class*='__totalCost'] > span")
   private WebElement reviewConfirmModalTotalPriceLabel;

   @FindBy(css = ".Modal__modalBody [class*='__formattedPrice']")
   private WebElement reviewConfirmModalTotalPrice;

   @FindBy(css = ".Modal__applyButton")
   private WebElement modalConfirmButton;

   @FindBy(css = ".Modal__cancelLink")
   private WebElement modalCancelButton;

   @FindBy(css = ".BackToYourHolidayLinkComponent__continue span")
   private WebElement returnToYourHolidayLink;

   public MultiSelectInsuranceComponent()
   {
      wait = new WebElementWait();
      searchDataHelper = new SearchDataHelper();
      searchCustom = new SearchCustom();
   }

   public void clickChooseInsuranceButton()
   {
      WebElementTools.mouseOverAndClick(chooseInsuranceEnabledButton);
      wait.forJSExecutionReadyLazy();
   }

   public void clickChangeSelectionLink()
   {
      WebElementTools.mouseOverAndClick(changeSelectionLink);
      wait.forJSExecutionReadyLazy();
   }

   private String[] getCurrentDate()
   {
      return LocalDate.now().toString().split("-");
   }

   private String[] getCurrentDateMinusYears(long years)
   {
      return LocalDate.now().minusYears(years).toString().split("-");
   }

   private void setAdultDOBData(int paxIndex, String day, String month, String year)
   {
      WebElementTools.scrollToCenter(insuranceComponent);
      WebElementTools.mouseOverAndClick(passengerCheckbox.get(paxIndex));
      WebElementTools.enterText(paxDOBDay.get(paxIndex), day);
      WebElementTools.enterText(paxDOBMonth.get(paxIndex), month);
      WebElementTools.enterText(paxDOBYear.get(paxIndex), year);
      WebElementTools.mouseOverAndClick(paxDOBDay.get(paxIndex));
      wait.forJSExecutionReadyLazy();
   }

   private void setChildDOBData(int paxIndex, String day, String month, String year)
   {
      WebElementTools.scrollToCenter(insuranceComponent);
      WebElementTools.mouseOverAndClick(childCheckbox.get(paxIndex));
      WebElementTools.enterText(childDOBDay.get(paxIndex), day);
      WebElementTools.enterText(childDOBMonth.get(paxIndex), month);
      WebElementTools.enterText(childDOBYear.get(paxIndex), year);
      WebElementTools.mouseOverAndClick(childDOBDay.get(paxIndex));
      wait.forJSExecutionReadyLazy();
   }

   private void setInfantDOBData(int paxIndex, String day, String month, String year)
   {
      WebElementTools.scrollToCenter(insuranceComponent);
      WebElementTools.mouseOverAndClick(infantCheckbox.get(paxIndex));
      WebElementTools.enterText(infantDOBDay.get(paxIndex), day);
      WebElementTools.enterText(infantDOBMonth.get(paxIndex), month);
      WebElementTools.enterText(infantDOBYear.get(paxIndex), year);
      WebElementTools.mouseOverAndClick(infantDOBDay.get(paxIndex));
      wait.forJSExecutionReadyLazy();
   }

   public void enterAdultDOB(int years, int paxIndex)
   {
      String[] dateParts = getCurrentDateMinusYears(years);
      setAdultDOBData(paxIndex, dateParts[2], dateParts[1], dateParts[0]);
   }

   public void enterAdultsDOB(int paxAmount)
   {
      String[] dateParts = getCurrentDateMinusYears(30);
      for (int i = 0; i < paxAmount; i++)
      {
         setAdultDOBData(i, dateParts[2], dateParts[1], dateParts[0]);
      }
   }

   public void enterChildrenDOB(int childrenAmount)
   {
      for (int i = 0; i < childrenAmount; i++)
      {
         String[] dateParts = getCurrentDateMinusYears(Long.parseLong(getChildrenAgeInDOBComponent().get(i)));
         setChildDOBData(i, dateParts[2], dateParts[1], dateParts[0]);
      }
   }

   public void enterInfantUnderOneYearDOB(int infantIndex)
   {
      LocalDate date = LocalDate.now().minusMonths(1);
      String[] dateParts = date.toString().split("-");
      setInfantDOBData(infantIndex, dateParts[2], dateParts[1], dateParts[0]);
   }

   public void enterAdultIncorrectDOBDay(int paxIndex)
   {
      String[] dateParts = getCurrentDate();
      setAdultDOBData(paxIndex, "00", dateParts[1], dateParts[0]);
   }

   public void enterAdultIncorrectDOBYear(int paxIndex)
   {
      String[] dateParts = getCurrentDate();
      setAdultDOBData(paxIndex, dateParts[2], dateParts[1], dateParts[0]);
   }

   public void enterChildIncorrectDOBYear(int paxIndex)
   {
      String[] dateParts = getCurrentDate();
      setChildDOBData(paxIndex, dateParts[2], dateParts[1], dateParts[0]);
   }

   public void enterInfantIncorrectDOBMonth(int paxIndex)
   {
      String[] dateParts = getCurrentDate();
      setInfantDOBData(paxIndex, dateParts[2], "13", dateParts[0]);
   }

   public int getCardsCount()
   {
      return insuranceCards.size();
   }

   public boolean isInsuranceCardDisplayed()
   {
      for (WebElement card : insuranceCards)
      {
         if (WebElementTools.isDisplayed(card))
         {
            return true;
         }
      }
      return false;
   }

   private List<WebElement> getCardsInSection(int sectionIndex)
   {
      return WebElementTools.getWebElementsByClass(insuranceTypeSections.get(sectionIndex),
               INSURANCE_CARD_CLASS);
   }

   public void selectInsuranceForPassenger(int sectionIndex, int cardIndex, int paxIndex)
   {
      WebElement insuranceElement = getCardInsuranceLabel(sectionIndex, cardIndex, paxIndex);
      WebElementTools.mouseOverAndClick(getCardInsTitle(sectionIndex, cardIndex));
      WebElementTools.mouseOverAndClick(
               WebElementTools.getWebElementByClass(insuranceElement, PER_PERSON_CHECKBOX_CLASS));
      wait.forJSExecutionReadyLazy();
   }

   private WebElement getCardInsuranceLabel(int sectionIndex, int cardIndex, int paxIndex)
   {
      return WebElementTools.getWebElementsByClass(getCardsInSection(sectionIndex).get(cardIndex),
               PER_PERSON_PASSENGER_LABEL_CLASS).get(paxIndex);
   }

   private List<SelenideElement> getCardsInSect(int sectionIndex)
   {
      return $$(".InsuranceType__insuranceCard").get(sectionIndex)
               .$$(".InsuranceType__selectableCard");
   }

   private SelenideElement getCardInsLabel(int sectionIndex, int cardIndex, int paxIndex)
   {
      return $$(getCardsInSect(sectionIndex).get(cardIndex)
               .$$(".PerPersonSelectList__passengerLabel")).get(paxIndex);
   }

   public SelenideElement getCardInsTitle(int sectionIndex, int cardIndex)
   {
      return getCardsInSect(sectionIndex).get(cardIndex).$$(".InsuranceType__title").first();
   }

   public boolean isInsuranceForPassengerSelected(int sectionIndex, int cardIndex, int paxIndex)
   {
      WebElement cardElement = WebElementTools.getWebElementByClass(
               getCardInsuranceLabel(sectionIndex, cardIndex, paxIndex),
               PER_PERSON_CHECKBOX_INPUT_CLASS);
      return WebElementTools.isChecked(cardElement);
   }

   public int getCountPassengersListedInCard(int cardIndex)
   {
      List<WebElement> passengerLabels = getCardPassengers(cardIndex);
      return passengerLabels.size();
   }

   private List<WebElement> getCardPassengers(int cardIndex)
   {
      return WebElementTools.getWebElementsByClass(insuranceCards.get(cardIndex),
               PER_PERSON_PASSENGER_LABEL_CLASS);
   }

   public boolean isPassengerCheckboxDisplayed(int cardIndex, int paxIndex)
   {
      List<WebElement> passengerLabels = WebElementTools.getWebElementsByClass(
               getCardPassengers(cardIndex).get(paxIndex), PER_PERSON_CHECKBOX_CLASS);
      return passengerLabels.size() == 1;
   }

   public ElementsCollection getExpandableSections()
   {
      return $$("[class*='AccordionToggle__accordionToggle undefined']");
   }

   public void expandAllSections()
   {
      for (SelenideElement element : getExpandableSections())
      {
         element.shouldBe(Condition.visible).click();
      }
   }

   public void expandSection(int index)
   {
      getExpandableSections().filterBy(Condition.visible).get(index).click();
   }

   public void toggleSelectedInsurancesAccordion()
   {
      WebElementTools.mouseOverAndClick(selectedInsurancesAccordion);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isSelectedInsuranceSummaryVisible()
   {
      return WebElementTools.isVisible(selectedInsuranceAccordionCollapsed);
   }

   public String getNoInsuranceSelectedText()
   {
      return WebElementTools.getElementText(noInsuranceSelected);
   }

   public String getSelectedInsurancePassengerName(int paxIndex)
   {
      return WebElementTools.getElementText(getPassengerInSelectedInsList(paxIndex));
   }

   public String getSelectedInsuranceTextForPassenger(int paxIndex)
   {
      return WebElementTools.getElementText(getInsuranceInSelectedInsList(paxIndex));
   }

   private WebElement getPassengerInSelectedInsList(int paxIndex)
   {
      return WebElementTools.getWebElementsByClass(MULTI_INSURANCE_SUMMARY_PASSENGER_NAME_CLASS)
               .get(paxIndex);
   }

   private WebElement getInsuranceInSelectedInsList(int paxIndex)
   {
      return WebElementTools.getWebElementsByClass(MULTI_INSURANCE_SUMMARY_INSURANCE_CLAS)
               .get(paxIndex);
   }

   public boolean isReviewConfirmButtonDisplayed()
   {
      return WebElementTools.isPresent(reviewConfirmButton)
               && WebElementTools.isTextNotContainsUA(reviewConfirmButton.getText());
   }

   public void clickReviewConfirmButton()
   {
      WebElementTools.mouseOverAndClick(reviewConfirmButton);
      wait.forJSExecutionReadyLazy();
   }

   private SelenideElement getReviewConfirmModal()
   {
      return $("[class*='ConfirmationPopup'] .Modal__modalBody");
   }

   public boolean isReviewConfirmModalDisplayed()
   {
      return getReviewConfirmModal().should(Condition.appear, Duration.ofSeconds(15)).isDisplayed();
   }

   public boolean isReviewConfirmModalHidden()
   {
      return !getReviewConfirmModal().shouldBe(Condition.disappear, Duration.ofSeconds(15)).isDisplayed();
   }

   public boolean isReviewConfirmModalTitleDisplayed()
   {
      return WebElementTools.isPresent(reviewConfirmModalTitle) &&
               WebElementTools.isTextNotContainsUA(reviewConfirmModalTitle.getText());
   }

   public String getReviewConfirmModalPassengerName(int paxIndex)
   {
      return WebElementTools.getElementText(reviewConfirmModalPassengersNames.get(paxIndex));
   }

   public String getReviewConfirmModalInsuranceTitle(int paxIndex)
   {
      return WebElementTools.getElementText(reviewConfirmModalInsuranceTitles.get(paxIndex));
   }

   public String getReviewConfirmModalInsurancePrice(int paxIndex)
   {
      return WebElementTools.getElementText(reviewConfirmModalInsurancePrices.get(paxIndex));
   }

   public boolean isReviewConfirmModalTotalPriceLabelDisplayed()
   {
      return WebElementTools.isPresent(reviewConfirmModalTotalPriceLabel) &&
               WebElementTools.isTextNotContainsUA(reviewConfirmModalTotalPriceLabel.getText());
   }

   public boolean isReviewConfirmModalTotalPriceDisplayed()
   {
      return WebElementTools.isPresent(reviewConfirmModalTotalPrice);
   }

   public Double getReviewConfirmModalDoubleTotalPrice()
   {
      wait.forJSExecutionReadyLazy();
      String totalPriceTextValue = WebElementTools.getElementText(reviewConfirmModalTotalPrice);
      return Double.valueOf(totalPriceTextValue.substring(1).replaceAll("\\s+", ""));
   }

   public void clickModalConfirmButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(modalConfirmButton);
   }

   public void clickModalCancelButton()
   {
      WebElementTools.mouseOverAndClick(modalCancelButton);
   }

   public boolean isInsuranceTitleEmpty(int paxIndex)
   {
      return getReviewConfirmModalInsuranceTitle(paxIndex).split(" x ").length > 1;
   }

   public void clickReturnToYourHolidayLink()
   {
      WebElementTools.mouseOverAndClick(returnToYourHolidayLink);
   }

   public TestDataAttributes getSearchParameters()
   {
      return searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
   }

   public List<Integer> getChildrenAgeInSearchParams()
   {
      List<String> ages = new ArrayList<>();
      List<Integer> intAge = new ArrayList<>();
      String childrenAge = getSearchParameters().getChildrenAge();
      if (childrenAge.contains(","))
      {
         Collections.addAll(ages, childrenAge.split(","));
      }
      else
      {
         ages.add(childrenAge);
      }

      for (String age : ages)
      {
         intAge.add(Integer.parseInt(age));
      }

      return intAge.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
   }

   public List<SelenideElement> getChildrenAgeMessagesInDOBComponent()
   {
      return $$(".GetQuoteV2__age");
   }

   public List<String> getChildrenAgeInDOBComponent()
   {
      List<String> childrenAge = new ArrayList<>();
      IntStream.range(0, getChildrenAgeMessagesInDOBComponent().size()).forEach(i ->
               childrenAge.add(String.valueOf(
                        getChildrenAgeMessagesInDOBComponent().get(i).should(Condition.visible)
                                 .getText().split(" ")[1].charAt(0))));
      return childrenAge;
   }

   public List<SelenideElement> getPassengerLabelInInsuranceCard(int sectionIndex, int cardIndex, int paxIndex)
   {
      SelenideElement insuranceElement = getCardInsLabel(sectionIndex, cardIndex, paxIndex);
      return insuranceElement.$$(".PerPersonSelectList__labelText span");
   }

   public List<String> getChildrenAgeInInsuranceCard(int sectionIndex, int cardIndex, int paxIndex)
   {
      List<SelenideElement> childrenAgeMessages =
               getPassengerLabelInInsuranceCard(sectionIndex, cardIndex, paxIndex);
      List<String> childrenAge = new ArrayList<>();
      IntStream.range(0, childrenAgeMessages.size()).forEach(i ->
               childrenAge.add(
                        String.valueOf(childrenAgeMessages.get(i).should(Condition.visible)
                                 .getText().split(" ")[3].charAt(0))));
      return childrenAge;
   }

   public List<SelenideElement> getInfantAgeMessagesInDOBComponent()
   {
      return $$(".InfantCheckbox .GetQuoteV2__toolTipAndName");
   }

   public List<SelenideElement> getDOBErrorMessages()
   {
      return $$(".inputs__error span");
   }

   public List<String> getDOBErrorMessagesTexts()
   {
      List<String> errorMessagesTexts = new ArrayList<>();
      for(SelenideElement message : getDOBErrorMessages())
      {
         errorMessagesTexts.add(message.should(Condition.visible).getText());
      }
      return  errorMessagesTexts;
   }

   public String getElementText(SelenideElement element)
   {
      return element.shouldBe(Condition.visible).getText().trim();
   }

   public SelenideElement getOrCombineBothDivider()
   {
      return $(".OrCombineBothDivider__divider");
   }

   public boolean isCombineBothDividerPresented()
   {
      return getOrCombineBothDivider().isDisplayed();
   }

   public String getCombineBothDividerText()
   {
      return getElementText(getOrCombineBothDivider()
               .$(".OrCombineBothDivider__dividerText"));
   }

   public SelenideElement getDontNeedInsurance()
   {
      return $$(".InsuranceType__insuranceTitle").first();
   }

   public boolean isDontNeedInsurancePresented()
   {
      return getDontNeedInsurance().isDisplayed();
   }

   public String getDontNeedInsuranceText()
   {
      return getElementText(getDontNeedInsurance().$("h3"));
   }
}
