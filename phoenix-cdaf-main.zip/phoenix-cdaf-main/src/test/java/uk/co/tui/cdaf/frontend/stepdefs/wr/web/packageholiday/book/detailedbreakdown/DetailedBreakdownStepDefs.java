package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.detailedbreakdown;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.detailedbreakdown.DetailedBreakdownPage;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

public class DetailedBreakdownStepDefs
{
   private static final int NUMBER_OF_PASSENGERS_IN_SCENARIO = 6;

   private final PackageNavigation packageNavigation = new PackageNavigation();

   private final DetailedBreakdownPage detailedBreakdownPage = new DetailedBreakdownPage();

   @Given("User is on the DetailedPriceBreakdown page")
   public void user_is_on_the_detailedPriceBreakdown_page()
   {
      packageNavigation.navigateToDetailedBreakdownPage();
   }

   @Then("Base Prise is displayed")
   public void base_price_is_displayed()
   {
      assertThat("Base Price is not present", detailedBreakdownPage.isBasePriceDisplayed(),
               is(true));
   }

   @Then("Total Prise is displayed")
   public void total_price_is_displayed()
   {
      assertThat("Total Price is not present", detailedBreakdownPage.isTotalPriceDisplayed(),
               is(true));
   }

   @Then("Info for all adult passengers is displayed")
   public void info_for_all_adult_passengers_is_displayed()
   {
      assertThat("Not for all adult passengers were displayed information",
               detailedBreakdownPage.countForHowManyPassengersIsDisplayedInfo(),
               equalTo(NUMBER_OF_PASSENGERS_IN_SCENARIO));
   }

   @And("insurance tax value is displayed in Detailed Price Breakdown page for {int} passengers")
   public void insurance_tax_value_is_displayed_in_Detailed_Price_Breakdown_page_for_passengers(
            Integer paxAmount)
   {
      for (int i = 0; i < paxAmount; i++)
      {
         assertTrue("Insurance price is absent or equal to zero",
                  detailedBreakdownPage.getInsuranceTaxesValuesDouble().get(i) > 0);
      }
   }
}
