package uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class FOSpecialAssistance extends AbstractPage
{
   private final WebElementWait wait;

   public String specialassistancecheckbox =
            "return document.querySelector(\"tui-fo-ssr\").shadowRoot.querySelector(\".checkboxWrapper__3tzR3\").querySelector(\".checkboxToggle__24nwB\")";

   public String selectSpecialAssistanceWCHR =
            "return document.querySelector(\"tui-fo-ssr\").shadowRoot.querySelector(\".notSelectedCard__1oxOU\").querySelector(\".checkboxToggle__24nwB\")";

   public FOSpecialAssistance()
   {
      wait = new WebElementWait();
   }

   public void clickOnspecialassistancecheckbox()
   {
      WebElement webelement = (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver())
               .executeScript(specialassistancecheckbox);
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(webelement);
      wait.forJSExecutionReadyLazy();
      webelement.click();
      wait.forJSExecutionReadyLazy();
   }

   public void selectSpecialAssistanceWCHR()
   {
      WebElement webelement = (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver())
               .executeScript(selectSpecialAssistanceWCHR);
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(webelement);
      webelement.click();
      wait.forJSExecutionReadyLazy();
   }

}
