package uk.co.tui.cdaf.frontend.pom.wr.search;

import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.utils.ConfigurationConstants;
import uk.co.tui.cdaf.utils.ConfigurationService;

public class SearchPanelFactory
{
   public static final String DEV_ENV = "dev";

   public static final String STNG = "stng";

   public static SearchPanel getSearchPanel()
   {
      // TODO: replace this check with parameters when implemented
      if (isMfeEnv())
         return new SearchPanelMfe();
      else
         return new SearchPanelLegacy();
   }

   private static boolean isMfeEnv()
   {
      return ExecParams.isDevEnv() || ExecParams.isStngEnv();
   }
}
