package uk.co.tui.cdaf.api.pojo.search.mfe;

import lombok.Data;

import java.util.List;

@Data
public class DateData
{
   private List<String> availableDates;
}
