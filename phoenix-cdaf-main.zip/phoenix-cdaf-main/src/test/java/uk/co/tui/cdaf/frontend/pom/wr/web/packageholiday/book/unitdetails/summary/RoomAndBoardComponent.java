package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import com.codeborne.selenide.Condition;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.HashMap;

import static com.codeborne.selenide.Selenide.$;

public class RoomAndBoardComponent extends AbstractPage
{

   private final HashMap<String, WebElement> roomAndBoardMap;

   private final HashMap<String, WebElement> roomOptionsMap;

   private final WebElementWait wait;

   @FindBy(css = "[aria-label='Room ancillary'] [aria-label='button']")
   protected WebElement includedButton;

   @FindBy(css = "[aria-label='Room ancillary'] [aria-label='button']")
   protected WebElement selectedStateCTA;

   @FindBy(css = "[aria-label='Room ancillary'] [aria-label='button']")
   protected WebElement selectCTA;

   @FindBy(css = "[aria-label='Room ancillary']")
   private WebElement roomAncillary;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='SummaryRoomComponent__description']")
   private WebElement roomAndBoardDescription;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='RoomTypesV2__moreDetailsLink']")
   private WebElement moreDetailsLink;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='Image__imgContainer']")
   private WebElement roomImage;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='RoomTypesV2__moreDetailsIcon']")
   private WebElement imageIcon;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='SummaryRoomComponent__description']")
   private WebElement altRoomtypeDescription;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='RoomTypesV2__moreDetailsLink']")
   private WebElement altMoreDetailsLink;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='Image__imgContainer']")
   private WebElement altRoomImage;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='RoomTypesV2__moreDetailsIcon']")
   private WebElement altPhotoIcon;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='SummaryRoomComponent__price']")
   private WebElement additionalTotalPrice;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='SummaryRoomComponent__price']")
   private WebElement pricePerPerson;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='HighlightedLink__text']")
   private WebElement viewAllRoomUpgrades;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='HighlightedLink__text']")
   private WebElement viewRoomUpgrades;

   @FindBy(css = "[aria-label='board options']")
   private WebElement yourBoard;

   @FindBy(css = ".//div[contains(@class,'active')]//span[@aria-label='board name']")
   private WebElement defaultBoardType;

   @FindBy(css = "[aria-label='price information'] [class*='BoardOptionsV2__icon']")
   private WebElement includedMark;

   @FindBy(css = "[aria-label='board options list'] .BoardOptionsV2__selectBlock:not(.BoardOptionsV2__active)")
   private WebElement otherAvailableBoardTypes;

   @FindBy(css = ".BoardOptionsV2__totalPrice")
   private WebElement priceDifference;

   @FindBy(css = "[aria-label='board options list'] .BoardOptionsV2__selectBlock:not(.BoardOptionsV2__active) button")
   private WebElement anotherSelectCTA;

   @FindBy(css = "div[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section  [class *='RoomTypesV2__selected'] [class *='RoomTypesV2__imageContainer'] > div:nth-child(1) img")
   private WebElement selectedMarker;

   @FindBy(css = "[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section > [class *='RoomTypesV2__selected'] [aria-label='room option details'] > div > div > h5")
   private WebElement twoRoomTypeDescription;

   @FindBy(css = "[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section > [class *='RoomTypesV2__selected'] [aria-label='room option details'] > div > div > .RoomTypesV2__occupancy")
   private WebElement occupancy;

   @FindBy(css = "[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section > [class *='RoomTypesV2__selected'] [aria-label='room option details'] > div > div > .RoomTypesV2__occupancy")
   private WebElement bedDetails;

   @FindBy(css = "[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section > [class *='RoomTypesV2__selected'] [aria-label='room option details'] > div > div > [aria-label='simple-popup']")
   private WebElement twoMoreDetailsLink;

   @FindBy(css = "div[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section  [class *='RoomTypesV2__selected'] [class *='RoomTypesV2__imageContainer'] > div:nth-child(1) img")
   private WebElement twoRoomImage;

   @FindBy(css = "[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section [class *='RoomTypesV2__selected'] div:nth-child(2) .RoomTypesV2__moreDetailsIcon svg")
   private WebElement twoPhotoIcon;

   @FindBy(css = "[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section > div:nth-child(4) [class *='selectablePrice'] > p:nth-child(1) b")
   private WebElement anotherPriceDifference;

   @FindBy(css = "[class *='RoomTypesV2__roomWrapper']:nth-child(1) > section > div:nth-child(4)  button")
   private WebElement twoSelectCTA;

   @FindBy(css = "[aria-label='room option 2'] [aria-label='room option details'] [aria-label='room option title']")
   private WebElement threeRoomTypeDescription;

   @FindBy(css = "[aria-label='room option 2'] [aria-label='room option details'] [class*='RoomTypesV2__occupancy']")
   private WebElement anotherOccupancy;

   @FindBy(css = "[aria-label='room option 2'] [aria-label='room option details'] [class*='RoomTypesV2__occupancy']")
   private WebElement anotherBedDetails;

   @FindBy(css = "[aria-label='room option 2'] [class*='RoomTypesV2__moreDetailsLink']")
   private WebElement threeMoreDetailsLink;

   @FindBy(css = "[aria-label='room option 2'] [class*='Image__imgContainer']")
   private WebElement threeRoomImage;

   @FindBy(css = "[aria-label='room option 2'] [class*='RoomTypesV2__moreDetailsIcon']")
   private WebElement threePhotoIcon;

   @FindBy(css = "[aria-label='Room ancillary'] [class*='SummaryRoomComponent__roomComponent'] [class*='SummaryRoomComponent__wrapper'] [class*='SummaryRoomComponent__selected']")
   private WebElement roomImageIcon;

   public RoomAndBoardComponent()
   {
      roomAndBoardMap = new HashMap<>();
      roomOptionsMap = new HashMap<>();
      wait = new WebElementWait();
   }

   public WebElement getRoomAncillaryElement()
   {
      return wait.getWebElementWithLazyWait(roomAncillary);
   }

   public void scrollToRoomAncillary()
   {
      WebElementTools.javaScriptScrollToElement(getRoomAncillaryElement());
   }

   public boolean isRoomAncillaryDisplayed()
   {
      return WebElementTools.isPresent(getRoomAncillaryElement());
   }

   public boolean isIncludedButtonDisplayed()
   {
      return WebElementTools.isPresent(includedButton);
   }

   public HashMap<String, WebElement> getRoomAndBoardComps()
   {
      roomAndBoardMap.put("Room Type Description", roomAndBoardDescription);
      roomAndBoardMap.put("More Details link", moreDetailsLink);
      roomAndBoardMap.put("Room Image", roomImage);
      roomAndBoardMap.put("Photo Icon", imageIcon);
      roomAndBoardMap.put("Selected state CTA", selectedStateCTA);
      roomAndBoardMap.put("Alternate Room Type Description", altRoomtypeDescription);
      roomAndBoardMap.put("Alternate More Details link", altMoreDetailsLink);
      roomAndBoardMap.put("Alternate Room Image", altRoomImage);
      roomAndBoardMap.put("Alternate Photo Icon", altPhotoIcon);
      roomAndBoardMap.put("Additional total price", additionalTotalPrice);
      roomAndBoardMap.put("Price pppn", pricePerPerson);
      roomAndBoardMap.put("Select CTA", selectCTA);
      return roomAndBoardMap;
   }

   public void clickOnRoomUpgrades()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(viewRoomUpgrades);
   }

   public void clickChangeRoomOptions()
   {
      $(".RoomAndBoard__changeRoomLink .HighlightedLink__text")
               .shouldBe(Condition.visible, Duration.ofSeconds(10)).click();
   }

   public boolean isYourBoardComponentDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(yourBoard);
   }

   public HashMap<String, WebElement> getRoomOptionsComps()
   {
      roomOptionsMap.put("YOUR BOARD", yourBoard);
      roomOptionsMap.put("Board Type", defaultBoardType);
      roomOptionsMap.put("Included Marker", includedMark);
      roomOptionsMap.put("Other Available Board Types", otherAvailableBoardTypes);
      roomOptionsMap.put("Price Difference", priceDifference);
      roomOptionsMap.put("Another Select CTA", anotherSelectCTA);
      roomOptionsMap.put("Selected Marker", selectedMarker);
      roomOptionsMap.put("Two Room Type Description", twoRoomTypeDescription);
      roomOptionsMap.put("Occupancy", occupancy);
      roomOptionsMap.put("Bed details", bedDetails);
      roomOptionsMap.put("Two More Details link", twoMoreDetailsLink);
      roomOptionsMap.put("Two Room Image", twoRoomImage);
      roomOptionsMap.put("Two Photo Icon", twoPhotoIcon);
      roomOptionsMap.put("Another Price difference", anotherPriceDifference);
      roomOptionsMap.put("Two Select CTA", twoSelectCTA);
      roomOptionsMap.put("Three Room Type Description", threeRoomTypeDescription);
      roomOptionsMap.put("Another Occupancy", anotherOccupancy);
      roomOptionsMap.put("Another Bed details", anotherBedDetails);
      roomOptionsMap.put("Three More Details link", threeMoreDetailsLink);
      roomOptionsMap.put("Three Room Image", threeRoomImage);
      roomOptionsMap.put("Three Photo Icon", threePhotoIcon);
      return roomOptionsMap;
   }

   public boolean isRooomImagePresent()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(roomImageIcon);
   }

}
