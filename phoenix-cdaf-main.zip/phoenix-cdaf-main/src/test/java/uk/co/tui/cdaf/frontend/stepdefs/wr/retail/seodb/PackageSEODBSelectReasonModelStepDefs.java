package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSEODBSelectReasonModelStepDefs
{

   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageSEODBSelectReasonModelStepDefs()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent is viewing the banking and reconciliation page")
   public void that_the_agent_is_viewing_the_banking_and_reconciliation_page()
   {
      packagenavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      wait.forJSExecutionReadyLazy();
   }

   @When("they have selected a reason from the dropdown next to a payment type accordion")
   public void they_have_selected_a_reason_from_the_dropdown_next_to_a_payment_type_accordion()
   {
      pKgReconcilationPaymentPageComponents.clickOverOrUnderReason();
   }

   @Then("an authorise discrepancy modal will appear on the screen")
   public void an_authorise_discrepancy_modal_will_appear_on_the_screen()
   {
      assertThat("An authorise discrepancy modal appeared",
               pKgReconcilationPaymentPageComponents.isAauthoriseDiscrepancyModalAppeared(),
               is(true));
   }

   @Then("the following information will be shown")
   public void the_following_information_will_be_shown(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Authorize Discrepancy Title displayed",
               pKgReconcilationPaymentPageComponents.isAuthorizeDiscrepancyTitleDisplayed(),
               is(true));
      assertThat("Amount or Reason displayed",
               pKgReconcilationPaymentPageComponents.isSelectReasonAmountReasonDisplayed(),
               is(true));
      assertThat("Free text area displayed",
               pKgReconcilationPaymentPageComponents.isSelectReasonTextAreaDisplayed(), is(true));
      assertThat("Cancel CTA displayed",
               pKgReconcilationPaymentPageComponents.isSelectReasonCancelCTADisplayed(), is(true));
      assertThat("Submit CTA displayed",
               pKgReconcilationPaymentPageComponents.isSelectReasonSubmitCTADisplayed(), is(true));
   }

   @Given("that the agent is viewing the authorize discrepancy modal")
   public void that_the_agent_is_viewing_the_authorize_discrepancy_modal()
   {
      packagenavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pKgReconcilationPaymentPageComponents.clickOverOrUnderReason();
      assertThat("An authorise discrepancy modal is viewing",
               pKgReconcilationPaymentPageComponents.isAauthoriseDiscrepancyModalAppeared(),
               is(true));
   }

   @When("they press the CANCEL CTA")
   public void they_press_the_CANCEL_CTA()
   {
      pKgReconcilationPaymentPageComponents.clickSelectReasonCancelCTA();
   }

   @Then("the reason modal will close")
   public void the_reason_modal_will_close()
   {
      assertThat("An authorise discrepancy modal is closed",
               pKgReconcilationPaymentPageComponents.isAauthoriseDiscrepancyModalAppeared(),
               is(false));
   }

   @Then("the reason selected will not be saved")
   public void the_reason_selected_will_not_be_saved()
   {
      assertThat("Reason content card not displayed",
               pKgReconcilationPaymentPageComponents.isReasonContentCardDisplayed(), is(false));
   }

   @When("they press the SUBMIT CTA")
   public void they_press_the_SUBMIT_CTA()
   {
      pKgReconcilationPaymentPageComponents.clickSelectReasonSubmitCTA();
   }

   @Then("the payment type accordion will be updated to show the notes that the agent had added")
   public void the_payment_type_accordion_will_be_updated_to_show_the_notes_that_the_agent_had_added()
   {
      assertThat("Reason content card displayed",
               pKgReconcilationPaymentPageComponents.isReasonContentCardDisplayed(), is(true));
   }
}
