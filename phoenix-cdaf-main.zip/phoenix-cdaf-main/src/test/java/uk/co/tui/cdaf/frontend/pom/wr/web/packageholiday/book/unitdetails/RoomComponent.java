package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class RoomComponent extends AbstractPage
{
   public final WebElementWait wait;

   public Map<String, SelenideElement> roomComponents;

   @FindBy(css = "[class='Rooms__roomItem'] [class*='arrowIcon']")
   private List<WebElement> roomAccordion;

   @FindBy(css = "[class='WCMS_component']")
   private WebElement boardBasisComponent;

   @FindBy(css = "[class='sections__showMore']")
   private WebElement showMoreLink;

   @FindBy(css = "[class='sections__showLess']")
   private WebElement showLessLink;

   @FindBy(css = ".sections__showMoreContent")
   private WebElement displayComponent;

   @FindBy(css = "[class='sections__showLess']")
   private WebElement changeToShowLess;

   @FindBy(css = "[class='sections__showMore']")
   private WebElement changeToShowMore;

   @FindBy(css = "[class='Boards__mainContent']")
   private WebElement collapseHeaderComponent;

   @FindBy(css = ".Boards__mainContent h4")
   private WebElement headerComponent;

   @FindBy(css = ".sections__showMoreContent div")
   private List<WebElement> displayDescription;

   @FindAll({ @FindBy(css = ".stylesRoomTypesV4__roomMobileActions div + button"),
            @FindBy(css = "stylesRoomTypesV4__roomContainer") })
   private List<WebElement> alternativeRoom;

   @FindBy(css = " [class='stylesRoomTypesV4__roomMobileSelectedLabel']")
   private WebElement roomLabelSelected;

   @FindBy(css = " div[class*='components__opened'] section.components__modalBody ")
   private WebElement roomDetailsModalPresent;

   @FindBy(xpath = "//div[@class='stylesRoomTypesV4__roomMobileActions']//button")
   private WebElement roomOptionButton;

   @FindAll({ @FindBy(css = "[aria-label='room selecton']>div>div>button"),
            @FindBy(css = "[class='RoomTypesV2__priceBlock'] button") })
   private List<WebElement> alternativeRooms;

   @FindAll({
            @FindBy(xpath = "//div[@class='stylesRoomTypesV4__selectedPriceBlock']/../../../..//h5"),
            @FindBy(xpath = "//span[@class=\"RoomTypesV2__icon \"]/../../../../..//div[@aria-label='room option details']//h5") })
   private WebElement roomUpgradesTitle;

   @FindAll({
            @FindBy(xpath = "//div[@class=\"stylesRoomTypesV4__optionBox\"]/div//h5[@aria-label='room option title']") })
   private List<WebElement> roomTitles;

   @FindAll({
            @FindBy(xpath = "//div[@class=\"stylesRoomTypesV4__optionBox stylesRoomTypesV4__roomListMobileDetail\"]/div//h5[@aria-label='room option title']") })
   private List<WebElement> mobileRoomTitles;

   @FindBy(xpath = "//p[@class=\"stylesRoomTypesV4__selectPricePPn\"]/b")
   private WebElement roomPriceDiff;

   @FindBy(xpath = "//div[@class=\"stylesRoomTypesV4__roomItemMobilePriceDiff\"]/p/b")
   private WebElement mobileRoomPriceDiff;


   @FindBy(css = "[class='stylesRoomTypesV4__allocationTitle']")
   private List<WebElement> noOfRooms;

   @FindBy(css = "[aria-label*='room option 1'] div:nth-child(2) img")
   private List<WebElement> moreRoomImage;

   @FindBy(css = "[class*='Galleries__iconRightNav ']")
   private List<WebElement> mutltiChevron;

   @FindBy(css = "[class*='Galleries__iconRightNav ']")
   private WebElement chevron;

   @FindBy(css = "[class='stylesRoomTypesV4__allocationTitle']")
   private List<WebElement> autoAllocationTitle;

   private SelenideElement getYourRoomHeading()
   {
      return $(".sections__sectionTitle");
   }

   private SelenideElement getYourRoomIcon()
   {
      return $(".sections__sectionIcon").$("svg");
   }

   private SelenideElement getYourRoomCard()
   {
      return $("[aria-label*='room option 1']");
   }

   private SelenideElement getAllocationTitle()
   {
      return $("[class='stylesRoomTypesV4__allocationTitle']");
   }

   private SelenideElement getYourRoomTitle()
   {
      return $("[aria-label*='section title']");
   }

   private SelenideElement getShowMoreOptions()
   {
      return $("[arialabel*='show more rooms']");
   }

   private SelenideElement getSelectedPrice()
   {
      return $("[class='stylesRoomTypesV4__selectedPriceBlock']");
   }

   public SelenideElement getRoomOccupancy()
   {
      return $(".stylesRoomTypesV4__occupancy p");
   }

   private SelenideElement getRoomCheckMark()
   {
      return $("[class='stylesRoomTypesV4__selectedCheckmarkWrapper']");
   }

   public SelenideElement getRoomTypeDescription()
   {
      return $("[aria-label*='room option title']");
   }

   public SelenideElement getFirstRoomImage()
   {
      return getYourRoomCard().$("div:nth-child(2) img");
   }

   public SelenideElement getMoreDetailsLink()
   {
      return $("[class='stylesRoomTypesV4__viewMoreTrigger']");
   }

   private SelenideElement getModalBulletPointedList()
   {
      return $(".stylesRoomTypesV4__popupFeaturesList li");
   }

   private SelenideElement getModalRoomOccupancy()
   {
      return $(".stylesRoomTypesV4__bedsAndOccupancy div");
   }

   private SelenideElement getCloseModalLink()
   {
      return $(".components__close");
   }

   private SelenideElement getModalRoomTypeDescription()
   {
      return $("h3.stylesRoomTypesV4__popupTitle");
   }

   private SelenideElement getRoomDetailsTitle()
   {
      return $(".components__modalTitle h4");
   }

   private SelenideElement getImageHolder()
   {
      return $("[class='Image__imgContainer'] [class*='Image__image']");
   }

   private SelenideElement getBedIcon()
   {
      return $("[class='sections__titleIconWrap'] svg");
   }

   public SelenideElement getRoomSelector()
   {
      return $("[class='buttons__button buttons__senary buttons__fill']");
   }

   public SelenideElement getPricePerPerson()
   {
      return $(".stylesRoomTypesV4__selectPricePPnWrapper p");
   }

   public SelenideElement getPriceTotal()
   {
      return $(".stylesRoomTypesV4__selectPricePPnWrapper p b");
   }

   public SelenideElement getCarouselFrame()
   {
      return $("[class='carousel__frame ']");
   }

   public SelenideElement getModalRoomChevron()
   {
      return $("[class='Galleries__iconRightNav ']");
   }

   public SelenideElement getFirstRoomHighlight()
   {
      return $("[class='Galleries__highlight']");
   }

   public SelenideElement getCameraIconXCloseModalLink()
   {
      return $("svg.popups__iconClose.popups__close");
   }

   private ElementsCollection getRoomUsps()
   {
      return $$("[class='Rooms__roomItem'] ul");
   }

   private ElementsCollection getYourRoomAccordionList()
   {
      return $$("div[aria-label='room option 1']");
   }

   public RoomComponent()
   {
      roomComponents = new HashMap<>();
      wait = new WebElementWait();
   }

   public Map<String, SelenideElement> yourRoomComponents()
   {
      roomComponents.put("Your Room icon", getYourRoomIcon());
      roomComponents.put("Bed icon", getBedIcon());
      roomComponents.put("Room Title", getFirstRoomTitle());
      roomComponents.put("Image", getImageHolder());
      roomComponents.put("Description", getRoomUsps().get(0));
      return roomComponents;
   }

   public Map<String, SelenideElement> roomComponent()
   {
      roomComponents.put("Room Icon", getYourRoomIcon());
      roomComponents.put("Room Title", getYourRoomTitle());
      roomComponents.put("Room allocation", getAllocationTitle());
      roomComponents.put("Room Card", getYourRoomCard());
      return roomComponents;
   }

   public Map<String, SelenideElement> getRoomComponents()
   {
      roomComponents.put("Your room heading", getYourRoomHeading());
      roomComponents.put("Room title", getFirstRoomTitle());
      return roomComponents;
   }

   public Map<String, SelenideElement> selectedRoomComponent()
   {
      roomComponents.put("Room Image", getFirstRoomImage());
      roomComponents.put("Room type description", getRoomTypeDescription());
      roomComponents.put("Tick in top right corner", getRoomCheckMark());
      roomComponents.put("Room Occupancy", getRoomOccupancy());
      roomComponents.put("More details", getMoreDetailsLink());
      roomComponents.put("Selected room", getSelectedPrice());
      roomComponents.put("Additional room option", getShowMoreOptions());

      return roomComponents;
   }

   public Map<String, SelenideElement> alternativeRoomComponent()
   {
      roomComponents.put("Room Image", getFirstRoomImage());
      roomComponents.put("Room type description", getRoomTypeDescription());
      roomComponents.put("Room Occupancy", getRoomOccupancy());
      roomComponents.put("More details", getMoreDetailsLink());
      roomComponents.put("Price total", getPriceTotal());
      roomComponents.put("Price per person", getPricePerPerson());
      roomComponents.put("Room selector", getRoomSelector());
      return roomComponents;
   }

   public Map<String, SelenideElement> roomCards()
   {
      roomComponents.put("Room Image", getFirstRoomImage());
      roomComponents.put("Room Details", getRoomOccupancy());
      roomComponents.put("Room type description", getRoomTypeDescription());
      roomComponents.put("Show details link", getMoreDetailsLink());
      return roomComponents;
   }

   public Map<String, SelenideElement> roomDetailsModelComponents()
   {
      roomComponents.put("Room Details title", getRoomDetailsTitle());
      roomComponents.put("Room type description", getModalRoomTypeDescription());
      roomComponents.put("X close modal link", getCloseModalLink());
      roomComponents.put("Room Occupancy", getModalRoomOccupancy());
      roomComponents.put("bullet pointed list", getModalBulletPointedList());
      return roomComponents;
   }

   public SelenideElement getFirstRoomTitle()
   {
      return $$(".stylesRoomTypesV4__allocationTitle").get(0);
   }

   public SelenideElement getRoomItemContainer()
   {
      return $("[class='Rooms__roomItem']");
   }

   public boolean isImagePlaceholder()
   {
      String checkImageSrc = WebElementTools.getElementAttribute(getImageHolder(), "src");
      return checkImageSrc.endsWith("image_coming_soon.png");
   }

   public boolean isRoomImagePresent()
   {
      String checkImageSrc = WebElementTools.getElementAttribute(getImageHolder(), "src");
      return checkImageSrc.contains("tuiwr");
   }

   public SelenideElement getRoomInfoContent()
   {
      return $("[class='Rooms__textBlock'] [class*='Rooms__fullContent']");
   }

   public SelenideElement getYouRoomDisplayed()
   {
      return $("[class='WCMS_component']");
   }

   public boolean isRoomAccordion()
   {
      return WebElementTools.isPresent(roomAccordion.get(0));
   }

   public boolean isShowMoreDisplayed()
   {
      return getShowMoreOptions().isDisplayed();
   }

   public boolean isAdditionalRoomAccordion()
   {
      return WebElementTools.isPresent(roomAccordion.get(1));
   }

   public void clickaccordion()
   {
      WebElementTools.click(roomAccordion.get(1));
   }

   public void clickMultipleShowDetails()
   {
      ElementsCollection showDetailsLink = $$(".stylesRoomTypesV4__fakeLink");
      if (!showDetailsLink.isEmpty())
      {
         for (SelenideElement element : showDetailsLink)
         {
            if (element.isDisplayed())
               WebElementTools.click(element);
         }
      }
   }

   public void showDetailsComponent()
   {
      ElementsCollection yourRoomOption2 = $$("[aria-label*='room option 2']");
      if (!yourRoomOption2.isEmpty())
      {
         for (SelenideElement element : yourRoomOption2)
         {
            if (element.isDisplayed())
               WebElementTools.click(element);
         }
      }
   }

   public void additionalInformation()
   {
      WebElementTools.isPresent(getRoomUsps().get(1));
   }

   public SelenideElement getRoomUpgradeLink()
   {
      return $("a[href*='roomoptions']");
   }

   public void clickRoomUpgradeLink()
   {
      getRoomUpgradeLink().click();
   }

   public boolean isBoardBasisDisplayed()
   {
      return WebElementTools.isPresent(boardBasisComponent);
   }

   public boolean selectShowMoreLink()
   {
      return WebElementTools.isPresent(showMoreLink);
   }

   public void displayComponent()
   {
      WebElementTools.isPresent(displayComponent);
   }

   public String changeToShowLessLink()
   {
      return WebElementTools.getElementText(changeToShowLess);
   }

   public String collapseHeader()
   {
      WebElementTools.click(showLessLink);
      return WebElementTools.getElementText(collapseHeaderComponent);
   }

   public String changeToShowMoreLink()
   {
      return WebElementTools.getElementText(changeToShowMore);
   }

   public boolean selectShowLessLink()
   {
      return WebElementTools.isPresent(showLessLink);
   }

   public String boardComponent()
   {
      return WebElementTools.getElementText(headerComponent);
   }

   public boolean boardComponents()
   {
      return WebElementTools.isPresent(headerComponent);
   }

   public boolean isDiscriptionDisplayed()
   {
      return WebElementTools.isPresent(displayDescription.get(2));
   }

   public boolean isAdditionalRoomAccordionDisplayed()
   {
      if (getYourRoomAccordionList().size() == 3)
      {
         return WebElementTools.isPresent(getYourRoomAccordionList().get(2));
      }
      else if (getYourRoomAccordionList().size() == 2)
      {
         return WebElementTools.isPresent(getYourRoomAccordionList().get(1));
      }
      else
      {
         return WebElementTools.isPresent(getYourRoomAccordionList().get(0));
      }

   }

   public boolean isShowMoreRoomOptionsButtonDisplayed()
   {
      return WebElementTools.isPresent(getShowMoreOptions());
   }

   public boolean clickOnShowMoreRoomOptionsButton()
   {
      return WebElementTools.isPresent(showMoreLink);
   }

   public void clickOnShowLessRoomOptionsButton()
   {
      WebElementTools.isPresent(showLessLink);
   }

   public boolean isAlternativeRoomsPresent()
   {
      if (getYourRoomAccordionList().size() > 1 || alternativeRoom.size() > 1)
      {
         for (SelenideElement element : getYourRoomAccordionList())
         {
            if (element.isDisplayed())
               WebElementTools.click(element);
         }
         return (WebElementTools.isPresent(getYourRoomAccordionList().get(1))
                  || WebElementTools.isPresent(alternativeRoom.get(1)));
      }
      else
      {
         return Boolean.FALSE;
      }
   }

   public boolean isShowLessRoomOptionsButtonDisplayed()
   {
      return getShowMoreOptions().isDisplayed();
   }

   public boolean isRoomCardPresent()
   {
      return WebElementTools.isPresent(getYourRoomCard());
   }

   public boolean isBaseRoomDisplayed()
   {
      return WebElementTools.isPresent(getYourRoomCard());
   }

   public boolean isRoomselectedstateDisplayed()
   {
      return WebElementTools.isPresent(roomLabelSelected);
   }

   public boolean isAlternativeRoomDisplayed()
   {
      return WebElementTools.isPresent(alternativeRoom.get(0));
   }

   public boolean isRoomOptionButtonDisplayed()
   {
      return WebElementTools.isPresent(roomOptionButton);
   }

   public void clickOnRoomOptionButton()
   {
      WebElementTools.click(roomOptionButton);
   }

   public boolean isMoreDetailsLinkDisplayed()
   {
      return WebElementTools.isPresent(getMoreDetailsLink());
   }

   public void clickOnMoreDetailsLink()
   {
      WebElementTools.click(getMoreDetailsLink());
   }

   public boolean isMoreDetailsModalDisplayed()
   {
      return WebElementTools.isPresent(roomDetailsModalPresent);
   }

   public void clickOnXCloseModalLink()
   {
      WebElementTools.click(getCloseModalLink());
   }

   public void isNextRoomDisplayed()
   {
      WebElementTools.scrollTo(alternativeRoom.get(0));
   }

   public String isAlternativeRoomsDisplayed()
   {
      return WebElementTools.getElementText(alternativeRooms.get(0));
   }

   public String getRoomUpgradesTitle()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(roomUpgradesTitle);
   }

   public void clickOnAlternativeRooms()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(alternativeRooms.get(0));
      WebElementTools.mouseOverAndClick(alternativeRooms.get(0));
   }

   public void clickOnMobileAlternativeRooms()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(alternativeRoom.get(1));
      WebElementTools.mouseOverAndClick(alternativeRoom.get(1));
   }

   public String getRoomTitle()
   {
      return $("[aria-label='room option title']").getText();
   }

   public boolean isRoomSelected()
   {
      wait.forJSExecutionReadyLazy();
      return (WebElementTools.isPresent(getRoomCheckMark())
               || WebElementTools.isPresent(roomLabelSelected));
   }

   public String getRoomPriceDifference()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(roomPriceDiff)
               ? WebElementTools.getElementText(roomPriceDiff)
               : WebElementTools.getElementText(mobileRoomPriceDiff);
   }

   public boolean isMobileAlternateRoomsDisplayed()
   {
      return StringUtils.isNotEmpty(WebElementTools.getElementText(alternativeRoom.get(1)));
   }

   public boolean isMobileBaseRoomSelected()
   {
      return (WebElementTools.isPresent(roomOptionButton)
               && WebElementTools.isPresent(roomLabelSelected));
   }

   public String getButtonText()
   {
      return WebElementTools.getElementText(roomOptionButton);
   }

   public String getYourRoomAvailable()
   {
      return $$("[class='stylesRoomTypesV4__priceCompareContainer'] div, " +
               "div.stylesRoomTypesV4__priceCompareContainer div[aria-label='limited availability']").asDynamicIterable()
               .stream().filter(SelenideElement::isDisplayed).findFirst().orElseThrow().getText();
   }

   public boolean verifyNoOfRooms()
   {
      return $$("div.stylesRoomTypesV4__roomWrapper").asDynamicIterable()
               .stream()
               .filter(SelenideElement::isDisplayed)
               .anyMatch(element -> element.$("div[aria-label='room option 1']").isDisplayed());
   }

   public boolean isMoreThanOneRoomRoomImage()
   {
      boolean value = false;
      for (int i = 0; i < getYourRoomAccordionList().size(); i++)
      {
         if (!moreRoomImage.isEmpty())
         {
            WebElementTools.isPresent(chevron);
            value = true;
            break;
         }
      }
      return value;
   }

   public void clickOnChevron()
   {
      WebElementTools.click(chevron);
   }

   public void carouselImages()
   {
      for (int i = 0; i < mutltiChevron.size(); i++)
      {
         WebElementTools.click(chevron);
      }
   }

   public void clickONCameraIcon()
   {
      $("[aria-label='Gallery Button']").scrollIntoView("{block: 'center'}").click();
   }

   public void XCloseIsPresent()
   {
      WebElementTools.isPresent(getCameraIconXCloseModalLink());
   }

   public void clickONXClose()
   {
      WebElementTools.click(getCameraIconXCloseModalLink());
   }

   public void infantWithAdult()
   {
      int headerString = autoAllocationTitle.size();
      try
      {
         switch (headerString)
         {
            case 5:
               String getallocatedText = autoAllocationTitle.get(4).getText();
               String[] room5 = getallocatedText.split(":");
               String type1 = room5[1];
               String[] gilt = type1.split(" ");
            case 4:
               String getallocatedText4 = autoAllocationTitle.get(3).getText();
               String[] room4 = getallocatedText4.split(":");
            case 3:
               String getallocatedText3 = autoAllocationTitle.get(2).getText();
               String[] room3 = getallocatedText3.split(":");
            case 2:
               String getallocatedText2 = autoAllocationTitle.get(1).getText();
               String[] room2 = getallocatedText2.split(":");
            case 1:
               String getallocatedText1 = autoAllocationTitle.get(0).getText();
               String[] room1 = getallocatedText1.split(":");
         }
      }
      catch (Exception e)
      {
         e.getMessage();
      }
   }

}
