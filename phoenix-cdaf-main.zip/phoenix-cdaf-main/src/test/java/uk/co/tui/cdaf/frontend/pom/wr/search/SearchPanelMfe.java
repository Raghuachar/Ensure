package uk.co.tui.cdaf.frontend.pom.wr.search;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.airport.Airport;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.airport.AirportMfe;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.departure.Departure;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.departure.DepartureMfe;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.Destination;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.DestinationMfe;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.pad_and_rooms.PaxAndRooms;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.pad_and_rooms.PaxAndRoomsMfe;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion.DestinationSuggestion;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion.DestinationSuggestionMfe;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.wrappers.ComponentWrappers;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.wrappers.ComponentWrappersMfe;
import uk.co.tui.cdaf.frontend.pom.wr.search.enums.StayDuration;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import java.time.Duration;
import java.util.Objects;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.executeJavaScript;

class SearchPanelMfe implements SearchPanel
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchPanelMfe.class);

   final Duration WAIT_TIMEOUT = Duration.ofSeconds(30);

   final Airport airportMfeComponent = new AirportMfe();

   final Destination destinationMfeComponent = new DestinationMfe();

   final Departure departureMfeComponent = new DepartureMfe();

   final PaxAndRooms paxAndRoomsMfeComponent = new PaxAndRoomsMfe();

   final DestinationSuggestion destinationSuggestionMfeComponent = new DestinationSuggestionMfe();

   @NotNull
   private static SelenideElement getPanel()
   {
      return $(shadowDeepCss(".search-panel-main"));
   }

   public boolean isSearchPanelMfe()
   {
      return getPanel().exists();
   }

   public boolean isCompactView()
   {
      return $(shadowDeepCss("[class='container search-panel compact']")).exists();
   }

   public boolean isFullView()
   {
      return $(shadowDeepCss("[class='container search-panel full']")).exists();
   }

   public boolean isSearchPanelDisplayed()
   {
      return getPanel().isDisplayed();
   }

   public SelenideElement legacyLink()
   {
      return getWrappers().getDepartureWrapper().$(".legacyLink");
   }

   public Airport airport()
   {
      openDropDown(getWrappers().getAirportWrapper(), ".airportList > .SelectAirports__listStyle",
               ".SelectAirports__iconClass");
      return airportMfeComponent;
   }

   public Destination destination()
   {
      openDropDown(getWrappers().getDestinationWrapper(), "div.dropModalContent", ".icon-reset");
      return destinationMfeComponent;
   }

   public DestinationSuggestion destinationSuggestions(String destination)
   {
      destination().clearSelection().confirmSelection();
      SelenideElement freeTextInput = getWrappers().getDestinationWrapper().$("input[type='text']");
      freeTextInput.click();
      freeTextInput.sendKeys(destination);
      return destinationSuggestionMfeComponent;
   }

   public Departure departure()
   {
      SelenideElement departureWrapper = getWrappers().getDepartureWrapper();
      openDropDown(departureWrapper, "div.dropModalContent", "span.inputs__children");
      return departureMfeComponent;
   }

   public void selectDuration(StayDuration duration)
   {
      getDurationSelector().selectOptionByValue(duration.getNumberOfNights());
   }

   public void selectRandomDuration()
   {
      ElementsCollection options = getDurationSelector().getOptions();
      int randomIndex = (int) (Math.random() * options.size());
      getDurationSelector().selectOption(randomIndex);
   }

   @NotNull
   public SelenideElement getDurationSelector()
   {
      return getWrappers().getDurationWrapper().$("select");
   }

   @Override
   public boolean isSearchButtonEnabled()
   {
      return getSearchButton().isEnabled();
   }

   private SelenideElement getSearchButton()
   {
      return getWrappers().getSearchButtonWrapper().$("button");
   }

   public void selectDuration(String durationString)
   {
      getDurationSelector().selectOptionContainingText(durationString);
   }

   public PaxAndRooms paxAndRooms()
   {
      openDropDown(getWrappers().getPaxAndRoomsWrapper(), "div.dropModalContent", ".icon-reset");
      return paxAndRoomsMfeComponent;
   }

   public void doSearch()
   {
      getSearchButton().click();
   }

   public SearchPanel selectDefaults()
   {
      airport().clearSelection().setAllAirportsSelected(true).confirmSelection();
      departure().clearSelection().selectFirstAvailableDate().confirmSelection();
      return this;
   }

   public SearchPanel selectWithParameters()
   {
      TestDataAttributes parameter = new SearchDataHelper().getSearchParameters();
      return selectWithParameters(parameter);
   }

   public SearchPanel selectWithParameters(TestDataAttributes parameter)
   {
      setAirports(parameter);
      setDepartureDate(parameter);
      setDestination(parameter);
      setSuggestion(parameter);
      setDuration(parameter);
      setPaxAndRooms(parameter);
      return this;
   }

   public void searchDefaults()
   {
      selectDefaults();
      doSearch();
      LOGGER.log(WebDriverUtils.getDriver().getCurrentUrl());
   }

   public void searchWithParameters()
   {
      TestDataAttributes parameter = new SearchDataHelper().getSearchParameters();
      searchWithParameters(parameter);
   }

   public void searchWithParameters(TestDataAttributes parameter)
   {
      selectWithParameters(parameter);
      doSearch();
      LOGGER.log(WebDriverUtils.getDriver().getCurrentUrl());
   }

   @Override
   public String[] getErrorMessages()
   {
      return $(shadowDeepCss("div.errorView")).getText().split("\n");
   }

   public String getSelectedAirtports()
   {
      return getWrappers().getAirportWrapper().$("input[readonly='true']").getAttribute("placeholder");
   }

   public String getSelectedDuration()
   {
      return getWrappers().getDurationWrapper().$(".input-selectedText").getText();
   }

   public String getSelectedDate()
   {
      return getWrappers().getDepartureWrapper().$("input[aria-label='select date']")
               .getAttribute("placeholder");
   }

   public String getSelectedDestination()
   {
      return getWrappers().getDestinationWrapper().$("input").getAttribute("placeholder");
   }

   public String getSelectedPaxAndRooms()
   {
      return getWrappers().getPaxAndRoomsWrapper().$("input[aria-label='room and guests']")
               .getAttribute("placeholder");
   }

   public String getAirportComponentLable()
   {
      return getComponentLable(getWrappers().getAirportWrapper());
   }

   @Override
   public String getSearchButtonLable()
   {
      return getWrappers().getSearchButtonWrapper().getText();
   }

   @Override
   public void clickClearAll()
   {
      getClearAllBtn().click();
   }

   @NotNull
   public SelenideElement getClearAllBtn()
   {
      return $(shadowDeepCss("div.clearSearchLink")).$("a");
   }

   public void openFromUnitDetails()
   {
      SelenideElement editSearchPanel =
               $(shadowDeepCss("div.EditButton__editSearch"));
      if (editSearchPanel.exists())
      {
         editSearchPanel.click();
      }
   }

   public String getDestinationComponentLable()
   {
      return getComponentLable(getWrappers().getDestinationWrapper());
   }

   public String getDepartureComponentLable()
   {
      return getComponentLable(getWrappers().getDepartureWrapper());
   }

   public String getDurationComponentLable()
   {
      return getComponentLable(getWrappers().getDurationWrapper());
   }

   public String getPaxAndRoomsdurationComponentLable()
   {
      return getComponentLable(getWrappers().getPaxAndRoomsWrapper());
   }

   public String getDestinationListLabel()
   {
      return getWrappers().getDestinationWrapper().should(Condition.exist, WAIT_TIMEOUT)
               .$(".destination-list")
               .getText();
   }

   private String getComponentLable(SelenideElement wrap)
   {
      String lableClassSelector = "span.text--label";
      return wrap.should(Condition.exist, WAIT_TIMEOUT)
               .$(lableClassSelector).should(Condition.exist, WAIT_TIMEOUT)
               .getText();
   }

   private void openDropDown(SelenideElement wrapper, String dropdownLocator,
            String clickableLocator)
   {
      enableDropDownMode();
      SelenideElement dropdown = wrapper.$(dropdownLocator);
      if (!dropdown.exists())
      {
         wrapper.$(clickableLocator).click();
         if (getLoader(wrapper).isDisplayed())
         {
            LOGGER.log("Loader appeared, waiting...");
            getLoader(wrapper).should(disappear, Duration.ofSeconds(30));
         }
         else
         {
            LOGGER.log("Loader was not appeared, proceeding");
         }
         dropdown.should(appear, WAIT_TIMEOUT);
      }
   }

   private void setAirports(TestDataAttributes parameter)
   {
      String airport = parameter.getAirportName();
      if (airport != null && !airport.isEmpty())
      {
         airport().clearSelection().selectAirportByName(airport).confirmSelection();
      }
      else
      {
         airport().clearSelection().setAllAirportsSelected(true).confirmSelection();
      }
   }

   private void setDepartureDate(TestDataAttributes parameter)
   {
      departure().clearSelection().selectDate(parameter).confirmSelection();
   }

   private void setPaxAndRooms(TestDataAttributes parameter)
   {
      String roomCount = parameter.getRoomCount();
      if (roomCount != null && !roomCount.isEmpty())
         paxAndRooms().selectNumberOfRooms(Integer.parseInt(roomCount));

      String noOfAdults = parameter.getNoOfAdults();
      if (noOfAdults != null && !noOfAdults.isEmpty())
         paxAndRooms().setAdultsNumber(Integer.parseInt(noOfAdults), 1);

      String noOfChildren = parameter.getNoOfChildren();
      if (noOfChildren != null && !noOfChildren.isEmpty())
      {
         int numChildren = Integer.parseInt(noOfChildren);
         if (numChildren > 0)
         {
            String childrenAge = parameter.getChildrenAge();
            String[] age;
            if (childrenAge.isEmpty())
               childrenAge = "0";

            if (childrenAge.contains(","))
            {
               age = childrenAge.split(",");
               for (int i = 0; i < numChildren; i++)
               {
                  paxAndRooms().addChild(age[i].trim(), 1);
               }
            }
            else
            {
               for (int i = 0; i < numChildren; i++)
               {
                  paxAndRooms().addChild(childrenAge, 1);
               }
            }
         }
      }
      paxAndRooms().confirmSelection();
   }

   private void setDuration(TestDataAttributes parameter)
   {
      String duration = parameter.getDuration();
      if (duration != null && !duration.isEmpty())
      {
         selectDuration(duration);
      }
   }

   private void setDestination(TestDataAttributes parameter)
   {
      String destination = parameter.getDestination();
      if (destination != null && !destination.isEmpty())
      {
         destination().clearSelection().selectDestinationFromList(destination, "")
                  .confirmSelection();
      }
   }

   private ComponentWrappers getWrappers()
   {
      return new ComponentWrappersMfe();
   }

   private void setSuggestion(TestDataAttributes parameter)
   {
      String suggestion = parameter.getSuggestion();
      if (suggestion != null && !suggestion.isEmpty())
      {
         destinationSuggestions(suggestion).selectSuggestionFromList(suggestion);
      }
   }

   @NotNull
   private SelenideElement getLoader(SelenideElement wrapper)
   {
      return wrapper.$("div.waitingSpinnerContainer");
   }

   private void waitForCrucialData()
   {
      getWrappers().getDurationWrapper().$("select")
               .shouldHave(Condition.not(Condition.attribute("value", "")),
                        WAIT_TIMEOUT);

   }

   private void enableDropDownMode()
   {
      SelenideElement mfeSearchPanel = $("tui-search-panel-mfe");
      if (!Objects.equals(mfeSearchPanel.getAttribute("dropmodel"), "true"))
         waitForCrucialData();
      executeJavaScript("arguments[0].setAttribute('dropmodel', 'true')",
               mfeSearchPanel);
   }
}
