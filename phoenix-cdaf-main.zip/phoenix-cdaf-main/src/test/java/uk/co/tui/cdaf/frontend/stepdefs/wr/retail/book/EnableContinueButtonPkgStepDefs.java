package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class EnableContinueButtonPkgStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   public EnableContinueButtonPkgStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @Given("that the Agent is on the make payment screen in bookflow")
   public void that_the_Agent_is_on_the_make_payment_screen_in_bookflow()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();
      retailpassengerdetailspage.fillRetailPassengerDetails();
   }

   @When("they view the make payment component at the bottom of the page")
   public void they_view_the_make_payment_component_at_the_bottom_of_the_page()
   {
      assertThat("Enable Continue Button PKG",
               retailpassengerdetailspage.enableContinueButtonPKG(), is(true));
   }

   @Then("they can see the continue CTA")
   public void they_can_see_the_continue_CTA()
   {
      retailpassengerdetailspage.partialpayment();
   }
}
