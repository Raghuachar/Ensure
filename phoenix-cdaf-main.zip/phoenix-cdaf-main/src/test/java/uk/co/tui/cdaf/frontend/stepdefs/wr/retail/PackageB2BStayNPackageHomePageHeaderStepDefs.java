package uk.co.tui.cdaf.frontend.stepdefs.wr.retail;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.nordics.web.browse.GlobalFooter;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class PackageB2BStayNPackageHomePageHeaderStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageB2BStayNPackageHomePageHeaderStepDefs.class);

   private final Map<String, String> searchMap = new HashMap<>();

   private final SearchResultsPage searchResultsPage = new SearchResultsPage();

   private final HomePage homepage = new HomePage();

   private final GlobalFooter globalFooter = new GlobalFooter();

   private final RetailPage retailPage = new RetailPage();

   @Given("a agent is on the B2B TUI homepage")
   public void a_agent_is_on_the_B_B_TUI_homepage()
   {
      searchResultsPage.searchPanelComponent.visit();
      retailPage.inhouseAgentLogin();
   }

   @When("they view the TUI Global Header")
   public void they_view_the_TUI_Global_Header()
   {
      homepage.viewHeader();
   }

   @Then("the following options will displayed in this order:")
   public void the_following_options_will_displayed_in_this_order(List<String> components)
   {
      homepage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(homepage.getHeaders());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final String element = searchMap.get(componentIdentifier.trim());
            LOGGER.log(LogLevel.INFO, searchMap);
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = true;
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     true, true), true, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("they will see the following secondary options in this order:")
   public void they_will_see_the_following_secondary_options_in_this_order(List<String> components)
   {
      homepage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(homepage.getHeadersComponents());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final String element = searchMap.get(componentIdentifier.trim());
            LOGGER.log(LogLevel.INFO, searchMap);
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = true;
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     true, true), true, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("they will see a logo for TUI")
   public void they_will_see_a_logo_for_TUI()
   {
      assertThat(" TUI Logo is not displayed", homepage.checkTUILogo(), is(true));
   }

   @Then("the information visible will what has been set up the global footer component")
   public void the_information_visible_will_what_has_been_set_up_the_global_footer_component()
   {
      assertThat("navigation structure is not present:", globalFooter.navStructure(), is(true));
   }

   @Then("the following options will be Displayed in this order:")
   public void the_following_options_will_be_Displayed_in_this_order(DataTable components)
   {
//      TODO: this method should be refactored since not all elements are always should be present and each brand has different elements
      homepage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(homepage.getB2CHeadersComponents());
      components.asList().forEach(componentIdentifier ->
      {
         try
         {
            final String element = searchMap.get(componentIdentifier.trim());
            LOGGER.log(LogLevel.INFO, searchMap);
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     true, true), true, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("they will see the following secondary Options in this order:")
   public void they_will_see_the_following_secondary_Options_in_this_order(DataTable components)
   {
      homepage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(homepage.getB2CSecondaryComponents());
//      components.stream().forEach(componentIdentifier ->
//      {
//         try
//         {
//            final String element = searchMap.get(componentIdentifier.trim());
//            LOGGER.log(LogLevel.INFO, searchMap);
//            assertThat(componentIdentifier + " component not found in the Map", element,
//                     is(notNullValue()));
//            boolean actual = true;
//            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
//                     true, true), true, is(true));
//         }
//         catch (Exception e)
//         {
//            assertThat(componentIdentifier + " component not displayed", false, is(true));
//         }
//      });
   }
}
