package uk.co.tui.cdaf.frontend.stepdefs.uk.web.beach_holiday.book.flight_options;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.book.flightoptions.FlightOptionsExtraSpaceSeatComponent;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class ExtraSpaceSeatConfirmationStepDefs
{
   FlightOptionsExtraSpaceSeatComponent extraSpacepage = new FlightOptionsExtraSpaceSeatComponent();

   @Then("they will see the following copy:")
   public void they_will_see_the_following_copy(List<String> seatContentList)
   {
      assertThat("modal content is not displayed", extraSpacepage.isModalContentDisplayed(),
               is(true));
   }

   @When("they select {string}")
   public void they_select(String modalSelection)
   {
      WebElement modalElement = extraSpacepage.getModalComponents(modalSelection);
      extraSpacepage.closeModal(modalElement);
   }
}
