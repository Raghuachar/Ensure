package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class ExcursionComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[class*='tuiExcursion']")
   private WebElement excursionContainer;

   @FindBy(css = "[class*='excursionImage']")
   private WebElement excursionImage;

   @FindBy(css = "[class*='excursionContent'] h3")
   private WebElement excursionTitle;

   @FindBy(css = "[class*='excursionContent'] p")
   private WebElement excursionDescription;

   @FindBy(css = "[class*='excursionContent'] a")
   private WebElement exploreButton;

   public ExcursionComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getExploreButton()
   {
      return wait.getWebElementWithLazyWait(exploreButton);
   }

   public void clickOnExploreButton()
   {
      WebElementTools.click(getExploreButton());
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getExursionComponents()
   {
      return new HashMap<>()
      {
         {
            put("TUI Excursion", excursionContainer);
            put("Excursion Image", excursionImage);
            put("Excursion Title", excursionTitle);
            put("Excursion desc", excursionDescription);
            put("Explore button", exploreButton);
         }
      };
   }

}
