package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.confirmation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;

public class ConfirmationMultipleRoomTypeinHolidayComponent extends AbstractPage
{
   private final HashMap<String, WebElement> multipleRoomTypeMap;

   @FindBy(css = "#holidaySummaryConfirmation__component > section > ul > li:nth-child(9)")
   private WebElement RoomTypeDescriptionOne;

   @FindBy(css = "#holidaySummaryConfirmation__component > section > ul > li:nth-child(10)")
   private WebElement RoomTypeDescriptionTwo;

   @FindBy(css = "#holidaySummaryConfirmation__component > section > ul > li:nth-child(11)")
   private WebElement boardBasis;

   public ConfirmationMultipleRoomTypeinHolidayComponent()
   {
      multipleRoomTypeMap = new HashMap<>();
   }

   public HashMap<String, WebElement> getMultipleRoomTypeComps()
   {
      multipleRoomTypeMap.put("Room Type Description", RoomTypeDescriptionOne);
      multipleRoomTypeMap.put("Another Room Type Description", RoomTypeDescriptionTwo);
      multipleRoomTypeMap.put("Board basis", boardBasis);
      return multipleRoomTypeMap;
   }
}
