package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TriangularFlightOptionComponent extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(TriangularFlightOptionComponent.class);

   private final HashMap<String, WebElement> searchOutCardMap;

   private final HashMap<String, WebElement> searchRTNCardMap;

   private final WebElementWait wait;

   @FindBy(css = "[class*='ResultsListItem__fightInfo']")
   private List<WebElement> flightOption;

   @FindBy(css = "[aria-label='overlay open'][class='popups__overlay popups__opened ']")
   private WebElement flightDetails;

   @FindBy(css = "[class*='rah-static rah-static--height-auto']")
   private WebElement text;

   @FindBy(css = "[class*='rah-static rah-static--height-zero']")
   private WebElement disappearText;

   @FindBy(xpath = "//div[@aria-label='overlay open']/section/section/header/span")
   private WebElement popUpClose;

   @FindBy(css = "[class*='FlightDetailsPopup__stopOverMessage'] p")
   private List<WebElement> textTriangularFlight;

   @FindBy(xpath = "//div[@aria-label='overlay open']//div[@class='FlightDetailsPopup__stopOverMessage']//font/font")
   private WebElement textTriangularFlights;

   @FindBy(xpath = "//div[@class='FlightDetailsPopop_timeinfo']\n")
   private WebElement outBoundTime;

   @FindBy(xpath = "//div[@class='FlightDetailsPopup__journeyType']/span[contains(text(),'UIT')]/../../div[@class='FlightDetailsPopup__date']\n")
   private WebElement outBoundDate;

   @FindBy(xpath = "//div[@class='FlightDetailsPopup__journeyType']/span[contains(text(),'Terug')]/../../div[@class='FlightDetailsPopup__date']\n")
   private WebElement returnDeptDate;

   @FindBy(xpath = "//div[@class='FlightDetailsPopup__airportInfo']/p")
   private WebElement OutBoundDepartAirport;

   @FindBy(xpath = " //div[contains(@class, 'FlightDetailsPopup__stopOverMessage') and text()='Show more']")
   private WebElement showMore;

   @FindBy(css = "[aria-label=['accordion toggle']")
   private WebElement showless;

   @FindBy(xpath = "//div[@class='FlightDetailsPopup__airportInfo']/p[2]")
   private WebElement OutBoundDepartAirportCode;

   @FindBy(xpath = "//p[@class='FlightDetailsModal__carrier']")
   private List<WebElement> thirdFlightOption;

   @FindBy(xpath = "[class='FlightDetailsPopup__infoTitle']")
   private WebElement soWhyAreYou;

   @FindBy(xpath = "We aim to offer you the best prices and widest selection of flight times from the airport that is most convenient for you. That's why on this occasion we are using an alternative airline to get you to and from your holiday destination.")
   private WebElement reassuranceMessage;

   @FindBy(xpath = "//span[@class='HighlightedLink__text'][contains(.,'Verberg informatie')]")
   private List<WebElement> showlessAccordion;

   @FindBy(css = "[class*='ResultListItemV2__flightType']")
   private List<WebElement> getflightType;

   @FindBy(css = "[class='popups__overlay popups__opened '] p[class='FlightDetailsPopup__carrier']")
   private List<WebElement> dynamicFlightName;

   @FindBy(css = "[class='popups__overlay popups__opened '] div[class='FlightDetailsPopup__infoTitle']")
   private WebElement dynamicFlightReassuranceMessageHeader;

   @FindBy(css = "[class='popups__overlay popups__opened '] p")
   private List<WebElement> dynamicFlightReassuranceMessage;

   @FindBy(css = "[data-testid='country-switcher-button']")
   private WebElement countySwitchButton;

   @FindBy(css = "[class='SelectDropdown__selectbox'] div")
   private WebElement selectDropdown;

   @FindBy(css = "[class='SelectDropdown__menuOpen'] li")
   private List<WebElement> selectDropdownList;

   @FindBy(css = "[aria-label='action apply']")
   private WebElement changeLangauage;

   @FindBy(xpath = "//div[@aria-label='overlay open']//div[2]//div[2]//div[1]//div[1]//div[1]//p[1]")
   private WebElement inBoundType;

   @FindBy(xpath = "//div[@aria-label='overlay open']//div[@class='popups__contentBody']//div[1]//div[2]//div[1]//div[1]//div[1]//p[1]")
   private WebElement outBoundType;

   @FindBy(xpath = "//div[@aria-label='overlay open']//div[@class='FlightDetailsModal__infoTitle']")
   private WebElement directFlightMessage1;

   @FindBy(css = "div[aria-label='overlay open'] p:nth-child(5)")
   private WebElement directFlightMessage2;

   @FindBy(css = "div[aria-label='overlay open'] p:nth-child(6)")
   private WebElement directFlightMessage3;

   public TriangularFlightOptionComponent()
   {
      searchOutCardMap = new HashMap<>();
      searchRTNCardMap = new HashMap<>();
      wait = new WebElementWait();
   }

   public boolean isFlightOptionDisplay()
   {
      for (WebElement element : flightOption)
      {
         WebElementTools.isPresent(element);
         return true;
      }
      return false;
   }

   public boolean isTextDisplay()
   {
      return WebElementTools.isPresent(text);
   }

   public boolean isDisappearText()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(disappearText);
   }

   public boolean isShowLessDisplay()
   {
      return WebElementTools.isPresent(showless);
   }

   public void clickShowLess()
   {
      WebElementTools.click(showless);
   }

   public void clickFlightOption()
   {
      for (WebElement i : flightOption)
      {
         wait.forJSExecutionReadyLazy();
         wait.forJSExecutionReadyLazy();
         wait.forJSExecutionReadyLazy();
         WebElementTools.mouseOverAndClick(i);
         wait.forComplexPageLoad();
         if (WebElementTools.isDisplayed(textTriangularFlights))
         {
            wait.forJSExecutionReadyLazy();
            break;
         }
         else
         {
            if (WebElementTools.isDisplayed(popUpClose))
            {
               wait.forComplexPageLoad();
               wait.forJSExecutionReadyLazy();
               WebElementTools.click(popUpClose);
            }
         }
      }
   }

   public void selectShowMore()
   {
      for (WebElement i : flightOption)
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.click(i);
         if (WebElementTools.isDisplayed(textTriangularFlight.get(4)))
         {
            WebElementTools.click(showMore);
         }

      }

   }

   public boolean isShowMoreDisplay()
   {
      return WebElementTools.isPresent(showMore);
   }

   public boolean isFlightDetailsDisplay()
   {
      return WebElementTools.isPresent(flightDetails);
   }

   public Map<String, WebElement> setSearchComponentsMap()
   {
      wait.forJSExecutionReadyLazy();
      if (WebElementTools.isDisplayed(textTriangularFlights))
      {
         wait.forJSExecutionReadyLazy();
         wait.forJSExecutionReadyLazy();
         wait.forJSExecutionReadyLazy();
         searchOutCardMap.put("Departure Date", outBoundDate);
         searchOutCardMap.put("Departure Time", outBoundTime);
         searchOutCardMap.put("Departure Airport", OutBoundDepartAirport);
         searchOutCardMap.put("Departure Airport Code", OutBoundDepartAirportCode);
         searchOutCardMap.put("Arrival Airport Name", OutBoundDepartAirport);
         searchOutCardMap.put("Arrival Airport Code", OutBoundDepartAirportCode);
         searchRTNCardMap.put("Departure Date", returnDeptDate);
         searchRTNCardMap.put("CardDeparture Time", outBoundTime);
         searchRTNCardMap.put("Departure Airport", OutBoundDepartAirport);
         searchRTNCardMap.put("Departure Airport Code", OutBoundDepartAirportCode);
         searchRTNCardMap.put("Arrival Airport Name", OutBoundDepartAirport);
         searchRTNCardMap.put("Arrival Airport Code", OutBoundDepartAirportCode);
      }
      else
      {
         wait.forJSExecutionReadyLazy();

         WebElementTools.click(popUpClose);
      }
      return searchOutCardMap;
   }

   public void thirdPartyFlightOptionCheck(String type)
   {
      for (int i = 0; i <= flightOption.size(); i++)
      {
         String currentType = WebElementTools.getElementText(getflightType.get(i)).replace(" ", "");
         if (currentType.equalsIgnoreCase(type))
         {
            wait.forJSExecutionReadyLazy();
            WebElementTools.click(flightOption.get(i));
            LOGGER.log(LogLevel.INFO, thirdFlightOption.size());
            String flightType = WebElementTools.getElementText(thirdFlightOption.get(i));
            LOGGER.log(LogLevel.INFO, thirdFlightOption.get(i));
            LOGGER.log(LogLevel.INFO, flightType);
            if (!currentType.equalsIgnoreCase("TUI fly"))
            {
               wait.forJSExecutionReadyLazy();
               break;
            }
            else
            {
               wait.forJSExecutionReadyLazy();
               wait.forJSExecutionReadyLazy();
               WebElementTools.click(popUpClose);
            }
         }
         else
         {
            LOGGER.log(LogLevel.WARN, currentType + " not equal to " + type);
         }
      }
   }

   public boolean showLessAccordion()
   {
      for (int i = 0; true; i++)
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.isPresent(showlessAccordion.get(i));
         LOGGER.log(LogLevel.INFO, showlessAccordion.get(i));
         break;
      }
      return true;
   }

   public void selectFlightDetailsLink()
   {
      closeDynamicFlightPopUp();
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(flightOption.get(0));
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
   }

   public Map<String, WebElement> messageSearchComponentsMap()
   {
      wait.forJSExecutionReadyLazy();
      String flightType = WebElementTools.getElementText(thirdFlightOption.get(2));
      if (!flightType.equalsIgnoreCase("TUI fly"))
      {
         wait.forJSExecutionReadyLazy();
         wait.forJSExecutionReadyLazy();
         wait.forJSExecutionReadyLazy();
         searchOutCardMap.put("So why are you flying with [CARRIER] on your TUI holiday?",
                  soWhyAreYou);
         searchOutCardMap.put(
                  "We aim to offer you the best prices and widest selection of flight times from the airport that is most convenient for you. That's why on this occasion we are using an alternative airline to get you to and from your holiday destination.",
                  reassuranceMessage);
      }
      else
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.click(popUpClose);
      }

      return searchOutCardMap;
   }

   public String getflightTypeAvailable(String type)
   {
      // TODO: logic should be changed to get flightOption based on current getflightType rather then it's index
      for (int i = 0; i <= getflightType.size(); i++)
      {
         String flightTypeText = WebElementTools.getElementText(getflightType.get(i));
         if (flightTypeText.equals(type) || flightTypeText.replace(" ", "").equalsIgnoreCase(type))
         {
            WebElementTools.javaScriptScrollToElement(flightOption.get(i));
            WebElementTools.click(flightOption.get(i));
            wait.forJSExecutionReadyLazy();
            WebElementTools.click(popUpClose);
            wait.forJSExecutionReadyLazy();
            return flightTypeText;
         }
      }
      return null;
   }

   public String getflightTypeTriangular(String type)
   {
      // TODO: logic should be changed to get flightOption based on current getflightType rather then it's index
      for (int i = 0; i <= getflightType.size(); i++)
      {
         String flightTypeText = WebElementTools.getElementText(getflightType.get(i));
         if (flightTypeText.equals(type) || flightTypeText.replace(" ", "").equalsIgnoreCase(type))
         {
            WebElementTools.javaScriptScrollToElement(flightOption.get(i));
            WebElementTools.click(flightOption.get(i));
            return flightTypeText;
         }
      }
      return null;
   }

   public boolean getFlightType(String type)
   {
      boolean flightType = false;
      for (int i = 0; i <= getflightType.size(); i++)
      {
         if (WebElementTools.getElementText(getflightType.get(i)).equals(type))
         {
            WebElementTools.javaScriptScrollToElement(flightOption.get(i));
            flightType = true;
            break;
         }
      }
      return flightType;
   }

   public void getDynamicFlights(String flightType)
   {
      wait.forJSExecutionReadyLazy();
      for (int i = 0; i <= getflightType.size(); i++)
      {
         if (WebElementTools.getElementText(getflightType.get(i)).equals(flightType))
         {
            wait.forJSExecutionReadyLazy();
            WebElementTools.javaScriptScrollToElement(flightOption.get(i));
            WebElementTools.click(flightOption.get(i));
            if (WebElementTools.getElementText(dynamicFlightName.get(0)).contains("Transavia"))
            {
               break;
            }
            else
            {
               wait.forJSExecutionReadyLazy();
               WebElementTools.click(popUpClose);
               wait.forJSExecutionReadyLazy();
            }
         }
      }
   }

   public String getDynamicFlightReassurenceMessage()
   {
      StringBuilder dymanic = new StringBuilder();
      dymanic = new StringBuilder(WebElementTools
               .getElementText(
                        wait.getWebElementWithLazyWait(dynamicFlightReassuranceMessageHeader)));
      for (int i = 0; i <= dynamicFlightReassuranceMessage.size(); i++)
      {
         int message = dynamicFlightReassuranceMessage.size();
         if (message - 2 == i || message - 1 == i)
         {
            dymanic.append(WebElementTools.getElementText(dynamicFlightReassuranceMessage.get(i)));
         }
      }
      return dymanic.toString();
   }

   public void changeLangaugeSelection()
   {
      WebElementTools.click(countySwitchButton);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(selectDropdown);
      WebElementTools.click(selectDropdownList.get(1));
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(changeLangauage);
   }

   public void dynamicFlight()
   {
      for (WebElement i : flightOption)
      {
         wait.forAppear(i);
         WebElementTools.mouseOverAndClick(i);
         wait.forComplexPageLoad();
         if (WebElementTools.getElementText(outBoundType).contains("Transavia"))
         {
            wait.forJSExecutionReadyLazy();
            break;
         }
         else
         {
            wait.forComplexPageLoad();
            wait.forJSExecutionReadyLazy();
            WebElementTools.click(popUpClose);
         }
      }
   }

   public void selectDynamicFlight()
   {
      if (WebElementTools.isDisplayed(popUpClose))
      {
         wait.forComplexPageLoad();
         wait.forJSExecutionReadyLazy();
         WebElementTools.click(popUpClose);
      }
      for (int i = 0; i <= flightOption.size(); i++)
      {
         if (WebElementTools.getElementText(getflightType.get(i)).contains("Direct"))
         {
            wait.forJSExecutionReadyLazy();
            WebElementTools.click(flightOption.get(i));
            if (!WebElementTools.getElementText(outBoundType)
                     .equalsIgnoreCase("TUI fly") && !WebElementTools.getElementText(inBoundType)
                     .equalsIgnoreCase("TUI fly"))
            {
               wait.forJSExecutionReadyLazy();
               break;
            }
            else
            {
               wait.forJSExecutionReadyLazy();
               wait.forJSExecutionReadyLazy();
               WebElementTools.click(popUpClose);
            }
         }
      }
   }

   public WebElement getDynamicFlightPopupMessages1()
   {
      return directFlightMessage1;

   }

   public WebElement getDynamicFlightPopupMessages2()
   {
      wait.forJSExecutionReadyLazy();
      return directFlightMessage2;
   }

   public WebElement getDynamicFlightPopupMessages3()
   {
      wait.forJSExecutionReadyLazy();
      return directFlightMessage3;
   }

   public void closeDynamicFlightPopUp()
   {
      if (WebElementTools.isDisplayed(popUpClose))
      {
         wait.forComplexPageLoad();
         wait.forJSExecutionReadyLazy();
         WebElementTools.click(popUpClose);
      }
   }
}
