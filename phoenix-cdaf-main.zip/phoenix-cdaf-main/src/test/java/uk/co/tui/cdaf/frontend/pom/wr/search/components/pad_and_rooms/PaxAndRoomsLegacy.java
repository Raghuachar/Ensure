package uk.co.tui.cdaf.frontend.pom.wr.search.components.pad_and_rooms;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.jetbrains.annotations.NotNull;

import java.time.Duration;
import java.util.Objects;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class PaxAndRoomsLegacy extends PaxAndRoomsMfe
{
   private static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   private SelenideElement dropdown;

   @Override
   public boolean isOpen()
   {
      return container().isDisplayed();
   }

   @Override
   public PaxAndRooms clearSelection()
   {
      getClearLink().click();
      return this;
   }

   @Override
   public PaxAndRooms selectNumberOfRooms(int roomsNumber)
   {
      getRoomSelector().selectOptionByValue(Integer.toString(roomsNumber));
      return this;
   }

   @Override
   public PaxAndRooms addChild(String age, int roomNumber)
   {
      SelenideElement childSelector = getRoom(roomNumber).shouldBe(Condition.visible,
                        WAIT_TIMEOUT).$(".ChildrenSelector__childrenSelector")
               .$("select");
      int currentNumberOfChildren = Integer.parseInt(
               Objects.requireNonNull(childSelector.getSelectedOptionValue()));
      childSelector
               .selectOptionByValue(String.valueOf(currentNumberOfChildren + 1));
      $$(".ChildrenAge__childAgeSelector").get(currentNumberOfChildren).$("select")
               .selectOptionByValue(age);
      return this;
   }

   @Override
   public PaxAndRooms setAdultsNumber(int numberOfPersons, int roomNumber)
   {
      getRoom(roomNumber).shouldBe(Condition.visible, WAIT_TIMEOUT)
               .$(".AdultSelector__adultSelector").$("select")
               .selectOptionByValue(String.valueOf(numberOfPersons));
      return this;
   }

   @NotNull
   private SelenideElement getPassengersBlock(int roomNumber)
   {
      SelenideElement room = getRoom(roomNumber);
      SelenideElement adultSelector = room.$("div.AdultSelector__adultSelector");
      return adultSelector.$("div.inputs__select");
   }

   @Override
   public SelenideElement getConfirmButton()
   {
      return container().$("div.DropModal__footerContainer").$("button");
   }

   @Override
   public SelenideElement getRoomSelector()
   {
      return container().$("div[aria-label='room select']").$("select");
   }

   @Override
   public String[] getLabels()
   {
      return $(shadowDeepCss("div.RoomAndPaxOverlay__roomAndPaxContent")).getText().split("\n");
   }

   @Override
   public PaxAndRooms selectRandomPaxAndRooms()
   {
      int roomsNumber = (int) (Math.random() * 4) + 1;
      for (int i = 0; i < roomsNumber; i++)
      {
         int room = i + 1;
         selectNumberOfRooms(room);
         setAdultsNumber(1, room);
      }
      addChild("8", 1);
      return this;
   }
   @Override
   public SelenideElement getClearLink()
   {
      return container().$("a.DropModal__clear");
   }

   @Override
   public String getErrorMessage()
   {
      return $(shadowDeepCss("div.alerts__alertMessages")).getText();
   }

   @Override
   public void confirmSelection()
   {
      getConfirmButton().click();
   }

   private SelenideElement container()
   {
      if (dropdown == null)
      {
         dropdown = $(shadowDeepCss("section[aria-label='room and guest']"));
      }
      dropdown.should(appear, WAIT_TIMEOUT);
      return dropdown;
   }

   @Override
   public SelenideElement getAdultSelector(int roomNumber)
   {
      SelenideElement passengersBlock = getPassengersBlock(roomNumber);
      return passengersBlock.$("span.inputs__selectText");
   }

   private SelenideElement getRoom(int roomNumber)
   {
      int roomIndex = roomNumber - 1;
      return container().$(".Passengers__passengerSelectorList").$$(".Passengers__passengerContent")
               .get(roomIndex);
   }
}
