package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.book.summary;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.summary.VipSummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class VIPCabinClassComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public final VipSummaryPage vipSummaryPage;

   public VIPCabinClassComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      vipSummaryPage = new VipSummaryPage();
   }

   @Given("the customer is on the Package Hotel Details page")
   public void the_customer_is_on_the_Package_Hotel_Details_page()
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @Given("the associated flight for their VIP package is VLH \\(Long Haul)")
   public void the_associated_flight_for_their_VIP_package_is_VLH_Long_Haul()
   {
      //Will implement this step once it is available
      throw new PendingException();
   }

   @When("they are navigated to the Customise page")
   public void they_are_navigated_to_the_Customise_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they are presented with the Cabin Class component")
   public void they_are_presented_with_the_Cabin_Class_component()
   {
      vipSummaryPage.vipCabinClassComponent.getVipCabinClassComponentsMap();
   }

   @Then("they will see that there is no option to upgrade or downgrade cabin class")
   public void they_will_see_that_there_is_no_option_to_upgrade_or_downgrade_cabin_class()
   {
      boolean actual = vipSummaryPage.vipCabinClassComponent.isOnlyDeluxClassDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Only Delux Cabin Component wasn't displayed", actual, true), actual, is(true));
   }
}
