package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.paymentoptions;

import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentOptionsComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentProviderPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentTypeComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.VoucherCodeComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.WCMSComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class PaymentOptionsPage
{
   public final ProgressionbarNavigationComponent navigationComponent;

   public final VoucherCodeComponent voucherComponent;

   public final PaymentTypeComponent paymentTypeComponent;

   public final WCMSComponent wcmsComponent;

   public final PaymentOptionsComponent paymentOptionsComponent;

   public final PaymentProviderPage pspPage;

   public final WebElementWait wait;

   private final Map<String, WebElement> paymentMap;

   public PaymentOptionsPage()
   {
      paymentMap = new HashMap<>();
      navigationComponent = new ProgressionbarNavigationComponent();
      voucherComponent = new VoucherCodeComponent();
      paymentTypeComponent = new PaymentTypeComponent();
      wcmsComponent = new WCMSComponent();
      wait = new WebElementWait();
      paymentOptionsComponent = new PaymentOptionsComponent();
      pspPage = new PaymentProviderPage();
   }

   public Map<String, WebElement> getPaymentPageComponents()
   {
      paymentMap.put("Price Panel", navigationComponent.getPricePanelElement());
      paymentMap.put("Navigation Panel", navigationComponent.getNavigationPanelElement());
      paymentMap.put("Voucher Code", voucherComponent.getVoucherHeadingElement());
      paymentMap.put("Payment Options", paymentTypeComponent.getPaymentType().get(0));
      paymentMap.put("Payment Methods", paymentTypeComponent.getPaymentCards().get(0));
      paymentMap.put("Continue CTA", wcmsComponent.getContinueElement());
      paymentMap.put("PAYMENT", paymentTypeComponent.getPaymentHeadingElement());
      paymentMap.put("Pay Amount Today", paymentTypeComponent.getTotalPaymentAmount());
      return paymentMap;
   }
}
