package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePaymentTypeAccordionStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   public final FOReconcilationPaymentPageComponents reconcilePage;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackagePaymentTypeAccordionStepDefs()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      reconcilePage = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Agent is viewing the package reconcile payments page")
   public void that_the_Agent_is_viewing_the_package_reconcile_payments_page()
   {
      packagenavigation.retailLogin();
      wait.forJSExecutionReadyLazy();

   }

   @When("a payment type has recieved payments")
   public void a_payment_type_has_recieved_payments()
   {
      reconcilePage.navigateToReconcilePaymentPage();
      wait.forJSExecutionReadyLazy();
   }

   @Then("it will appear in the banking table")
   public void it_will_appear_in_the_banking_table()
   {
      pKgReconcilationPaymentPageComponents.isPaymentTypeRecievedPayments();
   }

   @Then("will show the  information as following")
   public void will_show_the_information_as_following(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("payments types is  present", reconcilePage.paymentMethodTypeAccordian(),
               is(true));
      assertThat("payment totals numeric value is  present",
               reconcilePage.paymentMethodTypeAccordian(), is(true));
      assertThat("banking now numeric is value  present ",
               reconcilePage.paymentMethodTypeAccordian(), is(true));
      assertThat("discrepancy value is present", reconcilePage.paymentMethodTypeAccordian(),
               is(true));
      assertThat("reason dropdown value is present", reconcilePage.paymentMethodTypeAccordian(),
               is(true));
      assertThat("expand and collapse chevron is present",
               reconcilePage.paymentMethodTypeAccordian(), is(true));
   }

   @Given("that the Agent is viewing the banking and reconciliations page")
   public void that_the_Agent_is_viewing_the_banking_and_reconciliations_page()
   {
      packagenavigation.retailLogin();
      wait.forJSExecutionReadyLazy();
   }

   @When("they view the total discrepancies component beneath the banking table")
   public void they_view_the_total_discrepancies_component_beneath_the_banking_table()
   {
      reconcilePage.navigateToReconcilePaymentPage();
      wait.forJSExecutionReadyLazy();
   }

   @Then("they will see the total discrepancies that have accumulated")
   public void they_will_see_the_total_discrepancies_that_have_accumulated(
            io.cucumber.datatable.DataTable dataTable)
   {
      pKgReconcilationPaymentPageComponents.isDiscrepanciesBeneathBankingTable();
   }

}
