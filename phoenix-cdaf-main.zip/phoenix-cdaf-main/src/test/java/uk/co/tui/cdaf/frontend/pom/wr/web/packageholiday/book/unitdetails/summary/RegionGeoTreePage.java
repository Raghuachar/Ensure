package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class RegionGeoTreePage extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[aria-label='Your accommodation']")
   public WebElement summaryComponent;

   @FindBy(css = "[class='Accommodation__details']")
   public WebElement geoTreeSummary;

   @FindBy(css = "[aria-label='Accomodation Details']")
   public WebElement geoTreePax;

   @FindBy(css = "[aria-label='Slab title']")
   public WebElement clickOnHolidaySummary;

   @FindBy(css = "[aria-label='Accomodation Details']")
   public WebElement geoTreePayment;

   @FindBy(css = "[id='holidaySummaryConfirmation__component']")
   public WebElement confirmationComponent;

   @FindBy(css = "[aria-label='resort details']")
   public WebElement geoTreeConfirmation;

   public RegionGeoTreePage()
   {
      wait = new WebElementWait();
   }

   public boolean isSummaryComponentPresent()
   {
      return WebElementTools.isPresent(summaryComponent);
   }

   public boolean isSummaryGeoTreePresent()
   {
      return WebElementTools.isPresent(geoTreeSummary);
   }

   public void clickOnHolidaySummaryComponent()
   {
      WebElementTools.click(clickOnHolidaySummary);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isPaxGeoTreePresent()
   {
      return WebElementTools.isPresent(geoTreePax);
   }

   public boolean isPaymentGeoTreePresent()
   {
      return WebElementTools.isPresent(geoTreePayment);
   }

   public boolean isConfirmationComponentPresent()
   {
      return WebElementTools.isPresent(confirmationComponent);
   }

   public boolean isConfirmationGeoTreePresent()
   {
      return WebElementTools.isPresent(geoTreeConfirmation);
   }
}
