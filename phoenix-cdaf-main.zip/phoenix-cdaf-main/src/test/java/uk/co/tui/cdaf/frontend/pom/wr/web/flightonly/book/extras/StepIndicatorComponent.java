package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class StepIndicatorComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[aria-label='navigation link']")
   private WebElement navigationPanel;

   @FindBy(css = "[class*='stepIndicator'] ul>li>a")
   private List<WebElement> stepIndicator;

   public StepIndicatorComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getNavigationPanelElement()
   {
      return navigationPanel;
   }

   public List<WebElement> getStepIndicator()
   {
      return wait.getWebElementWithLazyWait(stepIndicator);
   }

   public void clickOnSeatBaggageIndicator()
   {
      WebElementTools.click(getStepIndicator().get(0));
   }

   public void clickOnExtrasIndicator()
   {
      WebElementTools.click(getStepIndicator().get(1));
   }

   public boolean isExtrasStepIndicatorDisplayed()
   {
      return WebElementTools.isPresent(getStepIndicator().get(1));
   }

}
