package uk.co.tui.cdaf.frontend.pom.wr.web.shared.browse.homepage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.ArrayList;
import java.util.List;

public class CountryLanguageSelector extends AbstractPage
{

   @FindBy(css = "#tui-country-selector label")
   private WebElement overlayLabel;

   @FindAll({
            @FindBy(css = "#tui-country-selector form div:nth-child(2) div.SelectDropdown__selectdropdown .SelectDropdown__large.SelectDropdown__button"),
            @FindBy(css = "div.SelectDropdown__selectdropdown .SelectDropdown__large.SelectDropdown__button") })
   private WebElement selectedlanguage;

   @FindBy(css = "#tui-country-selector form div:nth-child(1) div.SelectDropdown__selectdropdown .SelectDropdown__large.SelectDropdown__button")
   private WebElement selectedlanguageOnly;

   @FindBy(css = ".SelectDropdown__menuOpen li")
   private List<WebElement> availableLanguagesInDropdown;

   @FindBy(css = "footer>button")
   private WebElement changeSiteButton;

   @FindBy(css = "#tui-country-selector form div:nth-child(1) div.SelectDropdown__selectdropdown .SelectDropdown__large.SelectDropdown__button svg")
   private List<WebElement> selectedlanguageFrench;

   @FindBy(css = "footer>button")
   private List<WebElement> changeSiteButtonB2B;

   private List<String> tempList;

   public WebElement getOverlayLabel()
   {
      return overlayLabel;
   }

   public WebElement getSelectedlanguage()
   {
      return selectedlanguage;
   }

   public WebElement getSelectedlanguageOnly()
   {
      return selectedlanguageOnly;
   }

   public List<WebElement> getAvailableLanguagesInDropdown()
   {
      return availableLanguagesInDropdown;
   }

   public List<String> getAvailableLanguagesTextInDropdown()
   {
      tempList = new ArrayList<>();
      getAvailableLanguagesInDropdown().forEach(val -> tempList.add(val.getText()));
      return tempList;
   }

   public WebElement getChangeSiteButton()
   {
      return changeSiteButton;
   }

   public WebElement getLanguageLabelInModal()
   {
      return overlayLabel;
   }

   public List<WebElement> getSelectedlanguageFrench()
   {
      return selectedlanguageFrench;
   }

   public List<WebElement> getChangeSiteButtonb2b()
   {
      return changeSiteButtonB2B;
   }
}
