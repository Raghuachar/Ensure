package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchpanel;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.nordics.web.flight_only.NordicFlightOnlySearchPanelPage;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Objects;

public class SearchPanelComponent extends NordicFlightOnlySearchPanelPage
{

   @FindAll({ @FindBy(xpath = "//div[@aria-label='clear search']//a"),
            @FindBy(css = "[aria-label='clear search'] a"),
            @FindBy(css = "[aria-label*='search panel'] a") })
   private List<WebElement> clearSearch;

   @FindBy(css = "[aria-label*='Close']")
   private List<WebElement> privacyPopUpClose;

   public SearchPanelComponent()
   {
      super();
   }

   public void closePrivacyPopUp()
   {
      if (!privacyPopUpClose.isEmpty())
      {
         privacyPopUpClose = wait.getWebElementWithLazyWait(privacyPopUpClose);
         for (WebElement popUpClose : privacyPopUpClose)
            WebElementTools.clickElementJavaScript(popUpClose);
      }
   }

   public final void wrFoOneWaySearch()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      if (!clearSearch.isEmpty())
         WebElementTools.click(wait.getWebElementWithLazyWait(clearSearch.get(0)));
      wait.forAppear(oneWayRadioButton);
      selenideHelper.clickElementSelenide(oneWayRadioButton);
      selectDepartureAirport();
      wrFoselectArrivalAirport();
      selectDepartureDate();
      selectAdultAndChild();
      enterChildernAges();
      selenideHelper.clickElementSelenide(searchButton);
   }

   public final void wrFoTwoWaySearch()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      if (!clearSearch.isEmpty())
         WebElementTools.click(wait.getWebElementWithLazyWait(clearSearch.get(0)));
      wait.forAppear(twoWayRadioButton);
      selenideHelper.clickElementSelenide(twoWayRadioButton);
      selectDepartureDate();
      selectReturnDate();
      selectDepartureAirport();
      wrFoselectArrivalAirport();
      selectAdultAndChild();
      enterChildernAges();
      selenideHelper.clickElementSelenide(searchButton);
   }

   public final void wrFoselectArrivalAirport()
   {
      selenideHelper.clickElementSelenide(flyingTo);
      wait.forJSExecutionReadyLazy();
      TestDataAttributes parameter = new SearchDataHelper()
               .getSearchParameters(customSearch.getScenarioId());
      if (StringUtils.isNotEmpty(customSearch.getArrArpt()))
         WebElementTools.selectElementFromListBasedOnText(arrivalAirport,
                  customSearch.getArrArpt());
      else if (Objects.nonNull(parameter) && StringUtils.isNotEmpty(parameter.getArrAirport()))
         WebElementTools.selectElementFromListBasedOnText(arrivalAirport,
                  parameter.getArrAirport());
      else
      {
         wait.forJSExecutionReadyLazy();
         WebDriverUtils.executeScript("arguments[0].scrollIntoView(true);", arrivalAirport.get(0));
         WebElementTools.newActions().moveToElement(arrivalAirport.get(0)).build().perform();
         WebElementTools.click(arrivalAirport.get(0));
      }
   }
}
