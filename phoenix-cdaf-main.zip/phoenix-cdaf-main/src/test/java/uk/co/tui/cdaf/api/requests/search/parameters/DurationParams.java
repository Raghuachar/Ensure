package uk.co.tui.cdaf.api.requests.search.parameters;

import lombok.Getter;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import javax.annotation.Nullable;

@Getter
public enum DurationParams
{
   DAYS_2("02", "2115"),
   DAYS_3("03", "3115"),
   DAYS_4("04", "4115"),
   DAYS_5("05", "5115"),
   DAYS_6("06", "6115"),
   DAYS_7("07", "7115"),
   DAYS_8("08", "8115"),
   DAYS_9("09", "9115"),
   DAYS_10("10", "1015"),
   DAYS_11("11", "1115"),
   DAYS_12("12", "1215"),
   DAYS_13("13", "1315"),
   DAYS_14("14", "1415"),
   MORE_THEN_14("more", "1515");

   private final String text;
   private final String value;


   DurationParams(String text, String value) {
      this.text = text;
      this.value = value;
   }

   public static DurationParams getByText(@Nullable TestDataAttributes tda)
   {
      if (tda != null)
      {
         String inputText = tda.getDuration();
         return getByText(inputText);
      }
      return DAYS_7;
   }

   private static DurationParams getByText(String inputText)
   {
      for (DurationParams duration : DurationParams.values())
      {
         if (duration.text.equals(inputText))
         {
            return duration;
         }
      }
      return DAYS_7;
   }
}

