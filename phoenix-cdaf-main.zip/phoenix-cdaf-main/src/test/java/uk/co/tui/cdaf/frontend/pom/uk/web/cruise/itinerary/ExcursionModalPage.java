package uk.co.tui.cdaf.frontend.pom.uk.web.cruise.itinerary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class ExcursionModalPage extends AbstractPage
{

   public WebElementWait wait;

   @FindBy(css = "[aria-label='show less link']")
   private List<WebElement> showLessBtn;

   @FindBy(css = "[class='popups__close']")
   private List<WebElement> closeIcon;

   public ExcursionModalPage()
   {
      wait = new WebElementWait();
   }

   public Boolean isModalClosed()
   {
      return WebElementTools.isVisible(closeIcon.get(0));
   }

   public WebElement getShowLessButton()
   {
      return showLessBtn.get(0);
   }

}
