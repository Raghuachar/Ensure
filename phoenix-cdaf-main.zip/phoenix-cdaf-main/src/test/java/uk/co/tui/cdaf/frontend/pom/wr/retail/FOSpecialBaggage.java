package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class FOSpecialBaggage extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(FOSpecialBaggage.class);

   private final WebElementWait wait;

   public String specialsports =
            "return document.querySelector(\"tui-fo-ssr\").shadowRoot.querySelector(\".header__37VRq\")";

   public String addsportsequipment =
            "return document.querySelector(\"tui-fo-ssr\").shadowRoot.querySelector(\".addSsr__2lj6h\")";

   public String specialpets =
            "return document.querySelector(\"#ssr__wrapper__pets > div > div > tui-fo-ssr\").shadowRoot.querySelector(\".header__37VRq\")";

   public String addpets =
            "return document.querySelector(\"#ssr__wrapper__pets > div > div > tui-fo-ssr\").shadowRoot.querySelector(\".ssrPerFlight__3imF5\").querySelector(\".addSsr__2lj6h\")";

   public String upgradeseatsbe =
            "return document.querySelector(\"tui-fo-seat-type\").shadowRoot.querySelector(\"div > div > div > div:nth-child(1) > div > div:nth-child(2) > label > div.customRadio___dD4B5\")";

   public String upgradeseatsnl =
            "return document.querySelector(\"tui-fo-special-service-seat\").shadowRoot.querySelector(\"div > div > div > div:nth-child(1) > div:nth-child(2) > label > div.customRadio___dD4B5\")";

   public String upgradbaggage =
            "return document.querySelector(\"tui-fo-special-service-luggage\").shadowRoot.querySelector(\"div > div > div.luggageWrapper__54368f > div:nth-child(1) > div > div > ul > li:nth-child(2) > div.description__3750e2 > p > div\")";

   public FOSpecialBaggage()
   {
      wait = new WebElementWait();
   }

   public void clickOnspecialSports()
   {
      WebElement webelement = (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver())
               .executeScript(specialsports);
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(webelement);
      wait.forJSExecutionReadyLazy();
      webelement.click();

   }

   public void selectSportsEquipment()
   {
      WebElement webelement = (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver())
               .executeScript(addsportsequipment);
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(webelement);
      webelement.click();
      wait.forJSExecutionReadyLazy();
   }

   public void clickOnspecialPets()
   {
      WebElement webelement =
               (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver()).executeScript(
                        specialpets);
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(webelement);
      wait.forJSExecutionReadyLazy();
      webelement.click();

   }

   public void selectpets()
   {
      WebElement webelement =
               (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver()).executeScript(
                        addpets);
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(webelement);
      webelement.click();
      wait.forJSExecutionReadyLazy();
   }

   public void clickOnUpgardeSeatsBE()
   {
      WebElement webelement =
               (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver()).executeScript(
                        upgradeseatsbe);
      wait.forJSExecutionReadyLazy();
      if (webelement.isDisplayed())
      {
         WebElementTools.mouseHover(webelement);
         wait.forJSExecutionReadyLazy();
         webelement.click();
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "upgradeseats are not avaible to select");
      }

   }

   public void clickOnUpgardeSeatsNL()
   {
      WebElement webelement =
               (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver()).executeScript(
                        upgradeseatsnl);
      wait.forJSExecutionReadyLazy();
      if (webelement.isDisplayed())
      {
         WebElementTools.mouseHover(webelement);
         wait.forJSExecutionReadyLazy();
         webelement.click();
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "upgradeseats are not avaible to select");
      }

   }

   public void clickOnUpgardeSeats()
   {
      if (!ExecParams.getAgent().isB2C() && ExecParams.getTestExecutionParams().isBE())
         clickOnUpgardeSeatsBE();
      if (!ExecParams.getAgent().isB2C() && ExecParams.getTestExecutionParams().isNL())
         clickOnUpgardeSeatsNL();
   }

   public void clickOnUpgardeBaggage()
   {
      WebElement webelement =
               (WebElement) ((JavascriptExecutor) WebDriverUtils.getDriver()).executeScript(
                        upgradbaggage);
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(webelement);
      wait.forJSExecutionReadyLazy();
      webelement.click();
   }

}
