package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.detailedbreakdown;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Selenide.$$;

public class DetailedBreakdownPage extends AbstractPage
{
   @FindBy(css = ".PriceBlockHeader__header span")
   public WebElement basePrice;

   @FindBy(css = ".TotalPrice__total span")
   public WebElement totalPrice;

   @FindBy(xpath = "//div[@class='PriceBlock__priceBlockWrapper'][1]//div[contains(@class, 'PriceBlock__lineHeader')]")
   public List<WebElement> passengersInfoList;

   public boolean isBasePriceDisplayed()
   {
      return WebElementTools.isDisplayed(basePrice);
   }

   public boolean isTotalPriceDisplayed()
   {
      return WebElementTools.isDisplayed(totalPrice);
   }

   public int countForHowManyPassengersIsDisplayedInfo()
   {
      return passengersInfoList.size();
   }

   public List<String> getElementsTexts(ElementsCollection collection)
   {
      List<String> list = new ArrayList<>();
      for (SelenideElement element : collection)
      {
         list.add(element.shouldBe(Condition.visible).getText());
      }
      return list;
   }

   public List<Double> getPricesDouble(ElementsCollection collection)
   {
      List<Double> priceDouble = new ArrayList<>();
      for (SelenideElement element : collection)
      {
         priceDouble.add(Double.parseDouble(element.shouldBe(Condition.visible).
                  getText().split("€")[1].trim()));
      }
      return priceDouble;
   }

   private ElementsCollection getInsuranceProductTitle()
   {
      return $$("#priceBreakDownInsurance span:nth-of-type(1)");
   }

   public List<String> getInsuranceProductTitlesTexts()
   {
      return getElementsTexts(getInsuranceProductTitle());
   }

   private ElementsCollection getInsurancePrices()
   {
      return $$("#priceBreakDownInsurance span:nth-of-type(2)");
   }

   public List<Double> getInsurancePricesDouble()
   {
      return getPricesDouble(getInsurancePrices());
   }

   public void clickShowInsuranceTaxLink()
   {
      ElementsCollection showInsuranceTaxLink = $$("#priceBreakDownInsurance + .PriceBlock__showMoreWrapper svg");
      for (SelenideElement element : showInsuranceTaxLink)
      {
         element.shouldBe(Condition.visible).click();
      }
   }

   private ElementsCollection getInsuranceProductTaxes()
   {
      return $$("#priceBreakDownInsurance + .PriceBlock__showMoreWrapper .PriceBlock__lineSubItem");
   }

   public List<String> getInsuranceProductTaxesTexts()
   {
      return getElementsTexts(getInsuranceProductTaxes());
   }

   public ElementsCollection getInsuranceProductTaxesValues()
   {
      return $$("#priceBreakDownInsurance + .PriceBlock__showMoreWrapper .PriceBlock__lineSubItem span");
   }

   public List<Double> getInsuranceTaxesValuesDouble()
   {
      return getPricesDouble(getInsuranceProductTaxesValues());
   }

   public String getInsuranceFeeText()
   {
      ElementsCollection bookingFees = $$(".BookingCharges__chargeDescriptionText");
      StringBuilder builder = new StringBuilder();
      for (SelenideElement element : bookingFees)
      {
         builder.append(element.shouldBe(Condition.visible).getText()).append(" ");
      }
      return builder.toString();
   }
}
