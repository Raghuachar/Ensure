package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.extraoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.extraoptions.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;

import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class InsuranceCustomerStepDefs
{
   static AutomationLogManager LOGGER = new AutomationLogManager(InsuranceCustomerStepDefs.class);

   private final PackageNavigation packageNavigation = new PackageNavigation();

   private final ExtraOptionsPage extraOptionsPage = new ExtraOptionsPage();

   @Given("the user is on the package Extras page")
   public void the_user_is_on_the_package_Extras_page()
   {
      packageNavigation.navigateToExtrasPage();
   }

   @When("they have a package passenger aged 0 on their booking")
   public void they_have_a_package_passenger_aged_on_their_booking()
   {
      assertThat("Infant is not part of search",
               extraOptionsPage.insuranceComponent.isInfantNotBornCriteria(), is(true));
   }

   @And("they navigate to the package passenger aged 0 on the insurance component")
   public void they_navigate_to_the_package_passenger_aged_on_the_insurance_component()
   {
      extraOptionsPage.insuranceComponent.navigateToInfantNotBornCheckBox();
   }

   @Then("they will see a package Infant Not Born Yet tick box")
   public void they_will_see_a_package_Infant_Not_Born_Yet_tick_box()
   {
      assertThat("Infant Check box is not displayed",
               extraOptionsPage.insuranceComponent.isInfantCheckBoxDisplayed(), is(true));
   }

   @And("the package Infant tick box will be disabled")
   public void the_package_Infant_tick_box_will_be_disabled()
   {
      assertThat("Infant tick Check box is not disabled",
               extraOptionsPage.insuranceComponent.isInfantCheckBoxDisabled(), is(true));
   }

   @And("they select the package passenger tick box for the passenger aged 0")
   public void they_select_the_package_passenger_tick_box_for_the_passenger_aged()
   {
      extraOptionsPage.insuranceComponent.clickInfantNotBornCheckBox();
   }

   @And("they select the package infant not born yet tick box")
   public void they_select_the_package_infant_not_born_yet_tick_box()
   {
      extraOptionsPage.insuranceComponent.isInfantNotYetBornCheckBoxClicked();
   }

   @And("they will see the package Infant following message:")
   public void they_will_see_the_package_Infant_following_message(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      assertThat("Infant not yet born message is not displayed",
               extraOptionsPage.insuranceComponent.isInfantNotYetBornMessageDisplayed(), is(true));
      try
      {
         actual = extraOptionsPage.insuranceComponent.getInfantErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Infant error message is not same", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("they unselect the customer tick box")
   public void they_unselect_the_customer_tick_box()
   {
      extraOptionsPage.insuranceComponent.unSelectTickForNonLeadPassenger();
   }

   @And("click on the {string} button")
   public void click_on_the_button(String string)
   {
      extraOptionsPage.insuranceComponent.clickUpdatePriceButton();
      String beforeInsuranceTotalPrice = extraOptionsPage.insuranceComponent.getTotalPrice();
      LOGGER.log(LogLevel.INFO,
               "beforeInsuranceTotalPrice  :" + extraOptionsPage.insuranceComponent.getTotalPrice());
   }

   @And("click on the Travel Insurance and select the Travel Insurance")
   public void click_on_the_Travel_Insurance_and_select_the_Travel_Insurance()
   {
      extraOptionsPage.insuranceComponent.selectEnabledInsuranceButton();
   }

}
