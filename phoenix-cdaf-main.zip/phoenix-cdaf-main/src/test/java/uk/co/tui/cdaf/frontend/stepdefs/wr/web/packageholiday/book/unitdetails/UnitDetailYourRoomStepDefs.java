package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.unitdetails;

import com.codeborne.selenide.Selenide;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.RoomComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertTrue;

public class UnitDetailYourRoomStepDefs
{
   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   public final UnitDetailsPage unitDetailsPage = new UnitDetailsPage();

   private final WebElementWait wait;

   private final Map<String, WebElement> unitMap;

   private final RoomComponent roomComponent;

   private String totalPrice;

   private String roomUpgrades;

   private String perPersonPrice;

   private String roomPriceDiff;

   private String roomOptions;

   public UnitDetailYourRoomStepDefs()
   {
      wait = new WebElementWait();
      unitMap = new HashMap<>();
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      roomComponent = new RoomComponent();
   }

   @Given("the customer has completed a package search")
   public void the_customer_has_completed_a_package_search()
   {
      packageNavigation.navigateToMultiRoomUnitDetailsPage();
   }

   @And("they have selected a hotel from the search results")
   public void they_have_selected_a_hotel_from_the_search_results()
   {
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
   }

   @When("they view the unit details page")
   public void they_view_the_unit_details_page()
   {
      unitDetailsPage.isHotelDetailsPageDisplayed();
   }

   @Then("they will see the {string} component")
   public void they_will_see_the_component(String ignore)
   {
      assertTrue("Your Room component is not present",
               roomComponent.getYouRoomDisplayed().isDisplayed());
   }

   @Given("the customer is on the Unit details page")
   public void the_customer_is_on_the_Unit_details_page()
   {
      packageNavigation.navigateToMultiRoomUnitDetailsPage();
   }

   @When("they are viewing the {string} component")
   public void they_are_viewing_the_component(String ignore)
   {
      assertTrue("Your Room component is not present",
               roomComponent.getYouRoomDisplayed().isDisplayed());
   }

   @Then("the first room accordion will be open by default")
   public void the_first_room_accordion_will_be_open_by_default()
   {
      assertThat("Room accordion is not present", roomComponent.isRoomAccordion(), is(true));
   }

   @When("they want to see more information about the additional rooms")
   public void they_want_to_see_more_information_about_the_additional_rooms()

   {
      assertThat("Additional Rooms are not present", roomComponent.isAdditionalRoomAccordion(),
               is(true));
   }

   @Then("they can select the accordion arrow for each room")
   public void they_can_select_the_accordion_arrow_for_each_room()
   {
      roomComponent.clickaccordion();
   }

   @And("they will see additional information about the room")
   public void they_will_see_additional_information_about_the_room()
   {
      roomComponent.additionalInformation();
      wait.forJSExecutionReadyLazy();
      roomComponent.clickaccordion();
   }

   @When("they select to open the room accordions")
   public void they_select_to_open_the_room_accordions()
   {
      assertThat("Additional Rooms are not present", roomComponent.isAdditionalRoomAccordion(),
               is(true));
   }

   @Then("they will see a link {string}")
   public void they_will_see_a_link(String ignore)
   {
      assertTrue("See available upgrades or change number of rooms link is not displayed",
               roomComponent.getRoomUpgradeLink().isDisplayed());
   }

   @And("selecting this will take them to the room options page")
   public void selecting_this_will_take_them_to_the_room_options_page()
   {
      roomComponent.clickRoomUpgradeLink();
   }

   @Then("they can see the YOUR BOARD BASIS component underneath the your room component")
   public void they_can_see_the_YOUR_BOARD_BASIS_component_underneath_the_your_room_component()
   {
      assertThat("Board Basis component is not present", roomComponent.isBoardBasisDisplayed(),
               is(true));
   }

   @And("it displays the base board type by default")
   public void it_displays_the_base_board_type_by_default(List<String> boardFilters)
   {
      for (String boardBasis : boardFilters)
      {
         if (boardBasis.equalsIgnoreCase(roomComponent.boardComponent()))
         {
            assertThat("BoardBasis component is not present", roomComponent.boardComponents(),
                     is(true));
         }
      }

   }

   @And("what is included and description are consumed via the contentAPI")
   public void what_is_included_and_description_are_consumed_via_the_contentAPI()
   {
      assertThat("Board Basis Description is not displayed", roomComponent.isDiscriptionDisplayed(),
               is(true));
   }

   @Given("the {string} has collapsed the board basis component")
   public void the_has_collapsed_the_board_basis_component(String string)
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @When("they Select the {string} link")
   public void they_Select_the_link(String string)
   {
      roomComponent.selectShowMoreLink();
   }

   @Then("the component opens to display the entire component")
   public void the_component_opens_to_display_the_entire_component()
   {
      roomComponent.displayComponent();
   }

   @Then("the link changes to read {string}")
   public void the_link_changes_to_read(String string)
   {
      String actual, expected;
      try
      {
         expected = "Show less";
         actual = roomComponent.changeToShowLessLink();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Show less link is not displayed", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("Show less link is not displayed", false, is(true));
      }
   }

   @Given("the {string} is reviewing the board basis component")
   public void the_is_reviewing_the_board_basis_component(String string)
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @When("They select the {string} link")
   public void They_select_the_link(String string)
   {
      roomComponent.selectShowLessLink();
   }

   @Then("the component collapses to display the header only")
   public void the_component_collapses_to_display_the_header_only()
   {
      roomComponent.collapseHeader();
      wait.forJSExecutionReadyLazy();
   }

   @And("the link Changes to read {string}")
   public void the_link_Changes_to_read(String string)
   {
      String actual, expected;
      try
      {
         wait.forJSExecutionReadyLazy();
         expected = "Show more";
         actual = roomComponent.changeToShowMoreLink();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Show more link is not displayed", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("Show more link is not displayed", false, is(true));
      }
   }

   @Given("the {string} is on the Search Results page")
   public void the_is_on_the_Search_Results_page(String string)
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @Then("the Unit Details page shall be displayed")
   public void the_Unit_Details_page_shall_be_displayed()
   {
      unitDetailsPage.isHotelDetailsPageDisplayed();
   }

   @Then("alternate rooms are available")
   public void alternate_rooms_are_available()
   {
      unitDetailsPage.getAlternativeRoomCards();
   }

   @Then("the alternative room cards shall be ordered in ascending price order")
   public void the_alternative_room_cards_shall_be_ordered_in_ascending_price_order()
   {
      unitDetailsPage.getAlternativeRoomCardInAsc();
   }

   @And("they will see the following components")
   public void they_will_see_the_following_components(List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      unitMap.putAll(roomComponent.yourRoomComponents());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = unitMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + "component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });

   }

   @Then("room card for the room included within the package \\(base room) and up to {int} alternative available rooms")
   public void room_card_for_the_room_included_within_the_package_base_room_and_up_to_alternative_available_rooms(
            Integer int1)
   {
      unitDetailsPage.getAlternativeRoomCards();
   }

   @Then("{string} button if more than {int} rooms are available for the package accommodation")
   public void button_if_more_than_rooms_are_available_for_the_package_accommodation(String string,
            Integer int1)
   {
      try
      {
         roomComponent.isShowMoreDisplayed();
      }
      catch (Exception e)
      {
         assertThat("Alternate rooms are not available", false, is(true));
      }
   }

   @Given("the {string} is on the Unit Details page")
   public void the_is_on_the_Unit_Details_page(String string)
   {
      packageNavigation.navigateToUnitdetailsPage();
   }

   @When("they view the YOUR ROOM component")
   public void they_view_the_YOUR_ROOM_component()
   {
      assertTrue(unitDetailsPage.isRoomHeaderDisplayed());
   }

   @Then("the room card for the first base room included within the selected package shall display the following:")
   public void the_room_card_for_the_first_base_room_included_within_the_selected_package_shall_display_the_following(
            List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      unitMap.putAll(roomComponent.selectedRoomComponent());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = unitMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + "component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Given("alternative rooms are available for the accommodation on the package")
   public void alternative_rooms_are_available_for_the_accommodation_on_the_package()
   {
      unitDetailsPage.getAlternativeRoomCards();
   }

   @Then("the alternative room cards shall display the following:")
   public void the_alternative_room_cards_shall_display_the_following(List<String> components)
   {
      roomComponent.alternativeRoomComponent();
      SoftAssertions softly = new SoftAssertions();
      softly.assertThat(roomComponent.getFirstRoomImage().isDisplayed()).as("Room Image").isTrue();
      softly.assertThat(roomComponent.getRoomTypeDescription().isDisplayed())
               .as("Room type description").isTrue();
      softly.assertThat(roomComponent.getRoomOccupancy().isDisplayed()).as("Room Occupancy")
               .isTrue();
      softly.assertThat(roomComponent.getMoreDetailsLink().isDisplayed()).as("More details")
               .isTrue();
      softly.assertThat(roomComponent.getPriceTotal().isDisplayed()).as("Price total").isTrue();
      softly.assertThat(roomComponent.getPricePerPerson().isDisplayed()).as("Price per person")
               .isTrue();
      softly.assertThat(roomComponent.getRoomSelector().isDisplayed()).as("Room selector").isTrue();
      softly.assertAll();
   }

   @Given("the {string} is on the Search Results page and only one room is included in the package")
   public void the_is_on_the_Search_Results_page_and_only_one_room_is_included_in_the_package(
            String string)
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @Then("the YOUR ROOM component shall be displayed the following:")
   public void the_YOUR_ROOM_component_shall_display_the_following(List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      unitMap.putAll(roomComponent.roomComponent());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = unitMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + "component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("the YOUR ROOM component title shall change to YOUR ROOM")
   public void the_YOUR_ROOM_component_title_shall_change_to_YOUR_ROOM()
   {
      checkTitleChange("yourroom");
   }

   @Then("the YOUR ROOM component title shall change to YOUR ROOMS")
   public void the_YOUR_ROOM_component_title_shall_change_to_YOUR_ROOMS()
   {
      checkTitleChange("yourrooms");
   }

   // TODO: move this into a separate class, a translation provider
   private void checkTitleChange(String translationKey)
   {
      String jsCode = "return JSON.parse(i18nMessages)?." + translationKey + ";";
      String translation = Objects.requireNonNull(Selenide.executeJavaScript(jsCode)).toString();
      String actual = unitDetailsPage.getYourRoomsHeader();
      assertThat("Your rooms is not displayed", actual, Matchers.equalToIgnoringCase(translation));
   }

   @Given("the {string} is on the Search Results page and more than one room is included in the package")
   public void the_is_on_the_Search_Results_page_and_more_than_one_room_is_included_in_the_package(
            String ignore)
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @When("they review the {string} component on the Unit book page")
   public void they_review_the_component_on_the_Unit_book_page(String string)
   {
      unitDetailsPage.isHotelDetailsPageDisplayed();
   }

   @Then("no room cards for the alternative rooms available for the package accommodation shall be displayed below the other rooms included in the package")
   public void no_room_cards_for_the_alternative_rooms_available_for_the_package_accommodation_shall_be_displayed_below_the_other_rooms_included_in_the_package()
   {
      unitDetailsPage.getAlternativeRoomCards();
   }

   @Then("the base room cards for rooms shall display the following:")
   public void the_base_room_cards_for_rooms_or_more_shall_display_the_following(
            List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      unitMap.putAll(roomComponent.roomCards());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = unitMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + "component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Given("they are viewing the YOUR ROOM\\(S) component")
   public void they_are_viewing_the_YOUR_ROOM_S_component()
   {
      assertTrue(unitDetailsPage.isRoomHeaderDisplayed());
   }

   @Given("more than {int} alternative rooms are available for the accommodation on the package")
   public void more_than_alternative_rooms_are_available_for_the_accommodation_on_the_package(
            Integer int1)
   {
      assertThat("Additional Rooms are present", roomComponent.isAlternativeRoomsPresent(),
               is(true));
   }

   @When("they select the {string} button for any of the base room components included within the package")
   public void they_select_the_button_for_any_of_the_base_room_components_included_within_the_package(
            String string)
   {
      roomComponent.clickOnShowMoreRoomOptionsButton();
   }

   @Then("a separate room card for each available room will be displayed in the base room component they selected the {string} button from")
   public void a_separate_room_card_for_each_available_room_will_be_displayed_in_the_base_room_component_they_selected_the_button_from(
            String string)
   {
      roomComponent.isRoomCardPresent();
   }

   @Then("a {string} button shall be displayed")
   public void a_button_shall_be_displayed(String string)
   {
      assertTrue(roomComponent.isShowLessRoomOptionsButtonDisplayed());
   }

   @When("they select the SHOW FEWER OPTIONS button")
   public void they_select_the_SHOW_FEWER_OPTIONS_button()
   {
      roomComponent.clickOnShowLessRoomOptionsButton();
   }

   @Then("only the original room cards shall be displayed up to a maximum of {int} room cards")
   public void only_the_original_room_cards_shall_be_displayed_up_to_a_maximum_of_room_cards(
            Integer int1)
   {
      roomComponent.isRoomCardPresent();
   }

   @Then("the {string} button shall be displayed")
   public void the_button_shall_be_displayed(String string)
   {
      roomComponent.isShowMoreRoomOptionsButtonDisplayed();
   }

   @Given("the SHOW FEWER OPTIONS button shall be displayed")
   public void the_SHOW_FEWER_OPTIONS_button_shall_be_displayed()
   {
      roomComponent.isShowLessRoomOptionsButtonDisplayed();
   }

   @And("they are viewing the base room card \\(i.e. the room included in the package) in the YOUR room component")
   public void they_are_viewing_the_base_room_card_i_e_the_room_included_in_the_package_in_the_YOUR_room_component()
   {
      roomComponent.isBaseRoomDisplayed();
   }

   @And("the base room card is in selected state")
   public void the_base_room_card_is_in_selected_state()
   {
      roomComponent.isRoomselectedstateDisplayed();
   }

   @Given("alternative rooms are available")
   public void alternative_rooms_are_available()
   {
      roomComponent.isAlternativeRoomDisplayed();
   }

   @When("the select the {string} button")
   public void the_select_the_button(String string)
   {
      roomComponent.isRoomOptionButtonDisplayed();
      roomComponent.clickOnRoomOptionButton();
   }

   @Then("the customer will be positioned to the next room card in the carousel")
   public void the_customer_will_be_positioned_to_the_next_room_card_in_the_carousel()
   {
      roomComponent.isNextRoomDisplayed();
   }

   @Given("they are viewing a room card in the YOUR ROOMS component")
   public void they_are_viewing_a_room_card_in_the_YOUR_ROOMS_component()
   {
      roomComponent.isBaseRoomDisplayed();
   }

   @When("the select the {string} link")
   public void the_select_the_link(String string)
   {
      roomComponent.clickOnMoreDetailsLink();
   }

   @Then("the ROOM DETAILS modal shall be displayed")
   public void the_ROOM_DETAILS_modal_shall_be_displayed()
   {
      assertThat("The Room Details modal shall is not displayed ",
               roomComponent.isMoreDetailsModalDisplayed(), is(true));
   }

   @Then("the ROOM DETAILS modal shall display the following:")
   public void the_ROOM_DETAILS_modal_shall_display_the_following(List<String> components)
   {

      wait.forJSExecutionReadyLazy();
      unitMap.putAll(roomComponent.roomDetailsModelComponents());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = unitMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + "component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("the {string} is viewing the ROOM DETAILS modal")
   public void the_is_viewing_the_ROOM_DETAILS_modal(String string)
   {
      packageNavigation.navigateToUnitDetailsPage();
      roomComponent.clickOnMoreDetailsLink();
   }

   @When("the close the modal")
   public void the_close_the_modal()
   {
      roomComponent.clickOnXCloseModalLink();
   }

   @Then("the ROOM DETAILS modal shall close")
   public void the_ROOM_DETAILS_modal_shall_close()
   {
      assertThat("The Room Details modal shall is not closed ",
               !roomComponent.isMoreDetailsModalDisplayed(), is(true));
   }

   @And("the customer will be positioned by the room card they selected the {string} link from")
   public void the_customer_will_be_positioned_by_the_room_card_they_selected_the_link_from(
            String string)
   {
      roomComponent.isMoreDetailsLinkDisplayed();
   }

   @Given("they are viewing the YOUR ROOMS component")
   public void they_are_viewing_the_YOUR_ROOMS_component()
   {
      assertTrue(unitDetailsPage.isRoomHeaderDisplayed());
   }

   @When("they click on the {string} component for rooms two or higher")
   public void they_click_on_the_component_for_rooms_two_or_higher(String ignore)
   {
      roomComponent.clickMultipleShowDetails();
   }

   @Then("the room component they selected shall display the your room options")
   public void the_room_component_they_selected_shall_display_the_your_room_options()
   {
      roomComponent.showDetailsComponent();
   }

   @Then("alternative room cards shall be ordered in ascending price order")
   public void alternative_room_cards_shall_be_ordered_in_ascending_price_order()
   {
      unitDetailsPage.getShowDetailsAlternativeRoomCardInAsc();
   }

   @And("they have selected an alternative room card")
   public void they_have_selected_an_alternative_room_card()
   {
      if (!StringUtils.isEmpty(roomComponent.isAlternativeRoomsDisplayed()))
      {
         roomComponent.clickOnAlternativeRooms();
         totalPrice = unitDetailsPage.boardBasisComponent.getTotalPriceText();
         roomUpgrades = roomComponent.getRoomUpgradesTitle();
      }
      else
         assertThat("Alternative rooms are not available", false, is(true));
   }

   @Then("the room card they selected on the Unit Details page is highlighted as the selected option")
   public void the_room_card_they_selected_on_the_Unit_Details_page_is_highlighted_as_the_selected_option()
   {
      assertThat("Alternative Rooms  are not upgraded in spoke page",
               roomUpgrades.equalsIgnoreCase(roomComponent.getRoomUpgradesTitle()),
               is(true));
   }

   @And("the prices displayed within the price component reflect the price of the selected room")
   public void the_prices_displayed_within_the_price_component_reflect_the_price_of_the_selected_room()
   {
      assertThat("Rooms Prices are not updates in spoke page",
               totalPrice.contains(unitDetailsPage.boardBasisComponent.getTotalPriceText()),
               is(true));
   }

   @Then("the room card they applied on the Accommodation Options spoke is highlighted as the selected option")
   public void the_room_card_they_applied_on_the_Accommodation_Options_spoke_is_highlighted_as_the_selected_option()
   {
      assertThat(
               "room_card_they_applied_on_the_Accommodation_Options_spoke_is_highlighted  are not upgraded in spoke page",
               roomUpgrades.equalsIgnoreCase(roomComponent.getRoomUpgradesTitle()),
               is(true));
   }

   @Given("the Customer or Agent is on the Unit Details page")
   public void the_Customer_Agent_is_on_the_Unit_Details_page()
   {
      packageNavigation.navigateToUnitDetailsPageWithAltRoom();
   }

   @Given("more than one room is available")
   public void more_than_one_room_is_available()
   {
      assertThat("Alternate Rooms not present", roomComponent.isAlternativeRoomsPresent(),
               is(true));
   }

   @When("they choose the {string} button on an alternative room card")
   public void they_choose_the_button_on_an_alternative_room_card(String string)
   {
      totalPrice = unitDetailsPage.boardBasisComponent.getTotalPriceText();
      perPersonPrice = unitDetailsPage.boardBasisComponent.getPerPersonPriceText();
      roomPriceDiff = roomComponent.getRoomPriceDifference();
      if (!StringUtils.isEmpty(roomComponent.isAlternativeRoomsDisplayed()))
      {
         roomUpgrades = roomComponent.getRoomUpgradesTitle();
         roomComponent.clickOnAlternativeRooms();
      }
      else if (roomComponent.isMobileAlternateRoomsDisplayed())
      {
         roomUpgrades = roomComponent.getRoomTitle();
         roomOptions = roomComponent.getButtonText();
         roomComponent.clickOnMobileAlternativeRooms();
      }
      else
         assertThat("Alternative rooms are not available", false, is(true));
   }

   @Then("the chosen alternative room card shall be set to SELECTED")
   public void the_chosen_alternative_room_card_shall_be_set_to_SELECTED()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("Alternate Room not selected", roomComponent.isRoomSelected(), is(true));
   }

   @Then("the total price and per person prices in the Price component shall be updated to reflect the chosen alternative room price")
   public void the_total_price_and_per_person_prices_in_the_Price_component_shall_be_updated_to_reflect_the_chosen_alternative_room_price()
   {
      double oldTotalPrice = Double.parseDouble(totalPrice.replaceAll("[^\\d.]", ""));
      double oldPerPersonPrice = Double.parseDouble(perPersonPrice);
      double newTotalPrice =
               Double.parseDouble(unitDetailsPage.boardBasisComponent.getTotalPriceText()
                        .replaceAll("[^\\d.]", ""));
      double newPerPersonPrice =
               Double.parseDouble(unitDetailsPage.boardBasisComponent.getPerPersonPriceText());

      assertThat("Price not updated",
               (newTotalPrice > oldTotalPrice) && (newPerPersonPrice > oldPerPersonPrice),
               is(true));
   }

   @Then("the {string} room card shall display the total price difference, the per person price difference & the select button")
   public void the_room_card_shall_display_the_total_price_difference_the_per_person_price_difference_the_select_button(
            String string)
   {
      assertThat("Room price not updated",
               !StringUtils.equalsIgnoreCase(roomPriceDiff, roomComponent.getRoomPriceDifference()),
               is(true));
   }

   @Then("the {string} & chosen alternative room cards remain in the same positions they were in prior to the customer change")
   public void the_chosen_alternative_room_cards_remain_in_the_same_positions_they_were_in_prior_to_the_customer_change(
            String string)
   {
      assertThat("Room position has changed",
               StringUtils.equalsIgnoreCase(roomUpgrades, roomComponent.getRoomTitle()), is(true));
   }

   @Given("the current selected room is the base room")
   public void the_current_selected_room_is_the_base_room()
   {
      assertThat("Selected room is not base room", roomComponent.isMobileBaseRoomSelected(),
               is(true));
   }

   @Then("the {string} room card shall no longer display the ROOM OPTIONS button")
   public void the_room_card_shall_no_longer_display_the_ROOM_OPTIONS_button(String string)
   {
      wait.forJSExecutionReadyLazy();
      assertThat("RoomOptions is displayed",
               !StringUtils.equalsIgnoreCase(roomOptions, roomComponent.getButtonText()),
               is(true));
   }

   @Then("a message showing the number of available rooms should be displayed")
   public void a_message_showing_the_number_of_available_rooms_should_be_displayed(
            DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String agent = BDDSiteIdResolver.getAgent().toLowerCase();
      String siteId = BDDSiteIdResolver.getSiteRTId().toLowerCase();
      String actual = roomComponent.getYourRoomAvailable();
      String roomCount = actual.split(" ")[0];
      String expect = (agent.contains("inhouse") ? map.get(agent + "_" + siteId) : map.get(siteId)).replace("x", roomCount);
      assertThat("number of available roomsmessage is not matched", actual,
               Matchers.equalToIgnoringCase(expect));
   }
}

