package uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.room_options.hotel_list;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class HotelListPage extends AbstractPage
{

   WebElementWait wait = new WebElementWait();

   @FindAll({ @FindBy(css = "#overview"), @FindBy(css = "[aria-label='hero banner gallery']"),
            @FindBy(css = ".AccomEditorial__accomEditorialWrapper") })
   private WebElement hotelDetailsPage;

   public HotelListPage()
   {
      super();
   }

   public boolean isOverviewDisplayed()
   {
      wait.waitForElementToBePresent(hotelDetailsPage);
      return WebElementTools.isPresent(hotelDetailsPage);
   }

}
