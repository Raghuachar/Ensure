package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.EditSearchPackages;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory;
import uk.co.tui.cdaf.frontend.pom.wr.search.enums.StayDuration;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.stay.search.searchresults.SearchResults;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class PackageSearchPanelDurationStepDefs
{
   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   public final SearchResults searchResults;

   private final Map<String, WebElement> searchMap;

   private final SearchPanel searchPanel;

   private final SearchPanelComponent searchPanelComponent;

   EditSearchPackages esp;

   public PackageSearchPanelDurationStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      esp = new EditSearchPackages();
      searchResults = new SearchResults();
      searchMap = new HashMap<>();
      searchPanelComponent = new SearchPanelComponent();
      searchPanel = SearchPanelFactory.getSearchPanel();
   }

   @Given("the customer is on the WR package search results or unit details page")
   public void the_customer_is_on_the_WR_package_search_results_or_unit_details_page()
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @When("they view the edit search panel")
   public void they_view_the_edit_search_panel()
   {
      searchPanelComponent.visit();
   }

   @Then("They will see the following fields")
   public void they_will_see_the_following_fields(List<String> components)
   {
      SoftAssertions softAssertions = new SoftAssertions();
      softAssertions.assertThat(searchPanel.getSelectedAirtports()).isNotEmpty();
      softAssertions.assertThat(searchPanel.getSelectedDestination()).isNotEmpty();
      softAssertions.assertThat(searchPanel.getSelectedDate()).isNotEmpty();
      softAssertions.assertThat(searchPanel.getSelectedDuration()).isNotEmpty();
      softAssertions.assertThat(searchPanel.getSelectedPaxAndRooms()).isNotEmpty();
      softAssertions.assertThat(searchPanel.getSearchButtonLable()).isNotEmpty();
      softAssertions.assertAll();
   }

   @When("they view the duration field")
   public void they_view_the_duration_field()
   {
      searchPanelComponent.getDurationElement();

   }

   @Then("{int} nights will show as default")
   public void nights_will_show_as_default(int value)
   {
      String selectedDuration = getSearchPanel().getSelectedDuration();
      assertThat("default nights are not displaying",
               selectedDuration, Matchers.startsWith(String.valueOf(value)));
   }

   @When("they select the Duration")
   public void they_select_the_Duration()
   {
      searchPanelComponent.clickOnDurationField();

   }

   @Then("from 2 to 14 and 14+ days duration values would be presen")
   public void the_following_durations_will_show()
   {
      List<String> collect =
               getSearchPanel().getDurationSelector().getOptions().asDynamicIterable().stream()
                        .map(SelenideElement::getValue).collect(Collectors.toList());
      String[] actual = Arrays.stream(StayDuration.values())
               .map(StayDuration::getNumberOfNights).toArray(String[]::new);
      MatcherAssert.assertThat("All enum values should be present", collect,
               hasItems(actual));
   }

   @When("they select a duration from the list")
   public void they_select_a_duration_from_the_list()
   {
      String firstDurationOption =
               getSearchPanel().getDurationSelector().getOptions().first().getValue();
      assert firstDurationOption != null;
      getSearchPanel().getDurationSelector().selectOptionByValue(firstDurationOption);

      String firstDurationName =
               getSearchPanel().getDurationSelector().getOptions().first().getText();
      assertThat("selected duration is not displaying",
               getSearchPanel().getSelectedDuration(), is(firstDurationName));
   }

   @Then("the list will close")
   public void the_list_will_close()
   {
      esp.editSearchButton();

   }

   @Then("the selection will populate the duration field")
   public void the_selection_will_populate_the_duration_field()
   {
      String firstDurationName =
               getSearchPanel().getDurationSelector().getOptions().first().getText();
      assertThat("selected duration is not displaying",
               getSearchPanel().getSelectedDuration(), is(firstDurationName));
   }

   @And("an error message for departure airport or destination and calendar should display as follows")
   public void checkErrorMessages(DataTable dataTable)
   {
      searchResultsPage.searchPanelComponent.wait.forJSExecutionReadyLazy();
      List<Map<String, String>> messages = dataTable.asMaps();
      String currentLanguage = ExecParams.getTestExecutionParams().getBrandStr();
      Map<String, String> currentLanguageMessages = messages.stream()
               .filter(msg -> msg.get("language").equalsIgnoreCase(currentLanguage))
               .findFirst()
               .orElseThrow(() -> new IllegalArgumentException(
                        "No messages found for the current language: " + currentLanguage));
      String expectedDepartureMessage = currentLanguageMessages.get("departure message");
      String expectedCalendarMessage = currentLanguageMessages.get("calendar message");
      if (WebDriverRunner.url().toLowerCase().contains("sit"))
      {
         expectedCalendarMessage = expectedCalendarMessage.replace(".", "");
      }
      String[] errorFound = getSearchPanel().getErrorMessages();
      SoftAssertions softAssertions = new SoftAssertions();

      softAssertions.assertThat(errorFound)
               .as("departure airport or destination error message is not found '%s'",
                        expectedDepartureMessage)
               .contains(expectedDepartureMessage);

      softAssertions.assertThat(errorFound)
               .as("calendar error message is not matched")
               .contains(expectedCalendarMessage);

      softAssertions.assertAll();

   }

}
