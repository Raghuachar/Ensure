package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.SearchResultsCardComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class DurationFilterComponent extends AbstractPage
{

   public static final String NEW_LINE = "\n";

   public final SearchResultsComponent searchResultComponent;

   public final SearchPanelComponent searchPanelComponent;

   public final WebElementWait wait;

   @FindBy(xpath = "//*[@id=\"FilterPanelV2__component\"]/div[2]/div/div/ul/li[2]/span")
   public WebElement mobileSelectDuration;

   @FindBy(css = ".DatesAndDuration__cardContainer .DatesAndDuration__dateWrapper .DatesAndDuration__durationList")
   public WebElement mobileDurationList;

   @FindBy(css = ".DatesAndDuration__cardContainer .DatesAndDuration__dateWrapper .DatesAndDuration__durationList .DatesAndDuration__selected")
   public WebElement mobileDefaultSelectedDuration;

   @FindBy(css = ".DropModal__filterDropModal DropModal__filterOverlay DropModal__open")
   public WebElement modal;

   @FindBy(css = "div.DatesAndDuration__cardContainer")
   public WebElement datesAndDurationFilter;

   @FindBy(css = "div.DatesAndDuration__cardContainer > div:nth-child(2)")
   public WebElement durationsFilter;

   @FindBy(css = "div.DatesAndDuration__cardContainer > div:nth-child(3) > ul > li:nth-child(1)")
   public WebElement allDateFilter;

   @FindBy(css = "li.DatesAndDuration__selected")
   public WebElement defaultDuration;

   @FindBy(css = "div.DatesAndDuration__cardContainer > div:nth-child(2) > ul > li:last-child")
   public WebElement maxDuration;

   @FindBy(css = "div.DatesAndDuration__cardContainer > div:nth-child(2) > ul > li:first-child")
   public WebElement minDuration;

   public WebDriverUtils utils;

   public String filterValue;

   public String actual = StringUtils.EMPTY;

   public String expected = StringUtils.EMPTY;

   protected SearchResultsCardComponent searchCardComponent;

   public DurationFilterComponent()
   {
      searchCardComponent = new SearchResultsCardComponent();
      searchResultComponent = new SearchResultsComponent();
      searchPanelComponent = new SearchPanelComponent();
      wait = new WebElementWait();
   }

   public boolean isDatesAndDurationFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(datesAndDurationFilter);
   }

   public boolean isDurationFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(durationsFilter);
   }

   public boolean isAllDatesFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(allDateFilter);
   }

   public boolean isDefaultDurationSelected(String input)
   {
      return defaultDuration.getText().equalsIgnoreCase(input);
   }

   public boolean isSelectedDurationSelected(String input)
   {
      return WebElementTools.getElementText(defaultDuration).equalsIgnoreCase(input);
   }

   public void isMaxDurationSelectable()
   {
      WebElementTools.click(minDuration);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(maxDuration);
   }

   public void selectMobileDurationFilter()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(mobileSelectDuration);
   }

   public boolean durationListViewable()
   {
      wait.forJSExecutionReadyLazy();
      return mobileDurationList.isDisplayed();
   }

   public boolean isDefaultDurationSelectedMobile(String input)
   {
      return WebElementTools.getElementText(mobileDefaultSelectedDuration).equalsIgnoreCase(input);
   }

   public boolean isNightsVisible(String input, Map<String, String> dataTable)
   {
      String key = input + " nights";
      List<String> reqVals = new ArrayList<>();
      if (dataTable.containsKey(key))
      {
         reqVals.addAll(Arrays.asList(StringUtils.split(dataTable.get(key), ",")));
      }
      else
      {
         reqVals
                  .addAll(Arrays.asList(
                           StringUtils.split(dataTable.get("More than 14 Nights"), ",")));
      }
      List<WebElement> durations = mobileDurationList.findElements(By.tagName("li"));
      List<String> valList = new ArrayList<>();
      for (WebElement duration : durations)
      {
         valList.add(duration.getText());
      }
      reqVals.retainAll(valList);
      return reqVals.size() == valList.size();
   }

}
