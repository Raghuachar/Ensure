package uk.co.tui.cdaf.frontend.pom.wr.search.components.departure;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;
import static org.assertj.core.api.Assumptions.assumeThat;
import static uk.co.tui.cdaf.frontend.utils.logger.LogLevel.ERROR;

public class DepartureLegacy extends DepartureMfe
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageNavigation.class);

   @Override
   public boolean isOpen()
   {
      return container().isDisplayed();
   }

   @Override
   public Departure clearSelection()
   {
      container().$("a.DropModal__clear").click();
      return this;
   }

   @Override
   public SelenideElement getMonthSelector()
   {
      SelenideElement monthSelectContainer = container().$("[arialabel='select month']")
               .shouldBe(Condition.visible, WAIT_TIMEOUT);
      return monthSelectContainer.$("select");
   }

   @Override
   public SelenideElement getFlexDateSelector()
   {
      return container().$(
                        "ul.SelectLegacyDate__flexibleOptions, .SelectDate__flexibility.SelectDate__flexibilityContainer")
               .shouldBe(Condition.visible, WAIT_TIMEOUT);
   }

   @Override
   public void selectMonth(String month)
   {
      SelenideElement monthSelector = getMonthSelector();
      assumeThat(month).isNotEmpty().isNotNull();
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
      assumeThat(YearMonth.parse(getFirstAvailableMonth(), formatter)).isNotNull()
               .isLessThanOrEqualTo(YearMonth.parse(month, formatter));
      monthSelector.selectOptionByValue(month);
      LOGGER.log(monthSelector.getSelectedOptionText() + " month was selected");
   }

   @Override
   public boolean isDateAvailable(LocalDateTime expectedDate)
   {
      return Objects.requireNonNull(getSpecificDateElement(expectedDate).getAttribute("class"))
               .contains("SelectLegacyDate__available");
   }

   @Override
   public Departure selectDate(String day, String month)
   {
      selectMonth(month);
      selectDay(day);
      LOGGER.log("Following date was selected: " + day + " " + month);
      return this;
   }

   @Override
   public Departure selectDate(LocalDateTime expectedDate)
   {
      return selectDate(Integer.toString(expectedDate.getDayOfMonth()),
               getDepartureMonth(expectedDate));
   }

   @Override
   public Departure selectFirstAvailableDate()
   {
      selectDay(null);
      return this;
   }

   @Override
   public void confirmSelection()
   {
      SelenideElement confirmBtn = container().parent().$("button.DropModal__apply");
      confirmBtn.click();
      confirmBtn.should(disappear, WAIT_TIMEOUT);
   }

   @Override
   public Departure selectRandomMonth()
   {
      final ElementsCollection monthsOptions = container().$("select[aria-label='Select']")
               .shouldBe(Condition.exist, WAIT_TIMEOUT).$$("option");
      List<SelenideElement> selectableMonths = monthsOptions.asDynamicIterable().stream()
               .filter(selenideElement -> !(StringUtils.equals(monthsOptions.get(0).getText(),
                        selenideElement.getText()) || StringUtils.equals(
                        monthsOptions.get(1).getText(), selenideElement.getText())))
               .collect(Collectors.toList());
      int totalCount = selectableMonths.size();
      int randomIndex = (int) (Math.random() * (totalCount - 1));
      SelenideElement randomMonth = selectableMonths.get(randomIndex);
      selectMonth(Objects.requireNonNull(randomMonth.getValue()));
      return this;
   }

   @Override
   public Departure selectRandomDate()
   {
      getCalendarSelector();
      ElementsCollection dates = getAvailableDays();
      int totalCount = dates.size();
      int randomIndex = (int) (Math.random() * (totalCount - 1));
      SelenideElement randomDay = dates.get(randomIndex);
      selectDay(randomDay.getText());
      return this;
   }

   @Override
   public @NotNull SelenideElement getCalendarSelector()
   {
      return container().$(".SelectLegacyDate__calendar, .SelectDate__calendar")
               .shouldBe(Condition.visible, WAIT_TIMEOUT);
   }

   private void selectDay(String day)
   {
      getCalendarSelector();
      ElementsCollection availableDays = getAvailableDays();
      if (day == null)
      {
         availableDays.first().click();
      }
      else if (!availableDays.filterBy(Condition.exactText(day)).isEmpty())
      {
         container().$(byText(day)).click();
      }
      else
      {
         LOGGER.log(ERROR, "Day " + day + " is not available, selecting next available day");
         availableDays.asDynamicIterable().stream()
                  .filter(element -> element.getText().compareTo(day) > 0).findFirst().orElseThrow()
                  .click();
      }
      LOGGER.log(container().$(".SelectLegacyDate__selected").getText() + " day was selected");
   }

   @NotNull
   private ElementsCollection getAvailableDays()
   {
      return container().$$(".SelectLegacyDate__available");
   }


   private SelenideElement container()
   {
      return $("section[aria-label='Departure date']").should(appear, WAIT_TIMEOUT);
   }
}
