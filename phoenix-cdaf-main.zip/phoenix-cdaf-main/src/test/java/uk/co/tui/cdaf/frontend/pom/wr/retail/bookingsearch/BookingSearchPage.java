package uk.co.tui.cdaf.frontend.pom.wr.retail.bookingsearch;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;

public class BookingSearchPage extends AbstractPage
{
   public void navigateToBookingSearchPage()
   {
      $("a[href='/retail/travel/managebooking']").should(Condition.appear).scrollTo().click();
   }

   public void closePopupAndNavigateToBookingSearchPage()
   {
      BrowserCookies.closePrivacyPopUp();
      navigateToBookingSearchPage();
   }

   public SelenideElement getBookingSearch()
   {
      return $(shadowDeepCss("tui-booking-search-cfe")).should(Condition.appear);
   }

   public SelenideElement getAccommodationField()
   {
      return $(shadowDeepCss("tui-destination-search-field [data-testid='accommodation-field']"))
               .should(Condition.appear);
   }

   public SelenideElement getAccommodationFieldLabel()
   {
      return getAccommodationField().$("label span.label");
   }

   public SelenideElement getAccommodationFieldInput()
   {
      return getAccommodationField().$("#accommodation-field");
   }

   public SelenideElement getAccommodationFieldSuggestions()
   {
      return getAccommodationField().$(".suggestions");
   }

   public SelenideElement getAccommodationFieldSearchTipModal()
   {
      return getAccommodationField().$(".search-tip-wrapper");
   }

   public boolean isSearchIconPrecedesTheSearchTipModalText()
   {
      return getAccommodationFieldSearchTipModal().$(".search-tip-icon + .search-tip-text")
               .exists();
   }

   public SelenideElement getAccommodationFieldNoMatch()
   {
      return getAccommodationField().$(".no-match");
   }

   public SelenideElement getAirportField()
   {
      return $(shadowDeepCss("tui-destination-search-field [data-testid='airport-field']"))
               .should(Condition.appear);
   }

   public SelenideElement getAirportFieldLabel()
   {
      return getAirportField().$(".label");
   }

   public SelenideElement getAirportFieldInput()
   {
      return getAirportField().$("#airport-field");
   }

   public SelenideElement getAirportFieldSearchTipModal()
   {
      return getAirportField().$(".search-tip-wrapper");
   }

   public SelenideElement getAirportFieldSearchTipModalText()
   {
      return getAirportFieldSearchTipModal().$(".search-tip-text");
   }

   public SelenideElement getAirportFieldSearchTipModalIcon()
   {
      return getAirportFieldSearchTipModal().$(".search-tip-icon");
   }

   public SelenideElement getAirportFieldSuggestions()
   {
      return getAirportField().$(".suggestions");
   }

   public SelenideElement getAirportFieldAutocompleteWrapper()
   {
      return getAirportField().$(".auto-complete-wrapper");
   }

   public SelenideElement getAirportFieldNoMatch()
   {
      return getAirportField().$(".no-match");
   }

   public SelenideElement getRetrieveByBookingReferenceTab()
   {
      return $(shadowDeepCss("tui-booking-search-cfe .tabs [data-testid='retrieve-by-ref-tab']"))
               .should(Condition.appear);
   }

   public SelenideElement getRetrieveWithoutBookingReferenceTab()
   {
      return $(
               shadowDeepCss(
                        "tui-booking-search-cfe .tabs [data-testid='retrieve-without-ref-tab']"))
               .should(Condition.appear);
   }

   public SelenideElement getRetrieveBookingByBookingReferenceInput()
   {
      return $("#RetailMMBLogin__component .inputs__textInput input[name='bookingRefereneceId']");
   }

   public SelenideElement getRetrieveBookingByBookingReferenceInputErrorMessage()
   {
      return $("#RetailMMBLogin__component .inputs__textInput .inputs__errorMessage");
   }

   public SelenideElement getLoginToYourBookingCTAButton()
   {
      return $("#RetailMMBLogin__component button[type='submit']");
   }

   public SelenideElement getBookingRetrievalFailedErrorMessage()
   {
      return $("#RetailMMBLogin__component .UI__backendErrorMessage");
   }

   public SelenideElement getRetrieveWithoutReferenceSection()
   {
      return $(shadowDeepCss(".retrieve-without-ref")).should(Condition.appear);
   }

   public SelenideElement getLeadPassengerSurnameField()
   {
      return $(shadowDeepCss("#leadPaxSurname")).should(Condition.appear);
   }

   public SelenideElement getStartDateField()
   {
      return $(shadowDeepCss("tui-booking-search-cfe [data-testid='start-date-field']"))
               .should(Condition.appear);
   }

   public SelenideElement getStartDateFieldLabel()
   {
      return getStartDateField().$("label span.label");
   }

   public SelenideElement getStartDateFieldLabelTooltip()
   {
      return getStartDateFieldLabel().$(".tooltip");
   }

   public SelenideElement getStartDateFieldInput()
   {
      return getStartDateField().$("input#startDate");
   }

   public SelenideElement getStartDateFieldInputCalendarIcon()
   {
      return getStartDateField().$("input#startDate + i .icon[style*='calendar.svg']");
   }

   public SelenideElement getStartDateFieldTooltipText()
   {
      return getStartDateField().$("#tooltip-text");
   }

   public SelenideElement getCalendarModal()
   {
      return getStartDateField().$("#drop-modal");
   }

   public SelenideElement getCalendarModalHeader()
   {
      return getCalendarModal().$(".header");
   }

   public SelenideElement getCalendarModalHeaderCloseButton()
   {
      return getCalendarModalHeader().$(".drop-close-button");
   }

   public SelenideElement getCalendarModalHeaderCloseButtonIcon()
   {
      return getCalendarModalHeaderCloseButton().$("span.icon[style*='cross.svg']");
   }

   public SelenideElement getCalendarModalFooter()
   {
      return getCalendarModal().$(".footer");
   }

   public SelenideElement getCalendarModalFooterClearAllButton()
   {
      return getCalendarModalFooter().$(".clear-button");
   }

   public SelenideElement getCalendarModalFooterDoneButton()
   {
      return getCalendarModalFooter().$(".done-button");
   }

   public SelenideElement getCalendarTable()
   {
      return getCalendarModal().$("#calendar");
   }

   public SelenideElement getCalendarTableDays()
   {
      return getCalendarTable().$("#calendar-items");
   }

   public SelenideElement getCalendarMonthYearSelectDropdown()
   {
      return getCalendarModal().$("#month-select");
   }

   public SelenideElement getCalendarPreviousMonthArrow()
   {
      return getCalendarModal().$("#select-month-prev-btn");
   }

   public SelenideElement getCalendarNextMonthArrow()
   {
      return getCalendarModal().$("#select-month-next-btn");
   }

   public SelenideElement getSearchButton()
   {
      return $(shadowDeepCss("#search-btn")).should(Condition.appear);
   }

   public SelenideElement getBookingSearchListResults()
   {
      return $(shadowDeepCss("tui-booking-search-list-mfe [data-testid='booking-list-table']"))
               .should(Condition.appear);
   }

   public List<SelenideElement> getBookingSearchListHeader()
   {
      SelenideElement headerRow = getBookingSearchListResults().$("thead tr");
      if (headerRow.exists())
      {
         return headerRow.$$("th");
      }
      return null;
   }

   public List<SelenideElement> getBookingSearchRows()
   {
      return getBookingSearchListResults().$$("tbody tr");
   }

   public boolean checkBookingSearchResultCTA()
   {
      return getBookingSearchRows().stream().anyMatch(row -> row.$(".button.tertiary").exists());
   }

   public boolean clickBookingSearchResultCTA()
   {
      SelenideElement viewAnchorTag = getBookingSearchRows().get(0).$(".button.tertiary");

      if (viewAnchorTag.exists())
      {
         viewAnchorTag.should(Condition.visible).click();
         return true;
      }
      return false;
   }

   public SelenideElement getBookingListSortDropDown()
   {
      return $(shadowDeepCss("tui-booking-search-list-mfe [data-testid='sort-dropdown']"))
               .should(Condition.appear);
   }

   public List<SelenideElement> getBookingListSortDropDownOptions()
   {
      return getBookingListSortDropDown().$("select").$$("option");
   }

   public boolean areResultsSortedAscending()
   {
      return getBookingSearchRows().stream().map(row -> row.$("td", 0).getText())
               .collect(Collectors.toList()).equals(getBookingSearchRows().stream()
                        .map(row -> row.$("td", 0).getText()).sorted()
                        .collect(Collectors.toList()));
   }

   public boolean areResultsSortedDescending()
   {
      return getBookingSearchRows().stream().map(row -> row.$("td", 0).getText())
               .collect(Collectors.toList())
               .equals(getBookingSearchRows().stream().map(row -> row.$("td", 0).getText())
                        .sorted(Comparator.reverseOrder()).collect(Collectors.toList()));
   }

   public SelenideElement getEmptyFieldsError()
   {
      return $(shadowDeepCss("#empty-fields-error")).should(Condition.appear);
   }

   public SelenideElement getPagination()
   {
      return $(shadowDeepCss("tui-booking-search-list-mfe [data-testid='pagination-list']"))
               .should(Condition.appear);
   }

   public boolean clickSelectedOption(String selectedOption)
   {
      List<SelenideElement> optionElements = getBookingListSortDropDownOptions();
      boolean foundOption = false;
      for (SelenideElement option : optionElements)
      {
         if (selectedOption.equals(option.getValue()))
         {
            option.click();
            foundOption = true;
         }
      }
      return foundOption;
   }

   public int getPaginationListSize()
   {
      SelenideElement listElement = getPagination();
      ElementsCollection items = listElement.$$(".pagination-item");
      return items.size();
   }

   public SelenideElement getNextPageLink()
   {
      return getPagination().$("li.pagination-next a.link").should(Condition.visible);
   }

   public int getCurrentPageNumber()
   {
      SelenideElement pageNumberElement = getPagination().$(".pagination-item.selected");

      return Integer.parseInt(pageNumberElement.getText());
   }

   public SelenideElement getPreviousPageLink()
   {
      return getPagination().$("li.pagination-prev a.link").should(Condition.visible);
   }

   public void clickPageNumber(int pageNumber)
   {
      SelenideElement listElement = getPagination();
      ElementsCollection items = listElement.$$(".pagination-item");

      if (pageNumber >= 1 && pageNumber <= items.size())
      {
         items.get(pageNumber - 1).click();
      }
      else
      {
         throw new IllegalArgumentException("Invalid page number: " + pageNumber);
      }
   }

   public SelenideElement getSurnameField()
   {
      return $(shadowDeepCss("[data-testid='lead-pax-surname-field']"));
   }

   public SelenideElement getSurnameFieldLabel()
   {
      return getSurnameField().$(".label");
   }

   public SelenideElement getSurnameFieldInput()
   {
      return getSurnameField().$("input");
   }

   public SelenideElement getHolidayTypeField()
   {
      return $(shadowDeepCss("[data-testid='holiday-type-field']"));
   }

   public SelenideElement getHolidayTypeFieldLabel()
   {
      return getHolidayTypeField().$("label");
   }

   public SelenideElement getHolidayTypeFieldSelect()
   {
      return getHolidayTypeField().$("select");
   }

   public List<SelenideElement> getHolidayTypeFieldSelectOptions()
   {
      return getHolidayTypeFieldSelect().$$("option");
   }

   public SelenideElement getPageHeader()
   {
      return $(shadowDeepCss("tui-booking-search-cfe .container > h2.title"));
   }

   public SelenideElement getPageTabsWrapper()
   {
      return $(shadowDeepCss(".tabs"));
   }

   public SelenideElement getClearButton()
   {
      return $(shadowDeepCss("#clear-search-btn"));
   }

   public boolean isOnlyOneHolidayTypeOptionPresent()
   {
      List<SelenideElement> options = getHolidayTypeFieldSelectOptions();
      return options.size() == 1;
   }

   public boolean isRetrieveByRefTabActive()
   {
      return Objects.requireNonNull(getRetrieveByBookingReferenceTab().getAttribute("class"))
               .contains("active");
   }

   public SelenideElement getLicenseField()
   {
      return $(shadowDeepCss("[data-testid='license-field']"));
   }

   public SelenideElement getLicenseFieldInput()
   {
      return getLicenseField().$("input");
   }

   public SelenideElement getRandomCalendarDay()
   {
      List<SelenideElement> days = getCalendarTableDays().$$("time");
      Random rand = new Random();
      int randomDayNumber = rand.nextInt(days.size());
      return days.get(randomDayNumber);
   }
}
