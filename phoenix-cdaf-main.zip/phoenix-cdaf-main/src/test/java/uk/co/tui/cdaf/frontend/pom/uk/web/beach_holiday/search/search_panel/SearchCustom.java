package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class SearchCustom
{

   private static final String DURATION_PATTERN = "\\d+[\\w\\d\\s]*";

   private static final ThreadLocal<HashMap<String, String>> searchCriteria = new ThreadLocal<>();

   private final List<String> searchKeys;

   private List<String> tagNames;

   public SearchCustom()
   {
      searchKeys = new ArrayList<>();

   }

   public void searchComp()
   {
      Arrays.asList(SearchComp.values())
               .forEach(param -> searchKeys.add("@" + param.toString().toLowerCase()));
   }

   @Before
   public void setUp(Scenario scenario)
   {
      tagNames = (List<String>) scenario.getSourceTagNames();

      searchComp();
      setSearchCriteria();
   }

   public void setSearchCriteria()
   {
      HashMap<String, String> tempSearch = new HashMap<>();
      searchKeys.forEach(key -> (tagNames.stream()
               .filter(tag -> tag.contains(key) && tag.contains("=")).collect(Collectors.toList()))
               .forEach(tag -> tempSearch.put(key.replace("@", ""), tag.split("=")[1])));
      searchCriteria.set(tempSearch);
   }

   public String getAirport()
   {
      try
      {
         return searchCriteria.get().get(SearchComp.AIRPORT.toString().toLowerCase()).replace("_",
                  " ");
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getDestination()
   {
      try
      {
         return (searchCriteria.get().get(SearchComp.DESTINATION.toString().toLowerCase()))
                  .replace("_", " ");
      }
      catch (Exception e)
      {
         return null;
      }

   }

   public String getAccommodation()
   {
      return getStringValue(SearchComp.ACCOMMODATION);
   }

   public String getAccommodationCode()
   {
      return getStringValue(SearchComp.ACCOMMODATIONCODE);
   }

   private String getStringValue(SearchComp comp)
   {
      try
      {
         return (searchCriteria.get().get(comp.toString().toLowerCase())).replace("_", " ");
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getDuration()
   {
      try
      {
         String testData =
                  searchCriteria.get().get(SearchComp.DURATION.toString().toLowerCase())
                           .toLowerCase();
         if (testData.length() <= 2 && !testData.isEmpty())
         {
            return testData;
         }
         testData = testData.replace("_", " ").trim();
         Duration[] durationNameFromEnum = Duration.values();
         for (Duration duration : durationNameFromEnum)
         {
            String durationNameAfterUpdate =
                     duration.toString().replace("_", " ").toLowerCase().trim();
            if (testData.equals(durationNameAfterUpdate))
            {
               if (!durationNameAfterUpdate.matches(DURATION_PATTERN))
               {
                  char ch = (char) (durationNameAfterUpdate.charAt(0) - 32);
                  char[] charArr = durationNameAfterUpdate.toCharArray();
                  charArr[0] = ch;
                  durationNameAfterUpdate = String.valueOf(charArr);
               }
               return durationNameAfterUpdate;
            }
         }
      }
      catch (Exception e)
      {
         return "0000";
      }
      return "0000";
   }

   public Integer getNumberOfDays()
   {
      try
      {
         return Integer
                  .parseInt(searchCriteria.get().get(SearchComp.NDAYS.toString().toLowerCase()));
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public Integer getNumberOfMonths()
   {
      try
      {
         return Integer
                  .parseInt(searchCriteria.get().get(SearchComp.NMONTHS.toString().toLowerCase()));
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public Integer getAdultCount()
   {
      try
      {
         return Integer
                  .parseInt(searchCriteria.get().get(SearchComp.ADULT.toString().toLowerCase()));
      }
      catch (Exception e)
      {
         return null;
      }

   }

   public Integer getChildCount()
   {
      try
      {
         return Integer
                  .parseInt(searchCriteria.get().get(SearchComp.CHILD.toString().toLowerCase()));
      }
      catch (Exception e)
      {
         return null;
      }

   }

   public String getChildAges()
   {
      try
      {
         return searchCriteria.get().get(SearchComp.CHILDAGE.toString().toLowerCase());
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getDate()
   {
      try
      {
         return searchCriteria.get().get(SearchComp.DATE.toString().toLowerCase());
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getDateRange()
   {
      try
      {
         return searchCriteria.get().get(SearchComp.DATERANGE.toString().toLowerCase());
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getDepDate()
   {
      try
      {
         return searchCriteria.get().get(SearchComp.DEPDATE.toString().toLowerCase());
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getArrDate()
   {
      try
      {
         return searchCriteria.get().get(SearchComp.ARRDATE.toString().toLowerCase());
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getDepArpt()
   {
      try
      {
         return (searchCriteria.get().get(SearchComp.DEPAIRPORT.toString().toLowerCase()))
                  .replace("_", " ");
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getArrArpt()
   {
      try
      {
         return searchCriteria.get().get(SearchComp.ARRAIRPORT.toString().toLowerCase());
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getScenarioId()
   {
      try
      {
         return (searchCriteria.get().get(SearchComp.SCENARIOID.toString().toLowerCase()))
                  .replace("_", " ");
      }
      catch (Exception e)
      {
         return null;
      }
   }

   public String getCheckoutDays()
   {
      try
      {
         return (searchCriteria.get().get(SearchComp.CHECKOUTDAYS.toString().toLowerCase()))
                  .replace("_", " ");
      }
      catch (Exception e)
      {
         return null;
      }
   }

   enum SearchComp
   {
      DURATION, DESTINATION, ACCOMMODATION, ACCOMMODATIONCODE, AIRPORT, NDAYS, NMONTHS, INMONTHS,
      ADULT, CHILD, CHILDAGE, DATE, DATERANGE, DEPDATE, ARRDATE, DEPAIRPORT, ARRAIRPORT,
      SUBAIRPORT, FLIGHTTYPE, SCENARIOID, CHECKOUTDAYS
   }

   enum Duration
   {
      AROUND_A_WEEK, A_FEW_DAYS, AROUND_2_WEEKS, AROUND_11_NIGHTS, AROUND_10_NIGHTS, DAY_TRIP,
      _3_NIGHTS, _4_NIGHTS, _5_NIGHTS, _6_NIGHTS, _7_NIGHTS, _8_NIGHTS, _9_NIGHTS, _10_NIGHTS,
      _11_NIGHTS, _14_NIGHTS, MORE_THAN_14_NIGHTS, _4_VECKOR, _1_VECKA, _10_TILL_12_DAGAR,
      _2_VECKOR, _1_TILL_2_VECKOR, _3_VECKOR
   }

}
