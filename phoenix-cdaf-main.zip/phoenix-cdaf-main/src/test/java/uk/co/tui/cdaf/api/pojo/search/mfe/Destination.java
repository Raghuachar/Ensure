package uk.co.tui.cdaf.api.pojo.search.mfe;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Destination
{
   private String id;

   private String name;

   private String type;

   private boolean multiSelect;

   private String parentCode;

   private boolean available;

   private String parentType;

   private List<Destination> children;

}

