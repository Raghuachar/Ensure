package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SpecialAssistancePage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class SpecialAssistanceStepDefs
{
   public SpecialAssistancePage specialAssistancePage;

   public SpecialAssistanceStepDefs()
   {
      specialAssistancePage = new SpecialAssistancePage();
   }

   @Given("the associated flight is dynamic")
   public void the_associated_flight_is_dynamic()
   {
      assertThat("Carrier is not Dynamic Flight", specialAssistancePage.isDynamicFlight(),
               is(true));
   }

   @When("they scroll down the Customise page")
   public void they_scroll_down_the_Customise_page()
   {
      assertThat("Special Assistance Component is not present",
               specialAssistancePage.isSpecialAssistanceComponentPresent(), is(true));
   }

   @Then("they will be presented with a Special Assistance message")
   public void they_will_be_presented_with_a_Special_Assistance_message()
   {
      assertThat("Special Assistance Description is not present",
               specialAssistancePage.isSpecialAssistanceDescriptionPresent(), is(true));
   }
}
