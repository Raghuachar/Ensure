package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class PackageInsertPaymentErrorMessagesStepDefs
{

   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageInsertPaymentErrorMessagesStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent is viewing the Insert payment modal")
   public void that_the_agent_is_viewing_the_Insert_payment_modal()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pKgReconcilationPaymentPageComponents.isPageSubHeaderPresent();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickInsertPayment();
      wait.forJSExecutionReadyLazy();
   }

   @When("they press the save CTA")
   public void they_press_the_save_CTA()
   {
      pKgReconcilationPaymentPageComponents.isSaveCTADisplayed();
      pKgReconcilationPaymentPageComponents.clickOnSaveCTA();
   }

   @When("have not entered information into any of the fields on the modal")
   public void have_not_entered_information_into_any_of_the_fields_on_the_modal()
   {
      pKgReconcilationPaymentPageComponents.isPaymentAmountInputField();
      pKgReconcilationPaymentPageComponents.isReasonInputField();
   }

   @Then("the error message will appear")
   public void the_error_message_will_appear()
   {
      pKgReconcilationPaymentPageComponents.insertPaymentValidationMessage();
   }

   @Then("the empty fields will appear in a red colour")
   public void the_empty_fields_will_appear_in_a_red_colour(
            io.cucumber.datatable.DataTable dataTable)
   {
      pKgReconcilationPaymentPageComponents.isPaymentAmountInputFieldHaveErrorCss();
      pKgReconcilationPaymentPageComponents.isReasonInputFieldHaveErrorCss();
   }
}
