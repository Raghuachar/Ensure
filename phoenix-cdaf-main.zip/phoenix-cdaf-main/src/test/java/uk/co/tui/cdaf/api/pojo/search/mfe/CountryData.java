package uk.co.tui.cdaf.api.pojo.search.mfe;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CountryData
{
   private List<Destination> countries;
   private List<Destination> destinations;
   private List<Destination> hotels;
}

