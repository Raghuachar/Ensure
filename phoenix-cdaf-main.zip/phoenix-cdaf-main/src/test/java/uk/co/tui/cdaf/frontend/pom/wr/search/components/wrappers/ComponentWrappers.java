package uk.co.tui.cdaf.frontend.pom.wr.search.components.wrappers;

import com.codeborne.selenide.SelenideElement;

public interface ComponentWrappers
{
   SelenideElement getDepartureWrapper();

   SelenideElement getAirportWrapper();

   SelenideElement getDestinationWrapper();

   SelenideElement getDurationWrapper();

   SelenideElement getPaxAndRoomsWrapper();

   SelenideElement getSearchButtonWrapper();
}
