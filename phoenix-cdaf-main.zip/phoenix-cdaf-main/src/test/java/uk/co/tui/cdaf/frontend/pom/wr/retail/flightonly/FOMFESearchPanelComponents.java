package uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class FOMFESearchPanelComponents extends AbstractPage
{

   private final WebElementWait wait;

   private final String mfeParentElemnt = "tui-flight-search-bar";

   public FOMFESearchPanelComponents()
   {
      wait = new WebElementWait();
   }

   public WebElement getMFEOneWay()
   {
      String mfeOneWay = "#radio-oneway > div > i";
      wait.forAppear(SelenideHelper.getShadowRootElement(mfeOneWay, mfeParentElemnt));
      return SelenideHelper.getShadowRootElement(mfeOneWay, mfeParentElemnt);
   }

   public void selectOneWayMFE()
   {
      WebElementTools.scrollTo(getMFEOneWay());
      WebElementTools.click(getMFEOneWay());
   }

   public WebElement getOutboundAirport()
   {
      String outboundAirport = "#searchField-airport-outbound";
      wait.forAppear(SelenideHelper.getShadowRootElement(outboundAirport, mfeParentElemnt));
      return SelenideHelper.getShadowRootElement(outboundAirport, mfeParentElemnt);
   }

   public void selectOutboundAirport()
   {
      wait.forAppear(getOutboundAirport());
      WebElementTools.scrollTo(getOutboundAirport());
      WebElementTools.click(getOutboundAirport());
   }

   public WebElement getAllOutboundAirport()
   {
      String selectAllOutboundAirport = "#all_nearby_airports";
      wait
               .forAppear(SelenideHelper.getShadowRootElement(selectAllOutboundAirport,
                        mfeParentElemnt));
      return SelenideHelper.getShadowRootElement(selectAllOutboundAirport, mfeParentElemnt);
   }

   public void selectAllOutboundAirport()
   {
      wait.forAppear(getAllOutboundAirport());
      WebElementTools.scrollTo(getAllOutboundAirport());
      WebElementTools.click(getAllOutboundAirport());
   }

   public WebElement getSearchFieldAirportInbound()
   {
      String searchFieldAirportInbound = "#searchField-airport-inbound";
      wait.forAppear(
               SelenideHelper.getShadowRootElement(searchFieldAirportInbound, mfeParentElemnt));
      return SelenideHelper.getShadowRootElement(searchFieldAirportInbound, mfeParentElemnt);
   }

   public void selectSearchFieldAirportInbound()
   {
      wait.forAppear(getSearchFieldAirportInbound());
      WebElementTools.scrollTo(getSearchFieldAirportInbound());
      WebElementTools.click(getSearchFieldAirportInbound());
   }

   public List<SelenideElement> getInboundAirport()
   {
      String selectInboundAirport = "#AYT";
      return SelenideHelper.getShadowRootElements(selectInboundAirport, mfeParentElemnt);
   }

   public void selectInboundAirport()
   {
      WebElementTools.scrollTo(getInboundAirport().get(1));
      WebElementTools.click(getInboundAirport().get(1));
   }

   public WebElement getSearchFieldDateOutbound()
   {
      String searchFielddateoutbound = "#searchField-date-outbound";
      return SelenideHelper.getShadowRootElement(searchFielddateoutbound, mfeParentElemnt);

   }

   public void searchFieldDateOutbound()
   {
      WebElementTools.scrollTo(getSearchFieldDateOutbound());
      WebElementTools.click(getSearchFieldDateOutbound());
   }

   public WebElement getBoxNext()
   {
      String selectBoxNext = "#selectBox-next";
      return SelenideHelper.getShadowRootElement(selectBoxNext, mfeParentElemnt);

   }

   public void searchBoxNext()
   {
      WebElementTools.scrollTo(getBoxNext());
      WebElementTools.click(getBoxNext());
   }

   public List<SelenideElement> getAvailableDate()
   {
      String selectAvailableDate = "#calendarItems-outbound > div[class*='available']";
      return SelenideHelper.getShadowRootElements(selectAvailableDate, mfeParentElemnt);
   }

   public void selectAvailableDate()
   {
      WebElementTools.scrollTo(getAvailableDate().get(0));
      WebElementTools.click(getAvailableDate().get(0));
   }

   public WebElement getsearchButton()
   {
      String searchButton = "#searchButton";
      return SelenideHelper.getShadowRootElement(searchButton, mfeParentElemnt);

   }

   public void searchButton()
   {
      WebElementTools.scrollTo(getsearchButton());
      WebElementTools.click(getsearchButton());
   }

}
