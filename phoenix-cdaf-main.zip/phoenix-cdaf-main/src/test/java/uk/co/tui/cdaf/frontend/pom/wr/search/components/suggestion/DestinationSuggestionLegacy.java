package uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.Destination;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.DestinationLegacy;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;

public class DestinationSuggestionLegacy extends DestinationSuggestionMfe
{
   private static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   private SelenideElement dropdown;

   public SelenideElement container()
   {
      if (dropdown == null)
      {
         dropdown = $(shadowDeepCss("div.AutoComplete__autoCompleteWrapper "));
      }
      dropdown.should(appear, WAIT_TIMEOUT);
      return dropdown;
   }

   public List<SelenideElement> getAllSuggestionElements()
   {
      ElementsCollection selenideElements = container().$("div.AutoComplete__suggestion").$$("li");
      return selenideElements.asDynamicIterable().stream()
               .filter(el -> el != null && !el.getAttribute("class")
                        .contains("AutoComplete__unselectable"))
               .collect(Collectors.toList());
   }

   public SelenideElement getSearchAllDestinationBtn()
   {
      return container().$("div.AutoComplete__footer").$("a");
   }

   public Destination clickAllDestinationBtn()
   {
      getSearchAllDestinationBtn().click();
      return new DestinationLegacy();
   }

   public SelenideElement getNoMatchElement()
   {
      return container().$("span.HighlightedLink__text").$("span span");
   }

   public void selectSuggestionFromList(String suggestion)
   {
      getAllSuggestionElements().stream().filter(el -> el.getText().contains(suggestion))
               .findFirst().orElseThrow().click();
   }
}
