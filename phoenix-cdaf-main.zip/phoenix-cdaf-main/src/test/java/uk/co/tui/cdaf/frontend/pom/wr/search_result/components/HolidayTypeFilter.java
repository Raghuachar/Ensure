package uk.co.tui.cdaf.frontend.pom.wr.search_result.components;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

public class HolidayTypeFilter extends BaseComponent
{
   public void selectTypeByName(String name)
   {
      selectElement($(".FilterPanelV2__filterPanelContent").$(byText(name)));
   }
}
