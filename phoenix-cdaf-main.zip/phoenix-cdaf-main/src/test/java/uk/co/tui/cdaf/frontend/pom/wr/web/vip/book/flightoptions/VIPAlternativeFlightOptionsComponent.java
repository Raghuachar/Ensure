package uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.flightoptions;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class VIPAlternativeFlightOptionsComponent extends AbstractPage
{
   private final HashMap<String, WebElement> vipAlternateFlightsComponentsMap;

   @FindBy(css = "[class$='YourFlights__bg'] a")
   private WebElement alternativeFlightsComponent;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(1)")
   private WebElement outboundFlightDate;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(1) > div.Itinerary__itineraryTitle > div.Itinerary__date")
   private WebElement departureDate;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(1) > div.Itinerary__ItineraryDetails")
   private WebElement flightDuration;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(1) > div.Itinerary__ItineraryDetails > div.Itinerary__arrival > div.Itinerary__departureTime")
   private WebElement arrivalTime;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(1) > div.Itinerary__ItineraryDetails > div.Itinerary__departure > div:nth-child(3)")
   private WebElement outboundAirport;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(1) > div.Itinerary__ItineraryDetails > div.Itinerary__arrival > div:nth-child(3)")
   private WebElement destinationAirport;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(1) > div.Itinerary__ItineraryDetails > div.Itinerary__careerLogoContainer > span")
   private WebElement airline;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(2) > div.Itinerary__itineraryTitle > div.Itinerary__date > div > span")
   private WebElement returnFlightdate;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(2) > div.Itinerary__ItineraryDetails > div.Itinerary__departure > div.Itinerary__departureTime")
   private WebElement departureTime;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(2) > div.Itinerary__ItineraryDetails")
   private WebElement flightDurations;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(2) > div.Itinerary__ItineraryDetails > div.Itinerary__arrival > div.Itinerary__departureTime")
   private WebElement arrivalTimes;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(2) > div.Itinerary__ItineraryDetails > div.Itinerary__departure > div:nth-child(3)")
   private WebElement outboundAirports;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(2) > div.Itinerary__ItineraryDetails > div.Itinerary__arrival > div:nth-child(3)")
   private WebElement destinationAirports;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__eachFlights > div > div:nth-child(2) > div.Itinerary__ItineraryDetails > div.Itinerary__careerLogoContainer > span")
   private WebElement airlines;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__selectedSection > div")
   private WebElement priceDifference;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2) > div.AlternativeFlights__selectedSection > span > button")
   private WebElement selectButton;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1)")
   private WebElement alternativeFlightsAvailable;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.AlternativeFlights__directIndirectFlights.AlternativeFlights__filter > div > div:nth-child(1) > div:nth-child(2)")
   private WebElement availableFlight;

   @FindBy(css = "#selectedFlights__component > div > section > div.cards__card.Itinerary__itinerary.cards__elevationLevel0")
   private WebElement selectedFlight;

   @FindBy(css = "#backtoyourholidaybuttoncomponent__component > div > div > div > div > a > button")
   private WebElement applyChangesButton;

   @FindBy(css = "#YourFlightsSummary__component > div > section > div:nth-child(2)")
   private WebElement selectedFlightInSummary;

   @FindBy(css = "#alternativeFlights__component > div > section > div:nth-child(2) > div.DateCarousel__timelineCarousel > div.carousel__carouselContainer > div > div.DateCarousel__viewPager > div > div > div:nth-child(11) > div")
   private WebElement updatedPriceInDateSection;

   @FindBy(xpath = "//span[@class='DateCarousel__textBottom' and contains(text(),'vanaf')]")
   private List<WebElement> calendarDateEnable;

   @FindBy(xpath = "//span[@class='DateCarousel__textBottom' and contains(text(),'Geen vluchten')]")
   private List<WebElement> calendarDateDisable;

   public VIPAlternativeFlightOptionsComponent()
   {
      WebElementWait wait = new WebElementWait();
      vipAlternateFlightsComponentsMap = new HashMap<>();
   }

   public boolean isAlternateFlightsComponentDisplayed()
   {
      return WebElementTools.isPresent(alternativeFlightsComponent);
   }

   public HashMap<String, WebElement> getVipAlternateFlightsComponentsMap()
   {
      vipAlternateFlightsComponentsMap.put("Outbound Flight Date", outboundFlightDate);
      vipAlternateFlightsComponentsMap.put("Direct FLight & Duration", flightDuration);
      vipAlternateFlightsComponentsMap.put("Return Flight Date", returnFlightdate);
      vipAlternateFlightsComponentsMap.put("Departure Time", departureTime);
      vipAlternateFlightsComponentsMap.put("Direct Flight & Duration", flightDurations);
      vipAlternateFlightsComponentsMap.put("Arrival Time", arrivalTimes);
      vipAlternateFlightsComponentsMap.put("Outbound Airport", outboundAirports);
      vipAlternateFlightsComponentsMap.put("Destination Airport", destinationAirports);
      vipAlternateFlightsComponentsMap.put("Airline", airlines);
      vipAlternateFlightsComponentsMap.put("Difference in price per person", priceDifference);
      vipAlternateFlightsComponentsMap.put("Select CTA", selectButton);
      return vipAlternateFlightsComponentsMap;
   }

   public boolean isAlternateFlightsAvailable()
   {
      return WebElementTools.isPresent(alternativeFlightsAvailable);
   }

   public void clickOnViewAlternateFlightsLink()
   {
      WebElementTools.click(alternativeFlightsComponent);
   }

   public boolean isAvailableFlightDisplayed()
   {
      return WebElementTools.isPresent(availableFlight);
   }

   public void clickOnSelectButton()
   {
      $("div.DateCarousel__selected").should(Condition.appear);
      ElementsCollection selenideElements = $$("span.DateCarousel__textBottom");
      for (SelenideElement element : selenideElements.asDynamicIterable())
      {
         if (element.getText().contains("€"))
         {
            String parentClasses = element.parent().getAttribute("class");
            if (parentClasses != null && !parentClasses.contains("DateCarousel__selected"))
            {
               element.click();
               break;
            }
         }
      }
      $(".AlternativeFlights__selectButton").should(Condition.appear).click();
      $(".AlternativeFlights__selected").should(Condition.appear, Duration.ofSeconds(10)).shouldBe(Condition.enabled);
   }

   public boolean isSelectedFlightDisplayed()
   {
      return WebElementTools.isPresent(selectedFlight);
   }

   public void clickOnApplyButton()
   {
      WebElementTools.click(applyChangesButton);
   }

   public boolean isSelectedFlightInSummaryDisplayed()
   {
      return WebElementTools.isPresent(selectedFlightInSummary);
   }

   public String[] getActualDates()
   {
      return getDates($("div.YourFlights__summaryComponentWrapper").$(
                        "div.cards__card.Itinerary__itinerary.cards__elevationLevel0")
               .should(Condition.appear));
   }

   public String[] getExpectedDates()
   {
      return getDates($(".AlternativeFlights__selected").should(Condition.exist));
   }

   private String[] getDates(SelenideElement parentContainer)
   {
      String outValue =
               parentContainer.$$("span.Itinerary__date").first().getText();
      String inValue =
               parentContainer.$$("span.Itinerary__date").last().getText();
      return new String[] { inValue, outValue };
   }

   public String getAlertsMessageText()
   {
      return $(".alerts__message").should(Condition.appear).getText();
   }
}
