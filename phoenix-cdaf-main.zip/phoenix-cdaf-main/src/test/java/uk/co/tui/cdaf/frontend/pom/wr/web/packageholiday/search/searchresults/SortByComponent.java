package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang3.math.NumberUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class SortByComponent extends AbstractPage
{
   public final SearchResultsComponent searchResultComponent;

   private final WebElementWait wait;

   private final int filterPrice = 0;

   @FindAll({ @FindBy(css = ".SortResults__sortTypeList select[aria-label='Select'] option") })
   public List<WebElement> sortByOption;

   WebDriverUtils utils;

   @FindBy(css = ".SortResults__sortResults")
   private WebElement sortComponent;

   @FindBy(css = ".SortResults__sortTypeList select")
   private WebElement sortBy;

   @FindBy(css = "[class='ResultListItemV2__value']")
   private List<WebElement> prices;

   @FindBy(css = "[class='ResultListItemV2__deposit']")
   private List<WebElement> discountsElements;

   @FindBy(css = "[class='ResultListItemV2__totalParty']")
   private List<WebElement> totalPrices;

   @FindBy(css = "[aria-label='holiday count']")
   private WebElement holidayCountText;

   @FindBy(css = ".SortResults__sortTypeList [value='default']")
   private WebElement ourRecommended;

   @FindBy(css = ".csqRating__bar")
   private List<WebElement> ratings;

   @FindBy(css = ".ResultsListItem__value")
   private List<WebElement> resultPrices;

   @FindBy(css = "[class='ResultListItemV2__ratingNumber']")
   private List<WebElement> guestRatings;

   public SortByComponent()
   {
      searchResultComponent = new SearchResultsComponent();
      wait = new WebElementWait();
   }

   public boolean isSortByDisplayed()
   {
      return WebElementTools.isPresent(sortComponent);
   }

   public void selectSortBy()
   {
      $(sortBy).scrollTo().click();
      wait.forJSExecutionReadyLazy();
   }

   public void clickOnSortByDropdown(String sort)
   {
      String selector = ".SortResults__sortTypeList [value='".concat(sort).concat("']");

      SelenideElement sortOption = $(selector);

      WebElementTools.click(sortOption);
      $("div.SearchResults__fade").should(Condition.disappear, Duration.ofSeconds(5));
      $("div.SearchResults__noFade").should(Condition.appear, Duration.ofSeconds(5));
   }

   public boolean doLowtoHighResult()
   {
      wait.forJSExecutionReadyLazy();
      int[] priceList =
               prices.stream().mapToInt(price -> NumberUtils.toInt(price.toString())).toArray();
      List<Integer> intList = processTheSortForWr(priceList);
      return doSortCheckLowToHigh(intList);
   }

   public boolean doHighToLowResult()
   {
      wait.forJSExecutionReadyLazy();
      int[] priceList =
               prices.stream().mapToInt(price -> NumberUtils.toInt(price.toString())).toArray();
      List<Integer> intList = processTheSortForWr(priceList);
      return doSortCheckHighToLow(intList);
   }

   public boolean doTotalPersonHighToLowResult()
   {
      wait.forJSExecutionReadyLazy();
      int[] priceList = totalPrices.stream()
               .mapToInt(totalPrice -> NumberUtils.toInt(totalPrice.toString().substring(1)))
               .toArray();
      List<Integer> intList = processTheSortForWr(priceList);
      return doSortCheckHighToLow(intList);
   }

   public boolean doTotalPersonLowToHighResult()
   {
      wait.forJSExecutionReadyLazy();
      int[] priceList = totalPrices.stream()
               .mapToInt(totalPrice -> NumberUtils.toInt(totalPrice.toString().substring(1)))
               .toArray();
      List<Integer> intList = processTheSortForWr(priceList);
      return doSortCheckLowToHigh(intList);
   }

   public boolean doDiscountPersonHighToLowResult()
   {
      wait.forJSExecutionReadyLazy();
      List<Integer> discountValueList = new ArrayList<>();
      for (WebElement webElement : discountsElements)
      {
         WebElementTools.scrollTo(webElement);
         String discountText = webElement.getText();
         if (discountText != null)
         {
            String[] discountTextArray = discountText.split(" ");
            if (discountTextArray.length > 1)
            {
               int discountPrice =
                        NumberUtils.toInt(discountTextArray[1].substring(1).replace("p", ""));
               discountValueList.add(discountPrice);
            }
         }
      }
      discountValueList.sort(Integer::compareTo);
      return doSortCheckHighToLow(discountValueList);
   }

   private List<Integer> processTheSortForWr(int[] priceList)
   {
      List<Integer> intList = new ArrayList<>(priceList.length);
      for (int i : priceList)
      {
         intList.add(i);
      }
      intList.sort(Integer::compareTo);
      return intList;
   }

   private boolean doSortCheckLowToHigh(List<Integer> intList)
   {
      Integer[] arr = new Integer[intList.size()];
      for (int i = 0; i < intList.size(); i++)
      {
         arr[i] = intList.get(i);
      }
      for (int i = 0; i < arr.length - 1; i++)
      {
         if (arr[i] > arr[i + 1])
         {
            return false;
         }
      }
      return true;
   }

   private boolean doSortCheckHighToLow(List<Integer> intList)
   {
      Collections.reverse(intList);
      Integer[] arr = new Integer[intList.size()];
      for (int i = 0; i < intList.size(); i++)
      {
         arr[i] = intList.get(i);
      }
      for (int i = 0; i < arr.length - 1; i++)
      {
         if (arr[i] < arr[i + 1])
         {
            return false;
         }
      }
      return true;
   }

   public void clickSortoptions(int value)
   {
      $(sortByOption.get(value)).scrollTo().click();
      $("div.SearchResults__fade").should(Condition.disappear, Duration.ofSeconds(5));
      $("div.SearchResults__noFade").should(Condition.appear, Duration.ofSeconds(5));
   }

   public boolean isDefaultSelection(String sort)
   {
      String target = WebElementTools.getElementTextByInnerHtml(ourRecommended);
      return sort.equalsIgnoreCase(target);
   }

   public boolean isHolidayCountDisplayed()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(holidayCountText));
   }

   public boolean sortCust()
   {
      wait.forJSExecutionReadyLazy();
      int[] ratingList =
               ratings.stream().mapToInt(price -> utils.getNumberFromString(price.getText()))
                        .toArray();

      for (int i = 0; i < ratingList.length - 1; i++)
      {
         if (ratingList[i + 1] > ratingList[i])
         {
            return false;
         }
      }
      return true;
   }

   public boolean twoOrMoreCSPComparision()
   {
      wait.forJSExecutionReadyLazy();
      int[] ratingList =
               ratings.stream().mapToInt(price -> utils.getNumberFromString(price.getText()))
                        .toArray();
      int count = 0;
      for (int i = 0; i < ratingList.length - 1; i++)
      {
         if (ratingList[i + 1] == ratingList[i] && count > 1)
         {
            return true;
         }
         count++;
      }
      return false;
   }

   public boolean isFilteredByPrice()
   {
      wait.forJSExecutionReadyLazy();
      int[] filteredResultPrice = resultPrices.stream()
               .mapToInt(result -> utils.getNumberFromString(result.getText())).toArray();
      int[] filteredPrices =
               Arrays.stream(filteredResultPrice).filter(x -> x <= filterPrice).toArray();
      return filteredResultPrice.length == filteredPrices.length;
   }

   public boolean isSortByGuestPresent()
   {
      return sortByOption.stream().map(option -> option.getAttribute("value"))
               .collect(Collectors.toList()).contains("reviewDesc");
   }

   public List<Double> getDescendingGuestRatings()
   {
      ElementsCollection selenideElements = $$(".ResultListItemV2__ratingNumber");
      List<Double> ratingsList = new ArrayList<>();

      for (SelenideElement ratingElement : selenideElements)
      {
         double rating = NumberUtils.toDouble(ratingElement.getText());
         ratingsList.add(rating);
      }
      return ratingsList;
   }

}
