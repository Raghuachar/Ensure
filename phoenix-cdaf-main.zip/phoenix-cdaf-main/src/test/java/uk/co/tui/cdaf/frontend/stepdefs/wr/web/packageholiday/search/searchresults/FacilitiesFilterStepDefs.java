package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.number.OrderingComparison.greaterThan;

public class FacilitiesFilterStepDefs
{
   static AutomationLogManager LOGGER = new AutomationLogManager(FacilitiesFilterStepDefs.class);

   private final SearchResultsPage searchResultsPage;

   public FacilitiesFilterStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
   }

   @When("they are viewing the Facilities Filter")
   public void they_are_viewing_the_Facilities_Filter()
   {
      assertThat("Facilities component is not present",
               searchResultsPage.facilitiesFilterComponent.isFacilitiesDisplayed(), is(true));
   }

   @Then("they will see the following Facilities that they can filter by in alphabetical order")
   public void they_will_see_the_following_Facilities_that_they_can_filter_by_in_alphabetical_order(
            List<String> facilitiesFilter)
   {
      assertThat("Facilities component is not in alphabetical order",
               searchResultsPage.facilitiesFilterComponent.facilitiesInAlphaOrder(facilitiesFilter),
               is(true));
   }

   @When("there are more than 5 facilities available to filter by")
   public void there_are_more_than_5_facilities_available_to_filter_by()
   {
      if (searchResultsPage.facilitiesFilterComponent.isMoreThanFiveShowMorePresent())
         assertThat("there are no more than 5 facilities available for filter",
                  searchResultsPage.facilitiesFilterComponent.isMoreThanFiveShowMorePresent(),
                  is(true));
   }

   @Then("a show more link will display below the facilities already visible to the customer")
   public void a_show_more_link_will_display_below_the_facilities_already_visible_to_the_customer()
   {
      assertThat("show more link will not display",
               searchResultsPage.facilitiesFilterComponent.isShowMorePresent(), is(true));
   }

   @When("they select {string} link")
   public void they_select_link(String showMore)
   {
      searchResultsPage.facilitiesFilterComponent.clickShowMoreLink();
   }

   @Then("they will see more facilities listed in alphabetical order")
   public void they_will_see_more_facilities_listed_in_alphabetical_order()
   {
      searchResultsPage.facilitiesFilterComponent.alphabeticalOrder();
   }

   @And("a facilities {string} link will be visible and selecting show less hides")
   public void a_facilities_link_will_be_visible_and_selecting_show_less_hides(String string)
   {
      assertThat("show more link will not display",
               searchResultsPage.facilitiesFilterComponent.isShowMorePresent(), is(true));
      searchResultsPage.facilitiesFilterComponent.clickShowMoreLink();
   }

   @Then("they can select 1 or many facilities")
   public void they_can_select_1_or_many_facilities()
   {
      LOGGER.log(LogLevel.INFO,
               "Before facilities" + searchResultsPage.searchResultsFiltersComponent.hoildayResults());
      searchResultsPage.facilitiesFilterComponent.clickFacilitiesFilterOptions();
   }

   @And("the search results will facilities filter to reflect the selection")
   public void the_search_results_will_facilities_filter_to_reflect_the_selection()
   {
      LOGGER.log(LogLevel.INFO,
               "After facilities" + searchResultsPage.searchResultsFiltersComponent.hoildayResults());
   }

   @Then("they will be greyed out")
   public void they_will_be_greyed_out()
   {
      assertThat("facilites filter is not greyed out",
               searchResultsPage.facilitiesFilterComponent.isFacilitesDisableState(), is(true));
   }

   @And("the customer will not be able to select these.")
   public void the_customer_will_not_be_able_to_select_these()
   {
      assertThat("the_customer_will_not_be_able_to_select_these",
               searchResultsPage.facilitiesFilterComponent.clickFacilitiesFliterGreyedOut(),
               is(true));
   }

   @And("the customer can select what they wish to filter including Facilities")
   public void the_customer_can_select_what_they_wish_to_filter_including_Facilities()
   {
      searchResultsPage.facilitiesFilterComponent.clickFacilitiesFilterOptions();
   }

   @And("the {string} will be in an unselected state by default")
   public void the_will_be_in_an_unselected_state_by_default(String string)
   {
      assertThat("Facilites List component is not displayed",
               searchResultsPage.facilitiesFilterComponent.getFacilitesOptions().size(),
               greaterThan(0));
   }
}
