package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.book.passengerdetails.SalesQuoteComponent;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;

import java.time.Duration;
import java.util.List;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.cssClass;
import static org.junit.Assert.*;

import java.time.Duration;
import java.util.List;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.cssClass;
import static org.junit.Assert.*;

public class PassengerDetailsSalesQuoteStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PassengerDetailsSalesQuoteStepDefs.class);

   private final RetailPackageNavigation retailPackageNavigation;

   private final RetailPassengerDetailsPage retailPassengerDetailsPage;

   private final SalesQuoteComponent salesQuoteComponent;

   public PassengerDetailsSalesQuoteStepDefs()
   {
      retailPackageNavigation = new RetailPackageNavigation();
      retailPassengerDetailsPage = new RetailPassengerDetailsPage();
      salesQuoteComponent = new SalesQuoteComponent();
   }

   @Given("that the Agent is viewing the 'Passenger Details' page")
   public void that_the_agent_is_viewing_the_passenger_details_page()
   {
      if (isExecutedLocally())
      {
         retailPassengerDetailsPage.visit();
      }
      else
      {
         retailPackageNavigation.retailLoginChangeagent();
         retailPackageNavigation.navigateToPassengerPage();
      }
   }

   @Given("they fill the passenger details form")
   public void they_fill_the_passenger_details_form()
   {
      if (isExecutedLocally())
      {
         retailPassengerDetailsPage.fillThePassengerDetailsForAddFeeType();
      }
      else
      {
         retailPassengerDetailsPage.fillRetailPassengerDetailsForSalesQuote();
      }
   }

   @When("they navigate to the bottom of the page")
   public void they_navigate_to_the_bottom_of_the_page()
   {
      Selenide.executeJavaScript("window.scrollBy(0,document.body.scrollHeight)");
   }

   @Then("they can see the link to \"Create quote\"")
   public void they_can_see_the_link_to_create_quote() throws InterruptedException
   {
      assertTrue("\"Create quote\" link is not displayed",
               salesQuoteComponent.getCreateQuoteLink().isDisplayed());
   }

   @Then("this will appear beneath the \"Continue\" CTA")
   public void this_will_appear_beneath_the_continue_cta()
   {
      SelenideElement continueButton = retailPassengerDetailsPage.getContinueButton();
      SelenideElement createQuoteLink = salesQuoteComponent.getCreateQuoteLink();

      int continueButtonBottomY =
               continueButton.getLocation().getY() + continueButton.getSize().getHeight();
      int createQuoteLinkTopY = createQuoteLink.getLocation().getY();
      assertTrue("The createQuoteLink is not placed under the continueButton",
               createQuoteLinkTopY >= continueButtonBottomY);
   }

   @When("they click on the \"Create quote\" link")
   public void they_click_on_the_create_quote_link()
   {
      salesQuoteComponent.getCreateQuoteLink().click();
   }

   @When("they have clicked the link to \"Create quote\"")
   public void they_have_clicked_the_link_to_create_quote()
   {
      salesQuoteComponent.getCreateQuoteLink().click();
   }

   @Then("show the 'Oops, change the above {int} field\\(s\\) again' message")
   public void show_the_oops_change_the_above_fields_again_message(Integer _unused)
   {
      SelenideElement formValidationErrorElement =
               retailPassengerDetailsPage.getPaxScrollToErrorComponentAlert();

      assertTrue("Passenger Details form validation error is not visible",
               formValidationErrorElement.isDisplayed());

      LOGGER
               .log("Passenger Details form validation error: " + formValidationErrorElement.getText());

      assertTrue("Passenger Details form validation error is empty",
               formValidationErrorElement.$(".alerts__alertText").getText().length() > 0);
   }

   @Then("the modal will be shown")
   public void the_modal_will_be_shown()
   {
      assertTrue("Sales Quote modal is not displayed", salesQuoteComponent.getSalesQuoteModal()
               .should(appear, Duration.ofSeconds(30)).isDisplayed());
   }

   @Then("the modal contains 'Handling fee' as title")
   public void the_modal_contains_handling_fee_as_title()
   {
      SelenideElement modalTitle = salesQuoteComponent.getSalesQuoteModalTitle();

      assertTrue("Sales Quote modal Title is not displayed", modalTitle.isDisplayed());

      LOGGER.log("Sales Quote modal Title: " + modalTitle.getText());

      assertTrue("Sales Quote modal Title is empty", modalTitle.getText().length() > 0);
   }

   @Then("the modal contains a dropdown field for 'Cost Type'")
   public void the_modal_contains_a_dropdown_field_for_cost_type()
   {
      WebElement selectElementWrapper =
               salesQuoteComponent.getSalesQuoteCostTypeFieldWrapperById(1);

      assertTrue("'Cost Type' field is not displayed", selectElementWrapper.isDisplayed());
   }

   @Then("the modal contains a numeric field for 'Sum'")
   public void the_modal_contains_a_numeric_field_for_sum()
   {
      assertTrue("'Sum' field is not displayed",
               salesQuoteComponent.getSalesQuoteSumFieldById(1).isDisplayed());
   }

   @Then("the modal contains a free text field for 'Notes'")
   public void the_modal_contains_a_free_text_field_for_notes()
   {
      assertTrue("'Notes' field is not displayed",
               salesQuoteComponent.getSalesQuoteNotesFieldById(1).isDisplayed());
   }

   @Then("the modal contains an 'Add rate' link with icon")
   public void the_modal_contains_an_add_rate_link_with_icon()
   {
      assertTrue("'Add rate' link is not displayed",
               salesQuoteComponent.getSalesQuoteAddRateLink().isDisplayed());

      assertTrue("'Add rate' link does not have an icon",
               salesQuoteComponent.getSalesQuoteAddRateLink().$("svg").isDisplayed());
   }

   @Then("the modal contains a 'Delete' link with icon")
   public void the_modal_contains_a_delete_link_with_icon()
   {
      assertTrue("'Delete' link is not displayed",
               salesQuoteComponent.getSalesQuoteDeleteRateLinkById(1).isDisplayed());

      assertTrue("'Delete' link does not have an icon",
               salesQuoteComponent.getSalesQuoteDeleteRateLinkById(1).$("svg").isDisplayed());
   }

   @Then("the modal contains a 'Save as PDF' CTA")
   public void the_modal_contains_a_save_as_pdf_cta()
   {
      assertTrue("'Save as PDF' button is not displayed",
               salesQuoteComponent.getSalesQuoteSaveAsPDFButton().isDisplayed());
   }

   @When("they fill the fee section")
   public void they_fill_the_fee_section()
   {
      salesQuoteComponent.fillSalesQuoteFeeSectionByIndex(1);
   }

   @When("they click on the 'Delete' link")
   public void they_click_on_the_delete_link()
   {
      salesQuoteComponent.getSalesQuoteDeleteRateLinkById(1).click();
   }

   @Then("the fees section will be deleted")
   public void the_fees_section_will_be_deleted()
   {
      assertTrue("Sales Quote fee section is not deleted",
               salesQuoteComponent.isSalesQuoteFeeSectionDeletedByIndex(1));
   }

   @Then("they will be able to see default fields")
   public void they_will_be_able_to_see_default_fields()
   {
      assertFalse("There are no default fields",
               salesQuoteComponent.getSalesQuoteFeeSections().isEmpty());
   }

   @Then("they click on the 'Add rate' link")
   public void they_click_on_the_add_rate_link()
   {
      salesQuoteComponent.getAddRateLink().click();
   }

   @Then("a new row will be created for the Agent to add another Handling fee")
   public void a_new_row_will_be_created_for_the_agent_to_add_another_handling_fee()
   {
      assertTrue("The new fee row is not created",
               salesQuoteComponent.getSalesQuoteFeeSections().get(1).isDisplayed());
   }

   @Then("they will be see delete link with icon will appear on top corner")
   public void they_will_be_see_delete_link_with_icon_will_appear_on_top_corner()
   {
      assertTrue("The delete link is not displayed",
               salesQuoteComponent.getSalesQuoteDeleteRateLinkById(2).isDisplayed());
   }

   @When("they click on the 'Save as PDF' CTA")
   public void they_click_on_the_save_as_pdf_cta()
   {
      salesQuoteComponent.getSalesQuoteSaveAsPDFButton().click();
   }

   @Then("the dropdown should contain 'Handling fee' value")
   public void the_dropdown_should_contain_handling_fee_value()
   {
      LOGGER.log("[Manual] Sales Quote dropdown should have \"Handling fee\" value");

      Select dropdown = new Select(salesQuoteComponent.getSalesQuoteCostTypeFieldById(1));

      List<WebElement> options = dropdown.getOptions();

      LOGGER.log("[Manual] Sales Quote dropdown values");

      for (WebElement option : options)
      {
         LOGGER.log(option.getText());
      }

      assertTrue("Sales Quote dropdown does not have \"Handling fee\" value", options.size() > 1);
   }

   @Given("they have not entered required data")
   public void they_have_not_entered_required_data()
   {
      assertEquals("The sales quote cost type filed is not empty", "",
               salesQuoteComponent.getSalesQuoteCostTypeFieldById(1).getValue());
      assertEquals("The sales quote sum filed is not empty", "",
               salesQuoteComponent.getSalesQuoteSumFieldById(1).getAttribute("value"));
      assertEquals("The sales quote notes filed is not empty", "",
               salesQuoteComponent.getSalesQuoteNotesFieldById(1).getAttribute("value"));
   }

   @Then("they will see the inputs highlighted in red with appropriate error messages")
   public void they_will_see_the_inputs_highlighted_in_red_with_appropriate_error_messages()
   {
      assertTrue("'Cost Type' field is not highlighted",
               salesQuoteComponent.getSalesQuoteCostTypeFieldWrapperById(1)
                        .$(By.cssSelector(".inputs__selectList.inputs__error")).isDisplayed());

      assertFalse("'Cost Type' dropdown does not have a supportive error message",
               salesQuoteComponent.getSalesQuoteCostTypeFieldWrapperById(1)
                        .$(By.cssSelector(".inputs__selectList .inputs__errorMessage")).getText()
                        .isEmpty());

      assertTrue("'Sum' field is not highlighted",
               salesQuoteComponent.getSalesQuoteSumFieldById(1).has(cssClass("inputs__error")));

      assertFalse("'Sum' field does not have a supportive error message",
               salesQuoteComponent.getSalesQuoteSumFieldWrapperById(1)
                        .$(By.cssSelector(".inputs__errorMessage")).getText().isEmpty());

      assertTrue("'Notes' field is not highlighted",
               salesQuoteComponent.getSalesQuoteNotesFieldById(1).has(cssClass("TextArea__error")));

      assertFalse("'Notes' field does not have a supportive error message",
               salesQuoteComponent.getSalesQuoteNotesFieldWrapperById(1)
                        .$(By.cssSelector(".TextArea__errorMessage")).getText().isEmpty());
   }

   private boolean isExecutedLocally()
   {
      TestExecutionParams execParams = ExecParams.getTestExecutionParams();
      return StringUtils.containsIgnoreCase(execParams.getUrlStr(), "localhost");
   }
}
