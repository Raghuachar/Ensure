package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class PackageUpdateBankingModelStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents;

   public PackageUpdateBankingModelStepDefs()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      foReconcilationPaymentPageComponents = new FOReconcilationPaymentPageComponents();
   }

   @When("they click the link to Update banking")
   public void they_click_the_link_to_Update_banking()
   {
      pKgReconcilationPaymentPageComponents.clickOnUpdateBankingLink();
   }

   @Then("the Update banking modal will open on the screen")
   public void the_Update_banking_modal_will_open_on_the_screen()
   {
      assertThat("Update banking model opened",
               pKgReconcilationPaymentPageComponents.isUpdateBankingModelOpened(), is(true));
   }

   @Then("will display the following information")
   public void will_display_the_following_information(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Update banking title displayed",
               pKgReconcilationPaymentPageComponents.isUpdateBankingTitleDisplayed(), is(true));
      assertThat("Payment method title displayed",
               pKgReconcilationPaymentPageComponents.isPaymentMethodTitleDisplayed(), is(true));
      assertThat("Banking amount title and box displayed",
               pKgReconcilationPaymentPageComponents.isBankingAmountBoxDisplayed(), is(true));
      assertThat("Seal bag number title and box displayed",
               pKgReconcilationPaymentPageComponents.isSealBagNumberBoxDisplayed(), is(true));
      assertThat("Save icon displayed", pKgReconcilationPaymentPageComponents.isSaveIconDisplayed(),
               is(true));
      assertThat("Cancel CTA button displayed",
               pKgReconcilationPaymentPageComponents.isCancelCTADisplayed(), is(true));
   }

   @Given("that the Agent is viewing the update banking modal")
   public void that_the_Agent_is_viewing_the_update_banking_modal()
   {
      packagenavigation.retailLoginChangeagent();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pKgReconcilationPaymentPageComponents.clickOnUpdateBankingLink();
      assertThat("Update banking model opened",
               pKgReconcilationPaymentPageComponents.isUpdateBankingModelOpened(), is(true));
   }

   @When("they click the CANCEL CTA")
   public void they_click_the_CANCEL_CTA()
   {
      pKgReconcilationPaymentPageComponents.isCancelCTADisplayed();
      pKgReconcilationPaymentPageComponents.clickOnCancelCTA();
   }

   @And("they click the CLOSE CTA")
   public void they_click_the_CLOSE_CTA()
   {
      pKgReconcilationPaymentPageComponents.clickOnCLoseCTA();
   }

   @When("they view the CTA at the bottom of the modal")
   public void they_view_the_CTA_at_the_bottom_of_the_modal()
   {
      assertTrue("CTA at bottom was not displayed",
               pKgReconcilationPaymentPageComponents.isCTAAtBottomDisplayed());
   }

   @And("they can see it shows {string} instead of {string}")
   public void they_can_see_it_shows_CLOSE_instead_of_CANCEL(String strClose, String strCancel)
   {
      assertTrue("Close should have been displayed",
               pKgReconcilationPaymentPageComponents.isCloseCTADisplayed());
   }

   @Then("the update banking modal will close and no changes will be saved")
   public void the_update_banking_modal_will_close_and_no_changes_will_be_saved()
   {
      assertFalse("Update banking model closed",
               pKgReconcilationPaymentPageComponents.isUpdateBankingModelOpened());
   }

   @Then("the update banking modal will close")
   public void the_update_banking_modal_will_close()
   {
      assertThat("Update banking model closed",
               pKgReconcilationPaymentPageComponents.isUpdateBankingModelOpened(), is(false));
   }

   @Then("no changes will have been made to the reconciliation table")
   public void no_changes_will_have_been_made_to_the_reconciliation_table()
   {
      wait.forJSExecutionReadyLazy();
      assertThat(" Global Header is not present",
               foReconcilationPaymentPageComponents.isReconcilationTablePresent(), is(true));
   }
}
