package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageExpandCollapseForReasonDropdownStepDefs
{

   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageExpandCollapseForReasonDropdownStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent has pressed the SUBMIT CTA on the authorize discrepancy modal")
   public void that_the_agent_has_pressed_the_SUBMIT_CTA_on_the_authorize_discrepancy_modal()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pKgReconcilationPaymentPageComponents.selectReasonSelectBoxOption();
      pKgReconcilationPaymentPageComponents.enterRegionTextSubmitRegionModal();
      wait.forJSExecutionReadyLazy();
   }

   @When("they view the payment type accordion on the banking and reconciliation page")
   public void they_view_the_payment_type_accordion_on_the_banking_and_reconciliation_page()
   {
      assertThat("Payment Method Accordion is present",
               pKgReconcilationPaymentPageComponents.isPaymentMethodTypeAccordion(), is(true));

   }

   @Then("they can see the information within the reason column")
   public void they_can_see_the_information_within_the_reason_column(
            io.cucumber.datatable.DataTable dataTable)
   {
      wait.forJSExecutionReadyLazy();
      assertThat("Reason Detail Content is present",
               pKgReconcilationPaymentPageComponents.isReasonDetailContent(), is(true));
      assertThat("Show more or Hide details Expand and collapse is present",
               pKgReconcilationPaymentPageComponents.isShowReasonDetailLinkPresent(), is(true));
      assertThat("Reason type is present",
               pKgReconcilationPaymentPageComponents.isReasonTypeAdded(), is(true));
   }

   @Given("that the agent has pressed the show more expand and collapse")
   public void that_the_agent_has_pressed_the_show_more_expand_and_collapse()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pKgReconcilationPaymentPageComponents.selectReasonSelectBoxOption();
      pKgReconcilationPaymentPageComponents.enterRegionTextSubmitRegionModal();
      pKgReconcilationPaymentPageComponents.clickShowReasonDetailLink();
   }

   @Given("the notes that were entered are displayed")
   public void the_notes_that_were_entered_are_displayed()
   {
      assertThat("Reason content is present",
               pKgReconcilationPaymentPageComponents.isRegionContentPresent(), is(true));
   }

   @When("they press the hide details expand and collapse")
   public void they_press_the_hide_details_expand_and_collapse()
   {
      assertThat("Hide details or Hide details Expand and collapse is present",
               pKgReconcilationPaymentPageComponents.isHideReasonDetailLinkPresent(), is(true));
      pKgReconcilationPaymentPageComponents.clickHideReasonDetailLink();
   }

   @Then("the notes will hide and the text will change back to show more")
   public void the_notes_will_hide_and_the_text_will_change_back_to_show_more()
   {
      assertThat("Show more or Hide details Expand and collapse is present",
               pKgReconcilationPaymentPageComponents.isShowReasonDetailLinkPresent(), is(true));
   }
}
