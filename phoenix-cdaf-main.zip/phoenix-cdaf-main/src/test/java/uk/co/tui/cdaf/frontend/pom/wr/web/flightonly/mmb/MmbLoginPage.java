package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.mmb;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.ConfirmationPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.BookingAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import javax.annotation.Nonnull;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;

public class MmbLoginPage extends AbstractPage
{
   private final SearchPanelComponent searchPanelComponent;

   private final WebDriverUtils utils;

   private final PageErrorHandler errorHandler;

   private final ConfirmationPage confirmationPage;

   private final FlightOnlyPageNavigation flightOnlyPageNavigation;

   private final WebElementWait wait;

   private BookingAttributes testData;

   @FindAll({ @FindBy(css = "[id*= 'AmendDepartureDate']"),
            @FindBy(css = "[data-dojo-type*= 'AmendDepartureDate']"),
            @FindBy(xpath = "//div[@class='react-datepicker-wrapper']") })
   private WebElement departureDateField;

   @FindAll({ @FindBy(css = ".calendar select"),
            @FindBy(css = ".react-datepicker__month-year-select") })
   private WebElement departureDateMonthOptions;

   public MmbLoginPage()
   {
      errorHandler = new PageErrorHandler();
      wait = new WebElementWait();
      searchPanelComponent = new SearchPanelComponent();
      confirmationPage = new ConfirmationPage();
      utils = new WebDriverUtils();
      flightOnlyPageNavigation = new FlightOnlyPageNavigation();
   }

   private static void verifyCorrectDateWasSelected(String month, String date)
   {
      String expectedDate = LocalDate.parse(String.format("%02d %s", Integer.parseInt(date), month),
                        DateTimeFormatter.ofPattern("dd MMMM yyyy"))
               .format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
      String actualDate = $("#departureDate")
               .should(Condition.not(Condition.empty)).getValue();
      assertThat("Incorrect date was set:\n", actualDate, equalTo(expectedDate));
   }

   private static void clickOnAvailableDay(String month, String date, ElementsCollection els)
   {
      els.asFixedIterable().stream()
               .filter(dateValue -> !Objects.requireNonNull(dateValue.getAttribute("class"))
                        .contains("react-datepicker__day--outside-month"))
               .filter(dateValue -> !Objects.requireNonNull(dateValue.getAttribute("class"))
                        .contains("react-datepicker__day--disabled"))
               .filter(dateValue -> dateValue.getText().equals(date))
               .findFirst()
               .orElseThrow(() -> new NoSuchElementException("Date " + date + " "
                        + month + " was not found or unavaliable for selection"))
               .click();
   }

   @Nonnull
   private static SelenideElement getMmbLoginContainer()
   {
      SelenideElement mmbLogin = $("section.UI__mmbLoginPage");
      SelenideElement mmbLoginMfe = $("section.UI__retailMMBLoginMfe");

      return mmbLogin.exists() ? mmbLogin : mmbLoginMfe;
   }

   public void enterBookingReferenceNumber(String bookingReferenceNumber)
   {
      getBookingRefFieldB2C().setValue(bookingReferenceNumber);
   }

   public void enterLeadPaxLastName(String passengerLastName)
   {
      $("input[name='surname']").setValue(passengerLastName);
   }

   public void enterDepartureDate(String month, String date)
   {
      $(departureDateField).click();
      $(departureDateMonthOptions).selectOption(month);
      String formattedDayNumber = String.format("%03d", Integer.parseInt(date));

      ElementsCollection departureOptionElements =
               $$(".react-datepicker__day--" + formattedDayNumber);
      departureOptionElements.first().should(Condition.appear);
      assertThat("No available dates were found", departureOptionElements.size(),
               greaterThan(0));

      clickOnAvailableDay(month, date, departureOptionElements);
      verifyCorrectDateWasSelected(month, date);
   }

   public void doLogin()
   {
      SelenideElement loginBtn = getMmbLoginContainer().$("button.buttons__primary");
      loginBtn.should(Condition.visible).click();
      BrowserCookies.closePrivacyPopUp();
      loginBtn.should(Condition.disappear, Duration.ofSeconds(60));
   }

   public SelenideElement getBookingRefFieldB2C()
   {
      return $("input[name='bookingReferenceId']").should(Condition.appear, Duration.ofSeconds(15));
   }

   public void retrieveBooking(String applicationurl, String bookingRefNum, String depMonthYear,
            String depDate, String lName)
   {
      WebDriverUtils.getDriver().navigate().to(applicationurl);
      wait.forComplexPageLoad();
      enterBookingReferenceNumber(bookingRefNum);
      enterDepartureDate(depMonthYear, depDate);
      enterLeadPaxLastName(lName);
      doLogin();
      wait.forJSExecutionReadyLazy();
   }

}
