package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.SearchResultsCardComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class DestinationFilterComponent extends AbstractPage
{
   public static final String NEW_LINE = "\n";

   public final SearchResultsComponent searchResultComponent;

   public final SearchResultsFiltersComponent searchResultsFiltersComponent;

   public final SearchPanelComponent searchPanelComponent;

   public final WebElementWait wait;

   @FindBy(css = ".Destination__destinationWrapper")
   public WebElement destinationFilter;

   @FindBy(css = ".Destination__region")
   public List<WebElement> destination;

   @FindBy(css = ".FilterPanel__filterPanelWrapper .FilterPanel__desktop ul li a[aria-label*='destination']")
   public WebElement mobileDestinationFilter;

   @FindBy(css = ".Destination__notChecked")
   public WebElement unselectFilter;

   @FindBy(css = ".Destination__filterTitle li[aria-label*=destination name filter] input:checked+span+span")
   public WebElement country;

   @FindBy(css = ".Destination__checked input[type='checkbox'][checked] + .inputs__box")
   public WebElement selectDestination;

   @FindBy(css = ".Destination__regionListContainer .Destination__checked")
   public WebElement mobileSelectDestination;

   @FindBy(css = ".Destination__destinationWrapper .BoardBasis__clearLink")
   public WebElement clearFilters;

   @FindAll({
            @FindBy(css = ".inputs__checkBox undefined li[aria-label*='checkbox'] input:disabled") })
   public List<WebElement> greyed;

   @FindBy(css = ".Destination__region input:not(:checked)+.inputs__box")
   public List<WebElement> destinationsRegion;

   @FindBy(css = ".DropModal__filterDropModal DropModal__filterOverlay DropModal__open")
   public WebElement modal;

   @FindBy(css = ".Destination__region input:checked+span+span")
   public WebElement selectedDestination;

   @FindBy(css = ".Destination__region input:checked+span+span")
   public WebElement deselectedDestination;

   @FindBy(css = ".DropModal__filterDropdown .DropModal__dropModalContent .DropModal__close")
   public WebElement xWindow;

   @FindBy(css = ".DropModal__dropModalContent:nth-child(1) .DropModal__footerContainer")
   public WebElement applyButton;

   @FindBy(css = "div[aria-label*='tui Product Card component'] .UnitCard__unitCard .UnitCard__locationInfo, div[aria-label*='tui Product Card component'] .ResultsListItem__location span")
   public List<WebElement> resultsListLocationInfo;

   @FindBy(css = ".DropModal__filterModal .DropModal__clear")
   public WebElement clearAllFilter;

   @FindBy(css = ".Destination__region input:checked+span+span > span.Destination__count")
   public WebElement destinationCount;

   @FindBy(xpath = "//div//span[text()='Spanje']")
   public WebElement countryFilter;

   public WebDriverUtils utils;

   public String filterValue;

   public String actual = StringUtils.EMPTY;

   public String expected = StringUtils.EMPTY;

   protected SearchResultsCardComponent searchCardComponent;

   @FindBy(css = "[class='Destination__showMore']")
   private WebElement destinationShowMore;

   @FindBy(css = ".Destination__region input +span+span > span.Destination__count")
   private List<WebElement> regionOptions;

   @FindBy(css = "[class='ResultListItemV2__location']")
   private List<WebElement> searchCardsDestinations;

   public DestinationFilterComponent()
   {
      searchCardComponent = new SearchResultsCardComponent();
      searchResultComponent = new SearchResultsComponent();
      searchPanelComponent = new SearchPanelComponent();
      wait = new WebElementWait();
      searchResultsFiltersComponent = new SearchResultsFiltersComponent();

   }

   public boolean isDestinationFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(destinationFilter);
   }

   public boolean disabledDestination()
   {
      return !greyed.isEmpty();
   }

   public void clearAllFilter()
   {
      wait.forJSExecutionReadyLazy();

      WebElementTools.click(clearAllFilter);
   }

   public boolean isClearAllFilter()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(clearAllFilter);
   }

   public boolean elementIsDisplayed()
   {
      try
      {
         return WebElementTools.isPresent(destination.get(0));
      }
      catch (Exception e)
      {
         return false;
      }
   }

   public boolean verifyFilteredResults()
   {

      return verifyFilteredResultsLocation();
   }

   public boolean verifyFilteredResultsLocation()
   {
      boolean destinationNotMatch = false;
      wait.forJSExecutionReadyLazy();
      String destination = getSelectedDestinations().getText().toLowerCase();

      wait.forJSExecutionReadyLazy();
      WebElementTools.click(xWindow);

      for (WebElement locationInfo : resultsListLocationInfo)
      {
         String locationStr = locationInfo.getText().toLowerCase();
         if (!locationStr.contains(destination))
         {
            destinationNotMatch = true;
         }
      }
      return !destinationNotMatch;
   }

   public boolean closeModal(String component)
   {
      wait.forJSExecutionReadyLazy();
      if (StringUtils.containsIgnoreCase(component, "x"))
      {
         return WebElementTools.isPresent(xWindow);
      }
      else if (StringUtils.containsIgnoreCase(component, "Apply"))
      {
         return WebElementTools.isPresent(applyButton);
      }
      else
      {
         return false;
      }
   }

   public void selectDestinationFilter()
   {
      wait.waitForElementToBePresent(destinationFilter);
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(0, 0);
      WebElementTools.click(destinationFilter);
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(0, 0);

   }

   public boolean verifyFilterClosing(String component)
   {
      return closeModal(component);
   }

   public void setFilterValue(String filterValue)
   {
      this.filterValue = filterValue;
   }

   public boolean isFilterUnselected()
   {
      return WebElementTools.isPresent(unselectFilter);
   }

   public boolean isModalShown()
   {
      return WebElementTools.isPresent(modal);
   }

   public void selectMobileDestinationFilter()
   {
      wait.forJSExecutionReadyLazy();

      WebElementTools.click(mobileSelectDestination);
   }

   public boolean isDestinationDisplayed()
   {
      return WebElementTools.isPresent(destination.get(0));
   }

   public WebElement getCountry()
   {
      return country;
   }

   public WebElement getSelectedDestinations()
   {
      List<WebElement> selectedDestination = getDriver().findElements(By.xpath(
               "(//div[@class='DropModal__dropModalContent']//div[@class='Destination__filterTitle']//span[@class='inputs__text']//span)"));
      return selectedDestination.get(0);
   }

   public String getSelectedDestination()
   {
      try
      {
         return WebElementTools.getElementText(selectedDestination).replaceAll("\\(\\d+\\)", "")
                  .trim();
      }
      catch (Exception e)
      {
         return StringUtils.EMPTY;
      }
   }

   public void selectDestination()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(destinationFilter);
   }

   public boolean isClearFilterLinkDisplayed()
   {
      return WebElementTools.isPresent(clearFilters);
   }

   public void isClearFilterLinkClicked()
   {
      WebElementTools.click(clearFilters);
   }

   public String getActual()
   {
      return actual;
   }

   public void setActual(String actual)
   {
      this.actual = actual;
   }

   public String getExpected()
   {
      return expected;
   }

   public void setExpected(String expected)
   {
      this.expected = expected;
   }

   public boolean searchResultDestinationVerification()
   {
      wait.forJSExecutionReadyLazy();
      final List<WebElement> locationElements = searchCardComponent.getLocation();
      setExpected(filterValue);
      for (WebElement element : locationElements)
      {
         try
         {
            String location = WebElementTools.getElementText(element).trim();
            filterValue = StringUtils.substringBefore(filterValue, "(").trim();
            if (!StringUtils.containsIgnoreCase(location, filterValue))
            {
               setActual(location);
               return false;
            }
         }
         catch (Exception e)
         {
            return false;
         }
      }
      return true;
   }

   public void clickOnChildDestination()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.javaScriptScrollToElement(destination.get(0));
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(destination.get(0));

   }

   public boolean verifyFilterSelectedDestination()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(selectedDestination);
   }

   public boolean verifyDestinationCount()
   {
      return WebElementTools.isPresent(destinationCount);
   }

   public boolean verifyCountryLevelFilter()
   {

      return !WebElementTools.isPresent(countryFilter);
   }

   public void clickOnDestinationShowMore()
   {
      $(destinationShowMore).scrollTo().click();
   }

   public void selectRegionOption()
   {
      ElementsCollection regionOptions =
               $$(".Destination__region input +span+span > span.Destination__count");
      regionOptions.first().should(Condition.appear);
      for (SelenideElement option : regionOptions)
      {
         String optionText = option.getText();
         String numericPart = optionText.replaceAll("[^0-9]", "");
         int optionCount = Integer.parseInt(numericPart);
         if (optionCount < 3)
         {
            option.click();
            break;
         }
      }
   }

   public boolean verifySelectedFilterOption()
   {
      return $(selectDestination).should(Condition.appear).isDisplayed();
   }

   public List<String> getDestinationsInSearchCard()
   {
      return $$(searchCardsDestinations).asFixedIterable().stream().map(WebElement::getText)
               .map(destinationText -> destinationText.split(",")[1].trim())
               .collect(Collectors.toList());
   }

   public boolean isCheckboxUnSelected()
   {
      return unselectFilter.isDisplayed();
   }
}
