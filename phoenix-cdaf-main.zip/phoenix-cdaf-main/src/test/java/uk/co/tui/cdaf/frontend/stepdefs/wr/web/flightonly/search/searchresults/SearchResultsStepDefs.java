package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults.SearchResults;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ConfigurationConstants;
import uk.co.tui.cdaf.utils.ConfigurationService;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.open;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class SearchResultsStepDefs
{

   private final String datePattern = "\\w* \\d*\\w* \\w*";

   private final SearchResults searchresults;

   private final FlightOnlyPageNavigation foNavigation;

   private final WebElementWait wait;

   private String outboundCarousalFirstDate;

   private String outboundSelectedDate;

   private String outboundSelectedDateHeader;

   private String returnCarousalFirstDate;

   private String returnSelectedDate;

   private String returnSelectedDateHeader;

   private String currentUrl;

   public SearchResultsStepDefs()
   {
      searchresults = new SearchResults();
      foNavigation = new FlightOnlyPageNavigation();
      wait = new WebElementWait();
   }

   @Given("a {string} is on the TUI fly search results page")
   public void a_is_on_the_TUI_fly_search_results_page(String string)
   {
      foNavigation.navigateToSearchResultPage();
      foNavigation.availableSearchResults();
   }

   @Given("that a {string} is on the TUI fly search results page")
   public void that_a_is_on_the_TUI_fly_search_results_page(String string)
   {
      foNavigation.navigateToSearchResults();
   }

   @Given("search results are available")
   public void search_results_are_available()
   {
      assertThat("Search Results are not displayed", searchresults.isOutboundSearchResultsPresent(),
               is(true));
   }

   @When("they view the top of the TUI fly search results page")
   public void they_view_the_top_of_the_TUI_fly_search_results_page()
   {
      searchresults.viewSearchResultsPage();
   }

   @Then("the following Page Title will be visible in searchresults page:")
   public void the_following_Page_Title_will_be_visible(String flightFromText)
   {
      String headerPattern = "Flights from .+? To .+?";
      boolean returnValue = searchresults.checkHeaderText(headerPattern);
      assertThat("Header in Searchresults page is not matching",
               searchresults.checkHeaderText(headerPattern), is(true));
   }

   @Then("below the Page title the following text will be visible in searchresults page:")
   public void below_the_Page_title_the_following_text_will_be_visible(String flightFromText)
   {
      assertThat("Checkbox text in Searchresults page is not matching",
               searchresults.checkCheckBoxText(flightFromText), is(true));

   }

   @Then("the check box will be auto ticked")
   public void the_check_box_will_be_auto_ticked()
   {
      assertThat("Checkbox tick in Searchresults page is ticked", searchresults.isTickPresent(),
               is(true));
   }

   @When("they view the TUI fly search results page")
   public void they_view_the_TUI_fly_search_results_page()
   {
      searchresults.viewSearchResultsPage();
   }

   @Then("I will see a Date Carousel for my Outbound Flight")
   public void i_will_see_a_Date_Carousel_for_my_Outbound_Flight()
   {
      assertThat("Outbound carousal not present", searchresults.isOutboundCarousalPresent(),
               is(true));
   }

   @Then("the title {string} will display above the Carousel")
   public void the_title_OUTBOUND_will_display_above_the_Carousel(String label)
   {
      assertThat("Outbound heading not present", searchresults.isOutboundCarousalPresent(),
               is(true));
   }

   @Then("the Date Carousel will display {int} dates")
   public void the_Date_Carousel_will_display_dates(Integer ndays)
   {
      assertThat(ndays + " dates are not present in Outbound carousal",
               searchresults.checkNOutboundDates(ndays), is(true));
   }

   @Then("my default date will be in the Centre of the carousel and highlighted")
   public void my_default_date_will_be_in_the_Centre_of_the_carousel_and_highlighted()
   {
      assertThat("Outbound selected date not in Centre",
               searchresults.isOutboundSelectedDateInCentre(), is(true));
   }

   @Then("the Date and price will be visible for each date in the carousel where a flight is available")
   public void the_Date_and_price_will_be_visible_for_each_date_in_the_carousel_where_a_flight_is_available()
   {
      assertThat("Outbound Date and Price are not visible",
               searchresults.outboundDatePriceVisible(), is(true));
   }

   @Then("the Date and “No flights” will be visible for each date in the carousel where a flight is not available")
   public void the_Date_and_No_flights_will_be_visible_for_each_date_in_the_carousel_where_a_flight_is_not_available()
   {
      assertThat("Outbound Date and Price are visible for disabled",
               searchresults.outboundDisabledDatePriceVisible(), is(true));
   }

   @Then("left and right navigational arrows will be visible")
   public void left_and_right_navigational_arrows_will_be_visible()
   {
      assertThat("Navigation Arrow for Outbound not present",
               searchresults.isOutboundCarousalNavigationArrowsPresent(), is(true));
   }

   @Then("I will see a Date Carousel for my Return Flight")
   public void i_will_see_a_Date_Carousel_for_my_Return_Flight()
   {
      assertThat("Return carousal not present", searchresults.isReturnCarousalPresent(), is(true));
   }

   @Then("the title {string} will display above the Return Carousel")
   public void the_title_RETURN_will_display_above_the_Carousel(String headerText)
   {
      assertThat("Return heading not present", searchresults.isReturnCarousalPresent(), is(true));
   }

   @Then("the Date Carousel will display {int} dates for my Return Flight")
   public void the_Date_Carousel_will_display_dates_for_my_Return_Flight(Integer ndays)
   {
      assertThat(ndays + " dates are not present in Return carousal",
               searchresults.checkNReturnDates(ndays), is(true));
   }

   @Then("my default date will be in the Centre of the carousel and highlighted for my Return Flight")
   public void my_default_date_will_be_in_the_Centre_of_the_carousel_and_highlighted_for_my_Return_Flight()
   {
      assertThat("Return selected date not in Centre", searchresults.isReturnSelectedDateInCentre(),
               is(true));
   }

   @Then("the Date and price will be visible for each date in the carousel where a flight is available for my Return Flight")
   public void the_Date_and_price_will_be_visible_for_each_date_in_the_carousel_where_a_flight_is_available_for_my_Return_Flight()
   {
      assertThat("Return Date and Price are not visible", searchresults.returnDatePriceVisible(),
               is(true));
   }

   @Then("the Date and “No flights” will be visible for each date in the carousel where a flight is not available for my Return Flight")
   public void the_Date_and_No_flights_will_be_visible_for_each_date_in_the_carousel_where_a_flight_is_not_available_for_my_Return_Flight()
   {
      assertThat("Return Date and Price are visible for disabled",
               searchresults.returnDisabledDatePriceVisible(), is(true));
   }

   @Then("left and right navigational arrows will be visible for my Return Flight")
   public void left_and_right_navigational_arrows_will_be_visible_for_my_Return_Flight()
   {
      assertThat("Navigation Arrow for Return not present",
               searchresults.isReturnCarousalNavigationArrowsPresent(), is(true));
   }

   @When("they view the outbound search results cards")
   public void they_view_the_outbound_search_results_cards()
   {
      searchresults.viewOutboundSearchCards();
   }

   @Then("the outbound search results cards will be displayed below the OUTBOUND dates carousel")
   public void the_outbound_search_results_cards_will_be_displayed_below_the_OUTBOUND_dates_carousel()
   {
      assertThat("Search Cards not present", searchresults.searchCardsBelowOutboundDate(),
               is(true));
   }

   @Then("the date the results are for will be displayed above the first outbound results card e.g. FRIDAY {int}th July")
   public void the_date_the_results_are_for_will_be_displayed_above_the_first_outbound_results_card_e_g_FRIDAY_th_July(
            Integer int1)
   {
      assertThat("Selected Outbound Date format not as per requirement",
               searchresults.checkOutboundDateFormat(datePattern), is(true));
   }

   @When("they view the return search results cards")
   public void they_view_the_return_search_results_cards()
   {
      searchresults.viewReturnSearchCards();
   }

   @Then("the return search results cards will be displayed below the RETURN dates carousel")
   public void the_return_search_results_cards_will_be_displayed_below_the_RETURN_dates_carousel()
   {
      assertThat("Search Cards not present below return date",
               searchresults.searchCardsBelowReturnDate(), is(true));
   }

   @Then("the date the results are for will be displayed above the first return results card e.g. FRIDAY {int}th July")
   public void the_date_the_results_are_for_will_be_displayed_above_the_first_return_results_card_e_g_FRIDAY_th_July(
            Integer int1)
   {
      assertThat("Selected Return Date format not as per requirement",
               searchresults.checkReturnDateFormat(datePattern), is(true));
   }

   @When("they view either an Inbound or Return card")
   public void they_view_either_an_Inbound_or_Return_card()
   {
      searchresults.viewOutboundSearchCards();
   }

   @Then("the following information will be displayed in the card:")
   public void the_following_information_will_be_displayed_in_the_card(List<String> components)
   {
      searchresults.setSearchComponentsMap();
      components.forEach(component ->
               assertThat(component + " componenet is not displayed", WebElementTools.isPresent(
                                 searchresults.getOutboundSearchCardComponentsMap().get(component)),
                        is(true)));
      components.forEach(component ->
               assertThat(component + " componenet is not displayed", WebElementTools
                                 .isPresent(searchresults.getReturnSearchCardComponentsMap().get(component)),
                        is(true)));
   }

   @Given("no flight has been selected")
   public void no_flight_has_been_selected()
   {
      searchresults.viewOutboundSearchCards();
   }

   @When("they view the summary panel")
   public void they_view_the_summary_panel()
   {
      searchresults.viewSummaryPanel();
   }

   @Then("the following will be displayed in summary panle in search results:")
   public void the_following_will_be_displayed_in_summary_panle_in_search_results(
            List<String> components)
   {
      searchresults.setSearchComponentsMap();
      components.forEach(component ->
               assertThat(component + " componenet is not displayed",
                        WebElementTools.isPresent(
                                 searchresults.getSummaryPanelMap().get(component)),
                        is(true)));
   }

   @Given("OUTBOUND search results are available before the departure dates displayed in the outbound carousel")
   public void outbound_search_results_are_available_before_the_departure_dates_displayed_in_the_outbound_carousel()
   {
      outboundCarousalFirstDate = searchresults.getFirstAvailableDateInOutboundCarousal();
      returnCarousalFirstDate = searchresults.getFirstAvailableDateInReturnCarousal();
      assertThat("Previous dates are not present",
               searchresults.isPrevDatesPresentOutboundCarousal(), is(true));
   }

   @When("I click on the left arrow on the OUTBOUND Carousel")
   public void i_click_on_the_left_arrow_on_the_OUTBOUND_Carousel()
   {
      searchresults.clickLeftArrow();
   }

   @Then("my options within the Carousel will update to display {int} day earlier")
   public void my_options_within_the_Carousel_will_update_to_display_day_earlier(Integer int1)
   {
      assertThat("Date is not changed after clicking left arrow",
               outboundCarousalFirstDate.equals(
                        searchresults.getFirstAvailableDateInOutboundCarousal()),
               is(false));
   }

   @Then("the same number of options will be displayed to me \\({int} desktop & {int} Mobile)")
   public void the_same_number_of_options_will_be_displayed_to_me_desktop_Mobile(Integer deskDays,
            Integer mobileDays)
   {
      if (StringUtils.equalsIgnoreCase(
               ConfigurationService.getProperty(ConfigurationConstants.SELENIUM_BROWSER),
               "chrome-mobile"))
      {
         assertThat(mobileDays + " dates are not present in Outbound carousal",
                  searchresults.checkNOutboundDates(mobileDays), is(true));
      }
      else
      {
         assertThat(deskDays + " dates are not present in Outbound carousal",
                  searchresults.checkNOutboundDates(deskDays), is(true));
      }

   }

   @Then("the RETURN carousel will remain unchanged")
   public void the_RETURN_carousel_will_remain_unchanged()
   {
      assertThat("Return Date is changed after clicking left arrow in Outbound",
               returnCarousalFirstDate.equals(
                        searchresults.getFirstAvailableDateInReturnCarousal()),
               is(true));
   }

   @Given("OUTBOUND search results are available after the departure dates displayed in the outbound carousel")
   public void outbound_search_results_are_available_after_the_departure_dates_displayed_in_the_outbound_carousel()
   {
      outboundCarousalFirstDate = searchresults.getFirstAvailableDateInOutboundCarousal();
      returnCarousalFirstDate = searchresults.getFirstAvailableDateInReturnCarousal();
      assertThat("Next dates are not present", searchresults.isAfterDatesPresentOutboundCarousal(),
               is(true));
   }

   @When("I click on the right arrow on the OUTBOUND Carousel")
   public void i_click_on_the_right_arrow_on_the_OUTBOUND_Carousel()
   {
      searchresults.clickRightArrow();
   }

   @Then("my options within the Carousel will update to display {int} day later")
   public void my_options_within_the_Carousel_will_update_to_display_day_later(Integer int1)
   {
      assertThat("Date is not changed after clicking left arrow",
               outboundCarousalFirstDate.equals(
                        searchresults.getFirstAvailableDateInOutboundCarousal()),
               is(false));
   }

   @Given("RETURN search results are available before the return dates displayed in the return carousel")
   public void return_search_results_are_available_before_the_return_dates_displayed_in_the_return_carousel()
   {
      outboundCarousalFirstDate = searchresults.getFirstAvailableDateInOutboundCarousal();
      returnCarousalFirstDate = searchresults.getFirstAvailableDateInReturnCarousal();
      assertThat("Prev dates are not present", searchresults.isPrevDatesPresentReturnCarousal(),
               is(true));
   }

   @When("I click on the left arrow on the RETURN Carousel")
   public void i_click_on_the_left_arrow_on_the_RETURN_Carousel()
   {
      searchresults.clickLeftArrowReturn();
   }

   @Then("my options within the Return Carousel will update to display {int} day earlier")
   public void my_options_within_the_Return_Carousel_will_update_to_display_day_earlier(
            Integer int1)
   {
      assertThat("Date is not changed after clicking left arrow",
               returnCarousalFirstDate.equals(
                        searchresults.getFirstAvailableDateInReturnCarousal()),
               is(false));
   }

   @Then("the same number of options will be displayed to me in Return Carousal\\({int} desktop & {int} Mobile)")
   public void the_same_number_of_options_will_be_displayed_to_me_in_Return_Carousal_desktop_Mobile(
            Integer deskDays, Integer mobileDays)
   {
      if (StringUtils.equalsIgnoreCase(
               ConfigurationService.getProperty(ConfigurationConstants.SELENIUM_BROWSER),
               "chrome-mobile"))
      {
         assertThat(mobileDays + " dates are not present in Outbound carousal",
                  searchresults.checkNReturnDates(mobileDays), is(true));
      }
      else
      {
         assertThat(deskDays + " dates are not present in Outbound carousal",
                  searchresults.checkNReturnDates(deskDays), is(true));
      }
   }

   @Then("the OUTBOUND carousel will remain unchanged")
   public void the_OUTBOUND_carousel_will_remain_unchanged()
   {
      assertThat("Outbound Date is changed after clicking left arrow in Outbound",
               outboundCarousalFirstDate.equals(
                        searchresults.getFirstAvailableDateInOutboundCarousal()),
               is(true));
   }

   @Then("my options within the Return Carousel will update to display {int} day later")
   public void my_options_within_the_Return_Carousel_will_update_to_display_day_later(Integer int1)
   {
      assertThat("Date is not changed after clicking left arrow",
               returnCarousalFirstDate.equals(
                        searchresults.getFirstAvailableDateInReturnCarousal()),
               is(false));
   }

   @Given("RETURN search results are available after the departure dates displayed in the outbound carousel")
   public void return_search_results_are_available_after_the_departure_dates_displayed_in_the_outbound_carousel()
   {
      outboundCarousalFirstDate = searchresults.getFirstAvailableDateInOutboundCarousal();
      returnCarousalFirstDate = searchresults.getFirstAvailableDateInReturnCarousal();
      assertThat("Prev dates are not present", searchresults.isAfterDatesPresentReturnCarousal(),
               is(true));
   }

   @When("I click on the right arrow on the RETURN Carousel")
   public void i_click_on_the_right_arrow_on_the_RETURN_Carousel()
   {
      searchresults.clickRightArrowReturn();
   }

   @Given("OUTBOUND search results are available for more than {int} date")
   public void outbound_search_results_are_available_for_more_than_date(Integer int1)
   {
      assertThat("Alternate Search dates are not available",
               searchresults.isOutboundAlternateDateAvailable(), is(true));
   }

   @When("I select another available date from the Outbound Carousel")
   public void i_select_another_available_date_from_the_Outbound_Carousel()
   {
      outboundSelectedDate = searchresults.getSelectedOutboundDate();
      outboundSelectedDateHeader = searchresults.getOutboundSelectedDateHeader();
      searchresults.selectAlternateOutboundDate();
   }

   @Then("the date I have selected will be highlighted in the Outbound Carousel")
   public void the_date_I_have_selected_will_be_highlighted_in_the_Outbound_Carousel()
   {
      assertThat("Alternate selected date is not highlighted", StringUtils.containsIgnoreCase(
               outboundSelectedDate, searchresults.getSelectedOutboundDate()), is(false));
   }

   @Then("the outbound search cards will update to display results for the new date I have selected")
   public void the_outbound_search_cards_will_update_to_display_results_for_the_new_date_I_have_selected()
   {
      assertThat("Search Cards are not displayed", searchresults.isOutboundSearchResultsPresent(),
               is(true));
   }

   @Then("the Title above the Outbound search results cards will update to reflect the new date I have selected")
   public void the_Title_above_the_Outbound_search_results_cards_will_update_to_reflect_the_new_date_I_have_selected()
   {
      assertThat("Date not updated below Outbound Carousal", StringUtils.containsIgnoreCase(
                        outboundSelectedDateHeader, searchresults.getOutboundSelectedDateHeader()),
               is(false));
   }

   @Given("RETURN search results are available for more than {int} date")
   public void return_search_results_are_available_for_more_than_date(Integer int1)
   {
      wait.forJSExecutionReadyLazy();
      returnSelectedDate = searchresults.getSelectedReturnDate();
      assertThat("Alternate Return Search dates are not available",
               searchresults.isReturnAlternateDateAvailable(), is(true));
   }

   @When("I select another available date from the Return Carousel")
   public void i_select_another_available_date_from_the_Return_Carousel()
   {
      returnSelectedDateHeader = searchresults.getReturnSelectedDateHeader();
      searchresults.selectAlternateReturnDate();
   }

   @Then("the date I have selected will be highlighted in the Return Carousel")
   public void the_date_I_have_selected_will_be_highlighted_in_the_Return_Carousel()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("Alternate selected return date is not highlighted",
               StringUtils.containsIgnoreCase(returnSelectedDate,
                        searchresults.getSelectedReturnDate()),
               is(false));
   }

   @Then("the return search cards will update to display results for the new date I have selected")
   public void the_return_search_cards_will_update_to_display_results_for_the_new_date_I_have_selected()
   {
      assertThat("Return Search Cards are not displayed",
               searchresults.isReturnSearchResultsPresent(), is(true));
   }

   @Then("the Title above the Return search results cards will update to reflect the new date I have selected")
   public void the_Title_above_the_Return_search_results_cards_will_update_to_reflect_the_new_date_I_have_selected()
   {
      assertThat("Return Date not updated below Outbound Carousal", StringUtils.containsIgnoreCase(
               returnSelectedDateHeader, searchresults.getReturnSelectedDateHeader()), is(false));
   }

   @Given("Outbound search results are available")
   public void outbound_search_results_are_available()
   {
      assertThat("Search Results are not displayed", searchresults.isOutboundSearchResultsPresent(),
               is(true));
   }

   @Given("I have not yet made an outbound flight selection")
   public void i_have_not_yet_made_an_outbound_flight_selection()
   {
      assertThat("Outbound Search card is already selected",
               searchresults.isOutboundSearchCardSelected(), is(false));
   }

   @When("I click the {string} CTA on the outbound flight card")
   public void i_click_the_CTA_on_the_outbound_flight_card(String string)
   {
      searchresults.selectOutboundFlight();
   }

   @Then("the card will be highlighted with a tick \\(as per design)")
   public void the_card_will_be_highlighted_with_a_tick_as_per_design()
   {
      assertThat("Tick is not displayed for Outbound flight",
               searchresults.isOutboundTickDisplayed(), is(true));
   }

   @Then("the text within the card will read following text next to a tick icon")
   public void the_text_within_the_card_will_read_SELECTED_next_to_a_tick_icon(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = map.get(getTestExecutionParams().getBrandStr());
         actual = searchresults.getOutboundFlightSlectedText().trim();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Selected is not displayed after selecting Outbound flight", actual,
                           expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @When("I view the list of results")
   public void i_view_the_list_of_results()
   {
      searchresults.viewOutboundSearchCards();
   }

   @Then("they will be ordered by the earliest departure time.")
   public void they_will_be_ordered_by_the_earliest_departure_time()
   {
      assertThat("Outbound Search Results are not ordered",
               searchresults.isOutboundResultsOrdered(), is(true));

   }

   @Given("Return search results are available")
   public void return_search_results_are_available()
   {

      assertThat("Return Search Results are not displayed",
               searchresults.isReturnSearchResultsPresent(), is(true));
   }

   @When("I view the list of return results")
   public void i_view_the_list_of_retutn_results()
   {
      searchresults.viewOutboundSearchCards();
   }

   @Then("they return results will be ordered by the earliest departure time.")
   public void they_return_results_will_be_ordered_by_the_earliest_departure_time()
   {
      assertThat("Return Search Results are not ordered", searchresults.isReturnResultsOrdered(),
               is(true));
   }

   @Given("a {string} has selected an Outbound Flight Card with a DIRECT flight")
   public void a_has_selected_an_Outbound_Flight_Card_with_a_DIRECT_flight(String string)
   {
      foNavigation.navigateToSearchResultPage();
      searchresults.selectOutboundDirectFlight();
   }

   @When("I view the summary panel")
   public void i_view_the_summary_panel()
   {
      searchresults.viewFLightSummaryPanel();
   }

   @Then("the following information under the {string} Title will be visible:")
   public void the_following_information_under_the_Title_will_be_visible(String outboundtext,
            List<String> components)
   {
      searchresults.setSearchComponentsMapAfterFlightSelection();
      components.forEach(component ->
               assertThat(component + " componenet is not displayed",
                        WebElementTools.isPresent(
                                 searchresults.getSummaryPanelMap().get(component)),
                        is(true)));
   }

   @Given("a {string} has selected an Outbound Flight Card with a STOPOVER")
   public void a_has_selected_an_Outbound_Flight_Card_with_a_STOPOVER(String string)
   {
      foNavigation.flightSearch = "one way";
      foNavigation.navigateToSearchResultPage();
      searchresults.selectOutboundStopOverFlight();
   }

   @Given("I have not yet made a Return flight selection")
   public void i_have_not_yet_made_a_Return_flight_selection()
   {
      assertThat("Return Search card is already selected",
               searchresults.isReturnSearchCardSelected(), is(false));
   }

   @When("I click the {string} CTA on the return flight card")
   public void i_click_the_CTA_on_the_return_flight_card(String string)
   {
      searchresults.selectReturnFlight();
   }

   @Then("the return card will be highlighted with a tick \\(as per design)")
   public void the_return_card_will_be_highlighted_with_a_tick_as_per_design()
   {
      assertThat("Tick is not displayed for Return flight", searchresults.isReturnTickDisplayed(),
               is(true));
   }

   @Then("the text within the return card will read {string} next to a tick icon")
   public void the_text_within_the_return_card_will_read_next_to_a_tick_icon(String text)
   {
      assertThat("Selected is not displayed after selecting Return flight",
               StringUtils.equalsIgnoreCase(text, searchresults.getReturnFlightSlectedText()),
               is(true));
   }

   @Given("a {string} has selected a Return Flight Card with a DIRECT flight")
   public void a_has_selected_a_Return_Flight_Card_with_a_DIRECT_flight(String string)
   {
      foNavigation.navigateToSearchResultPage();
      searchresults.selectReturnDirectFlight();
   }

   @Given("a {string} has selected a Return Flight Card with a STOPOVER flight")
   public void a_has_selected_a_Return_Flight_Card_with_a_STOPOVER_flight(String string)
   {
      foNavigation.navigateToSearchResultPage();
      searchresults.selectReturnStopOverFlight();
   }

   @Given("a {string} has selected an Outbound flight")
   public void a_has_selected_an_Outbound_flight(String string)
   {
      searchresults.selectOutboundFlight();
   }

   @Given("the customer selects outbound and return flight options")
   public void the_customer_selects_outbound_and_return_flight_options()
   {
      searchresults.selectOutboundFlight();
      searchresults.selectReturnDirectFlight();
      wait.forJSExecutionReadyLazy();
      searchresults.clickContinuButton();
   }

   @Given("has selected a Return Flight")
   public void has_selected_a_Return_Flight()
   {
      searchresults.selectReturnFlight();
   }

   @When("they view the Summary panel")
   public void they_view_the_Summary_panel()
   {
      searchresults.viewFLightSummaryPanel();
   }

   @Then("the following information will be displayed in competed summarypanel:")
   public void the_following_information_will_be_displayed_in_competed_summarypanel(
            List<String> components)
   {
      searchresults.setSearchComponentsMapAfterFlightSelection();
      components.forEach(component ->
               assertThat(component + " componenet is not displayed",
                        WebElementTools.isPresent(
                                 searchresults.getSummaryPanelMap().get(component)),
                        is(true)));
   }

   @Given("I have made an outbound flight selection")
   public void i_have_made_an_outbound_flight_selection()
   {
      searchresults.selectOutboundFlight();
   }

   @When("I click the {string} CTA on the flight card I want from the RETURN search results list")
   public void i_click_the_CTA_on_the_flight_card_I_want_from_the_RETURN_search_results_list(
            String string)
   {
      searchresults.selectReturnFlight();
   }

   @Given("I have made a return flight selection")
   public void i_have_made_a_return_flight_selection()
   {
      searchresults.selectReturnFlight();
   }

   @Then("the customer will see a sticky summary panel with the following visible:")
   public void the_customer_will_see_a_sticky_summary_panel_with_the_following_visible(
            List<String> components)
   {
      searchresults.setSearchComponentsMapAfterFlightSelection();
      components.forEach(component ->
               assertThat(component + " componenet is not displayed",
                        WebElementTools.isPresent(
                                 searchresults.getSummaryPanelMap().get(component)),
                        is(true)));
      searchresults.checkStickynessOFContinueButton();
   }

   @Then("when i scroll up the page, the full summary panel will be visible \\(as per ux)")
   public void when_i_scroll_up_the_page_the_full_summary_panel_will_be_visible_as_per_ux()
   {
      assertThat("Summary Panel not displayed", searchresults.checkSummaryPanel(), is(true));
   }

   @Then("the customer will see a collapsed summary panel with the following visible at the bottom of the page:")
   public void the_customer_will_see_a_collapsed_summary_panel_with_the_following_visible_at_the_bottom_of_the_page(
            io.cucumber.datatable.DataTable dataTable)
   {
      searchresults.checkCollapssedSummaryPanel();
   }

   @Given("a “Customer” is on the TUI fly search results page")
   public void a_Customer_is_on_the_TUI_fly_search_results_page()
   {
      // TODO: remove hardcoded url
      open("https://localhost:8004/flightsonly/searchresultsv2/");
   }

   @And("search results are available on the page")
   public void test()
   {
      assertThat("Search Results are not displayed", searchresults.isSelectableCardPresent(),
               is(true));
   }

   @When("I view the search result page")
   public void i_view_the_search_result_page()
   {
      searchresults.viewSearchResultsPage();
   }

   @Then("the title should be displayed with the following attributes")
   public void the_title_should_be_displayed(List<String> components)
   {

      searchresults.setSearchResultsTitle();
      components.forEach(component ->
               assertThat(component + " component is not displayed",
                        WebElementTools.isPresent(
                                 searchresults.getSearchResultsTitle().get(component)),
                        is(true)));
   }

   @When("I click on CONTINUE button on Search Results Page")
   public void i_click_on_CONTINUE_button_on_Search_Results_Page()
   {
      currentUrl = WebDriverUtils.getDriver().getCurrentUrl();
      wait.forJSExecutionReadyLazy();
      searchresults.clickContinuButton();
   }

   @Then("I will be taken to the Flight Options page")
   public void i_will_be_taken_to_the_Flight_Options_page()
   {
      assertThat("Flighst page is not displayed",
               currentUrl.equals(WebDriverUtils.getDriver().getCurrentUrl()), is(false));
   }

   @Given("a {string} is on the TUI fly search results page with departure date not available")
   public void a_is_on_the_TUI_fly_search_results_page_with_departure_date_not_available(
            String string)
   {
      open(new SearchDataHelper()
               .getSearchParameters("FlightNotAvailable").getSearchresURL());
   }

   @When("I view the Outbound date carousel")
   public void i_view_the_Outbound_date_carousel()
   {
      searchresults.isOutboundCarousalPresent();
   }

   @Then("the following message will be displayed underneath:")
   public void the_following_message_will_be_displayed_underneath(String valText)
   {
      assertThat("No Flights available text not matching",
               StringUtils.containsIgnoreCase(valText, searchresults.getOutboundFlightNAText()),
               is(true));
   }

   @Given("a {string} is on the TUI fly search results page with  plusminus {int} days of my departure date are not available")
   public void a_is_on_the_TUI_fly_search_results_page_with_days_of_my_departure_date_are_not_available(
            String string, Integer int1)
   {
      open(new SearchDataHelper()
               .getSearchParameters("7DaysNotAvailable").getSearchresURL());
      foNavigation.searchPanelComponent.closePrivacyPopUp();
   }

   @Then("all visible dates in the carousel will be disabled")
   public void all_visible_dates_in_the_carousel_will_be_disabled()
   {
      assertThat("Return Date and Price are visible for disabled",
               searchresults.returnDisabledDatePriceVisible(), is(true));
   }

   @Then("left and right arrows will be enabled if flights are available")
   public void left_and_right_arrows_will_be_enabled_if_flights_are_available()
   {
      assertThat("Navigation Arrow for Outbound not present",
               searchresults.isOutboundCarousalNavigationArrowsPresent(), is(true));
   }

   @Given("the customer has selected an outbound flight")
   public void the_customer_has_selected_an_outbound_flight()
   {
      searchresults.selectOutboundFlight();
   }

   @Given("the customer has selected a date on the {string} carousel which has a date before the outbound flight")
   public void the_customer_has_selected_a_date_on_the_carousel_which_has_a_date_before_the_outbound_flight(
            String string)
   {
      open(new SearchDataHelper()
               .getSearchParameters("ReturnBeforeOutbound").getSearchresURL());
   }

   @When("the customer selects a return flight card which has a date before the outbound flight")
   public void the_customer_selects_a_return_flight_card_which_has_a_date_before_the_outbound_flight()
   {
      searchresults.selectReturnFlight();
   }

   @Then("an error message pop up should display stating:")
   public void an_error_message_pop_up_should_display_stating(DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = map.get(getTestExecutionParams().getBrandStr());
         actual = searchresults.getInvalidFlightErrorMessage().trim();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Error message id not as pe requirement", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Given("has selected a return flight")
   public void has_selected_a_return_flight()
   {
      searchresults.selectReturnFlight();
   }

   @Given("the customer has selected a date on the outbound carousel which is after the return flight date")
   public void the_customer_has_selected_a_date_on_the_outbound_carousel_which_is_after_the_return_flight_date()
   {
      open(new SearchDataHelper()
               .getSearchParameters("OutboundafterReturn").getSearchresURL());
   }

   @When("the Customer selects a outbound flight card which has a date after the return flight")
   public void the_Customer_selects_a_outbound_flight_card_which_has_a_date_after_the_return_flight()
   {
      searchresults.selectReturnFlight();
      searchresults.selectOutboundFlight();
   }

   @Given("they have selected a return flight card which is before their outbound flight card")
   public void they_have_selected_a_return_flight_card_which_is_before_their_outbound_flight_card()
   {

      open(new SearchDataHelper()
               .getSearchParameters("ReturnBeforeOutbound").getSearchresURL());
      searchresults.selectOutboundFlight();
      searchresults.selectReturnFlight();
   }

   @Given("the following error message is displaying:")
   public void the_following_error_message_is_displaying(io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = map.get(getTestExecutionParams().getBrandStr());
         actual = searchresults.getInvalidFlightErrorMessage().trim();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Error message id not as pe requirement", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @When("the Customer selects {string} in flights error popup")
   public void the_Customer_selects_in_flights_error_popup(String string)
   {
      searchresults.clickOkCloseErrorPopup();
   }

   @Then("the return flight should be retained")
   public void the_return_flight_should_be_retained()
   {
      assertThat("Return Flight is not retained", searchresults.isReturnFlightRetained(), is(true));
   }

   @Then("the pop up should close")
   public void the_pop_up_should_close()
   {
      assertThat("Pop up is not closed", searchresults.isPopupClosed(), is(false));
   }

   @Then("the original outbound flight is unselected")
   public void the_original_outbound_flight_is_unselected()
   {
      assertThat("Outbound Flight is  retained", searchresults.isOutboundFlightRetained(),
               is(false));
   }

   @Given("they have selected a outbound flight card which is after their return flight card")
   public void they_have_selected_a_outbound_flight_card_which_is_after_their_return_flight_card()
   {
      open(new SearchDataHelper()
               .getSearchParameters("OutboundafterReturn").getSearchresURL());
      searchresults.selectReturnFlight();
      wait.forJSExecutionReadyLazy();
      searchresults.selectOutboundFlight();
   }

   @Then("the outbound flight should be retained")
   public void the_outbound_flight_should_be_retained()
   {
      assertThat("Outbound Flight is not retained", searchresults.isOutboundFlightRetained(),
               is(true));
   }

   @Then("the original return flight is unselected")
   public void the_original_return_flight_is_unselected()
   {
      assertThat("Return Flight is  retained", searchresults.isReturnFlightRetained(), is(false));
   }

   @Given("an error message is displaying")
   public void an_error_message_is_displaying()
   {
      open(new SearchDataHelper()
               .getSearchParameters("ReturnBeforeOutbound").getSearchresURL());
      foNavigation.searchPanelComponent.closePrivacyPopUp();
      searchresults.selectOutboundFlight();
      searchresults.selectReturnFlight();

   }

   @When("a customer chooses to {string}, {string} or {string} out of the error message")
   public void a_customer_chooses_to_or_out_of_the_error_message(String string, String string2,
            String string3)
   {
      searchresults.clickOkCloseErrorPopup();
   }

   @Then("the last selection is not retained")
   public void the_last_selection_is_not_retained()
   {
      assertThat("Outbound Flight is  retained", searchresults.isOutboundFlightRetained(),
               is(false));
   }

   @Given("the customer has selected valid outbound and return flights")
   public void the_customer_has_selected_valid_outbound_and_return_flights()
   {
      searchresults.selectOutboundFlight();
      searchresults.selectReturnFlight();
   }

   @And("capture the values from search result page")
   public void capture_the_values_from_search_result_page() throws InterruptedException
   {
      searchresults.searchSummaryComponents();
   }

   @And("they click on continue button in search result page")
   public void they_click_on_continue_button_in_search_result_page()
   {
      WebElementTools
               .click(wait.getWebElementWithLazyWait(searchresults.getContinueToFlightButton()));
   }

}
