package uk.co.tui.cdaf.frontend.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import java.util.List;

import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class DOMElementHelper
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(DOMElementHelper.class);

   /*
    * use it only for ALL react pages as the react standard is to check against
    * aria-labels.
    */
   public static boolean isElementExistByAriaLabel(String ariaLabel)
   {
      LOGGER.log(LogLevel.INFO, "checking for element by aria-label");
      List<WebElement> element =
               getDriver().findElements(By.xpath("//*[@aria-label='" + ariaLabel + "']"));
      if (!element.isEmpty())
      {
         return element.get(0).isDisplayed();
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "Element with aria-label: " + ariaLabel + " is not present.");
         return false;
      }
   }

   /*
    * ONLY **use it only for non react pages** as the react standard is to
    * check against aria-labels.
    */
   public static boolean isElementExistByClass(String className)
   {
      LOGGER.log(LogLevel.INFO, "checking for element by className");
      List<WebElement> element =
               getDriver().findElements(By.xpath("//*[contains(@class," + className + ")]"));
      if (!element.isEmpty())
      {
         return element.get(0).isDisplayed();
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "Element with className: " + className + " is not present.");
         return false;
      }
   }

   /*
    * Check against the <a> anchor tag, to find the links using text()
    */
   public static boolean getElementByAnchor(String anchorText)
   {
      LOGGER.log(LogLevel.INFO, "checking for element by aria-label");
      String xpath = "(//a[normalize-space(text())= '" + anchorText + "'][1])";
      List<WebElement> element = getDriver().findElements(By.xpath(xpath));

      if (!element.isEmpty())
      {
         return element.get(0).isDisplayed();
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "Element with aria-label: " + anchorText + " is not present.");
         return false;
      }
   }

   /*
    * Get the element by placeholder value
    */
   public static boolean getElementByPlaceholder(String placeholder)
   {
      LOGGER.log(LogLevel.INFO, "checking for element by placeholder");
      List<WebElement> element =
               getDriver().findElements(By.xpath("//*[@placeholder='" + placeholder + "']"));
      if (!element.isEmpty())
      {
         return element.get(0).isDisplayed();
      }
      else
      {
         LOGGER.log(LogLevel.INFO,
                  "Element with placeholder attribute: " + placeholder + " is not present.");
         return false;
      }
   }

   public static List<WebElement> getElementsByAriaLabel(String ariaLabel)
   {
      String xpath = "//*[@aria-label='" + ariaLabel + "']";
      return getDriver().findElements(By.xpath(xpath));
   }
}
