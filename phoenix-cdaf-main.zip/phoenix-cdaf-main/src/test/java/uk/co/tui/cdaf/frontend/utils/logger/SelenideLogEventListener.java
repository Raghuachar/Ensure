package uk.co.tui.cdaf.frontend.utils.logger;

import com.codeborne.selenide.logevents.LogEvent;
import com.codeborne.selenide.logevents.LogEventListener;

public class SelenideLogEventListener implements LogEventListener
{

   @Override
   public void beforeEvent(LogEvent currentLog)
   {
      addSelenideLog(currentLog);
   }

   @Override
   public void afterEvent(LogEvent currentLog)
   {
      if (currentLog.getStatus().equals(LogEvent.EventStatus.FAIL))
      {
         addSelenideLog(currentLog);
      }
   }

   private void addSelenideLog(LogEvent currentLog)
   {
      AutomationLogManager.appendEvents("[Selenide] DEBUG:" + currentLog.toString());
   }
}
