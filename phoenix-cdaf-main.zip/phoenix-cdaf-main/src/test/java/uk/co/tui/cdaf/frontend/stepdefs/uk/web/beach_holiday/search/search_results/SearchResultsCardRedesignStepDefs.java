package uk.co.tui.cdaf.frontend.stepdefs.uk.web.beach_holiday.search.search_results;

import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.SearchResultsCardComponentV2;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class SearchResultsCardRedesignStepDefs extends AbstractPage
{
   private final SearchResultsCardComponentV2 searchResultsCard =
            new SearchResultsCardComponentV2();

   @When("they review the Search Results card")
   public void they_review_the_Search_Results_card()
   {
      assertTrue("Search card is not present", searchResultsCard.reviewSearchCard());
   }

   @When("the user search for no of  room availability")
   public void the_user_search_for_no_of_room_availability()
   {
      searchResultsCard.isRoomAvailability();
   }
}
