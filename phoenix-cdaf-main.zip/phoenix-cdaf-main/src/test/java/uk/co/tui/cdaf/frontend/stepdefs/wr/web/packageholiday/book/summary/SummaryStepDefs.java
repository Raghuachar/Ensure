package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.MultipleRoomTypeInHolidaySummaryComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.PassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.InsuranceAndExtrasComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.PriceBreakDownComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.RoomAndBoardComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class SummaryStepDefs
{
   public final SummaryPage summaryPage;

   public final UnitDetailsPage unitDetailsPage;

   public final PackageNavigation packageNavigation;

   public final PassengerDetailsPage passengerPage;

   public final InsuranceAndExtrasComponent insExComponent;

   public final NordicsPassengerDetailsPage nordicPassengerPage;

   public final PriceBreakDownComponent priceBreakComponent;

   public final MultipleRoomTypeInHolidaySummaryComponent holidaySummaryComponent;

   public final RoomAndBoardComponent roomAndBoardComponent;

   public SummaryStepDefs()
   {
      summaryPage = new SummaryPage();
      unitDetailsPage = new UnitDetailsPage();
      packageNavigation = new PackageNavigation();
      passengerPage = new PassengerDetailsPage();
      insExComponent = summaryPage.insExComponent;
      nordicPassengerPage = new NordicsPassengerDetailsPage();
      priceBreakComponent = summaryPage.priceBreakComponent;
      holidaySummaryComponent = new MultipleRoomTypeInHolidaySummaryComponent();
      roomAndBoardComponent = new RoomAndBoardComponent();
   }

   @And("they are presented with the Book Now component with the following info")
   public void they_are_presented_with_the_Book_Now_component_with_the_following_info(
            List<String> components)
   {
      summaryPage.wait.forJSExecutionReadyLazy();
      Map<String, WebElement> priceMap =
               summaryPage.navigationComponent.getPricePanelComponentsOfSummary();
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = priceMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they are presented with the Flight Component with the following info:")
   public void they_are_presented_with_the_Flight_Component_with_the_following_info(
            List<String> components)
   {
      summaryPage.wait.forJSExecutionReadyLazy();
      Map<String, WebElement> flightMap =
               summaryPage.flightSummaryComponent.getFlightSummaryComponents();
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = flightMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they are presented with the Accommodation Component with the following info:")
   public void they_are_presented_with_the_Accommodation_Component_with_the_following_info(
            List<String> components)
   {
      summaryPage.wait.forJSExecutionReadyLazy();
      Map<String, WebElement> accomMap =
               summaryPage.accomodationComponent.getAccomodationComponents();
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = accomMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they are presented with the Price Breakdown Component with the following info:")
   public void they_are_presented_with_the_Price_Breakdown_Component_with_the_following_info(
            List<String> components)
   {
      summaryPage.wait.forJSExecutionReadyLazy();
      Map<String, WebElement> priceMap = summaryPage.priceBreakComponent.getPriceBreakdownComps();
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = priceMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they are presented with the Transfer Component with the following info:")
   public void they_are_presented_with_the_Transfer_Component_with_the_following_info(
            List<String> components)
   {
      summaryPage.wait.forJSExecutionReadyLazy();
      Map<String, WebElement> transferMap = summaryPage.transferComponent.getTransferComponents();
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = transferMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they are presented with the Insurance Component with the following info:")
   public void they_are_presented_with_the_Insurance_Component_with_the_following_info(
            List<String> components)
   {
      summaryPage.wait.forJSExecutionReadyLazy();
      Map<String, WebElement> insuranceMap =
               summaryPage.insExComponent.getInsuranceComponents();
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = insuranceMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they navigate to the Passenger Details Page")
   public void they_navigate_to_the_Passenger_Details_Page()
   {
      summaryPage.navigationComponent.clickOnContinueButton();
   }

   @And("they navigate to the Passenger Details Page for Price change")
   public void they_navigate_to_the_Passenger_Details_Page_for_Price_change()
   {
      passengerPage.multipleRoomTypeInHolidaySummaryComponent.NavigateRoomOptions();
      summaryPage.Pricechange();
      summaryPage.navigationComponent.clickOnContinueButton();
   }

   @And("the customise Holiday page will be displayed")
   public void the_customise_Holiday_page_will_be_displayed()
   {
      summaryPage.navigationComponent.isPageDisplayed();
   }

   @And("they click on the Hotel details breadcrumb")
   public void they_click_on_the_Hotel_details_breadcrumb()
   {
      summaryPage.navigationComponent.clickOnHotelDetailsBreadCrumb();
   }

   @And("user can compare search results values with customize summary page")
   public void user_can_compare_search_results_values_with_customize_summary_page()
   {
      String customizeSummaryValues;
      HashMap<String, String> searchValues = searchStoreValues.getSearchValues();
      searchStoreValues
               .setPerPersonPrice(unitDetailsPage.progressbarComponent.getPerPersonPriceElement());
      searchStoreValues.setTotalPrice(unitDetailsPage.progressbarComponent.getTotalPriceValue());
      customizeSummaryValues = summaryPage.accomodationComponent.getAccommodationdetails();
      assertThat("Accommodation Component is not matched with Summary details page",
               searchValues.get("Hotel Name").trim(), equalToIgnoringCase(customizeSummaryValues));
   }

   @And("the summary page should be displayed")
   public void the_summary_page_should_be_displayed()
   {
      boolean isDisplayed = summaryPage.navigationComponent.isPageDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Summary page wasn't loaded", isDisplayed, true), isDisplayed, is(true));
   }

   @Given("user is on the Summary page of a package")
   public void user_is_on_the_summary_page_of_package()
   {
      packageNavigation.navigateToSummaryPageOfContractedPkg();
   }

   @Given("user is on the Summary page of a package with alternative rooms")
   public void user_is_on_the_summary_page_of_package_with_alternative_rooms()
   {
      packageNavigation.navigateTosummaryPage();
   }

   @Given("user is on the Summary page of a package with alternative boards")
   public void user_is_on_the_summary_page_of_package_with_alternative_boards()
   {
      packageNavigation.navigateToSummaryWithAltBoard();
   }

   @And("the default insurance option highlighted as selected is No Insurance")
   public void the_default_insurance_option_highlighted_as_selected_is_No_Insurance()
   {
      assertTrue("Default insurance option is not displayed", insExComponent.noInsuranceOpted());
   }

   @And("they click on choose insurance link")
   public void they_click_on_choose_insurance_link()
   {
      insExComponent.clickOnChooseInsurance();
      insExComponent.selectpassengerforinsurance();
      nordicPassengerPage.enterAdultDOB();
      insExComponent.clickOnChangeInsuranceoption();
      insExComponent.clickOnBackToVacationButton();
   }

   @Then("within Room & Board sub section, upgraded and description will display and show as Included")
   public void within_Room_Board_sub_section_upgraded_and_description_will_display_and_show_as_Included()
   {
      passengerPage.multipleRoomTypeInHolidaySummaryComponent.NavigateRoomOptions();
      passengerPage.multipleRoomTypeInHolidaySummaryComponent.getRoomTypeComps();
   }

   @And("they select the tooltip in the price component")
   public void they_select_the_tooltip_in_the_price_component()
   {
      priceBreakComponent.VerifySummarypageTooltip();
   }

   @Then("they are shown a tooltip in Summary page showing the text data")
   public void they_are_shown_a_tooltip_in_Summary_page_showing_the_text_data(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String actual = priceBreakComponent.tooltipTextForSummaryPage();
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertThat("Tooltip text for Summary page is not the same", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @Then("they are shown a tooltip in Extras page showing the text data")
   public void they_are_shown_a_tooltip_in_Extras_page_showing_the_text_data(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String actual = priceBreakComponent.tooltipTextForExtrasPage();
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertThat("Tooltip text for Extras page is not the same", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @Then("they are shown a tooltip in Room&Board page showing the text data")
   public void they_are_shown_a_tooltip_in_room_board_page_showing_the_text_data(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String actual = priceBreakComponent.tooltipTextForRoomBoardPage();
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertThat("Tooltip text for Room&Board page is not the same", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @Then("Navigate to Extras Page")
   public void navigate_to_Extras_Page()
   {
      summaryPage.navigationComponent.ClickonExtras();
   }

   @Then("Navigate to Summary Page")
   public void navigate_to_Summary_Page()
   {
      insExComponent.clickOnBackToVacationButton();
   }

   @Then("continue to Room&Board option")
   public void continue_to_Room_Board_option()
   {
      holidaySummaryComponent.clickOnIconToExpandHolidaySummary();
   }

   @Then("they are shown a tooltip showing the text data for passenger details page")
   public void they_are_shown_a_tooltip_showing_the_text_data_for_passenger_details_page(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String actual = priceBreakComponent.tooltipTextForPassengerDetailsPage();
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertThat("Tooltip text for Passenger details page is not the same", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @When("user navigates to Extras & Options page")
   public void user_navigates_to_Extras_Options_page()
   {
      summaryPage.wait.forJSExecutionReadyLazy();
      insExComponent.clickOnChooseInsurance();
      summaryPage.errorHandler.isPageLoadingCorrectly();
   }

   @And("user navigates to Room options page")
   public void user_navigates_to_room_options_page()
   {
      roomAndBoardComponent.clickChangeRoomOptions();
   }

   @And("user is on the Summary page of a package with luggage added for {int} passengers")
   public void user_is_on_the_summary_page_of_package_with_luggage_added(Integer paxAmount)
   {
      packageNavigation.navigateToSummaryPage();
      summaryPage.luggageAncillaryComponent.addCheapestLuggageForPassengers(paxAmount);
   }

   @And("user is on the Summary page of a package with comfort seats added")
   public void user_is_on_the_summary_page_of_package_with_comfort_seats_added()
   {
      packageNavigation.navigateToSummaryPageOfContractedPkg();
      summaryPage.seatAncillaryComponent.addComfortSeats();
   }
}
