package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageUpdatingTotalDiscrepanciesStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageUpdatingTotalDiscrepanciesStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that shop has taken card payments against bookings")
   public void that_shop_has_taken_card_payments_against_bookings()
   {
      packagenavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      wait.forJSExecutionReadyLazy();
      assertThat("Payment Method Accordion is present",
               pKgReconcilationPaymentPageComponents.isPaymentMethodTypeAccordion(), is(true));
      pKgReconcilationPaymentPageComponents.clickPaymentMethodTypeAccordion();
   }

   @When("they view the {string} free text field")
   public void they_view_the_free_text_field(String string)
   {
      assertThat("Discrepancy Amount Input Credit Card Present",
               pKgReconcilationPaymentPageComponents.isDiscrepancyAmountInputCreditCardPresent(),
               is(true));
   }

   @When("enter a numeric figure")
   public void enter_a_numeric_figure()
   {
      pKgReconcilationPaymentPageComponents.enterDiscrepancyAmountInputCreditCard();
   }

   @Then("the banking now entry within the card table will be updated and the total discrepancies component will be updated")
   public void the_banking_now_entry_within_the_card_table_will_be_updated_and_the_total_discrepancies_component_will_be_updated()
   {
      wait.forJSExecutionReadyLazy();
   }
}
