package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.FreeCancellationComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class FreeCancellationMessageStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(FreeCancellationMessageStepDefs.class);

   public final SearchResultsPage searchResultsPage;

   public PackageNavigation packageNavigation;

   public FreeCancellationComponent freeCancellationComponent;

   public FreeCancellationMessageStepDefs()
   {
      packageNavigation = new PackageNavigation();
      freeCancellationComponent = new FreeCancellationComponent();
      searchResultsPage = new SearchResultsPage();
   }

   @And("they are at least 41 days inclusive of today before departure of any results")
   public void they_are_at_least_days_inclusive_of_today_before_departure_of_any_results()
   {
      try
      {
         assertThat("Free Cancellation component AccommInfo is present",
                  freeCancellationComponent.visibileAccomInfoComponent(), is(true));
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, e.getMessage());
      }
   }

   @When("they view a search results card that includes free cancellation")
   public void they_view_a_search_results_card_that_includes_free_cancellation()
   {
      assertThat("Free Cancellation component is Not present",
               freeCancellationComponent.visibileFreeCancellationComponent(), is(true));
   }

   @Then("the following message will appear")
   public void the_following_message_will_appear(List<String> element)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      assertThat("Free Cancellation component Message is Not present",
               freeCancellationComponent.visibileDateFromNowSevenDay(element.get(0)), is(true));
   }

   @And("they have clicked on a free cancellation Message link within a search results card")
   public void they_have_clicked_on_a_link_within_a_search_results_card()
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      assertThat("Free Cancellation component Text Link is Not Clicked",
               freeCancellationComponent.clickFreeCancellationLink(), is(true));
   }

   @When("the modal opens")
   public void the_modal_opens()
   {
      assertThat("Free Cancellation component Text Link is Model Popup Not opened",
               freeCancellationComponent.isModalHasContent(), is(true));
   }

   @Then("the following information will be displayed in local language:")
   public void the_following_information_will_be_displayed_in_local_language(
            List<String> freeCancellationElement)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      assertThat("Free Cancellation component PopUp Content body is Not present",
               freeCancellationComponent.isModalHasBodyContent(freeCancellationElement), is(true));
   }

}
