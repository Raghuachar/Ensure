package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsFiltersComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class CommissionMarkersStepDefs
{
   static AutomationLogManager LOGGER = new AutomationLogManager(CommissionMarkersStepDefs.class);

   private final Map<String, WebElement> searchMap;

   private final SearchResultsFiltersComponent searchResultsFiltersComponent;

   private final SearchResultsPage searchResultsPage;

   private final SearchPanel searchPanel = getSearchPanel();

   private final WebElementWait wait;

   private String commissionMarkerType = "";

   private int actualSelectedCount;

   private String actualHoildayCount = "";

   public CommissionMarkersStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
      wait = new WebElementWait();
      searchMap = new HashMap<>();
      searchResultsFiltersComponent = new SearchResultsFiltersComponent();
   }

   @When("they can see a commission marker which displays:")
   public void they_can_see_a_commission_marker_which_displays(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Commission Markers Bands are not displayed",
               searchResultsPage.commissionMarkers.verifyCommissionMarkersBand(dataTable),
               is(true));
   }

   @When("it displays underneath the departure airport row")
   public void it_displays_underneath_the_departure_airport_row()
   {
      LOGGER.log(LogLevel.INFO, "Commission Markers information in underneath departure airport : "
               + searchResultsPage.commissionMarkers.getCommissionMarkers());
   }

   @When("ALL packages are assigned a marker")
   public void all_packages_are_assigned_a_marker()
   {
      assertThat("Commission Markers Bands are not displayed",
               searchResultsPage.commissionMarkers.verifyCommissionMarkers(), is(true));

   }

   @When("they review the filters component")
   public void they_review_the_filters_component()
   {
      assertThat("Commission Markers Filters are not displayed",
               searchResultsPage.commissionMarkers.isCommissionMarkerFilterIsDisplayed(), is(true));
   }

   @Then("they can see a filter titled Commission")
   public void they_can_see_a_filter_titled_Commission(io.cucumber.datatable.DataTable dataTable)
   {
      searchResultsPage.searchPanelComponent.wait.forJSExecutionReadyLazy();
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = map.get(getTestExecutionParams().getBrandStr());
         actual = searchResultsPage.commissionMarkers.getCommissionMarkerFilterTitle();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Commission Marker Filter is not display", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("the Commission filter will be the first displayed within the filters component")
   public void the_Commission_filter_will_be_the_first_displayed_within_the_filters_component()
   {
      LOGGER.log(LogLevel.INFO, "Commission Markers Filter is not displayed in first order : "
               + searchResultsPage.commissionMarkers.getFirstTitle());
   }

   @Then("the commission filter shall contain the following details for each different accommodation marker returned")
   public void the_commission_filter_shall_contain_the_following_details_for_each_different_accommodation_marker_returned(
            List<String> components)
   {
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchResultsPage.commissionMarkers
                     .getCommissionMarkerFilterComponents().get(componentIdentifier.trim());
            WebElementTools.scrollTo(element);
            assertThat(componentIdentifier + " component not found in the commission marker Filter",
                     element, is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + "commission marker Filter component not displayed",
                     false, is(true));
         }
      });
   }

   @Then("the commission marker codes shall be ordered in alphabetical order")
   public void the_commission_marker_codes_shall_be_ordered_in_alphabetical_order()
   {
      List<String> actuals = searchResultsPage.commissionMarkers.getCommissionMarkerCodeInAlpha();
      List<String> expecteds = actuals.stream().sorted().collect(Collectors.toList());
      assertEquals(expecteds, actuals);
   }

   @Then("a {string} link shall be displayed below the {int}rd commission marker details")
   public void a_link_shall_be_displayed_below_the_rd_commission_marker_details(String string,
            Integer int1, io.cucumber.datatable.DataTable dataTable)
   {
      if (!searchResultsPage.commissionMarkers.getShowMoreLinkText().isEmpty()
               && searchResultsPage.commissionMarkers.getMoreThanThreeCommission() == int1)
      {
         LOGGER.log(LogLevel.INFO, "Commission Markers Filter Show more Link is displyaing : "
                  + searchResultsPage.commissionMarkers.getShowMoreLinkText());
         searchResultsPage.searchPanelComponent.wait.forJSExecutionReadyLazy();
         String actual, expected;
         Map<String, String> map = dataTable.asMap(String.class, String.class);
         try
         {
            expected = map.get(getTestExecutionParams().getBrandStr());
            actual = searchResultsPage.commissionMarkers.getShowMoreLinkText();
            assertThat(
                     ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                              "Commission Marker Filter is not display", actual, expected),
                     StringUtils.equalsIgnoreCase(expected, actual), is(true));
         }
         catch (Exception e)
         {
            assertThat("component not found in map", false, is(true));
         }
      }
      else
         LOGGER.log(LogLevel.INFO, "Commission Markers Filter Show more Link is not displyaing : "
                  + searchResultsPage.commissionMarkers.getShowMoreLinkText());
   }

   @When("they select commission filter the {string} link")
   public void they_select_commission_filter_the_link(String filter)
   {
      if (!searchResultsPage.commissionMarkers.getShowMoreLinkText().isEmpty())
         searchResultsPage.commissionMarkers.clickOnShowMoreLink();
   }

   @Then("the commission filter shall be expanded")
   public void the_commission_filter_shall_be_expanded()
   {
      if (searchResultsPage.commissionMarkers.getMoreThanThreeCommission() >= 3)
         LOGGER.log(LogLevel.INFO,
                  "Commission Markers Filter Show more Link expanded is displyaing : "
                           + searchResultsPage.commissionMarkers.getShowMoreLinkText());
   }

   @Then("a {string} link shall be displayed after the last commission marker code & description")
   public void a_link_shall_be_displayed_after_the_last_commission_marker_code_description(
            String string, io.cucumber.datatable.DataTable dataTable)
   {
      if (!searchResultsPage.commissionMarkers.getShowMoreLinkText().isEmpty()
               && searchResultsPage.commissionMarkers.getMoreThanThreeCommission() >= 3)
      {
         LOGGER.log(LogLevel.INFO, "Commission Markers Filter Show more Link is displyaing : "
                  + searchResultsPage.commissionMarkers.getShowMoreLinkText());
         searchResultsPage.searchPanelComponent.wait.forJSExecutionReadyLazy();
         String actual, expected;
         Map<String, String> map = dataTable.asMap(String.class, String.class);
         try
         {
            expected = map.get(getTestExecutionParams().getBrandStr());
            actual = searchResultsPage.commissionMarkers.getShowMoreLinkText();
            assertThat(
                     ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                              "Commission Marker Filter  show aless is not display", actual,
                              expected),
                     StringUtils.equalsIgnoreCase(expected, actual), is(true));
         }
         catch (Exception e)
         {
            assertThat("component not found in map", false, is(true));
         }
      }
      else
         LOGGER.log(LogLevel.INFO, "Commission Markers Filter Show more Link is not displyaing : "
                  + searchResultsPage.commissionMarkers.getShowMoreLinkText());
   }

   @Then("the commission filter shall collapse")
   public void the_commission_filter_shall_collapse()
   {
      if (searchResultsPage.commissionMarkers.getMoreThanThreeCommission() <= 3)
         LOGGER.log(LogLevel.INFO,
                  "Commission Markers Filter Show more Link expanded is not displyaing : "
                           + searchResultsPage.commissionMarkers.getShowMoreLinkText());
   }

   @And("the change langauge to fr")
   public void the_change_langauge_to_fr()
   {
      searchResultsPage.commissionMarkers.clickOnLanguageCountrySelector();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.commissionMarkers.selectLanguageSelector();
   }

   @When("they select a Commission marker filter option")
   public void they_select_a_Commission_marker_filter_option()
   {
      commissionMarkerType = searchResultsPage.commissionMarkers.selectCheckBox();
   }

   @Then("the search results are filtered to only display packages with accommodations that contain the selected commission marker")
   public void the_search_results_are_filtered_to_only_display_packages_with_accommodations_that_contain_the_selected_commission_marker()
   {
      String[] commissionMarkerTypeS = commissionMarkerType.split(" ");
      searchResultsPage.commissionMarkers.commissionMarkerType().forEach(action ->
      {
         if (action.equals(commissionMarkerTypeS[0]))
            LOGGER.log(LogLevel.INFO,
                     action + "Commission Markers Filter selection and search cards type both are same: "
                              + commissionMarkerTypeS[0]);
      });

   }

   @Then("a {string} link shall be displayed on the {string} filter title row")
   public void a_link_shall_be_displayed_on_the_filter_title_row(String string, String string2,
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Commission Markers Filters clear link are not displayed",
               searchResultsPage.commissionMarkers.isCommissionMarkerClearLinkIsDisplayed(),
               is(true));
      searchResultsPage.searchPanelComponent.wait.forJSExecutionReadyLazy();
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = map.get(getTestExecutionParams().getBrandStr());
         actual = searchResultsPage.commissionMarkers.getClearLinkText();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Commission Marker Filter is not display", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("they have selected one or more commission filters")
   public void they_have_selected_one_or_more_commission_filters()
   {
      actualHoildayCount = searchResultsPage.commissionMarkers.hoildayCount();
      searchResultsPage.commissionMarkers.selectCheckBox();
   }

   @When("the customer selects the {string} by the Commission filter title")
   public void the_customer_selects_the_by_the_Commission_filter_title(String string)
   {
      searchResultsPage.commissionMarkers.clikOnClearLink();
      actualSelectedCount = searchResultsPage.commissionMarkers.deSelectedCount();
   }

   @Then("all the Commission filters previously selected shall be deselected")
   public void all_the_Commission_filters_previously_selected_shall_be_deselected()
   {
      if (actualSelectedCount == searchResultsPage.commissionMarkers.deSelectedCount())
         LOGGER.log(LogLevel.INFO, "Commission Markers Filter selection shall be deselected: ");
   }

   @And("the search results page shall be redisplayed for all packages which meet the search criteria and other selected filters \\(if any)")
   public void the_search_results_page_shall_be_redisplayed_for_all_packages_which_meet_the_search_criteria_and_other_selected_filters_if_any()
   {
      if (actualHoildayCount.equalsIgnoreCase(searchResultsPage.commissionMarkers.hoildayCount()))
         LOGGER.log(LogLevel.INFO, "Hoilday count displaying same: ");
   }

   @When("the customer deselects one or more Commission marker filter option\\(s)")
   public void the_customer_deselects_one_or_more_Commission_marker_filter_option_s()
   {
      searchResultsPage.commissionMarkers.checkedCheckbox();
   }

   @Then("the {string} modal shall display the following:")
   public void the_modal_shall_display_the_following(String string, List<String> components)
   {
      searchMap.putAll(searchResultsPage.commissionMarkers.getCommissionMarkerComponents());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("a {string} modal shall be displayed")
   public void a_modal_shall_be_displayed(String string)
   {
      searchResultsPage.commissionMarkers.clickOnMobileCommissionMarker();
   }

   @And("select the {string} button select {string} to close the modal")
   public void select_the_button_select_to_close_the_modal(String string, String string2)
   {
      searchResultsFiltersComponent.clickApplyButton();
   }

   @When("they select the Commission Marker CLEAR link")
   public void they_select_the_Commission_Marker_CLEAR_link()
   {
      searchResultsPage.commissionMarkers.clickClearLink();
   }

   @And("performing a search with default parameters")
   public void performing_a_search_with_default_parameters()
   {
      searchPanel.airport().setAllAirportsSelected(true);
      searchPanel.searchDefaults();
      searchPanel.doSearch();
   }

   @Then("they can see a filter titled {string}")
   public void they_can_see_a_filter_titled(String expected)
   {
      String actual = searchResultsPage.commissionMarkers.getCommissionMarkerFilterTitle();
      assertThat("Commission Marker Filter is not display", actual,
               Matchers.equalToIgnoringCase(expected));

   }

   @Then("the {string} filter shall be the first filter displayed within the filters component")
   public void the_filter_shall_be_the_first_filter_displayed_within_the_filters_component(
            String expected)
   {
      String actual = searchResultsPage.commissionMarkers.getFirstTitle();
      assertThat("Commission Markers Filter is not displayed in first order", expected,
               equalTo(actual));

   }
}
