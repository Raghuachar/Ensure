package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.mmb;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;
import java.util.Map;

public class PackageRetrieval extends AbstractPage
{

   @FindBy(css = "#globalHeader__component .LanguageCountrySelector__countrySwitcher")
   private WebElement globalHeader;

   @FindBy(css = "#HeroStrapBanner__component .UI__Bookingref")
   private WebElement yourHolidayBanner;

   @FindBy(css = "#DirectDebit__component")
   private WebElement paymentComponent;

   @FindBy(css = "#PassengerList__component")
   private WebElement passengerDetailsComponent;

   @FindBy(css = "#FlightDetails__component")
   private WebElement flightDetailsComponent;

   @FindBy(css = ".bookingAmendments")
   private WebElement bookingAmendmentsSection;

   @FindBy(css = "#Upgrades__component")
   private WebElement upgradeComponent;

   @SuppressWarnings("serial")
   public Map<String, WebElement> getPackageRetrievalComponents()
   {
      return new HashMap<>()
      {
         {
            put("Global Header (including Country/Language Selector)", globalHeader);
            put("'Your Holiday' Banner with Reference Number", yourHolidayBanner);
            put("Payment History/Price Breakdown Component", paymentComponent);
            put("Passenger Details Component", passengerDetailsComponent);
            put("Flight Details Component", flightDetailsComponent);
            put("Extras & Upgrades Component", upgradeComponent);
            put("Booking Amendments and Information Section", bookingAmendmentsSection);
         }
      };
   }

}
