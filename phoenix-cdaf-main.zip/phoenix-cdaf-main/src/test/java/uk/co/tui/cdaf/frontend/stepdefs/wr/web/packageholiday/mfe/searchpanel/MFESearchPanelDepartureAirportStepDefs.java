package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.*;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class MFESearchPanelDepartureAirportStepDefs
{
   private final PackageNavigation packageNavigation;

   private final SearchResultsPage searchResultsPage;

   private final Map<String, WebElement> searchMap;

   private final SearchPanelComponent searchPanelComponent;

   private final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent;

   private final SearchPanel searchPanel = getSearchPanel();

   private final WebElementWait wait = new WebElementWait();

   public SoftAssertions softAssert = new SoftAssertions();

   public MFESearchPanelDepartureAirportStepDefs()
   {
      departureAirportOrDestinationComponent =
               new DepartureAirportAndDestinationAndDatesComponent();
      packageNavigation = new PackageNavigation();
      searchMap = new HashMap<>();
      searchPanelComponent = new SearchPanelComponent();
      searchResultsPage = new SearchResultsPage();
   }

   @When("they select the Search Panel Departure Airport field")
   public void they_select_the_Search_Panel_Departure_Airport_field()
   {
      departureAirportOrDestinationComponent.selectAirportMFE();
   }

   @Then("the Departure Airports modal shall be displayed")
   public void the_Departure_Airports_modal_shall_be_displayed()
   {
      assertTrue("Departure Airports model view is not Displayed",
               departureAirportOrDestinationComponent.mfeDepartureAirportsIsPresent());
   }

   @And("a list of departure airports in alphabetical order")
   public void a_list_of_departure_airports_in_alphabetical_order()
   {
      departureAirportOrDestinationComponent.isMFEDepartureAirportAlphabeticalOrder();
   }

   @And("the Departure Airports modal shall display the following:")
   public void the_Departure_Airports_modal_shall_display_the_following(List<String> components)
   {
      searchMap.putAll(departureAirportOrDestinationComponent.getDepartureAiportComponentsMFE());
      components.stream().forEach(componentIdentifier ->
      {
         final WebElement element = searchMap.get(componentIdentifier.trim());
         assertThat(componentIdentifier + " component not found in the Map", element,
                  is(notNullValue()));
         boolean actual = WebElementTools.isPresent(element);
         assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                  actual, true), actual, is(true));
      });
   }

   @Then("a tick box shall be displayed by the All airports group option default state unticked")
   public void a_tick_box_shall_be_displayed_by_the_All_airports_group_option_default_state_unticked()
   {
      assertTrue("all airport default state ticked ",
               departureAirportOrDestinationComponent.isAllAirportBoxByDefaultUncheckedMFE());
   }

   @Then("a tick box shall be displayed by each of the departure airport options default state unticked")
   public void a_tick_box_shall_be_displayed_by_each_of_the_departure_airport_options_default_state_unticked()
   {
      assertTrue("Each airports default not unchecked ",
               departureAirportOrDestinationComponent.isEachAirportBoxByDefaultUncheckedMFE());
   }

   @Then("all the text on the Departure Airports modal shall be translated as follows:")
   public void all_the_text_on_the_Departure_Airports_modal_shall_be_translated_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);

      String siteID = getTestExecutionParams().getLocaleStr();
      String actualAirportHeader =
               departureAirportOrDestinationComponent.getMFEAirportHeaderText().getText();
      String actualAllAirport =
               departureAirportOrDestinationComponent.getMFEAllAirportText().getText();
      String actualClearAll = departureAirportOrDestinationComponent.getMFEClearAllText().getText();
      String actualDone = departureAirportOrDestinationComponent.getMFEDoneText().getText();
      String expectedAirportHeader =
               dataTableTemp.stream().filter(row -> row.get("siteId").equals(siteID))
                        .map(row -> row.get("Airports (Select airports you can fly from)"))
                        .findFirst().orElse(null);
      String expectedAllAirport =
               dataTableTemp.stream().filter(row -> row.get("siteId").equals(siteID))
                        .map(row -> row.get("All airports")).findFirst().orElse(null);
      String expectedClearAll =
               dataTableTemp.stream().filter(row -> row.get("siteId").equals(siteID))
                        .map(row -> row.get("CLEAR ALL")).findFirst().orElse(null);
      String expectedDone = dataTableTemp.stream().filter(row -> row.get("siteId").equals(siteID))
               .map(row -> row.get("DONE")).findFirst().orElse(null);
      SoftAssertions softAssertions = new SoftAssertions();
      softAssertions.assertThat(expectedAirportHeader)
               .withFailMessage("Airport Header text is not matched ")
               .isEqualTo(actualAirportHeader);
      softAssertions.assertThat(expectedAllAirport)
               .withFailMessage("All Airport text is not matched")
               .isEqualTo(actualAllAirport);
      softAssertions.assertThat(expectedClearAll)
               .withFailMessage("Clear All text is not matched ")
               .isEqualTo(actualClearAll);
      softAssertions.assertThat(expectedDone)
               .withFailMessage("done text is not matched ")
               .isEqualTo(actualDone);
      softAssertions.assertAll();
   }

   // TODO: cleanup, this step definition fully or partially duplicates step definitions from the list bellow:
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel.MFESearchPanelDepartureAirportStepDefs.java
   //        the_is_on_the_Belgium_Dutch_page(String, String)
   //        the_is_on_the_Belgium_French_page(String, String)
   //        the_is_on_the_Netherlands_page(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.RoomAndGuestAutoAllocationStepDefs.java
   //        is_on_the_page(String)
   //        they_re_on_the_page(String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.B2BVipSelectSingleAccommodationSearch.java
   //        the_is_on_the_page_VIP_Select_package(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage.B2BTUIVIPBrandToggleFlipStepDefs.java
   //        the_is_on_the_page(String, String)
   @And("the {string} is on the Belgium Dutch {string} page")
   public void the_is_on_the_Belgium_Dutch_page(String agent, String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Home page"))
      {
         packageNavigation.navigateToHoldaySearchPage();
      }
      else if (respectivePage.equalsIgnoreCase("Search Results"))
      {
         packageNavigation.navigateToSearchResultPage();
      }
      else if (respectivePage.equalsIgnoreCase("Unit details"))
      {
         packageNavigation.navigateToUnitDetailsPage();
      }
   }

   @And("the departure airports shall be displayed in alphabetical order")
   public void the_departure_airports_shall_be_displayed_in_alphabetical_order()
   {
      assertTrue("Departure Airports model view is not Displayed",
               departureAirportOrDestinationComponent.mfeDepartureAirportsIsPresent());
   }

   @Then("the departure airports shall be translated as follows dutch:")
   public void the_departure_airports_shall_be_translated_as_follows_dutch(
            List<String> expectedDepartureAiports)
   {
      List<String> actualDepartureAirports =
               departureAirportOrDestinationComponent.getMFEAirportText();
      assertEquals("Airport translations do not match", expectedDepartureAiports,
               actualDepartureAirports);
   }

   // TODO: cleanup, this step definition fully or partially duplicates step definitions from the list bellow:
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel.MFESearchPanelDepartureAirportStepDefs.java
   //        the_is_on_the_Belgium_Dutch_page(String, String)
   //        the_is_on_the_Belgium_French_page(String, String)
   //        the_is_on_the_Netherlands_page(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.RoomAndGuestAutoAllocationStepDefs.java
   //        is_on_the_page(String)
   //        they_re_on_the_page(String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.B2BVipSelectSingleAccommodationSearch.java
   //        the_is_on_the_page_VIP_Select_package(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage.B2BTUIVIPBrandToggleFlipStepDefs.java
   //        the_is_on_the_page(String, String)
   @And("the {string} is on the Belgium French {string} page")
   public void the_is_on_the_Belgium_French_page(String agent, String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Home page"))
      {
         packageNavigation.navigateToHoldaySearchPage();
         searchPanelComponent.selectLanguageMFE("fr-BE");
      }
      else if (respectivePage.equalsIgnoreCase("Search Results"))
      {
         packageNavigation.navigateToSearchResultPage();
      }
      else if (respectivePage.equalsIgnoreCase("Unit details"))
      {
         packageNavigation.navigateToUnitDetailsPage();
      }
   }

   @And("the departure airports shall be translated as follows:")
   public void the_departure_airports_shall_be_translated_as_follows(
            DataTable dataTable)
   {
      wait.forJSExecutionReadyLazy();
      String site = getTestExecutionParams().getLocaleStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String airportList = maps.stream().filter(row -> row.get("site").equals(site))
               .map(row -> row.get("airports")).findFirst().orElseThrow();
      List<String> expectedDepartureAirports = List.of(airportList.split(","));
      List<String> actualDepartureAirports =
               departureAirportOrDestinationComponent.getMFEAirportText();
      assertEquals("Airport translations do not match", expectedDepartureAirports,
               actualDepartureAirports);
   }

   // TODO: cleanup, this step definition fully or partially duplicates step definitions from the list bellow:
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel.MFESearchPanelDepartureAirportStepDefs.java
   //        the_is_on_the_Belgium_Dutch_page(String, String)
   //        the_is_on_the_Belgium_French_page(String, String)
   //        the_is_on_the_Netherlands_page(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.RoomAndGuestAutoAllocationStepDefs.java
   //        is_on_the_page(String)
   //        they_re_on_the_page(String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.B2BVipSelectSingleAccommodationSearch.java
   //        the_is_on_the_page_VIP_Select_package(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage.B2BTUIVIPBrandToggleFlipStepDefs.java
   //        the_is_on_the_page(String, String)
   @And("the {string} is on the Netherlands {string} page")
   public void the_is_on_the_Netherlands_page(String agent, String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Home page"))
      {
         packageNavigation.navigateToHoldaySearchPage();
         searchPanelComponent.selectLanguageMFE("nl");
      }
      else if (respectivePage.equalsIgnoreCase("Search Results"))
      {
         packageNavigation.navigateToSearchResultPage();
      }
      else if (respectivePage.equalsIgnoreCase("Unit details"))
      {
         packageNavigation.navigateToUnitDetailsPage();
      }
   }

   @And("the departure airports shall be translated as follows nl:")
   public void the_departure_airports_shall_be_translated_as_follows_nl(
            List<String> expectedDepartureAiports)
   {
      List<String> actualDepartureAirports =
               departureAirportOrDestinationComponent.getMFEAirportText();
      assertEquals("Airport translations do not match", expectedDepartureAiports,
               actualDepartureAirports);
   }

   @And("the {string} is viewing the Search Panel Departure Airport modal via the {string} page")
   public void the_is_viewing_the_Search_Panel_Departure_Airport_modal_via_the_page(String agent,
            String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Home page"))
      {
         packageNavigation.navigateToHoldaySearchPage();
         departureAirportOrDestinationComponent.selectAirportMFE();
      }
      else if (respectivePage.equalsIgnoreCase("Search Results page"))
      {
         packageNavigation.navigateToSearchResultPage();
         departureAirportOrDestinationComponent.selectAirportMFE();
      }
      else if (respectivePage.equalsIgnoreCase("Unit Details page"))
      {
         packageNavigation.navigateToUnitDetailsPage();
         searchResultsPage.editSearch().hover().click();
         departureAirportOrDestinationComponent.selectAirportMFE();
      }
      else if (respectivePage.equalsIgnoreCase("Single accommodation Search Results page"))
      {
         packageNavigation.navigateToSingleAccomSearchResultPage();
         departureAirportOrDestinationComponent.selectAirportMFE();
      }
   }

   @And("they wish to close the Departure Airport modal")
   public void they_wish_to_close_the_Departure_Airport_modal()
   {
      assertTrue("Departure Airports model view is not Displayed",
               departureAirportOrDestinationComponent.getMFEDonePrsent());
   }

   @And("they can do this Departure Airport modal by selecting the following:")
   public void they_can_do_this_Departure_Airport_modal_by_selecting_the_following(
            List<String> closeModal)
   {
      for (String closeDate : closeModal)
      {
         if (closeDate.equalsIgnoreCase("x") || closeDate.equalsIgnoreCase("DONE")
                  || closeDate.equalsIgnoreCase("Select outside of the modal"))
            departureAirportOrDestinationComponent.closeDepartureAirportModalMFE();
      }
   }

   @And("click on any airport")
   public void click_on_any_airport()
   {
      departureAirportOrDestinationComponent.clickOnAnyAirportMFE();
   }

   @And("they select CLEAR ALL")
   public void they_select_CLEAR_ALL()
   {
      departureAirportOrDestinationComponent.clickClearAllAirportMFE();
   }

   @And("the All Airports tick box shall be set to deselected unticked")
   public void the_All_Airports_tick_box_shall_be_set_to_deselected_unticked()
   {
      assertTrue("all airport default state ticked ",
               departureAirportOrDestinationComponent.isAllAirportBoxByDefaultUncheckedMFE());
   }

   @And("all the available departure airports tick boxes shall be set to deselected, including any departure airports that were previously selected")
   public void all_the_available_departure_airports_tick_boxes_shall_be_set_to_deselected_including_any_departure_airports_that_were_previously_selected()
   {
      assertTrue("Each airports default not unchecked ",
               departureAirportOrDestinationComponent.isEachAirportBoxByDefaultUncheckedMFE());
   }

   @And("the Search Panel Departure Airport field shall be set to the default value")
   public void the_Search_Panel_Departure_Airport_field_shall_be_set_to_the_default_value()
   {
      assertTrue("the Search Panel Departure Airport field Not set to the default value ",
               departureAirportOrDestinationComponent.getMFEDefaultAirportValue());
   }

   @And("they have previously entered values in one or more of the search panel entry fields")
   public void they_have_previously_entered_values_in_one_or_more_of_the_search_panel_entry_fields()
   {
      departureAirportOrDestinationComponent.selectAirportMFE();
      departureAirportOrDestinationComponent.clickOnAnyAirportMFE();
      searchPanelComponent.selectRoomAndGuestMFEInputField();
      searchPanelComponent.clickChildrenStepper("+", 1);
   }

   @And("the clear search translations as following:")
   public void the_clear_search_translations_as_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      String actualDefaultText = dataTableTemp.get(getTestExecutionParams().getLocaleStr());
      String expectedDefaultText = departureAirportOrDestinationComponent.getClearSearchText();
      assertEquals("Clear search translation are not correct", expectedDefaultText,
               actualDefaultText);
   }

   @When("they select the clear search link")
   public void they_select_the_clear_search_link()
   {
      departureAirportOrDestinationComponent.clickClearSearch();
   }

   @Then("all the Search Panel fields shall be reset to their default values")
   public void all_the_Search_Panel_fields_shall_be_reset_to_their_default_values(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> maps = dataTable.asMaps();
      String site = getTestExecutionParams().getLocaleStr();
      String expectedDepartureAirport = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Departure Airport")).findFirst().orElse(null);
      String expectedDestinations = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Destination or hotel")).findFirst().orElse(null);
      String expectedDates = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Departure Date")).findFirst().orElse(null);
      String expectedDuration = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Duration")).findFirst().orElse(null);
      String expectedRoomGuest = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Room & Guests")).findFirst().orElse(null);
      String actualAirport = departureAirportOrDestinationComponent.getDefaultAirportText();
      String actualDestination = departureAirportOrDestinationComponent.getMFEDestinationText()
               .getAttribute("placeholder");
      String actualDepartureDate =
               searchPanelComponent.getDefaultDepartureDate().getAttribute("placeholder");
      String actualDuration = departureAirportOrDestinationComponent.getMfeDefaultDurationValue();
      String actualRoomAndGuest =
               searchPanelComponent.getDefaultRoomAndGuest().getAttribute("placeholder");
      softAssert.assertThat(actualAirport).isEqualTo(expectedDepartureAirport);
      softAssert.assertThat(actualDestination).isEqualTo(expectedDestinations);
      softAssert.assertThat(actualDepartureDate).isEqualTo(expectedDates);
      softAssert.assertThat(actualDuration).isEqualTo(expectedDuration);
      softAssert.assertThat(actualRoomAndGuest).isEqualTo(expectedRoomGuest);
      softAssert.assertAll();
   }

   @And("they view the Departure Airports modal")
   public void they_view_the_Departure_Airports_modal()
   {
      assertTrue("Departure Airports model view is not Displayed",
               departureAirportOrDestinationComponent.mfeDepartureAirportsIsPresent());
   }

   @And("all the unavailable departure airports shall be greyed out")
   public void all_the_unavailable_departure_airports_shall_be_greyed_out()
   {
      assertTrue("unavailable Departure Airports are in the greyed out",
               departureAirportOrDestinationComponent.mfeUnavailableAirportsIsGreyedout());
   }

   @And("the customer will not be able to select any of the unavailable departure airports")
   public void the_customer_will_not_be_able_to_select_any_of_the_unavailable_departure_airports()
   {
      assertTrue("unavailable Departure Airports are in the greyed out and able to select",
               departureAirportOrDestinationComponent.mfeUnavailableToSelectAirportsIsGreyedout());
   }

   @Then("all the available airports shall be selectable")
   public void all_the_available_airports_shall_be_selectable()
   {
      departureAirportOrDestinationComponent.clickOnAnyAirportMFE();
   }

   @And("they select the All airports group tick box within the Departure Airports modal")
   public void they_select_the_All_airports_group_tick_box_within_the_Departure_Airports_modal()
   {
      wait.forJSExecutionReadyLazy();
      searchPanel.airport().clearSelection();
      departureAirportOrDestinationComponent.clickOnAnyAirportMFE();
   }

   @And("all the available airports within the All airports group shall be selected")
   public void all_the_available_airports_within_the_All_airports_group_shall_be_selected()
   {
      assertTrue("all airport default state Not ticked ",
               departureAirportOrDestinationComponent.isAllAirportsBoxcheckedMFE());
   }

   @And("the customer will be able to tick or untick any of these selections")
   public void the_customer_will_be_able_to_tick_or_untick_any_of_these_selections()
   {
      assertTrue("the customer will Not able to tick or untick any of these selections",
               departureAirportOrDestinationComponent.canTickUntickSelections());
   }

   @And("the Search Panel Departure Airport field shall show the name of the first airport alphabetically that is available + number more where the number will be equal to the remaining available departure airports")
   public void the_Search_Panel_Departure_Airport_field_shall_show_the_name_of_the_first_airport_alphabetically_that_is_available_number_more_where_the_number_will_be_equal_to_the_remaining_available_departure_airports()
   {
      departureAirportOrDestinationComponent.clickOnAnyAirportMFE();
      String expectedValue =
               departureAirportOrDestinationComponent.getMFEFirstAirportValuePlusRemaining();
      String actualValue = departureAirportOrDestinationComponent.getMFEDeparturesAirports();
      assertEquals("The Search Panel Departure Airport field is not set to the default value.",
               expectedValue, actualValue);
   }

   @And("they select one of the available departure airports")
   public void they_select_one_of_the_available_departure_airports()
   {
      wait.forJSExecutionReadyLazy();
      departureAirportOrDestinationComponent.selectOneDepartureAirportMFE();
   }

   @Then("the Search Panel Departure Airport field shall show the name of the departure airport they selected")
   public void the_Search_Panel_Departure_Airport_field_shall_show_the_name_of_the_departure_airport_they_selected()
   {
      String expectedValue = departureAirportOrDestinationComponent.getMFEOneAirportSelected();
      String actualValue = departureAirportOrDestinationComponent.getMFEDeparturesAirports();
      assertEquals("The Search Panel Departure Airport field is not set to the one airport value.",
               expectedValue, actualValue);
   }

   @Then("the selected airport can be ticked or unticked")
   public void the_selected_airport_can_be_ticked_or_unticked()
   {
      assertTrue("the customer will Not able to tick or untick any of selected airport",
               departureAirportOrDestinationComponent.selectedAirportTickedUntick());
   }

   @And("they had previously selected multiple airports")
   public void they_had_previously_selected_multiple_airports()
   {
      departureAirportOrDestinationComponent.selectMultipleDepartureAirportsMFE();
   }

   @And("they remove the very first airport they selected")
   public void they_remove_the_very_first_airport_they_selected()
   {
      assertTrue("the customer will Not able to untick the first selected airport",
               departureAirportOrDestinationComponent.UnSelectFirstAirport());
   }

   @Then("the Search Panel Departure Airport field shall show the name of the second airport they originally selected")
   public void the_Search_Panel_Departure_Airport_field_shall_show_the_name_of_the_second_airport_they_originally_selected()
   {
      String expectedValue = departureAirportOrDestinationComponent.getMFESecondAirportSelected();
      String[] actualValue =
               departureAirportOrDestinationComponent.getMFEDeparturesAirports().split(" ");
      assertEquals("The Search Panel Departure Airport field is not set to the one airport value.",
               expectedValue, actualValue[0]);
   }

   @Then("it shall show + number more if multiple airports have been selected")
   public void it_shall_show_number_more_if_multiple_airports_have_been_selected()
   {
      String expectedValue =
               departureAirportOrDestinationComponent.getMFEFirstAirportValuePlusRemaining();
      String actualValue = departureAirportOrDestinationComponent.getMFEDeparturesAirports();
      assertEquals("unable to show + number more if multiple airports have been selected",
               expectedValue, actualValue);
   }

   @And("if they have selected one or more departure airports then the selected airports shall be retained on the Departure Airport modal")
   public void if_they_have_selected_one_or_more_departure_airports_then_the_selected_airports_shall_be_retained_on_the_Departure_Airport_modal()
   {
      departureAirportOrDestinationComponent.selectMultipleDepartureAirportsMFE();
   }

   @Then("the Search Panel Departure Airport field shall be populated with the selected departure airports")
   public void the_Search_Panel_Departure_Airport_field_shall_be_populated_with_the_selected_departure_airports()
   {
      assertTrue("Departure Airports field view is not populated with selected airports",
               departureAirportOrDestinationComponent.mfeDepartureAirportsFieldIsPresent());
   }

   @And("they select the {string} clear search link")
   public void theySelectTheClearSearchLink(String respectivePage)
   {
      wait.forJSExecutionReadyLazy();
      if (respectivePage.equalsIgnoreCase("Search Results page") || respectivePage.equalsIgnoreCase(
               "Unit Details page") || respectivePage.equalsIgnoreCase(
               "Single accommodation Search Results page"))
         departureAirportOrDestinationComponent.clickClearSearch();
   }
}
