package uk.co.tui.cdaf.frontend.pom.wr.search_result;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.SearchResultAttributes;

import java.util.List;
import java.util.stream.Collectors;

import static uk.co.tui.cdaf.frontend.utils.SelenideHelper.extractText;

public class SearchResultExtractor
{
   public static SearchResultAttributes extractFromElement(SelenideElement element)
   {
      SearchResultAttributes attributes = new SearchResultAttributes();
      attributes.setProductName(extractText(element, "span.productIdentifier__name"));
      attributes.setAccomodationName(
               extractText(element, "a[aria-label='accomodation name'] > span"));
      attributes.setLocation(extractText(element, "p.ResultListItemV2__location > span"));
      attributes.setGuestReviewRating(extractText(element,
               "div.ResultListItemV2__guestReviewContainer > span.ResultListItemV2__ratingNumber"));
      attributes.setDuration(extractText(element,
               "ul.ResultListItemV2__hotelExtrasItems > li.ResultListItemV2__icon > span"));
      attributes.setRoomDetails(
               extractText(element, "li.ResultListItemV2__roomDetails > span > span"));
      attributes.setFlightName(extractText(element,
               "li.ResultListItemV2__flightDetails > span > span > span.ResultListItemV2__flightName"));
      attributes.setTransfer(extractText(element, "li[aria-label='transfers'] > span"));
      attributes.setCommissionMarkers(extractText(element, "div[aria-label='commission markers']"));
      attributes.setPerPersonPriceValue(extractText(element,
               "div.ResultListItemV2__perPersonPrice > span.ResultListItemV2__value"));
      attributes.setPerPersonPriceCurrency(extractText(element,
               "div.ResultListItemV2__perPersonPrice > span.ResultListItemV2__currency"));
      attributes.setBoardType(extractText(element,
               "div.ResultListItemV2__perPersonPrice > span.ResultListItemV2__boardType"));
      attributes.setTotalPartyPrice(extractText(element, "span.ResultListItemV2__totalParty"));
      attributes.setSpecialOffers(extractText(element, "div.ResultListItemV2__specialOffers"));
      return attributes;
   }

   public static List<SearchResultAttributes> extractFromElements(ElementsCollection elements)
   {
      return elements.asFixedIterable().stream()
               .map(SearchResultExtractor::extractFromElement)
               .collect(Collectors.toList());
   }

}
