package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results;

import com.codeborne.selenide.Condition;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;

public class SearchResultsSingleAccomComponent extends AbstractPage
{

   public boolean singleAccomCalendar()
   {
      return $(".UI__calendar").should(Condition.appear, Duration.ofSeconds(30)).isDisplayed();
   }

}
