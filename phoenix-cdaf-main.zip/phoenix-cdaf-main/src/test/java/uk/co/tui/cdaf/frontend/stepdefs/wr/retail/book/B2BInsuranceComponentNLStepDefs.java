package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class B2BInsuranceComponentNLStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerpage;

   public B2BInsuranceComponentNLStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerpage = new RetailPassengerDetailsPage();
   }

   @Given("that an Third Party agent is on the NL Customise Page")
   public void that_an_Third_Party_agent_is_on_the_NL_Customise_Page()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToExtrasPage();
   }

   @When("they scroll down on Customise Page")
   public void they_scroll_down_on_Customise_Page()
   {
      retailpassengerpage.scrollToInsurence();
   }

   @Then("they will not be presented with the Insurance Component")
   public void they_will_not_be_presented_with_the_Insurance_Component()
   {
      retailpassengerpage.nlTPInsurance();
      retailpassengerpage.selectContinueBookingWR();
      retailpassengerpage.fillRetailPassengerDetails();
      retailpassengerpage.userLogout();
   }

}
