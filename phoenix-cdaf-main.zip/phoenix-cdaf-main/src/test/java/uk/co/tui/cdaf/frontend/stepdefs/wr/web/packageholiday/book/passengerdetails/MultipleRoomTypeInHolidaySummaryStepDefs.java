package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.passengerdetails;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.PassengerDetailsPage;

public class MultipleRoomTypeInHolidaySummaryStepDefs
{

   public final PackageNavigation packageNavigation;

   public PassengerDetailsPage passengerPage;

   public MultipleRoomTypeInHolidaySummaryStepDefs()
   {
      packageNavigation = new PackageNavigation();
      passengerPage = new PassengerDetailsPage();
   }

   @Given("the customer is on the Passenger Details page")
   public void the_customer_is_on_the_Passenger_Details_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @Given("there has been no room upgrade")
   public void there_has_been_no_room_upgrade()
   {
      // Will implement this step once it is available
   }

   @When("the Holiday Summary component is expanded")
   public void the_Holiday_Summary_component_is_expanded()
   {
      passengerPage.multipleRoomTypeInHolidaySummaryComponent.clickOnIconToExpandHolidaySummary();
   }

   @Then("within Room & Board sub section, the number of room types and description will display and show as Included")
   public void within_Room_Board_sub_section_the_number_of_room_types_and_description_will_display_and_show_as_Included()
   {
      passengerPage.multipleRoomTypeInHolidaySummaryComponent.getRoomTypeComps();
   }

   @Given("there have been upgrades to room types with increased price")
   public void there_have_been_upgrades_to_room_types_with_increased_price()
   {
      // Will implement this step once it is available
   }

}
