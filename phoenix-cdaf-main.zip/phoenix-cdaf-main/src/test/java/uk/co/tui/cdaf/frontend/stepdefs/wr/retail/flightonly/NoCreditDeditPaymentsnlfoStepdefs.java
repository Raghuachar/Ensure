package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class NoCreditDeditPaymentsnlfoStepdefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailSearchPanelComponent retailsearchPanelComponent;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final ExtraOptionsPage extraOptionsPage;

   public NoCreditDeditPaymentsnlfoStepdefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailsearchPanelComponent = new RetailSearchPanelComponent();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      extraOptionsPage = new ExtraOptionsPage();
   }

   @Given("that the inhouse agent is on the nlfo payment page")
   public void that_the_inhouse_agent_is_on_the_nlfo_payment_page()
   {
      retailpackagenavigation.retailLogin();
      retailsearchPanelComponent.wrFoOneWaySearch();
      retailsearchPanelComponent.selectFlight();
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
   }

   @When("they view the nlfo payment component")
   public void they_view_the_nlfo_payment_component()
   {
      assertThat(" Credit card or Debit type is not present",
               retailpassengerdetailspage.isCreditDebitTypePresent(), is(false));

   }

   @Then("there is no option for Debit Credit Card available to be selected for nlfo")
   public void there_is_no_option_for_Debit_Credit_Card_available_to_be_selected_for_nlfo()
   {
      retailpassengerdetailspage.retailPayment();
   }

}
