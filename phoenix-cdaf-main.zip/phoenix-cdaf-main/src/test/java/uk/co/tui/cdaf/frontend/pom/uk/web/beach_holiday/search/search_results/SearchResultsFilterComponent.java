package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.List;

public class SearchResultsFilterComponent extends AbstractPage
{
   @FindBy(css = ".BoardBasis__option label input:not(:checked)+span")
   private List<WebElement> boardFilterOptions;

   public List<WebElement> getBoardOptions()
   {
      return boardFilterOptions;
   }
}
