package uk.co.tui.cdaf.frontend.pom.wr.search_result.components;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;

import static com.codeborne.selenide.Selenide.$;

public class DatesAndDurationFilter extends BaseComponent
{

   public void selectRandomDate()
   {
      ElementsCollection allDates = getDates();
      ElementsCollection els = allDates.filter(Condition.not(Condition.checked));
      selectRandomElement(els, "date");
   }

   public void selectRandomDuration()
   {
      ElementsCollection allDurations = getDurations();
      ElementsCollection els = allDurations.filterBy(
               Condition.not(Condition.cssClass("DatesAndDuration__selected")));
      selectRandomElement(els, "duration");
   }

   private ElementsCollection getDurations()
   {
      return $("ul.DatesAndDuration__durationList").$$("li");
   }

   private ElementsCollection getDates()
   {
      return $("ul.DatesAndDuration__datesList").$$("input");
   }
}
