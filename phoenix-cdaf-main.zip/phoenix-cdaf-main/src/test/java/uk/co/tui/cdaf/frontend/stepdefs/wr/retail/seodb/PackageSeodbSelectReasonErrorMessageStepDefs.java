package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageSEODBComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSeodbSelectReasonErrorMessageStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageSeodbSelectReasonErrorMessageStepDefs.class);

   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final PackageSEODBComponents pKgSEODBComponents;

   public PackageSeodbSelectReasonErrorMessageStepDefs()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      pKgSEODBComponents = new PackageSEODBComponents();

   }

   @When("there is a negative discrepancy")
   public void there_is_a_negative_discrepancy()
   {
      LOGGER.log(LogLevel.INFO, "Negative Discrepency is present.");

   }

   @When("they have not selected a reason")
   public void they_have_not_selected_a_reason()
   {

      wait.forJSExecutionReadyLazy();

   }

   @When("have clicked the authorise CTA")
   public void have_clicked_the_authorise_CTA()
   {

      pKgReconcilationPaymentPageComponents.clickAuthoriseCTA();
   }

   @Then("the error message appear")
   public void the_error_message_appear(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Add banking amount error is present",
               pKgSEODBComponents.isSelectReasonErrorMessagePresent(), is(true));
   }
}
