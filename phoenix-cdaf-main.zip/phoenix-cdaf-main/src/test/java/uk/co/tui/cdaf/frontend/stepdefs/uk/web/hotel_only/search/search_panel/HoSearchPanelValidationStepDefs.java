package uk.co.tui.cdaf.frontend.stepdefs.uk.web.hotel_only.search.search_panel;

import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.hotel_only.search.search_panel.HotelOnlySearchPanel;
import uk.co.tui.cdaf.frontend.pom.uk.web.hotel_only.search.search_results.HotelOnlyPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class HoSearchPanelValidationStepDefs
{

   private final HotelOnlyPage hotelOnly;

   private final HotelOnlySearchPanel HoSearchPanel;

   public HoSearchPanelValidationStepDefs()
   {
      hotelOnly = new HotelOnlyPage();
      HoSearchPanel = new HotelOnlySearchPanel();
   }

   @When("they view the search panel")
   public void they_view_the_search_panel()
   {

      assertThat("Search Panel is not present", hotelOnly.isSearchPanelDisplayed(), is(true));
   }

   @When("they select the hotel only recent search")
   public void they_select_the_hotel_only_recent_search()
   {
      HoSearchPanel.clickOnRecentSearchLink();
   }

}
