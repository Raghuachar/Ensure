package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;
import java.util.Map;

public class ImportantInformationComponent extends AbstractPage
{

   @FindBy(css = "[aria-label='important information'] [aria-label*='header']")
   private WebElement impInfoHeading;

   @FindBy(css = "[aria-label='important information'] [class*='imp_info']")
   private WebElement impInfoSubHeading;

   @FindBy(css = "[aria-label='important information'] [aria-label='checkbox']")
   private WebElement impInfoCheckbox;

   @FindBy(css = "[aria-label='important information'] [class*='information']")
   private WebElement impInformationText;

   @SuppressWarnings("serial")
   public Map<String, WebElement> getImpInfoComponents()
   {
      return new HashMap<>()
      {
         {
            put("Important info heading", impInfoHeading);
            put("Important info sub heading", impInfoSubHeading);
            put("Important info checkbox", impInfoCheckbox);
            put("Important information", impInformationText);
         }
      };
   }

}
