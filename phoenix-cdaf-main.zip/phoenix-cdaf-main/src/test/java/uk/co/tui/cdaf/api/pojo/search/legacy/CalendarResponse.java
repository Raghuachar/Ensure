package uk.co.tui.cdaf.api.pojo.search.legacy;

import uk.co.tui.cdaf.api.pojo.search.legacy.calendar.Data;

@lombok.Data
public class CalendarResponse
{
   private String error;

   private int errorCode;

   private Data data;
}
