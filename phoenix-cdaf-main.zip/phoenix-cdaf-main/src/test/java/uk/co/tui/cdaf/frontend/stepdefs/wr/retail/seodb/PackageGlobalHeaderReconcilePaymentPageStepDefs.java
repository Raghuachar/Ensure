package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageGlobalHeaderReconcilePaymentPageStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageGlobalHeaderReconcilePaymentPageStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent is viewing the PKG Reconcile payments page")
   public void that_the_agent_is_viewing_the_PKG_Reconcile_payments_page()
   {
      packagenavigation.retailLoginFO();
      assertThat(" Global Header is not present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
      pKgReconcilationPaymentPageComponents.clickAdminTab();
      pKgReconcilationPaymentPageComponents.clickBankingLink();
      wait.forJSExecutionReadyLazy();
      assertThat(" Global Header is not present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
      wait.forJSExecutionReadyLazy();
   }

}
