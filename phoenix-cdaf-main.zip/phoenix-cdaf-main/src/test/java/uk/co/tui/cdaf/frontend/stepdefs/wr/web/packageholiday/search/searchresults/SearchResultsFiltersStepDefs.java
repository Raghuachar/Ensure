package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.SearchResultsFilterComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsTRatingFilter;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ConfigurationHelper;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.number.OrderingComparison.greaterThan;

public class SearchResultsFiltersStepDefs
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchResultsFiltersStepDefs.class);

   public final PackageNavigation packageNavigation = new PackageNavigation();

   private final SearchResultsFilterComponent filterComponent = new SearchResultsFilterComponent();

   private final SearchResultsTRatingFilter searchResultsTRatingFilter =
            new SearchResultsTRatingFilter();

   private final Map<String, WebElement> searchMap = new HashMap<>();

   public SearchResultsPage searchResultsPage = new SearchResultsPage();

   @Given("the customer is on the package search results page")
   public void the_customer_is_on_the_package_search_results_page()
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @When("they are viewing the Destinations filter")
   public void they_are_viewing_the_Destinations_filter()
   {
      assertThat("NOt able to view destination filter",
               searchResultsPage.destinationFilterComponent.isDestinationFilterDisplayed(),
               is(true));
   }

   @When("they have searched for a specific <destination>")
   public void they_have_searched_for_a_specific_destination()
   {
      assertThat("component is not displayed by clicking back button",
               searchResultsPage.destinationFilterComponent.elementIsDisplayed(), is(true));
   }

   @Then("they will see the following <hierarchy>")
   public void they_will_see_the_following_hierarchy(List<String> filterList)
   {
      for (String headerString : filterList)
      {
         switch (headerString)
         {
            case "Country":
               WebElementTools.isPresent(searchResultsPage.destinationFilterComponent.getCountry());

            case "destination":
               searchResultsPage.destinationFilterComponent.isDestinationDisplayed();

         }
      }
   }

   @Then("the filters will be in an unselected state by default")
   public void the_filters_will_be_in_an_unselected_state_by_default()
   {
      assertThat("Destination filters are not unselected",
               searchResultsPage.destinationFilterComponent.isFilterUnselected(), is(true));
   }

   @When("they select the destination\\/resort filters")
   public void they_select_the_destination_resort_filters()
   {

      searchResultsPage.destinationFilterComponent.selectDestination();

   }

   @Then("they will be able to select {int} or many filters")
   public void they_will_be_able_to_select_or_many_filters(Integer int1)
   {
      searchResultsPage.destinationFilterComponent.getCountry();
   }

   @Then("the results will filter taking into account the selections")
   public void the_results_will_filter_taking_into_account_the_selections()
   {
      boolean status =
               searchResultsPage.destinationFilterComponent.searchResultDestinationVerification();
      String reporting = ReportFormatter.generateReportStatementForComponentCheck(
               "Selected destination ", searchResultsPage.destinationFilterComponent.getActual(),
               searchResultsPage.destinationFilterComponent.getExpected());
      assertThat(reporting, status, is(true));
   }

   @Then("the clear filter links will show")
   public void the_clear_filter_links_will_show()
   {
      searchResultsPage.destinationFilterComponent.isClearFilterLinkDisplayed();
   }

   @Given("the customer has selected a destination\\/resort from the destination filters")
   public void the_customer_has_selected_a_destination_resort_from_the_destination_filters()
   {
      searchResultsPage.destinationFilterComponent.selectDestination();
   }

   @When("they want to deselect more of the selected filters")
   public void they_want_to_deselect_more_of_the_selected_filters()
   {
      searchResultsPage.destinationFilterComponent.isFilterUnselected();
   }

   @When("they select the top hierarchy of the Destinations filter")
   public void they_select_the_top_hierarchy_of_the_Destinations_filter()
   {
      searchResultsPage.destinationFilterComponent.getCountry();
   }

   @Then("all of the lower hierarchy filters will show in a selected state")
   public void all_of_the_lower_hierarchy_filters_will_show_in_a_selected_state()
   {
      searchResultsPage.destinationFilterComponent.isDestinationDisplayed();

   }

   @When("a destination is not available")
   public void a_destination_is_not_available()
   {
      searchResultsPage.destinationFilterComponent.disabledDestination();

   }

   @Then("the customer is not able to select this")
   public void the_customer_is_not_able_to_select_this()
   {
      searchResultsPage.destinationFilterComponent.disabledDestination();
   }

   @Given("the customer is on the packages search results page on a mobile device")
   public void the_customer_is_on_the_packages_search_results_page_on_a_mobile_device()
   {
      if (StringUtils.containsIgnoreCase(ConfigurationHelper.getBrowserDetails(), "mobile"))
      {
         packageNavigation.navigateToSearchResultPage();
      }
   }

   @When("they select the Destinations filter")
   public void they_select_the_Destinations_filter()
   {
      searchResultsPage.destinationFilterComponent.selectDestinationFilter();
   }

   @Then("the destinations modal will open")
   public void the_destinations_modal_will_open()
   {

      String selectedFilter = searchResultsPage.destinationFilterComponent.getSelectedDestination();
      searchResultsPage.destinationFilterComponent.setFilterValue(selectedFilter);
   }

   @Then("the customer can select  many destinations to filter")
   public void the_customer_can_select_many_destinations_to_filter()
   {
      searchResultsPage.destinationFilterComponent.selectDestinationFilter();
   }

   @Given("they are viewing the Modal")
   public void they_are_viewing_the_Modal()
   {
      searchResultsPage.destinationFilterComponent.isModalShown();
   }

   @Then("they can do this by selecting the following")
   public void they_can_do_this_by_selecting_the_following(List<String> components)
   {
      components.forEach(component ->
               searchResultsPage.destinationFilterComponent.verifyFilterClosing(component));
   }

   @Then("the search results will filter to reflect the selection made")
   public void the_search_results_will_filter_to_reflect_the_selection_made()
   {
      assertThat("results not updated:",
               searchResultsPage.destinationFilterComponent.verifyFilteredResults(), is(true));
   }

   @Then("the filter will show in a selected state")
   public void the_filter_will_show_in_a_selected_state()
   {
      searchResultsPage.destinationFilterComponent.selectMobileDestinationFilter();
   }

   @Given("they have filtered the Destinations")
   public void they_have_filtered_the_Destinations()
   {
      boolean status =
               searchResultsPage.destinationFilterComponent.searchResultDestinationVerification();
      String reporting = ReportFormatter.generateReportStatementForComponentCheck(
               "Selected destination ", searchResultsPage.destinationFilterComponent.getActual(),
               searchResultsPage.destinationFilterComponent.getExpected());
      assertThat(reporting, status, is(true));
   }

   @When("they want to clear the destinations filter selections")
   public void they_want_to_clear_the_destinations_filter_selections()
   {
      searchResultsPage.destinationFilterComponent.isClearFilterLinkDisplayed();

   }

   @Then("they will be able to clear")
   public void they_will_be_able_to_clear()
   {
      searchResultsPage.destinationFilterComponent.isClearFilterLinkClicked();
   }

   @When("they want to clear the selections")
   public void they_want_to_clear_the_selections()
   {
      searchResultsPage.destinationFilterComponent.isClearAllFilter();
   }

   @Then("they will be able select clear from the destinations modal")
   public void they_will_be_able_select_clear_from_the_destinations_modal()
   {
      searchResultsPage.destinationFilterComponent.clearAllFilter();

   }

   @When("they are viewing the Board Filter")
   public void they_are_viewing_the_Board_Filter()
   {
      assertThat("Filterpanel component is not present",
               searchResultsPage.searchResultsFiltersComponent.isBoardBasisDisplayed(), is(true));
   }

   @Then("they will see the following board basis that they can filter by")
   public void they_will_see_the_following_board_basis_that_they_can_filter_by(
            List<String> expectedBoardFilters)
   {
      List<String> actualBoardFilters =
               searchResultsPage.searchResultsFiltersComponent.getListOfBoardFilterNames();
      assertThat(actualBoardFilters, everyItem(is(in(expectedBoardFilters))));
   }

   @And("these will be in an unselected state by default")
   public void these_will_be_in_an_unselected_state_by_default()
   {

      assertThat("Board Basis List component is not displayed",
               filterComponent.getBoardOptions().size(), greaterThan(0));
   }

   @When("they select a board basis")
   public void they_select_a_board_basis()
   {
      searchResultsPage.searchResultsFiltersComponent.selectBoardBasis(0);
   }

   @Then("they can select 1 to many board basis")
   public void they_can_select_1_to_many_board_basis() throws Exception
   {
      LOGGER.log(LogLevel.INFO, searchResultsPage.searchResultsFiltersComponent.hoildayResults());
      searchResultsPage.searchResultsFiltersComponent.selectBoardBasis(0);
   }

   @And("the search results will filter to reflect the selection")
   public void the_search_results_will_filter_to_reflect_the_selection()
   {
      searchResultsPage.searchResultsFiltersComponent.verifyBoardBasisSearchResults();
      LOGGER.log(LogLevel.INFO, searchResultsPage.searchResultsFiltersComponent.hoildayResults());
      assertThat("search results will filter to reflect the selection",
               searchResultsPage.searchResultsFiltersComponent.verifyBoardBasisSearchResults(),
               is(true));
   }

   @And("the clear {string} filters links will show")
   public void the_clear_filters_links_will_show(String filterPanel)
   {
      assertThat("clear filters links  is not present",
               searchResultsPage.searchResultsFiltersComponent.isClearLinkisDisplayed(),
               is(true));
   }

   @When("they want to clear the board basis selections")
   public void they_want_to_clear_the_board_basis_selections()
   {
      they_select_a_board_basis();
   }

   @Then("they will be able select to clear")
   public void they_will_be_able_select_to_clear()
   {
      assertThat("clear filters links  is not present",
               searchResultsPage.searchResultsFiltersComponent.isClearLinkisDisplayed(), is(true));
      assertThat("clear All filters links  is not present",
               searchResultsPage.searchResultsFiltersComponent.isClearAllLinkisDisplayed(),
               is(true));
      searchResultsPage.searchResultsFiltersComponent.clickClearAllFilter();

   }

   @When("they select the board basis filter")
   public void they_select_the_board_basis_filter()
   {
      searchResultsPage.searchResultsFiltersComponent.clickOnBoardBasisFilter();
   }

   @And("the customer can select 1 or many basis they wish to filter by")
   public void the_customer_can_select_1_or_many_basis_they_wish_to_filter_by()
   {

      searchResultsPage.searchResultsFiltersComponent.selectBoardBasis(0);
      searchResultsPage.searchResultsFiltersComponent.clickApplyButton();

   }

   @Then("the filter options will open in a modal")
   public void the_filter_options_will_open_in_a_modal()
   {
      assertThat("Open in a model is not present",
               searchResultsPage.searchResultsFiltersComponent.isOpenmodelisDisplayed(), is(true));
   }

   @Then("the more filter options will open in a modal")
   public void the_more_filter_options_will_open_in_a_modal()
   {
      assertThat("Open in a model is not present",
               searchResultsPage.searchResultsFiltersComponent.isOpenmodelMoreisDisplayed(),
               is(true));
   }

   @And("they are viewing the Board Filter modal")
   public void they_are_viewing_the_Board_Filter_modal()
   {
      assertThat("Filterpanel component is not present",
               searchResultsPage.searchResultsFiltersComponent.isBoardBasisDisplayed(), is(true));
      searchResultsPage.searchResultsFiltersComponent.clickOnBoardBasisFilter();
      searchResultsPage.searchResultsFiltersComponent.selectBoardBasis(0);
   }

   @Then("they can do this by {string} selecting the following")
   public void they_can_do_this_by_selecting_the_following(String selection,
            List<String> components)
   {
      if (selection.equalsIgnoreCase("board"))
         components.forEach(component ->
                  assertThat("close options not available:",
                           searchResultsPage.searchResultsFiltersComponent.closeModal(component),
                           is(true)));
      if (selection.equalsIgnoreCase("flight") || selection.equalsIgnoreCase("price"))
         components.forEach(component ->
                  assertThat("close options not available:",
                           searchResultsPage.searchResultsFiltersComponent.closeModelMoreFilter(
                                    component),
                           is(true)));
   }

   @And("the search results will {string} filter to reflect the selection made")
   public void the_search_results_will_filter_to_reflect_the_selection_made(String applyButton)
   {
      if (applyButton.equalsIgnoreCase("board"))
         searchResultsPage.searchResultsFiltersComponent.clickApplyButton();
      if (applyButton.equalsIgnoreCase("flight"))
         searchResultsPage.searchResultsFiltersComponent.clickApplyMoreButton();
      if (applyButton.equalsIgnoreCase("facilities"))
         searchResultsPage.searchResultsFiltersComponent.clickApplyMoreButton();
      if (applyButton.equalsIgnoreCase("flight"))
      {
         searchResultsPage.searchResultsFiltersComponent.clickFlightInfo("going out");
      }
      else if (applyButton.equalsIgnoreCase("board"))
      {
         searchResultsPage.searchResultsFiltersComponent.verifyBoardBasisSearchResults();
         LOGGER.log(LogLevel.INFO,
                  searchResultsPage.searchResultsFiltersComponent.hoildayResults());
         assertThat("search results will filter to reflect the selection",
                  searchResultsPage.searchResultsFiltersComponent.verifyBoardBasisSearchResults(),
                  is(true));
      }
   }

   @Then("they will be able select clear from the Board Basis modal")
   public void they_will_be_able_select_clear_from_the_Board_Basis_modal()
   {
      searchResultsPage.searchResultsFiltersComponent.clickClearBoardBasis();
   }

   @And("they have {string} filtered the results")
   public void they_have_filtered_the_results(String filter)
   {
      if (filter.equalsIgnoreCase("board"))
      {
         assertThat("Filterpanel component is not present",
                  searchResultsPage.searchResultsFiltersComponent.isBoardBasisDisplayed(),
                  is(true));
         searchResultsPage.searchResultsFiltersComponent.clickOnBoardBasisFilter();
         searchResultsPage.searchResultsFiltersComponent.selectBoardBasis(0);
      }
      if (filter.equalsIgnoreCase("flight"))
      {
         searchResultsPage.searchResultsFiltersComponent.clickMoreFilters();
         searchResultsPage.searchResultsFiltersComponent.clickDepartureTime("going out");
      }

   }

   @Then("they will be able select {string} Clear all from the {string} modal")
   public void they_will_be_able_select_Clear_all_from_the_modal(String filter, String moreFilter)
   {
      if (filter.equalsIgnoreCase("board"))
      {
         assertThat("Compare Board basis text  component on search results is not present",
                  searchResultsPage.searchResultsFiltersComponent.moreFiltersTextCompare(
                           moreFilter),
                  is(true));
         searchResultsPage.searchResultsFiltersComponent.clickMoreFilters();
         searchResultsPage.searchResultsFiltersComponent.clearAllModel();
      }
      else if (filter.equalsIgnoreCase("flight") || filter.equalsIgnoreCase("price"))
      {
         searchResultsPage.searchResultsFiltersComponent.clearAllModel();
      }
   }

   @When("they are viewing the Flights filter")
   public void they_are_viewing_the_Flights_filter()
   {
      searchResultsPage.searchResultsFiltersComponent.isFilterisDisplayed();
   }

   @Then("they will see the following")
   public void they_will_see_the_following(List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchResultsFiltersComponent.getFlightFilterComponents());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("they want to filter by Departure Point")
   public void they_want_to_filter_by_Departure_Point()
   {
      assertThat("Filterpanel component is not present",
               searchResultsPage.searchResultsFiltersComponent.isDeparturePointPresent(), is(true));
   }

   @Then("they will be able to select 1 or many from a list based on what the customer searched for")
   public void Then_they_will_be_able_to_select_1_or_many_from_a_list_based_on_what_the_customer_searched_for()
   {
      searchResultsPage.searchResultsFiltersComponent.clickOnDeparturePoint();
   }

   @And("the results will filter to reflect this")
   public void the_results_will_filter_to_reflect_this()
   {
      LOGGER.log(LogLevel.INFO,
               searchResultsPage.searchResultsFiltersComponent.departurePointText());
      assertThat("Filterpanel component is not present",
               searchResultsPage.searchResultsFiltersComponent.verifingDeparturePointinSearchResults(),
               is(true));
   }

   @When("a filter item is unavailable")
   public void a_filter_item_is_unavailable()
   {
      assertThat("Filterpanel component is not present",
               searchResultsPage.searchResultsFiltersComponent.isFlightFliterGreyedOut(), is(true));
   }

   @Then("the filter will be greyed out")
   public void the_filter_will_be_greyed_out()
   {
      a_filter_item_is_unavailable();
   }

   @And("the customer will not be able to select these")
   public void the_customer_will_not_be_able_to_select_these()
   {
      try
      {
         searchResultsPage.searchResultsFiltersComponent.clickFlightFliterGreyedOut();
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.INFO, "Unable to click Greyed Out element");
      }
   }

   @When("they want to filter by Departure time {string}")
   public void they_want_to_filter_by_Departure_time(String going)
   {
      if (going.equalsIgnoreCase("going out"))
         assertThat("Filterpanel component is not present",
                  searchResultsPage.searchResultsFiltersComponent.departureTime("going out"),
                  is(true));
      if (going.equalsIgnoreCase("coming back"))
         assertThat("Filterpanel component is not present",
                  searchResultsPage.searchResultsFiltersComponent.departureTime("coming back"),
                  is(true));
   }

   @Then("they will be able to select 1 or many from the {string} following")
   public void they_will_be_able_to_select_1_or_many_from_the_following(String departure,
            List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchResultsFiltersComponent.getDepartureTime(departure));
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });

      if (departure.equalsIgnoreCase("going out"))
         searchResultsPage.searchResultsFiltersComponent.clickDepartureTime(departure);
      if (departure.equalsIgnoreCase("coming back"))
         searchResultsPage.searchResultsFiltersComponent.clickDepartureTime(departure);
   }

   @And("the results {string} will filter to reflect this")
   public void the_results_will_filter_to_reflect_this(String reflect)
   {
      if (reflect.equalsIgnoreCase("going out"))
      {
         searchResultsPage.searchResultsFiltersComponent.clickFlightInfo(reflect);
         searchResultsPage.searchResultsFiltersComponent.clickflightInfoCloseButton();
      }
      if (reflect.equalsIgnoreCase("coming back"))
      {
         searchResultsPage.searchResultsFiltersComponent.clickFlightInfo(reflect);
         searchResultsPage.searchResultsFiltersComponent.clickflightInfoCloseButton();
      }
   }

   @When("they select the {string} filter")
   public void they_select_the_filter(String moreFilter)
   {
      assertThat("Compare more filter component on search results is not present",
               searchResultsPage.searchResultsFiltersComponent.moreFiltersTextCompare(moreFilter),
               is(true));
      searchResultsPage.searchResultsFiltersComponent.clickMoreFilters();
   }

   @And("the customer can select the filters they wish to filter by including Flights")
   public void the_customer_can_select_the_filters_they_wish_to_filter_by_including_Flights()
   {
      searchResultsPage.searchResultsFiltersComponent.clickOnDeparturePoint();
      searchResultsPage.searchResultsFiltersComponent.clickDepartureTime("going out");
   }

   @When("they wish to close the modal")
   public void they_wish_to_close_the_modal()
   {
      searchResultsPage.searchResultsFiltersComponent.clickDepartureTime("going out");
   }

   @And("if selections have been made, the filter will show in a selected state")
   public void if_selections_have_been_made_the_filter_will_show_in_a_selected_state()
   {
      assertThat("more filter will not show as a selected state",
               searchResultsPage.searchResultsFiltersComponent.isFlightSelectedState(), is(true));
   }

   @When("they want to {string} clear the filter selection")
   public void they_want_to_clear_the_filter_selection(String string)
   {
      searchResultsPage.searchResultsFiltersComponent.clickClearLink();
   }

   @Then("they will be able select clear from the {string} modal")
   public void they_will_be_able_select_clear_from_the_modal(String string)
   {
      searchResultsPage.searchResultsFiltersComponent.clearAllModel();
   }

   @When("a basis is not available")
   public void a_basis_is_not_available()
   {
      searchResultsTRatingFilter.changeFiveTRating();
   }

   @Then("this will be greyed out")
   public void this_will_be_greyed_out()
   {
      searchResultsPage.searchResultsFiltersComponent.isBoardBasisDisableState();
   }

   @And("the customer will not be able to select the basis")
   public void the_customer_will_not_be_able_to_select_the_basis()
   {
      try
      {
         searchResultsPage.searchResultsFiltersComponent.clickFlightFliterGreyedOut();
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.INFO, "Unable to click Greyed Out element");
      }
   }

}
