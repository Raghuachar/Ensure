package uk.co.tui.cdaf.frontend.pom.wr.web.vip.browse.homepage;

import uk.co.tui.cdaf.frontend.utils.AbstractPage;

public class HomePage extends AbstractPage
{

}
