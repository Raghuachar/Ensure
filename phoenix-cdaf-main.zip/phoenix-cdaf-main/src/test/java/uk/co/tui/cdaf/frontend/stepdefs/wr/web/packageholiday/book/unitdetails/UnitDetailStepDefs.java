package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.unitdetails;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.api.requests.search.PackageSearchApi;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.unit_details.AccommodationInfoPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.*;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class UnitDetailStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(UnitDetailStepDefs.class);

   public final UnitDetailsPage unitDetailsPage = new UnitDetailsPage();

   public final ProgressionbarNavigationComponent progressbarComponent =
            new ProgressionbarNavigationComponent();

   public final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent =
            new DepartureAirportAndDestinationAndDatesComponent();

   private final WebElementWait wait = new WebElementWait();

   private final Map<String, WebElement> unitMap = new HashMap<>();

   private final AccomodationComponent accomodationComponent = new AccomodationComponent();

   private final PackageNavigation packageNavigation = new PackageNavigation();

   private final HeroBannerComponent heroBannerComponent = new HeroBannerComponent();

   private final RoomComponent roomComponent = new RoomComponent();

   private final PackageSoldOutErrorPage soldOutPage = new PackageSoldOutErrorPage();

   private final SearchPanelComponent searchPanelComponent = new SearchPanelComponent();

   private final SearchResultsComponent searchResultsComponent = new SearchResultsComponent();

   AccommodationInfoPage unitDetailsaccommodation = new AccommodationInfoPage();

   private String totalPrice;

   private String boardUpgrades;

   private String siteId;

   @And("the following components should be dislayed in hotel details page")
   public void the_following_components_should_be_dislayed_in_hotel_details_page(
            List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      unitMap.putAll(unitDetailsPage.progressbarComponent.getProgressionBarComponents());
      unitMap.putAll(unitDetailsPage.accomComponent.getAccomComponents());
      unitMap.putAll(unitDetailsPage.heroBannerComponent.getHeroBannerComponents());
      unitMap.putAll(unitDetailsPage.roomComponent.getRoomComponents());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = unitMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they select continue button and navigated to customize summary page")
   public void they_select_continue_button_and_navigated_to_customize_summary_page()
   {
      unitDetailsPage.progressbarComponent.clickOnContinueButton();
   }

   @And("the Hotel details page will be displayed")
   public void the_customise_Holiday_page_will_be_displayed()
   {
      unitDetailsPage.isHotelDetailsPageDisplayed();
   }

   @And("user can compare search results values with unit details")
   public void user_can_compare_search_results_values_with_unit_details()
   {
      String unitDetailsValues;
      HashMap<String, String> searchValues = searchStoreValues.getSearchValues();
      unitDetailsValues = unitDetailsPage.progressbarComponent.getHotelNameElement();
      assertThat("Hotel Name is not matched with unit details page",
               searchValues.get("Hotel Name").trim(), equalToIgnoringCase(unitDetailsValues));
   }

   @Then("the following information will be shown as in the design:")
   public void the_following_information_will_be_shown_as_in_the_design(List<String> ignore)
   {

      // TODO: this should be checked with hotels that has specific concept (for example "Time To Smile")
      //    assertTrue("ConceptLabel not displayed",
      //       accomodationComponent.validateUnitPageHeaderConceptLabel().isDisplayed());
      assertTrue("Geo information not displayed", accomodationComponent.isGeoInformation());
   }

   @Given("a Customer is on the unit details page via API")
   public void navigateToUnitDetailsViaApi()
   {
      PackageSearchApi.openSearchResultsPage();
      searchResultsComponent.selectFirstAvailableResultCard();
   }

   @Given("a {string} is on the unit details page")
   public void a_is_on_the_unit_details_page(String ignore)
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @When("they view the image gallery")
   public void viewGallery()
   {
      assertTrue("Gallery Not Available", heroBannerComponent.getPageGalleryTitle().isDisplayed());
   }

   @Then("the image will be presented in the order that they are given in the contentAPI")
   public void galleryImageInOrder()
   {
      assertTrue("Gallery Images Not in Order", heroBannerComponent.isImageInOrder());
   }

   @And("the first image that displays on the page is the image at order 1 in the contentAPI")
   public void firstImageDisplay()
   {
      assertTrue("Gallery Image is not first", heroBannerComponent.getHeroBannerImageCount());
   }

   @When("they view the room type description & image")
   public void they_view_the_room_type_description_image()
   {
      assertTrue("room not contains description & image", roomComponent.getRoomItemContainer().isDisplayed());
   }

   @And("an image for the selected room type is available")
   public void an_image_for_the_selected_room_type_is_available()
   {
      assertThat("room contains no image", roomComponent.isRoomImagePresent(), is(true));
   }

   @And("an image for the selected room type is NOT available")
   public void an_image_for_the_selected_room_type_is_not_available()
   {
      assertThat("room contains image", roomComponent.isImagePlaceholder(), is(true));
   }

   @Then("the following information will be seen:")
   public void the_following_information_will_be_seen(List<String> listString)
   {
      for (String roomString : listString)
      {
         if (roomString.equalsIgnoreCase("Room type description"))
         {
            assertTrue("room not contains image", roomComponent.getFirstRoomTitle().isDisplayed());
         }
         else if (roomString.equalsIgnoreCase("Room type image"))
         {
            assertThat("room not contains image", roomComponent.isRoomImagePresent(), is(true));
         }
         else if (roomString.equalsIgnoreCase("Room type information text"))
         {
            assertTrue("room not contains information", roomComponent.getRoomInfoContent().isDisplayed());
         }
         else if (roomString.equalsIgnoreCase("Room type image placeholder"))
         {
            assertThat("room not contains information", roomComponent.isImagePlaceholder(),
                     is(true));
         }
      }
   }

   @Then("the following information will be shown as in the design part:")
   public void the_following_information_will_be_shown_as_in_the_design_part(DataTable ignore)
   {
      SoftAssertions softly = new SoftAssertions();
      softly.assertThat(unitDetailsaccommodation.getAccommodationHeader().isDisplayed())
               .as("Hotel name component is not displayed").isTrue();
      softly.assertThat(unitDetailsaccommodation.getAccomodationRating().isDisplayed())
               .as("TRating component is not displayed").isTrue();
      softly.assertAll();
   }

   @When("they are viewing the overview tab of the page")
   public void they_are_viewing_the_overview_tab_of_the_page()
   {
      accomodationComponent.getAccomComponents();
   }

   @Then("following informations will be shown as in the design of accommodation:")
   public void the_following_informations_will_be_shown_as_in_the_design(List<String> ignore)
   {
      SoftAssertions softly = new SoftAssertions();
      softly.assertThat(accomodationComponent.isaccommodationDescription())
               .as("Official rating component is not displayed").isTrue();
      softly.assertThat(accomodationComponent.isaccommodationUSPs())
               .as("Accommodation USP's component is not displayed").isTrue();
      softly.assertThat(accomodationComponent.isofficialRating())
               .as("Accommodation Description component is not displayed").isTrue();
      softly.assertAll();
   }

   @And("the hotel details page should be displayed")
   public void the_hotel_details_page_should_be_displayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forComplexPageLoad();
      boolean isDisplayed = unitDetailsPage.accomComponent.isHotelNamedisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Hotel details page wasn't displayed", isDisplayed, true), isDisplayed, is(true));
   }

   @And("Navigate back to unit details page")
   public void navigate_back_to_unit_details_page()
   {
      unitDetailsPage.progressbarComponent.ClickOnBackToUnitDetailspage();
   }

   @And("the Your Board component shall display the following:")
   public void the_Your_Board_component_shall_display_the_following(List<String> boardComponents)
   {
      for (String boardBasis : boardComponents)
      {
         if (boardBasis.equalsIgnoreCase("A board basis icon"))
            assertThat("BoardBasis icon is not present",
                     unitDetailsPage.boardBasisComponent.boardBasisIconIsPresent(), is(true));
         if (boardBasis.equalsIgnoreCase("A 'YOUR BOARD' title"))
            assertThat("BoardBasis Title is not present",
                     unitDetailsPage.boardBasisComponent.boardBasisTitleIsPresent(), is(true));
         if (boardBasis.equalsIgnoreCase(
                  "A board basis card for each available board basis returned from inventory"))
            assertThat("BoardBasis cards is not present",
                     unitDetailsPage.boardBasisComponent.boardBasisCardsIsPresent(), is(true));
      }
   }

   @And("they are ordered in ascending price order")
   public void they_are_ordered_in_ascending_price_order()
   {
      unitDetailsPage.boardBasisComponent.getBoardBasisUpgrades();
   }

   @And("alternative board basis are available for the accommodation on the selected package")
   public void alternative_board_basis_are_available_for_the_accommodation_on_the_selected_package()
   {
      throw new PendingException();
   }

   @And("they are viewing the YOUR BOARD component")
   public void they_are_viewing_the_YOUR_BOARD_component()
   {
      assertThat("Your Board component is not present",
               unitDetailsPage.boardBasisComponent.isBoardBasisComponentDisplayed(), is(true));
   }

   @When("more than one boards basis is available and choose the {string} button")
   public void more_than_one_boards_basis_is_available_and_choose_the_button(String string)
   {
      if (!StringUtils
               .isEmpty(unitDetailsPage.boardBasisComponent.isAlternativeBoardBasisDisplayed()))
      {
         unitDetailsPage.boardBasisComponent.clickOnAlternativeBoardBasis();
         totalPrice = unitDetailsPage.boardBasisComponent.getTotalPriceText();
      }
      else
         assertThat("Alternative rooms are not available", false, is(true));
   }

   @Then("the chosen alternative board basis card shall be set to SELECTED")
   public void the_chosen_alternative_board_basis_card_shall_be_set_to_SELECTED()
   {
      assertThat("Your Board component is not present",
               unitDetailsPage.boardBasisComponent.isboardUgradeLabelSelectedDisplayed(), is(true));

   }

   @Then("the total price and per person prices in the Price component shall be updated to reflect the chosen alternative board basis price")
   public void the_total_price_and_per_person_prices_in_the_Price_component_shall_be_updated_to_reflect_the_chosen_alternative_board_basis_price()
   {
      LOGGER.log(LogLevel.INFO,
               "Before Total price value :" + totalPrice + "After Total price value :"
                        + unitDetailsPage.boardBasisComponent.getTotalPriceText());
      assertThat("Total price is not updated",
               totalPrice.equalsIgnoreCase(unitDetailsPage.boardBasisComponent.getTotalPriceText()),
               is(true));
   }

   @Then("the previously selected board basis card shall display the total price difference, the per person price difference & the select button")
   public void the_previously_selected_board_basis_card_shall_display_the_total_price_difference_the_per_person_price_difference_the_select_button()
   {
      LOGGER.log(LogLevel.INFO,
               "the previously selected board basis card shall display the total price difference"
                        + unitDetailsPage.boardBasisComponent.getBoardBasisPriceText());
   }

   @And("they have selected an alternative board basis card")
   public void they_have_selected_an_alternative_board_basis_card()
   {
      if (!StringUtils
               .isEmpty(unitDetailsPage.boardBasisComponent.isAlternativeBoardBasisDisplayed()))
      {
         unitDetailsPage.boardBasisComponent.clickOnAlternativeBoardBasis();
         totalPrice = unitDetailsPage.boardBasisComponent.getTotalPriceText();
         boardUpgrades = unitDetailsPage.boardBasisComponent.getBoardUpgradesBoardNameText();
      }
      else
         assertThat("Alternative board basis are not available", false, is(true));
   }

   @When("they navigate to the Accommodation Options spoke")
   public void they_navigate_to_the_Accommodation_Options_spoke()
   {
      progressbarComponent.clickOnContinueButton();
      unitDetailsPage.boardBasisComponent.clickOnRoomAndBoardLink();
   }

   @Then("the board basis card they selected on the Unit Details page is highlighted as the selected option")
   public void the_board_basis_card_they_selected_on_the_Unit_Details_page_is_highlighted_as_the_selected_option()
   {
      String boardUpgradesExpected =
               unitDetailsPage.boardBasisComponent.getBoardUpgradesBoardNameText();
      assertThat("Alternative board basis  are not upgraded in spoke page",
               boardUpgradesExpected.equals(boardUpgrades), is(true));
   }

   @And("the prices displayed within the price component reflect the price of the selected board basis")
   public void the_prices_displayed_within_the_price_component_reflect_the_price_of_the_selected_board_basis()
   {
      assertThat("Prices are not updates in spoke page",
               totalPrice.contains(unitDetailsPage.boardBasisComponent.getTotalPriceText()),
               is(true));
   }

   @Given("the {string} is on the Accommodation Options spoke")
   public void the_is_on_the_Accommodation_Options_spoke(String string)
   {
      packageNavigation.navigateToSummaryPage();
      unitDetailsPage.boardBasisComponent.clickOnRoomAndBoardLink();
   }

   @When("they navigate back to the Unit Details page")
   public void they_navigate_back_to_the_Unit_Details_page()
   {
      unitDetailsPage.boardBasisComponent.clickOnBackToYourHoildayLink();
      unitDetailsPage.boardBasisComponent.clickOnBackToPreviousPageLink();
   }

   @Then("the board basis card they applied on the Accommodation Options spoke is highlighted as the selected option")
   public void the_board_basis_card_they_applied_on_the_Accommodation_Options_spoke_is_highlighted_as_the_selected_option()
   {
      String boardUpgradesExpected =
               unitDetailsPage.boardBasisComponent.getBoardUpgradesBoardNameText();
      assertThat("Alternative board basis  are not upgraded in spoke page",
               boardUpgradesExpected.equals(boardUpgrades), is(true));
   }

   @When("they click on {string} CTA.")
   public void they_click_on_CTA(String string)
   {
      soldOutPage.selectHomePageButton();
   }

   @Then("a modal displaying additional content related to that board basis \\(e.g. what is included for breakfast, what drinks are included, etc...) shall be displayed")
   public void a_modal_displaying_additional_content_related_to_that_board_basis_e_g_what_is_included_for_breakfast_what_drinks_are_included_etc_shall_be_displayed()
   {
      assertThat("Board Details modal is not Displayed",
               unitDetailsPage.boardBasisComponent.isBoardDetailsModalDisplayed(), is(true));

   }

   @Given("the {string} link is displayed in your board component")
   public void the_link_is_displayed_in_your_board_component(String string)
   {
      unitDetailsPage.boardBasisComponent.isBoardBasisShoworeLinkDisplayed();
   }

   @When("the select {string} link in your board component")
   public void the_select_link_in_your_board_component(String string)
   {
      unitDetailsPage.boardBasisComponent.clickOnBoardBasisShoworeLink();
   }

   @Given("they are viewing an additional board basis content modal")
   public void they_are_viewing_an_additional_board_basis_content_modal()
   {
      unitDetailsPage.boardBasisComponent.clickOnBoardBasisShoworeLink();
      unitDetailsPage.boardBasisComponent.isBoardDetailsModalDisplayed();
   }

   @Then("the board basis card containing the board basis name & all the board basis meal options shall be redisplayed")
   public void the_board_basis_card_containing_the_board_basis_name_all_the_board_basis_meal_options_shall_be_redisplayed()
   {

      assertThat("board basis card is not Displayed",
               unitDetailsPage.boardBasisComponent.isBoardBasisComponentDisplayed(), is(true));
   }

   @Then("the customer will be positioned to the board basis card they were previously viewing & selected the {string} link from")
   public void the_customer_will_be_positioned_to_the_board_basis_card_they_were_previously_viewing_selected_the_link_from(
            String string)
   {
      assertThat("Board Basis Showore Link is not Displayed",
               unitDetailsPage.boardBasisComponent.isBoardBasisShoworeLinkDisplayed(), is(true));
   }

   @When("they close the BoardDetailsmodal")
   public void they_close_the_BoardDetailsmodal()
   {
      unitDetailsPage.boardBasisComponent.clickOnBoardDetailsModalCloseX();
   }

   @Given("they are viewing a board basis card in the YOUR BOARD component")
   public void they_are_viewing_a_board_basis_card_in_the_YOUR_BOARD_component()
   {
      unitDetailsPage.boardBasisComponent.isBoardBasisCardDisplayed();
   }

   @Then("the board basis card shall expand")
   public void the_board_basis_card_shall_expand()
   {
      assertThat("Board Basis card shall not expanded ",
               unitDetailsPage.boardBasisComponent.isBoardCardShallExpanded(), is(true));

   }

   @Then("additional content related to that board basis shall be displayed \\(e.g. what is included for breakfast, what drinks are included, etc...)")
   public void additional_content_related_to_that_board_basis_shall_be_displayed_e_g_what_is_included_for_breakfast_what_drinks_are_included_etc()
   {
      assertThat("Board Basis Showore Link is not Displayed",
               unitDetailsPage.boardBasisComponent.isBoardBasisShallDisplayed(), is(true));
   }

   @Then("the {string} accordion shall be displayed")
   public void the_accordion_shall_be_displayed(String string)
   {
      unitDetailsPage.boardBasisComponent.isBoardCardShallExpanded();
   }

   @When("they select the {string} accordion in the YOUR BOARD component")
   public void they_select_the_accordion_in_the_YOUR_BOARD_component(String string)
   {
      unitDetailsPage.boardBasisComponent.clickOnBoardBasisShoworeLink();
   }

   @And("they are viewing an expanded board basis card in the YOUR BOARD component")
   public void they_are_viewing_an_expanded_board_basis_card_in_the_YOUR_BOARD_component()
   {
      unitDetailsPage.boardBasisComponent.clickOnBoardBasisShoworeLink();
      unitDetailsPage.boardBasisComponent.isBoardCardShallExpanded();
   }

   @Then("the board basis card shall collapse")
   public void the_board_basis_card_shall_collapse()
   {
      assertThat("the board basis card shall not collapsed",
               unitDetailsPage.boardBasisComponent.isBoardBasisShoworeLinkDisplayed(), is(true));
   }

   @When("the select the {string} accordion")
   public void the_select_the_accordion(String string)
   {
      unitDetailsPage.boardBasisComponent.clickOnBoardBasisShowLessLink();
   }

   @Then("the board basis card collapsed view \\(including the board basis name, all the board basis meal options & the {string} accordion) shall be displayed")
   public void the_board_basis_card_collapsed_view_including_the_board_basis_name_all_the_board_basis_meal_options_the_accordion_shall_be_displayed(
            String string)
   {
      assertThat("the board basis card shall collapsed view not dispalyed   ",
               unitDetailsPage.boardBasisComponent.isBoardBasisShoworeLinkDisplayed(), is(true));
      unitDetailsPage.boardBasisComponent.boardBasisCardComponents();
   }

   @And("the Unit Details Legacy Message switch is set to On")
   public void the_Unit_Details_Legacy_Message_switch_is_set_to_On()
   {
      assertTrue("the Unit Details Legacy Message switch is not On",
               unitDetailsPage.islegacyMessageDisplayed());
   }

   @And("the Unit Details Legacy Message switch is set to Off")
   public void the_Unit_Details_Legacy_Message_switch_is_set_to_Off()
   {
      assertTrue("the Unit Details Legacy Message switch is not On",
               unitDetailsPage.islegacyMessageDisplayed());
   }

   @When("they view the Unit Details page")
   public void they_view_the_Unit_Details_page()
   {
      assertTrue(unitDetailsPage.accomadationNameDisplayed());
   }

   @Then("the Unit Details legacy message shall not be displayed")
   public void the_Unit_Details_legacy_message_shall_not_be_displayed()
   {
      assertFalse("the Unit Details legacy message shall not be displayed",
               (unitDetailsPage.islegacyMessageShallDisplayed()));
   }

   @Then("no empty space shall be displayed \\(i.e. the Your Board component shall be displayed in this space instead)")
   public void no_empty_space_shall_be_displayed_i_e_the_Your_Board_component_shall_be_displayed_in_this_space_instead()
   {
      assertFalse("no empty space shall not displayed ",
               (unitDetailsPage.islegacyMessageShallDisplayed()));
   }

   @And("the Unit Details legacy message shall be displayed")
   public void the_Unit_Details_legacy_message_shall_be_displayed()
   {
      assertTrue("the Unit Details legacy message shall not be displayed",
               unitDetailsPage.islegacyMessageShallDisplayed());
   }

   @And("the Unit Details legacy message shall display the following:")
   public void the_Unit_Details_legacy_message_shall_display_the_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      siteId = getTestExecutionParams().getBrandStr();

      Map<String, String> matchingRow = dataTableTemp.stream()
               .filter(row -> row.get("site").equals(siteId)).findFirst().orElseThrow(
                        () -> new IllegalArgumentException(
                                 "Cannot find expected strings for " + siteId));

      String expectedLegacyMessagingMainText = matchingRow.get("LegacyMessagingMainText");
      String actualLegacyMessagingMainText = unitDetailsPage.getlegacyMessageMainText();
      assertThat("Legacy message text is not matched ", actualLegacyMessagingMainText,
               equalToIgnoringCase(expectedLegacyMessagingMainText));
      String expectedLegacyMessagingSubText = matchingRow.get("LegacyMessagingSubText");
      String actualLegacyMessagingSubText = unitDetailsPage.getlegacyMessageSubText();
      assertThat("Legacy message text is not matched ", actualLegacyMessagingSubText,
               equalToIgnoringCase(expectedLegacyMessagingSubText));
      String expectedLegacyMessagingSiteLinkText = matchingRow.get("legacyMessagingSiteLinkText");
      String actualLegacyMessagingSiteLinkText = unitDetailsPage.getlegacyMessageLinkText();
      assertThat("Legacy message text is not matched ", actualLegacyMessagingSiteLinkText,
               equalToIgnoringCase(expectedLegacyMessagingSiteLinkText));
   }

   @When("they select the hyperlink with in the legacy message")
   public void they_select_the_hyperlink_with_in_the_legacy_message()
   {
      siteId = getTestExecutionParams().getBrandStr();
      unitDetailsPage.getAccomadationName();
      unitDetailsPage.clickOnlegacyMessageHyperLink();
   }

   @And("the customer shall be directed to the accommodation page on the Legacy website for the same accommodation they were viewing")
   public void the_customer_shall_be_directed_to_the_accommodation_page_on_the_Legacy_website_for_the_same_accommodation_they_were_viewing()
   {
      unitDetailsPage.sameAccomadationNameDispalyed();
   }

   @And("the legacy website site shall be displayed in the relevant source market language")
   public void the_legacy_website_site_shall_be_displayed_in_the_relevant_source_market_language(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      Map<String, String> matchingRow = dataTableTemp.stream()
               .filter(row -> row.get("site").equals(siteId)).findFirst().orElseThrow(
                        () -> new IllegalArgumentException(
                                 "Cannot find expected strings for " + siteId));

      actual = unitDetailsPage.getLegacyWebSiteUrl();
      expected = matchingRow.get("Legacy Website URL");
      assertThat(
               "the legacy website site shall not displayed in the relevant source market language",
               actual, containsString(expected));
   }

   @Given("the Customer is viewing the Search Panel Departure Date modal legacy message on the TRIPS Unit Details page")
   public void the_Customer_is_viewing_the_Search_Panel_Departure_Date_modal_legacy_message_on_the_TRIPS_Unit_Details_page()
   {
      packageNavigation.navigateToUnitDetailsPage();
      searchPanelComponent.selectWhenField();
      departureAirportOrDestinationComponent.selectLegacyDropdown(0);
   }
}
