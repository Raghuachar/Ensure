package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.search_result.FiltersPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search_result.SearchResutlNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.search_result.components.DatesAndDurationFilter;
import uk.co.tui.cdaf.frontend.pom.wr.search_result.components.HolidayTypeFilter;
import uk.co.tui.cdaf.frontend.pom.wr.search_result.components.RaitingFilter;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.PackageGuestRatingFilter;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.SearchResultAttributes;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PackageGuestRatingFilterStepDefs
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageGuestRatingFilterStepDefs.class);

   private final PackageGuestRatingFilter packageGuestRatingFilter = new PackageGuestRatingFilter();

   private final SearchResultsPage searchResultsPage = new SearchResultsPage();

   private final SearchResutlNavigation searchResutlNavigation = new SearchResutlNavigation();

   private final FiltersPanel filtersPanel = new FiltersPanel();

   private final RaitingFilter raitingFilter = new RaitingFilter();

   private final HolidayTypeFilter holidayTypeFilter = new HolidayTypeFilter();

   private final PackageNavigation packageNavigation = new PackageNavigation();

   private final DatesAndDurationFilter datesAndDurationFilter = new DatesAndDurationFilter();

   private final SoftAssertions softAssert = new SoftAssertions();

   private int enabledCheckboxesBeforeFilter;

   private int getNoOfHolidaysCountBefore;

   private List<String> hotelsInfo;

   private List<String> disabledCheckboxes;

   @And("the backend has returned guest ratings for one or more package accommodations")
   public void the_backend_has_returned_guest_ratings_for_one_or_more_package_accommodations()
   {
      assertTrue("The backend Not returned guest ratings for one or more package accommodations",
               packageGuestRatingFilter.isGuestReviewsDisplayed());
   }

   @When("they view the filters component")
   public void they_view_the_filters_component()
   {
      assertTrue("The filters component Not displayed",
               packageGuestRatingFilter.isFiltersComponentDisplayed());
   }

   @Then("they shall see the Guest rating as the first ratings option in the Rating Filter")
   public void they_shall_see_the_Guest_rating_as_the_first_ratings_option_in_the_Rating_Filter()
   {
      assertTrue("The Guest Rating filter component Not displayed",
               packageGuestRatingFilter.isGuestRatingFilterComponentDisplayed());
   }

   @Then("they shall see the following Guest rating filter text in the relevant source market language:")
   public void they_shall_see_the_following_Guest_rating_filter_text_in_the_relevant_source_market_language(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedRatingTitle = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("Guest rating title")).findFirst().orElse(null);

      String actualRatingTitle = packageGuestRatingFilter.getRatingTitleText().get(0);

      assertEquals("Guest rating filter title translation is not matched ", expectedRatingTitle,
               actualRatingTitle);
   }

   @And("the following information shall be shown in each guest rating row:")
   public void the_following_information_shall_be_shown_in_each_guest_rating_row(
            List<String> expectedComponents)
   {
      Map<String, List<SelenideElement>> guestComponents =
               new HashMap<>(packageGuestRatingFilter.isGuestRatingFiltersComponentsDisplayed());
      expectedComponents.forEach(componentIdentifier ->
      {
         final List<SelenideElement> elements = guestComponents.get(componentIdentifier.trim());
         assertTrue(componentIdentifier + " component not found",
                  elements != null && !elements.isEmpty());
         boolean allElementsDisplayed = elements.stream().allMatch(SelenideElement::isDisplayed);
         assertTrue(componentIdentifier + " elements are not visible", allElementsDisplayed);
      });
   }

   @Then("guest ratings shall be provided for the following ratings:")
   public void guest_ratings_shall_be_provided_for_the_following_ratings(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      for (int i = 0; i < 5; i++)
      {
         final int ratingIndex = i;
         String expectedRating = maps.stream().filter(row -> row.get("site").equals(siteId))
                  .map(row -> row.get((ratingIndex + 5) + ".0 and over")).findFirst().orElse(null)
                  .trim();

         String actualRating =
                  packageGuestRatingFilter.guestReviewFilterOptionsText().get(ratingIndex).trim();

         softAssert.assertThat(actualRating)
                  .describedAs((ratingIndex + 5) + ".0 and over translations is not matched")
                  .isEqualTo(expectedRating);
      }
   }

   @And("the Guest rating filter shall not contain any filter options for less than five")
   public void the_Guest_rating_filter_shall_not_contain_any_filter_options_for_less_than_five()
   {
      assertTrue("The Guest rating filter contains filter options less than five",
               packageGuestRatingFilter.isGuestRatingFilterOptionsValid());
   }

   @And("the backend has not returned guest ratings for one or more of the ratings")
   public void the_backend_has_not_returned_guest_ratings_for_one_or_more_of_the_ratings()
   {
      assertTrue(
               "the backend has not returned guest ratings for one or more of the ratings are enabled",
               packageGuestRatingFilter.verifyDisabledFilterOptions());
   }

   @Then("the radio button and text for all guest ratings that have not been returned from the backend shall be greyed out & disabled")
   public void the_radio_button_and_text_for_all_guest_ratings_that_have_not_been_returned_from_the_backend_shall_be_greyed_out_disabled()
   {
      List<Double> searchCardsRatings = packageGuestRatingFilter.getRatingsInSearchCard();
      List<Double> disabledRatings = packageGuestRatingFilter.getDisabledRatings();

      assertThat("Disabled rating should Not be present in search card ratings", searchCardsRatings,
               not(containsInAnyOrder(disabledRatings.toArray())));
   }

   @When("they select any Destinations filter options")
   public void they_select_any_Destinations_filter_options()
   {
      List<WebElement> enabledCheckboxesBeforeSize =
               searchResultsPage.searchResultsFiltersComponent.getEnabledBoardBasisCheckboxes();
      enabledCheckboxesBeforeFilter = enabledCheckboxesBeforeSize.size();
      searchResultsPage.destinationFilterComponent.clickOnDestinationShowMore();
      searchResultsPage.destinationFilterComponent.selectRegionOption();
   }

   @Then("the checkbox for the selected filter option shall be selected")
   public void the_checkbox_for_the_selected_filter_option_shall_be_selected()
   {
      assertTrue("The checkbox for the selected filter option is not selected",
               searchResultsPage.destinationFilterComponent.verifySelectedFilterOption());
   }

   @And("the Search Results page shall be updated to display all packages where the accommodation meet the guest rating & Destination filter option")
   public void the_Search_Results_page_shall_be_updated_to_display_all_packages_where_the_accommodation_meet_the_guest_rating_Destination_filter_option()
   {
      Double selectedRating = packageGuestRatingFilter.getGuestReviewRatingSelected();
      List<Double> searchCardsRatings = packageGuestRatingFilter.getRatingsInSearchCard();

      for (Double rating : searchCardsRatings)
      {
         assertThat("Selected rating should be greater than or equal to search cards ratings",
                  rating, greaterThanOrEqualTo(selectedRating));
      }

      String selectedDestination =
               searchResultsPage.destinationFilterComponent.getSelectedDestination();

      List<String> searchCardsDestinations =
               searchResultsPage.destinationFilterComponent.getDestinationsInSearchCard();

      for (String destination : searchCardsDestinations)
      {
         assertEquals("Selected destination should match search cards destinations", destination,
                  selectedDestination);
      }
   }

   @And("all other filter options that are no longer applicable shall be displayed in grey and not selectable")
   public void all_other_filter_options_that_are_no_longer_applicable_shall_be_displayed_in_grey_and_not_selectable()
   {
      List<WebElement> enabledCheckboxesAfterFilterSize =
               searchResultsPage.searchResultsFiltersComponent.getEnabledBoardBasisCheckboxes();
      int enabledCheckboxesAfterFilter = enabledCheckboxesAfterFilterSize.size();

      assertNotEquals("Enabled checkboxes should have changed after selecting the filter",
               enabledCheckboxesBeforeFilter, enabledCheckboxesAfterFilter);
   }

   @And("the Clear link shall be displayed by the title of the Destination filter option that has been selected")
   public void the_Clear_link_shall_be_displayed_by_the_title_of_the_Destination_filter_option_that_has_been_selected()
   {
      assertTrue("Destination filter Clear link is not displayed",
               packageGuestRatingFilter.isDestinationClearFilterLinkDisplayed());
   }

   @When("they select any of the available Guest rating filter options")
   public void they_select_any_of_the_available_Guest_rating_filter_options()
   {
      packageGuestRatingFilter.selectGuestFilterOption();
   }

   @Then("the radio button for the selected Guest rating filter option shall be selected")
   public void the_radio_button_for_the_selected_Guest_rating_filter_option_shall_be_selected()
   {
      Double expectedRating = packageGuestRatingFilter.getGuestReviewRatingSelected();

      Double selectedRating = packageGuestRatingFilter.getSelectedRatingValue();

      assertEquals("The expected radio button is not selected: Expected", selectedRating,
               expectedRating);
   }

   @And("the Search Results page shall be updated to display all packages where the accommodation has a guest rating greater than or equal to the selected filter option")
   public void the_Search_Results_page_shall_be_updated_to_display_all_packages_where_the_accommodation_has_a_guest_rating_greater_than_or_equal_to_the_selected_filter_option()
   {
      Double selectedRating = packageGuestRatingFilter.getGuestReviewRatingSelected();

      List<Double> searchCardsRatings = packageGuestRatingFilter.getRatingsInSearchCard();

      for (Double rating : searchCardsRatings)
      {
         assertThat("Selected rating should be greater than or equal to search cards ratings",
                  rating, greaterThanOrEqualTo(selectedRating));
      }
   }

   @And("the Clear link shall be displayed by the Rating filter title")
   public void the_Clear_link_shall_be_displayed_by_the_Rating_filter_title()
   {
      assertTrue("Guest Review Rating Clear link is not displayed",
               packageGuestRatingFilter.isGuestReviewRatingClearFilterLinkDisplayed());
   }

   @And("the Clear All link shall be displayed by the Filters title")
   public void the_Clear_All_link_shall_be_displayed_by_the_Filters_title()
   {
      assertTrue("Clear All link is not displayed",
               packageGuestRatingFilter.isClearAllFilterLinkDisplayed());
   }

   @When("they select the Clear link by the Rating title")
   public void they_select_the_Clear_link_by_the_Rating_title()
   {
      packageGuestRatingFilter.clickGuestReviewRatingClearFilterLink();
   }

   @Then("the radio button by the previously selected Guest rating filter shall be deselected")
   public void the_radio_button_by_the_previously_selected_Guest_rating_filter_shall_be_deselected()
   {
      assertTrue("Selected radio button should be deselected",
               packageGuestRatingFilter.isRadioButtonUnSelected());
   }

   @And("the Search Results page shall be updated to display all packages that meet all the search panel selection criteria including package accommodations that have a guest review rating less than five")
   public void the_Search_Results_page_shall_be_updated_to_display_all_packages_that_meet_all_the_search_panel_selection_criteria_including_package_accommodations_that_have_a_guest_review_rating_less_than_five()
   {
      Double basicRating = 0.0;
      List<Double> searchCardsRatings = packageGuestRatingFilter.getRatingsInSearchCard();

      for (Double rating : searchCardsRatings)
      {
         assertThat("Selected rating should be greater than or equal to search cards ratings",
                  rating, greaterThanOrEqualTo(basicRating));
      }
   }

   @And("the Clear link by the Rating filter title shall no longer be displayed")
   public void the_Clear_link_by_the_Rating_filter_title_shall_no_longer_be_displayed()
   {
      assertTrue("Clear link should not be displayed",
               packageGuestRatingFilter.isGuestReviewRatingClearFilterLinkNotDisplayed());
   }

   @And("the Clear All should not be shown when only one filter applied")
   public void noClearAllWithOneFilter()
   {
      assertThat("Unexpected number of ActiveFiltersOptions found",
               filtersPanel.getActiveFiltersOptions().size(), equalTo(1));
      assertFalse("Clear All link should not be displayed",
               filtersPanel.isClearFilterAllLinkDisplayed());
   }

   @And("the Clear All should not be shown when no filter applied")
   public void noClearAllWithoutFilter()
   {
      assertThat("Unexpected number of ActiveFiltersOptions found",
               filtersPanel.getActiveFiltersOptions().size(), equalTo(0));
      assertFalse("Clear All link should not be displayed",
               filtersPanel.isClearFilterAllLinkDisplayed());
   }

   @And("they have previously selected multiple filters including the Guest rating filter")
   public void they_have_previously_selected_multiple_filters_including_the_Guest_rating_filter()
   {
      getNoOfHolidaysCountBefore = packageGuestRatingFilter.getNoOfHolidaysCount();
      packageGuestRatingFilter.selectGuestFilterOption();
      searchResultsPage.destinationFilterComponent.clickOnDestinationShowMore();
      searchResultsPage.destinationFilterComponent.selectRegionOption();
   }

   @When("they select the Clear All link by the Filters title")
   public void they_select_the_Clear_All_link_by_the_Filters_title()
   {
      packageGuestRatingFilter.clickClearAllFilterLink();
   }

   @Then("the radio button by the previously selected filter options shall be deselected")
   public void the_radio_button_by_the_previously_selected_filter_options_shall_be_deselected()
   {
      assertTrue("Selected rating filter radio button should be deselected",
               packageGuestRatingFilter.isRadioButtonUnSelected());

      assertTrue("Selected Destination filter checkbox should be deselected",
               searchResultsPage.destinationFilterComponent.isCheckboxUnSelected());
   }

   @Then("the Search Results page shall be updated to display all packages that meet all the search panel selection criteria")
   public void the_Search_Results_page_shall_be_updated_to_display_all_packages_that_meet_all_the_search_panel_selection_criteria()
   {
      Double basicRating = 0.0;

      List<Double> searchCardsRatings = packageGuestRatingFilter.getRatingsInSearchCard();

      for (Double rating : searchCardsRatings)
      {
         assertThat("Selected rating should be greater than or equal to search cards ratings",
                  rating, greaterThanOrEqualTo(basicRating));
      }

      int getNoOfHolidaysCountAfter = packageGuestRatingFilter.getNoOfHolidaysCount();

      assertEquals("The Search Results page Not updated after the Clear all filter cleared",
               getNoOfHolidaysCountBefore, getNoOfHolidaysCountAfter);
   }

   @And("current filter options and search results are memorized")
   public void currentFilterOptionsAndSearchResultsAreMemorized()
   {
      hotelsInfo = getCurrentHotelNames();
      disabledCheckboxes = filtersPanel.getDisabledCheckboxes();
   }

   @When("Guest rating changes to the highest")
   public void guestRatingChanges()
   {
      raitingFilter.selectHighestRating();
   }

   @Then("other filter options and search results are changes appropriatelly")
   public void otherFilterOptionsAndSearchResultsAreChangesAppropriatelly()
   {
      List<String> newHotelsInfo = getCurrentHotelNames();
      assertThat(newHotelsInfo, not(equalTo(hotelsInfo)));

      List<String> latestDisabledCheckboxes = filtersPanel.getDisabledCheckboxes();
      assertThat(latestDisabledCheckboxes, not(equalTo(disabledCheckboxes)));
   }

   @Given("the customer is on the Search Results page with lowest Guest rating applied")
   public void theCustomerSearchResultsPageWithGuestRatingApplied()
   {
      packageNavigation.navigateToSearchResultPage();
      raitingFilter.selectLowestRating();
   }

   @Given("the customer is on the Search Results page")
   public void theCustomerSearchResultsPage()
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @Given("dates and duration filters should be applied with random values")
   public void dateAndDurationRandom()
   {
      datesAndDurationFilter.selectRandomDate();
      datesAndDurationFilter.selectRandomDuration();
   }

   @When("Hotel type filter changes to {string}")
   public void hotelTypeFilterChangesTo(String holidayTypeName)
   {
      holidayTypeFilter.selectTypeByName(holidayTypeName);
   }

   @And("the 'Clear All' link should be shown when multiple filter applied")
   public void clearAllWithMultipleFilters()
   {
      assertTrue("Clear All link should be displayed",
               filtersPanel.isClearFilterAllLinkDisplayed());
   }

   @And("'Clear All' link clicked")
   public void clearAllClocked()
   {
      filtersPanel.clickClearAllBtn();
   }

   @And("other filter options and search results should be restored")
   public void resultsRestored()
   {
      List<String> newHotelsInfo = getCurrentHotelNames();
      LOGGER.log(hotelsInfo.size() + " | " + newHotelsInfo.size());
      assertThat(newHotelsInfo, equalTo(hotelsInfo));
      List<String> latestDisabledCheckboxes = filtersPanel.getDisabledCheckboxes();
      assertThat(latestDisabledCheckboxes, equalTo(disabledCheckboxes));
   }

   private List<String> getCurrentHotelNames()
   {
      return searchResutlNavigation.getAllSearchResultAttributes().stream()
               .map(SearchResultAttributes::getAccomodationName).collect(Collectors.toList());
   }
}
