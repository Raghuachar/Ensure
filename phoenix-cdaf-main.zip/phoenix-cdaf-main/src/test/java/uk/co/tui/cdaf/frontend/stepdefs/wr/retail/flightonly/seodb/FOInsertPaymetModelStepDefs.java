package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class FOInsertPaymetModelStepDefs
{
   public final WebElementWait wait;

   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents;

   public FOInsertPaymetModelStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      wait = new WebElementWait();
      foReconcilationPaymentPageComponents = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Agent is on the reconcile payments page")
   public void that_the_Agent_is_on_the_reconcile_payments_page()
   {
      retailflightNavigation.retailLoginFO();
      foReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

}
