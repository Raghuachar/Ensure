package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.codeborne.selenide.Selenide.$;

public class SearchResultsPage extends AbstractPage
{
   public final SearchResultsComponent searchResultComponent;

   public final SearchPanelComponent searchPanelComponent;

   public final SearchResultsFiltersComponent searchResultsFiltersComponent;

   public final DestinationFilterComponent destinationFilterComponent;

   public final FacilitiesFilterComponent facilitiesFilterComponent;

   public final SingleAccommodationComponent singleAccommodationComponent;

   public final CommissionMarkers commissionMarkers;

   public final WebElementWait wait;

   private final Map<String, WebElement> sessionTimeOutComponent;

   @FindBy(css = "[class='UI__regLabel']")
   private WebElement holidayDuration;

   @FindBy(xpath = "//ul[@class='Duration__durationList']/li[not(contains(@class,'disabled')) and not(contains(@class,'selected'))]")
   private WebElement altDurations;

   @FindBy(css = "[aria-label='single_accom_dates_prices']")
   private WebElement availabityCalendar;

   @FindBy(css = ".NoResultsPopup__oopsText")
   private WebElement sessionTimeOutPopUp;

   @FindBy(css = "[class='NoResultsPopup__oopsText']+p")
   private WebElement someThingWentWrongMessage;

   @FindBy(css = "[class='NoResultsPopup__oopsSorry']+button")
   private WebElement reloadCTAButtton;

   @FindBy(css = "[class='FilterPanelV2__holidayCounts']")
   private WebElement hoildayCount;

   @FindBy(css = "Span[class='ResultListItemV2__ratingNumber']")
   private WebElement guestReviewRatingNumber;

   @FindBy(css = "div[class='ResultListItemV2__guestReviewContainer'] a")
   private WebElement guestReviewHyperLink;

   @FindBy(css = "div[class='ResultListItemV2__guestReviewContainer']")
   private WebElement guestReviewRating;

   @FindBy(css = "span[class='HighlightedLink__text']")
   private WebElement guestReviewText;

   @FindBy(css = "div[class='ResultListItemV2__guestReviewContainer'] span+span")
   private WebElement guestReviewDescription;

   public SearchResultsPage()
   {
      searchResultComponent = new SearchResultsComponent();
      searchPanelComponent = new SearchPanelComponent();
      wait = new WebElementWait();
      searchResultsFiltersComponent = new SearchResultsFiltersComponent();
      destinationFilterComponent = new DestinationFilterComponent();
      facilitiesFilterComponent = new FacilitiesFilterComponent();
      singleAccommodationComponent = new SingleAccommodationComponent();
      sessionTimeOutComponent = new HashMap<>();
      commissionMarkers = new CommissionMarkers();
   }

   public boolean validateAlternateDurationExists()
   {
      return Objects.nonNull(holidayDuration);
   }

   public void selectAlternativeDuration()
   {
      WebElementTools.click(altDurations);
      wait.forJSExecutionReadyLazy();

   }

   public boolean isAvailabilityCalendarPresent()
   {
      wait.forAppear(availabityCalendar);
      wait.forJSExecutionReadyLazy();
      return availabityCalendar.isDisplayed();
   }

   public void inActiveForCertainAmountOfTime(int timer)
   {
      wait.waitForAWhile(timer);
   }

   public boolean isSessionTimeOutPopUp()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(sessionTimeOutPopUp);
   }

   public Map<String, WebElement> getSessionTimeOutComponent()
   {
      wait.forJSExecutionReadyLazy();
      sessionTimeOutComponent.put("OOPS. SORRY!", sessionTimeOutPopUp);
      sessionTimeOutComponent.put("Er ging iets fout tijdens het laden van de pagina",
               someThingWentWrongMessage);
      sessionTimeOutComponent.put("Laad de pagina opnieuw en probeer nog eens", reloadCTAButtton);
      return sessionTimeOutComponent;
   }

   public boolean isCTAButtonDisplayed()
   {
      return WebElementTools.isDisplayed(reloadCTAButtton);
   }

   public void clickCTAButton()
   {
      WebElementTools.click(reloadCTAButtton);
   }

   public boolean isHoildayCountDisplayed()
   {
      return WebElementTools.isDisplayed(hoildayCount);
   }

   public boolean isGuestReviewDisplayed()
   {
      return WebElementTools.isPresent(guestReviewRating);
   }

   public boolean isGuestReviewHyperLinkDisplayed()
   {
      return WebElementTools.isDisplayed(guestReviewHyperLink);
   }

   public String getGuestReviewText()
   {
      return WebElementTools.getElementText(guestReviewText);
   }

   public Double getGuestReviewRating()
   {
      return Double.parseDouble(WebElementTools.getElementText(guestReviewRatingNumber));

   }

   public String getGuestReviewDescription()
   {
      return WebElementTools.getElementText(guestReviewDescription);
   }

   public void selectGuestReviewHyperLink()
   {
      WebElementTools.click(guestReviewText);
   }

   public SelenideElement editSearch()
   {
      return $("[aria-label='edit search']");
   }

   public SelenideElement allGoneBanner()
   {
      return $(".AllGone__notice");
   }

   public String errorPageHeader()
   {
      return $(".ContentBox__heroContent").$("div.Textbox__header")
               .should(Condition.appear, Duration.ofSeconds(15)).getText();
   }
}
