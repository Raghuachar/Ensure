package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.SearchResultsSingleAccomComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSingleAccomDepartureAirportStepDefs extends AbstractPage
{

   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   private final SearchResultsSingleAccomComponent searchResultsSingleAccomComponent;

   public PackageSingleAccomDepartureAirportStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      searchResultsSingleAccomComponent = new SearchResultsSingleAccomComponent();
   }

   @When("they review the {string} section")
   public void they_review_the_section(String string)
   {
      assertThat("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed(), is(true));
   }

   @Then("they can see a {string} dropdown")
   public void they_can_see_a_dropdown(String string)
   {
      assertThat("departure airport dropdown is not displayed",
               searchResultsPage.singleAccommodationComponent.isDepartureAirportDisplayed(),
               is(true));
   }

   @Given("the backend has returned only one departure airport \\(the one searched for)")
   public void the_backend_has_returned_only_one_departure_airport_the_one_searched_for()
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
   }

   @When("they select the {string} dropdown")
   public void they_select_the_dropdown(String departureAirport)
   {
      searchResultsPage.singleAccommodationComponent.selectDepartureAirportDropdown();
   }

   @Then("they can only see one departure airport option")
   public void they_can_only_see_one_departure_airport_option()
   {
      assertThat("departure airport dropdown is not displayed",
               searchResultsPage.singleAccommodationComponent.isDepartureAirportDisplayed(),
               is(true));
   }

   @Then("it is in a selected state")
   public void it_is_in_a_selected_state()
   {
      searchResultsPage.singleAccommodationComponent.selectDepartureAirportDropdown();
   }

   @Given("the backend has returned more than one departure airport")
   public void the_backend_has_returned_more_than_one_departure_airport()
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
   }

   @Then("they can see that the default selection is {string}")
   public void they_can_see_that_the_default_selection_is(String All)
   {
      assertThat("default selection All is not displayed",
               searchResultsPage.singleAccommodationComponent.isDefaultSelectionDisplayed(),
               is(true));
   }

   @Then("a multitude of airports are available to select")
   public void a_multitude_of_airports_are_available_to_select()
   {
      searchResultsPage.singleAccommodationComponent.selectDepartureAirportDropdown();
   }

   @Then("the price in each calendar cell represents the base package Departure Airport price")
   public void the_price_in_each_calendar_cell_represents_the_base_package_Departure_Airport_price()
   {
      assertThat("Customer seeing the calender",
               searchResultsSingleAccomComponent.singleAccomCalendar(), is(true));
   }

   @Then("they can see those airports are greyed out")
   public void they_can_see_those_airports_are_greyed_out()
   {
      assertThat("departure airport greyedout is not displayed",
               searchResultsPage.singleAccommodationComponent.isGreyedOutOptionDisplayed(),
               is(true));
   }

   @Given("they have opened the {string} dropdown")
   public void they_have_opened_the_dropdown(String string)
   {
      searchResultsPage.singleAccommodationComponent.selectDepartureAirportDropdown();
   }

   @When("they select an airport")
   public void they_select_an_airport()
   {
      searchResultsPage.singleAccommodationComponent.selectDepartureAirport();
   }

   @Then("the prices in the calendar represent the selected Departure Airport package")
   public void the_prices_in_the_calendar_represent_the_selected_Departure_Airport_package()
   {
      assertThat("Customer seeing the calender",
               searchResultsSingleAccomComponent.singleAccomCalendar(), is(true));
   }

   @Then("the package availability in the calendar changes according to the inventory available for the selected airport")
   public void the_package_availability_in_the_calendar_changes_according_to_the_inventory_available_for_the_selected_airport()
   {
      searchResultsPage.singleAccommodationComponent.selectDepartureAirport();

   }

}
