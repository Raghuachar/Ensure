package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.flightoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.FlightSummaryComponent;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AlternateFlightComponent extends FlightSummaryComponent
{

   private final Map<String, WebElement> alternateFlightMap;

   @FindBy(css = "[aria-label='alternate flights'] h2")
   private WebElement alternateFlightHeading;

   @FindBy(css = "[aria-label='alternative flight dates']")
   private WebElement datesHeading;

   @FindBy(css = "[aria-label='Direct Flights']")
   private WebElement directFlightHeading;

   @FindBy(css = "[class='DateCarousel__prev']")
   private WebElement leftChevron;

   @FindBy(css = "div[class*='AlternativeFlights__flightContainer'][class*='selected']")
   private WebElement selectedFlightCard;

   @FindBy(css = "[class*='DateCarousel__dateBlock']:not([class*='selected']):not([class*='disabled'])")
   private List<WebElement> availableDates;

   public AlternateFlightComponent()
   {
      alternateFlightMap = new HashMap<>();
   }

   public Map<String, WebElement> getAlternateFlightComponents()
   {
      alternateFlightMap.put("ALTERNATIVE FLIGHTS", alternateFlightHeading);
      alternateFlightMap.put("DATES", datesHeading);
      alternateFlightMap.put("DIRECT FLIGHTS", directFlightHeading);
      //alternateFlightMap.put("Flight ordering dropdown", sortFlightDropdown);
      alternateFlightMap.put("Adjust week chevrons", leftChevron);
      alternateFlightMap.put("Alternative flight dates", availableDates.get(0));
      alternateFlightMap.put("Available flight cards for selected date", selectedFlightCard);
      return alternateFlightMap;
   }

}
