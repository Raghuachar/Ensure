package uk.co.tui.cdaf.api.requests.search;

import com.codeborne.selenide.Selenide;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.api.pojo.search.base.Airport;
import uk.co.tui.cdaf.api.pojo.search.mfe.Destination;
import uk.co.tui.cdaf.api.pojo.search.mfe.Room;
import uk.co.tui.cdaf.api.pojo.search.mfe.RoomManager;
import uk.co.tui.cdaf.api.requests.search.parameters.SearchParameters;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PackageSearchApi
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageSearchApi.class);

   private static final String OR_ENCODED = "%7C";

   private static final String COLON_ENCODED = "%3A";

   private static SearchParameters searchParameters;

   private static final SearchDataHelper searchDataHelper = new SearchDataHelper();

   public static String uriBuilder(TestDataAttributes parameter)
   {
      PackageSearchApi.searchParameters = new SearchParameters(parameter);
       return uriBuilder(searchParameters);
   }

   public static String uriBuilder()
   {
      TestDataAttributes parameter = searchDataHelper.getSearchParameters();
      return uriBuilder(parameter);
   }

   @NotNull
   public static String uriBuilder(SearchParameters searchParameters)
   {
      PackageSearchApi.searchParameters = searchParameters;
      String urlStr = ExecParams.getTestExecutionParams().getUrlStr();

      LOGGER.log(LogLevel.INFO, "Package search url: " + urlStr);

      return urlStr + "/packages?searchType=search&" + getAirportsQuery() + getUnitsQuery() +
               getWhenQuery() + getFlexibilityQuery() + getDurationQuery() + getPaxAndRoomsQuery();
   }

   private static String getPaxAndRoomsQuery()
   {
      RoomManager roomsManager = searchParameters.getRoomsManager();
      List<Room> rooms = roomsManager.getRooms();

      int[] totals = calculateTotalAdultsAndChildren(rooms);
      int totalAdults = totals[0];
      int totalChildren = totals[1];

      String childrenAges = getChildrenAges(rooms);
      String roomQuery = getRoomQuery(rooms);

      return "noOfAdults=" + totalAdults
              + "&noOfChildren=" + totalChildren
              + "&childrenAge=" + URLEncoder.encode(childrenAges, StandardCharsets.UTF_8)
              + "&room=" + roomQuery;
   }

   private static int[] calculateTotalAdultsAndChildren(List<Room> rooms)
   {
      int totalAdults = 0;
      int totalChildren = 0;

      for (Room room : rooms)
      {
         int adults = Integer.parseInt(room.getAdults());
         int children = Integer.parseInt(room.getKids());
         totalAdults += adults;
         totalChildren += children;
      }

      return new int[] { totalAdults, totalChildren };
   }

   private static String getChildrenAges(List<Room> rooms)
   {
      StringBuilder childrenAges = new StringBuilder();

      for (Room room : rooms)
      {
         if (!room.getKidsAges().isEmpty())
         {
            if (childrenAges.length() > 0)
            {
               childrenAges.append(",");
            }
            childrenAges.append(room.getKidsAges());
         }
      }

      return childrenAges.toString();
   }

   private static String getRoomQuery(List<Room> rooms)
   {
      StringBuilder roomQuery = new StringBuilder();

      for (Room room : rooms)
      {
         if (roomQuery.length() > 0)
         {
            roomQuery.append("-");
         }
         roomQuery.append(room.getNumber())
                 .append("%7C")
                 .append(room.getAdults())
                 .append("%7C0%7C")
                 .append(room.getKids())
                 .append("%7C0%7C");

         if (!room.getKidsAges().isEmpty())
         {
            roomQuery.append(URLEncoder.encode(room.getKidsAges(), StandardCharsets.UTF_8));
         }
      }

      return roomQuery.toString();
   }

   private static String getDurationQuery()
   {
      return "duration=" + searchParameters.getDurationParams().getValue() + "&";
   }

   private static String getFlexibilityQuery()
   {
      int flexibleDays = searchParameters.getFlexibleDays();
      if (flexibleDays > 0)
         return "flexibility=true&" + "flexibleDays=" + flexibleDays + "&";
      return "flexibility=false&flexibleDays=&";
   }

   private static String getAirportsQuery()
   {
      List<Airport> availableAirports = searchParameters.getAvailableAirports();
      return "airports[]=" + availableAirports.stream()
               .map(Airport::getId)
               .collect(Collectors.joining(OR_ENCODED)) + "&";
   }

   private static String getUnitsQuery()
   {
      List<Destination> destinationList = Stream.of(searchParameters.getAvailableDestinations(),
                        searchParameters.getSuggestion())
               .flatMap(List::stream)
               .collect(Collectors.toList());
      return "units[]=" + destinationList.stream()
               .map(destination -> destination.getId() + COLON_ENCODED + destination.getType())
               .collect(Collectors.joining(OR_ENCODED)) + "&";
   }

   private static String getWhenQuery()
   {
      String firstAvailableDate = searchParameters.getWhenDateTime();
      return "when=" + firstAvailableDate + "&";
   }

   public static void openSearchResultsPage(TestDataAttributes parameter){
      Selenide.open(uriBuilder(parameter));
      BrowserCookies.closePrivacyPopUp();
   }

   public static void openSearchResultsPage()
   {
      Selenide.open(uriBuilder());
      BrowserCookies.closePrivacyPopUp();
   }
}
