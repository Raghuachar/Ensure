package uk.co.tui.cdaf.api.pojo.search.mfe;

import lombok.Data;
import uk.co.tui.cdaf.api.pojo.search.base.Airport;

import java.util.List;

@Data
public class AirportData
{
   private List<Airport> airports;
}

