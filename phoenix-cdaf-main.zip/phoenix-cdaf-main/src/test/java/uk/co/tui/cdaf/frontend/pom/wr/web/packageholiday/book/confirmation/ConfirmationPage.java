package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.confirmation;

import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.FlightSummaryComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.PassengerDetailsComponent;

public class ConfirmationPage
{
   public final BookingReferenceComponent bookReferenceComponent;

   public final ConfirmationMultipleRoomTypeinHolidayComponent confirmationHolidayComponent;

   public final PassengerDetailsComponent passengerDetailsComponent;

   public final FlightSummaryComponent flightSummaryComponent;

   public ConfirmationPage()
   {
      bookReferenceComponent = new BookingReferenceComponent();
      confirmationHolidayComponent = new ConfirmationMultipleRoomTypeinHolidayComponent();
      passengerDetailsComponent = new PassengerDetailsComponent();
      flightSummaryComponent = new FlightSummaryComponent();
   }

}
