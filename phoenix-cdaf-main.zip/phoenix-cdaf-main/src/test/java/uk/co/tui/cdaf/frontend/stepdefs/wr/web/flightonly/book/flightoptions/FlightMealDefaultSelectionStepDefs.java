package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.flightoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FlightMealDefaultSelectionStepDefs
{

   private final FlightOptionsPage flightOptionsPage;

   private String totalPrice;

   public FlightMealDefaultSelectionStepDefs()
   {
      flightOptionsPage = new FlightOptionsPage();
   }

   @Then("the no meal option should be chosen by default")
   public void the_no_meal_option_should_be_chosen_by_default()
   {
      flightOptionsPage.mealsComponent.getFlightMealSelecetdElement().stream()
               .forEach(selectedMeal ->
               {
                  String mealText = WebElementTools.getElementText(selectedMeal);
                  boolean matched = StringUtils.containsIgnoreCase(mealText, "Choose meal");
                  assertThat(
                           ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                                    "Choose meal option not displayed by default", mealText,
                                    "Choose meal"),
                           matched, is(true));
               });
   }

   @And("the no meal option should be at the top of the drop down list")
   public void the_no_meal_option_should_be_at_the_top_of_the_drop_down_list()
   {
      boolean flag = flightOptionsPage.mealsComponent.isChooseMealAtTopOfDropdown();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Choose meal is not at top of dropdown", flag, true), flag, is(true));
   }

   @And("a user has already selected a paid-for meal")
   public void a_user_has_already_selected_a_paid_for_meal()
   {
      flightOptionsPage.mealsComponent.selectMeal(StringUtils.EMPTY, 1);
      totalPrice = flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
   }

   @When("they select the no meal option")
   public void they_select_the_no_meal_option()
   {
      flightOptionsPage.mealsComponent.selectMeal(StringUtils.EMPTY, 0);
   }

   @Then("the paid-for meal should be removed from all flight segments")
   public void the_paid_for_meal_should_be_removed_from_all_flight_segments()
   {
      flightOptionsPage.summaryPanelComponent.clickOnPriceSummary();
      boolean displayed = flightOptionsPage.summaryPanelComponent.isFlightExtrasDisplayed();
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Paid meal is not removed from flight segment", displayed, false),
               displayed, is(false));
   }

   @And("the total price of WR FO package should be updated on WR FO Flight Option page")
   public void the_total_price_of_WR_FO_package_should_be_updated_on_WR_FO_Flight_Options_page()
   {
      String tpAfterMealRemovel = flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
      boolean matched = StringUtils.equalsIgnoreCase(tpAfterMealRemovel, totalPrice);
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Price value is not updated after removelof paid-meal", tpAfterMealRemovel,
                        totalPrice),
               matched, is(false));
   }

}
