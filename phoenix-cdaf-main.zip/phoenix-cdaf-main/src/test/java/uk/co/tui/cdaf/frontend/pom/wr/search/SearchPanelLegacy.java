package uk.co.tui.cdaf.frontend.pom.wr.search;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.airport.Airport;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.airport.AirportLegacy;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.departure.Departure;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.departure.DepartureLegacy;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.Destination;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.DestinationLegacy;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.pad_and_rooms.PaxAndRooms;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.pad_and_rooms.PaxAndRoomsLegacy;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion.DestinationSuggestion;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion.DestinationSuggestionLegacy;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.wrappers.ComponentWrappers;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.wrappers.ComponentWrappersLegacy;
import uk.co.tui.cdaf.frontend.pom.wr.search.enums.StayDuration;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import java.util.Objects;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;

class SearchPanelLegacy extends SearchPanelMfe
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchPanelLegacy.class);

   final Airport airportLegacyComponent = new AirportLegacy();

   final Destination destinationLegacyComponent = new DestinationLegacy();

   final Departure departureLegacyComponent = new DepartureLegacy();

   final PaxAndRooms paxAndRoomsLegacyComponent = new PaxAndRoomsLegacy();

   final DestinationSuggestion destinationSuggestionComponent = new DestinationSuggestionLegacy();

   @Override
   public boolean isSearchPanelDisplayed()
   {
      return $(shadowDeepCss("div[aria-label='search panel container']")).isDisplayed();
   }

   @Override
   public Airport airport()
   {
      openDropDown(getWrappers().getAirportWrapper(),
               "section.DropModal__dropdown[aria-label='airports']",
               "input.SelectAirports__pointer");
      return airportLegacyComponent;
   }

   @Override
   public Departure departure()
   {
      openDropDown(getWrappers().getDepartureWrapper(), "section[aria-label='Departure date']",
               "span.inputs__children");
      return departureLegacyComponent;
   }

   @Override
   public Destination destination()
   {
      openDropDown(getWrappers().getDestinationWrapper(),
               ".Package__destinationContainer, .Search__destinationContainer, .SearchPanel__destinationContainer",
               "span.inputs__children");
      return destinationLegacyComponent;
   }

   @Override
   public DestinationSuggestion destinationSuggestions(String destination)
   {
      destination().clearSelection().confirmSelection();
      SelenideElement freeTextInput =
               getWrappers().getDestinationWrapper().$("input[aria-label='select destinations']");
      freeTextInput.click();
      freeTextInput.sendKeys(destination);
      return destinationSuggestionComponent;
   }

   @Override
   public PaxAndRooms paxAndRooms()
   {
      openDropDown(getWrappers().getPaxAndRoomsWrapper(), ".RoomAndPaxOverlay__roomAndPaxWrappper",
               "span.inputs__children");
      return paxAndRoomsLegacyComponent;
   }

   private void openDropDown(SelenideElement wrapper, String dropdownLocator,
            String clickableLocator)
   {
      SelenideElement dropdown = $(dropdownLocator);
      if (!dropdown.isDisplayed())
      {
         wrapper.$(clickableLocator).click();
         dropdown.should(appear, WAIT_TIMEOUT);
      }
   }

   @Override
   public void selectDuration(StayDuration duration)
   {
      getDurationSelector()
               .selectOptionByValue(duration.getNumberOfNights());
   }

   @Override
   public void selectDuration(String durationString)
   {
      getDurationSelector().selectOptionContainingText(durationString);
   }

   @NotNull
   public SelenideElement getDurationSelector()
   {
      return getWrappers().getDurationWrapper().$("select");
   }

   @Override
   public boolean isSearchButtonEnabled()
   {
      String searhBtnParentClassName =
               Objects.requireNonNull(getSearchButton().parent().getAttribute("class"));
      boolean isClassHasDisabledMarker = searhBtnParentClassName.contains("__disabled");
      return !isClassHasDisabledMarker;
   }

   private SelenideElement getSearchButton()
   {
      return getWrappers().getSearchButtonWrapper().$("button");
   }

   @Override
   public void doSearch()
   {
      getSearchButton().click();
   }

   @Override
   public void searchDefaults()
   {
      airport().clearSelection().setAllAirportsSelected(true).confirmSelection();
      departure().clearSelection().selectFirstAvailableDate().confirmSelection();
      doSearch();
   }

   @Override
   public void searchWithParameters()
   {
      TestDataAttributes parameter = new SearchDataHelper().getSearchParameters();
      searchWithParameters(parameter);
   }

   @Override
   public void searchWithParameters(TestDataAttributes parameter)
   {
      if (parameter != null)
      {
         setAirports(parameter);
         setDepartureDate(parameter);
         setDestination(parameter);
         setSuggestion(parameter);
         setDuration(parameter);
         setPaxAndRooms(parameter);
      }
      doSearch();
      LOGGER.log(WebDriverUtils.getDriver().getCurrentUrl());
   }

   private void setAirports(TestDataAttributes parameter)
   {
      String airport = parameter.getAirportName();
      if (airport != null && !airport.isEmpty())
      {
         airport().clearSelection().selectAirportByName(airport).confirmSelection();
      }
      else
      {
         airport().clearSelection().setAllAirportsSelected(true).confirmSelection();
      }
   }

   private void setDepartureDate(TestDataAttributes parameter)
   {
      departure().clearSelection().selectDate(parameter).confirmSelection();
   }

   private void setDestination(TestDataAttributes parameter)
   {
      String destination = parameter.getDestination();
      if (destination != null && !destination.isEmpty())
      {
         destination().clearSelection().selectDestinationFromList(destination, "")
                  .confirmSelection();
      }
   }

   private void setSuggestion(TestDataAttributes parameter)
   {
      String suggestion = parameter.getSuggestion();
      if (suggestion != null && !suggestion.isEmpty())
      {
         destinationSuggestions(suggestion).selectSuggestionFromList(suggestion);
      }
   }

   private void setDuration(TestDataAttributes parameter)
   {
      String duration = parameter.getDuration();
      if (duration != null && !duration.isEmpty())
      {
         selectDuration(duration);
      }
   }

   private void setPaxAndRooms(TestDataAttributes parameter)
   {
      String roomCount = parameter.getRoomCount();
      if (roomCount != null && !roomCount.isEmpty())
         paxAndRooms().selectNumberOfRooms(Integer.parseInt(roomCount));

      String noOfAdults = parameter.getNoOfAdults();
      if (noOfAdults != null && !noOfAdults.isEmpty())
         paxAndRooms().setAdultsNumber(Integer.parseInt(noOfAdults), 1);

      String noOfChildren = parameter.getNoOfChildren();
      if (noOfChildren != null && !noOfChildren.isEmpty())
      {
         int numChildren = Integer.parseInt(noOfChildren);
         if (numChildren > 0)
         {
            String childrenAge = parameter.getChildrenAge();
            String[] age;
            if (childrenAge.isEmpty())
               childrenAge = "0";

            if (childrenAge.contains(","))
            {
               age = childrenAge.split(",");
               for (int i = 0; i < numChildren; i++)
               {
                  paxAndRooms().addChild(age[i].trim(), 1);
               }
            }
            else
            {
               for (int i = 0; i < numChildren; i++)
               {
                  paxAndRooms().addChild(childrenAge, 1);
               }
            }
         }
      }
      paxAndRooms().confirmSelection();
   }

   @Override
   public String[] getErrorMessages()
   {
      return $(shadowDeepCss("div[aria-label='error message']")).getText().split("\n");
   }

   @Override
   public String getSelectedAirtports()
   {
      return getWrappers().getAirportWrapper().$("input[name='Departure Airport']")
               .getAttribute("placeholder");
   }

   @Override
   public String getSelectedDuration()
   {
      return getWrappers().getDurationWrapper().$("span.inputs__selectText").getText();
   }

   @Override
   public String getSelectedDate()
   {
      return getWrappers().getDepartureWrapper().$("input[aria-label='select date']")
               .getValue();
   }

   @Override
   public String getSelectedDestination()
   {
      return getWrappers().getDestinationWrapper().$("input[aria-label='select destinations']")
               .getAttribute("placeholder");
   }

   @Override
   public String getSelectedPaxAndRooms()
   {
      return getWrappers().getPaxAndRoomsWrapper().$("input[aria-label='rooms and guests']")
               .getValue();
   }

   @Override
   public String getPaxAndRoomsdurationComponentLable()
   {
      return getComponentLable(getWrappers().getPaxAndRoomsWrapper());
   }

   @Override
   public void clickClearAll()
   {
      getClearAllBtn().click();
   }

   @NotNull
   public SelenideElement getClearAllBtn()
   {
      return $(shadowDeepCss("div.ClearSearch__clearSearchPanel")).$("a");
   }

   private String getComponentLable(SelenideElement wrap)
   {
      String lableClassSelector = "label";
      return wrap.should(Condition.exist, WAIT_TIMEOUT)
               .$(lableClassSelector).should(Condition.exist, WAIT_TIMEOUT)
               .getText();
   }

   private ComponentWrappers getWrappers()
   {
      return new ComponentWrappersLegacy();
   }
}
