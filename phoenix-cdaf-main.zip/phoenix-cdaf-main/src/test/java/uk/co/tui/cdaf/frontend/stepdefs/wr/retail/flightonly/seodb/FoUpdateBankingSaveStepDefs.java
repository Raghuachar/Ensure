package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;

public class FoUpdateBankingSaveStepDefs
{
   private final RetailPackageNavigation retailpackagenaviagtion;

   private final FOReconcilationPaymentPageComponents reconcilationPage;

   public FoUpdateBankingSaveStepDefs()
   {
      retailpackagenaviagtion = new RetailPackageNavigation();
      reconcilationPage = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Agent is viewing the fo update banking modal")
   public void that_the_Agent_is_viewing_the_fo_update_banking_modal()
   {
      retailpackagenaviagtion.retailLoginChangeagent();
      reconcilationPage.navigateToReconcilePaymentPage();
      reconcilationPage.clickOnUpdateBankingLink();
   }

}
