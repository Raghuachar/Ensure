package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentOptionPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults.SearchResults;
import uk.co.tui.cdaf.frontend.utils.Generic;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static com.codeborne.selenide.Selenide.open;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class FlightOnlyPageNavigation
{

   private static final String DOT = ".";

   public final SearchResults searchResults;

   public final PageErrorHandler errorHandler;

   public final FlightOptionsPage flightOptionsPage;

   public final WebElementWait wait;

   public final PaymentOptionPage paymentOptionPage;

   public final ExtraOptionsPage extraOptionsPage;

   public final SearchPanelComponent searchPanelComponent;

   public final WebDriverUtils utils;

   public final RetailPage retailPage;

   public String flightSearch = StringUtils.EMPTY;

   private String adfsUrl = StringUtils.EMPTY;

   public FlightOnlyPageNavigation()
   {
      searchResults = new SearchResults();
      errorHandler = new PageErrorHandler();
      wait = new WebElementWait();
      flightOptionsPage = new FlightOptionsPage();
      paymentOptionPage = new PaymentOptionPage();
      extraOptionsPage = new ExtraOptionsPage();
      searchPanelComponent = new SearchPanelComponent();
      utils = new WebDriverUtils();
      retailPage = new RetailPage();
   }

   public void availableSearchResults()
   {
      searchPanelComponent.closePrivacyPopUp();
      if (!searchResults.isOutboundFlightButtonDisplyed())
      {
         if (searchResults.getOutboundDates().isEmpty())
         {
            do
            {
               WebElementTools.clickElementJavaScript(searchResults.getOutboundNextArrow());
               wait.forJSExecutionReadyLazy();
            } while (searchResults.getOutboundDates().isEmpty());
         }
         int incr = 0;
         while (incr < searchResults.getOutboundDates().size())
         {
            final WebElement element = searchResults.getOutboundDates().get(incr);
            WebElementTools.javaScriptScrollToElement(element);
            WebElementTools.clickElementJavaScript(element);
            if (WebElementTools.isPresent(searchResults.getInfoMessageModalElement()))
               WebElementTools.click(searchResults.getInfoMessageModalCloseElement());
            else
               break;
            WebElementTools.clickElementJavaScript(searchResults.getOutboundNextArrow());
            wait.forJSExecutionReadyLazy();
            incr++;
         }
      }
      if (!searchResults.isInboundFlightButtonDisplyed())
      {
         if (searchResults.getInboundDates().isEmpty())
         {
            do
            {
               WebElementTools.clickElementJavaScript(searchResults.getInboundNextArrow());
               wait.forJSExecutionReadyLazy();
            } while (searchResults.getInboundDates().isEmpty());
         }
         int incr = 0;
         while (incr < searchResults.getInboundDates().size())
         {
            final WebElement element = searchResults.getInboundDates().get(incr);

            WebElementTools.javaScriptScrollToElement(element);
            WebElementTools.clickElementJavaScript(element);

            if (WebElementTools.isPresent(searchResults.getInfoMessageModalElement()))
               WebElementTools.click(searchResults.getInfoMessageModalCloseElement());
            else
               break;
            WebElementTools.click(searchResults.getInboundNextArrow());
            wait.forJSExecutionReadyLazy();
            incr++;
         }
      }
   }

   public void oneWayAvailableSearchResults()
   {
      searchPanelComponent.closePrivacyPopUp();
      if (!searchResults.isOutboundFlightButtonDisplyed())
      {
         if (searchResults.getOutboundDates().isEmpty())
         {
            do
            {
               WebElementTools.clickElementJavaScript(searchResults.getOutboundNextArrow());
               wait.forJSExecutionReadyLazy();
            } while (searchResults.getOutboundDates().isEmpty());
         }
         int incr = 0;
         while (incr < searchResults.getOutboundDates().size())
         {
            final WebElement element = searchResults.getOutboundDates().get(incr);
            WebElementTools.javaScriptScrollToElement(element);
            WebElementTools.clickElementJavaScript(element);
            if (WebElementTools.isPresent(searchResults.getInfoMessageModalElement()))
               WebElementTools.click(searchResults.getInfoMessageModalCloseElement());
            else
               break;
            WebElementTools.clickElementJavaScript(searchResults.getOutboundNextArrow());
            wait.forJSExecutionReadyLazy();
            incr++;
         }
      }
   }

   public void navigateToFlightPage()
   {
      navigateToSearchResultPage();
      final WebElement outboundButton = searchResults.getOutboundFlightButton();
      WebElementTools.clickElementJavaScript(outboundButton);
      if (!flightSearch.equals("one way"))
      {
         final WebElement inboundButton = searchResults.getInboundFlightButton();
         WebElementTools.clickElementJavaScript(wait.getWebElementWithLazyWait(inboundButton));
      }
      WebElementTools
               .click(wait.getWebElementWithLazyWait(searchResults.getContinueToFlightButton()));
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToSearchResults()
   {
      navigateToSearchResultPage();
      final WebElement outboundButton = searchResults.getOutboundFlightButton();
      final WebElement inboundButton = searchResults.getInboundFlightButton();
      WebElementTools.clickElementJavaScript(outboundButton);
      WebElementTools.clickElementJavaScript(wait.getWebElementWithLazyWait(inboundButton));
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToSearchResultPage()
   {
      searchPanelComponent.visit();
      searchPanelComponent.closePrivacyPopUp();
      adfsUrl = utils.getCurrentURL();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      String url = getTestExecutionParams().getUrlStr()
               .replace("sncuser:U2FsZXMmQ29udGVudERvbWFpbg==@", StringUtils.EMPTY);
      if (!url.contains(".ma"))
         open(url);
      searchPanelComponent.closePrivacyPopUp();
      if (flightSearch.equalsIgnoreCase("one way"))
      {
         searchPanelComponent.wrFoOneWaySearch();
         oneWayAvailableSearchResults();
      }
      else
      {
         searchPanelComponent.wrFoTwoWaySearch();
         availableSearchResults();
      }
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToExtraPage()
   {
      navigateToFlightPage();
      flightOptionsPage.clickOnContinue();
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPassengerDetailsPage()
   {
      navigateToExtraPage();
      extraOptionsPage.clickOnContinue();
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPaymentOptionsPage()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      navigateToPassengerDetailsPage();
      nordicPassengerPage.fillThePassengerDetailsForWr();
      searchPanelComponent.closePrivacyPopUp();
      errorHandler.isPageLoadingCorrectly();
   }

}
