package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.DetailPriceBreakDown;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class DetailPriceBreakDownStepDefs
{
   public final RetailPackageNavigation retailpackagenavigation;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final DetailPriceBreakDown detailpricebreakdown;

   public DetailPriceBreakDownStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      detailpricebreakdown = new DetailPriceBreakDown();
   }

   @Given("that the agent has added a discount on the passenger details page to the booking")
   public void that_the_agent_has_added_a_discount_on_the_passenger_details_page_to_the_booking()
   {
      retailpackagenavigation.retailLogin();
      retailpackagenavigation.navigateToPassengerPage();
      retailpackagenavigation.addPassengerDetailsandwaitforAddFeetype();
      retailpassengerdetailspage.addFeeType();
      retailpackagenavigation.discountLessthantotal();
   }

   @When("they click the link {string}")
   public void they_click_the_link(String string)
   {
      detailpricebreakdown.priceDescriptionLink();
   }

   @Then("they can see the discount they have just added in the detailed price breakdown")
   public void they_can_see_the_discount_they_have_just_added_in_the_detailed_price_breakdown()
   {
      detailpricebreakdown.priceDescriptionDiscountisDisplayed();
      retailpassengerdetailspage.continueBacktoPassengerdetails();
      retailpassengerdetailspage.skippayment();
      retailpassengerdetailspage.userLogout();
   }

   @Given("that the agent has added a fee on the passenger detailed page to the booking")
   public void that_the_agent_has_added_a_fee_on_the_passenger_detailed_page_to_the_booking()
   {
      retailpackagenavigation.retailLogin();
      retailpackagenavigation.navigateToPassengerPage();
      retailpackagenavigation.addPassengerDetailsandwaitforAddFeetype();
      retailpassengerdetailspage.addFeeType();
      retailpackagenavigation.selectfeeType();
   }

   @Then("they can see the fee they have just added in the detailed price breakdown")
   public void they_can_see_the_fee_they_have_just_added_in_the_detailed_price_breakdown()
   {
      detailpricebreakdown.priceDescriptionFeeisDisplayed();
      retailpassengerdetailspage.continueBacktoPassengerdetails();
      retailpassengerdetailspage.skippayment();
      retailpassengerdetailspage.userLogout();
   }
}
