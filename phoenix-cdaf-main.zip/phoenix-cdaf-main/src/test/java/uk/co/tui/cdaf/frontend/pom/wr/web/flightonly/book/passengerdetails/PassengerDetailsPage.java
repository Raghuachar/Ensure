package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class PassengerDetailsPage extends AbstractPage
{
   public final PassengerFormComponent passengerFormComponent;

   public final WebElementWait wait;

   public final MarketingPermisssionComponent marketPermissionComp;

   public final ImportantInformationComponent impInfoComp;

   public final HomeStayEmergencyComponent emergencyComponent;

   private final Map<String, WebElement> passengerMap;

   @FindBy(css = "[aria-label='continue button'] button")
   private WebElement continueButton;

   @FindBy(css = "[aria-label='navigation link']")
   private WebElement navigationPanel;

   @FindBy(css = "[aria-label='price panel']")
   private WebElement pricePanel;

   @FindBy(css = "[aria-label='price panel'] [class*='totalPrice']")
   private WebElement totalPrice;

   public PassengerDetailsPage()
   {
      passengerMap = new HashMap<>();
      passengerFormComponent = new PassengerFormComponent();
      wait = new WebElementWait();
      marketPermissionComp = new MarketingPermisssionComponent();
      impInfoComp = new ImportantInformationComponent();
      emergencyComponent = new HomeStayEmergencyComponent();
   }

   public WebElement getContinueElement()
   {
      return wait.getWebElementWithLazyWait(continueButton);
   }

   public Map<String, WebElement> getPassengerComponents()
   {
      passengerMap.put("Navigation Panel", navigationPanel);
      passengerMap.put("Price Display (Sticky)", pricePanel);
      passengerMap.put("Passenger Details (Adult, Child, Infant)",
               passengerFormComponent.getPassengerFormElement());
      passengerMap.put("Continue Button", getContinueElement());
      passengerMap.putAll(marketPermissionComp.getMarketPermissionComponents());
      passengerMap.putAll(emergencyComponent.getEmergencyContactComponents());
      passengerMap.putAll(impInfoComp.getImpInfoComponents());
      return passengerMap;
   }

   public String passengerDetailsValues(String componentValues)
   {
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(totalPrice));
   }

}
