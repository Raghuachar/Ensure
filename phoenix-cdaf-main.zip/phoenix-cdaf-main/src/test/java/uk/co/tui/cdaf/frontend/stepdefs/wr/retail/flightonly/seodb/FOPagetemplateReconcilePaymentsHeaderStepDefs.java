package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOPagetemplateReconcilePaymentsHeaderStepDefs
{
   public final WebElementWait wait;

   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents;

   public FOPagetemplateReconcilePaymentsHeaderStepDefs()
   {

      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      wait = new WebElementWait();
      foReconcilationPaymentPageComponents = new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Agent is viewing the Reconcile payments page")
   public void that_the_Agent_is_viewing_the_Reconcile_payments_page()
   {
      retailflightNavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      foReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

   @When("they view the header beneath the TUI Global header")
   public void they_view_the_header_beneath_the_TUI_Global_header()
   {
      assertThat(" Global Header is not present",
               foReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
   }

   @Then("they can see the {string} header")
   public void they_can_see_the_header(String string)
   {
      wait.forJSExecutionReadyLazy();

   }

}
