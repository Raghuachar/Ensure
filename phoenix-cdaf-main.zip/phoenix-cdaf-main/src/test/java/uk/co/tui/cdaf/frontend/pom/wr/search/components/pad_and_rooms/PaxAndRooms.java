package uk.co.tui.cdaf.frontend.pom.wr.search.components.pad_and_rooms;

import com.codeborne.selenide.SelenideElement;

public interface PaxAndRooms
{
   boolean isOpen();

   PaxAndRooms clearSelection();

   PaxAndRooms selectNumberOfRooms(int i);

   PaxAndRooms setAdultsNumber(int i, int i1);

   PaxAndRooms addChild(String childrenAge, int i);

   PaxAndRooms selectRandomPaxAndRooms();

   SelenideElement getClearLink();

   SelenideElement getConfirmButton();

   SelenideElement getRoomSelector();

   String[] getLabels();

   String getErrorMessage();

   void confirmSelection();

    SelenideElement getAdultSelector(int roomNumber);
}
