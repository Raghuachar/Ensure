package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class DynamicFlightComponent
{

   @FindBy(css = "[aria-label='your flights']")
   private WebElement yourFlight;

   @FindBy(css = "[aria-label='Fuel Protection Fee']")
   private WebElement fuelProtectionFeeComponent;

   @FindBy(css = "[aria-label = 'expanded Insurance']")
   private WebElement insuranceComponent;

   @FindBy(css = "[aria-label='simple-popup']")
   private WebElement termsAndConditions;

   public Boolean isCareerInfoTransavia()
   {
      String careerInfo = (String) WebDriverUtils
               .executeScript(
                        "return jsonData.packageViewData.flightViewData[0].inboundJourneySummary.carrierName");
      return careerInfo.equalsIgnoreCase("transavia");
   }

   public boolean isDynamicFlight()
   {
      JavascriptExecutor executor = (JavascriptExecutor) getDriver();
      return (boolean) executor.executeScript(
               "return jsonData.packageViewData.flightViewData[0].isDynamicFlight");
   }

   public boolean isDirectInboundFlight()
   {
      String flightType = (String) WebDriverUtils
               .executeScript(
                        "return jsonData.packageViewData.flightViewData[0].inboundJourneySummary.journeyType");
      return flightType.equalsIgnoreCase("direct");
   }

   public boolean isDirectOutboundFlight()
   {
      String flightType = (String) WebDriverUtils
               .executeScript(
                        "return jsonData.packageViewData.flightViewData[0].outboundJourneySummary.journeyType");
      return flightType.equalsIgnoreCase("direct");
   }

   public boolean isFuelFeeProtectionComponentPresent()
   {
      return WebElementTools.isPresent(fuelProtectionFeeComponent);
   }

   public boolean isInsuranceComponentPresent()
   {
      return WebElementTools.isPresent(insuranceComponent);
   }

   public boolean isFlightDetailsPresent()
   {
      return WebElementTools.isPresent(yourFlight);
   }

   public boolean isTermsAndConditionsPresent()
   {
      return WebElementTools.isPresent(termsAndConditions);
   }
}
