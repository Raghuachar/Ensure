package uk.co.tui.cdaf.frontend.pom.wr.search.components.airport;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;

public class AirportMfe implements Airport
{
   static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   private static final AutomationLogManager LOGGER = new AutomationLogManager(AirportMfe.class);

   @Override
   public boolean isOpen()
   {
      return container().isDisplayed();
   }

   @Override
   public Airport clearSelection()
   {
      container().$("a.clear").click();
      return this;
   }

   @Override
   public Airport setAllAirportsSelected(boolean shouldSelect)
   {
      if (getAllAirportsCheckbox().isSelected() != shouldSelect)
      {
         SelenideElement selectAllCheckbox =
                  container().$("div.airportGroup").$("i.icon-checkbox[aria-checked='false']");
         selectAllCheckbox.click();
      }
      return this;
   }

   @NotNull
   public SelenideElement getAllAirportsCheckbox()
   {
      return container().$("div.airportGroup").$("input[type='checkbox']");
   }

   @Override
   public Airport selectRandomAirport()
   {
      ElementsCollection allAirports = getEnabledAirports();
      int totalCount = allAirports.size();
      int randomIndex = (int) (Math.random() * (totalCount - 1));
      SelenideElement randomAirport = allAirports.get(randomIndex);
      randomAirport.$(".icon-checkbox").click();
      String selected = randomAirport.$(".label-inline").getText();
      LOGGER.log("Random airport was selected: " + selected);
      return this;
   }

   @Override
   public Airport selectAirportByName(String airportName)
   {
      container().$(byText(airportName)).parent().$("i.icon-checkbox").click();
      LOGGER.log("Single airport was selected: " + airportName);
      return this;
   }

   @Override
   public List<String> getSelectedAirports()
   {
      return getEnabledAirports().asDynamicIterable().stream()
               .filter(selenideElement -> selenideElement.$("input").isSelected())
               .map(selenideElement -> selenideElement.$(".label-inline").getText()).distinct()
               .collect(Collectors.toList());
   }

   @Override
   public void confirmSelection()
   {
      container().$("button.primary").click();
   }

   public ElementsCollection getEnabledAirports()
   {
      SelenideElement airportList = container().$(".airportList > .SelectAirports__listStyle");
      return airportList.$$("li > .input-checkbox > .enabled");
   }

   private SelenideElement container()
   {
      return $(shadowDeepCss("div.dropModalContent")).should(appear, WAIT_TIMEOUT);
   }
}
