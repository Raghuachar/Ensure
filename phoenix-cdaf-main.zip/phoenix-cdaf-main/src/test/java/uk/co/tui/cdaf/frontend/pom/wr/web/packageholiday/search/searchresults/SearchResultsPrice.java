package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import org.apache.commons.lang3.math.NumberUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.Arrays;
import java.util.List;

import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class SearchResultsPrice extends AbstractPage
{
   static AutomationLogManager LOGGER = new AutomationLogManager(SearchResultsPrice.class);

   private final WebDriverUtils utils;

   public WebElementWait wait;

   @FindBy(css = "[class=Price__clearLink]")
   public List<WebElement> clearFilter;

   Actions act;

   private int filterPrice = 0;

   @FindBy(css = "[aria-label='price slider']")
   private WebElement priceFilter;

   @FindBy(css = "[class='Price__filterType'] [class='slider__slider'] input")
   private List<WebElement> sliderPrice;

   @FindBy(css = "[aria-label='price slider'] input[type='range']")
   private List<WebElement> priceSlider;

   @FindBy(css = "[aria-label='price slider'] .Price__value")
   private WebElement priceSliderCount;

   @FindBy(css = "[class='ResultListItemV2__value']")
   private List<WebElement> resultPrices;

   @FindBy(css = ".FilterPanelV2__clearAll")
   private WebElement clearAllFilters;

   @FindBy(css = "[class='Price__filterType'] [class='slider__slider'] input")
   private WebElement sliderPriceModal;

   public SearchResultsPrice()
   {
      utils = new WebDriverUtils();
      act = new Actions(getDriver());
      wait = new WebElementWait();
   }

   public boolean isPriceFilterDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(priceFilter);
   }

   public boolean isSliderPriceDisplayed()
   {
      return WebElementTools.isPresent(sliderPrice.get(0));
   }

   public boolean defaultPriceSliderValue()
   {
      String maxValue = sliderPrice.get(0).getAttribute("max");
      String sliderValue = sliderPrice.get(0).getAttribute("value");
      return sliderValue.equals(maxValue);
   }

   public boolean verifyPriceSliderChanged()
   {
      String sliderValue = sliderPrice.get(0).getAttribute("value");
      return !sliderValue.isEmpty();
   }

   public void selectSlider()
   {
      wait.forJSExecutionReadyLazy();
      int x = 10;
      int width = priceSlider.get(0).getSize().getWidth();
      act.moveToElement(priceSlider.get(0), ((width * x) / 100), 0).click().build().perform();
      filterPrice = utils.getNumberFromString(WebElementTools.getElementText(priceSliderCount));
      LOGGER.log(LogLevel.INFO, "filtered Price is :" + filterPrice);
      wait.forJSExecutionReadyLazy();
      verifyPriceSliderChanged();
   }

   public boolean isFilteredByPrice()
   {
      wait.forJSExecutionReadyLazy();
      int[] filteredResultPrice =
               resultPrices.stream().mapToInt(result -> NumberUtils.toInt(result.toString()))
                        .toArray();
      int[] filteredPrices =
               Arrays.stream(filteredResultPrice).filter(x -> x <= filterPrice).toArray();
      return filteredResultPrice.length == filteredPrices.length;
   }

   public boolean isClearFilterLinkDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(clearFilter.get(0)));
   }

   public boolean isClearAllFilterLinkDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(clearAllFilters);
   }

   public boolean isSliderPriceDisplayedModal()
   {
      return WebElementTools.isPresent(sliderPriceModal);
   }
}
