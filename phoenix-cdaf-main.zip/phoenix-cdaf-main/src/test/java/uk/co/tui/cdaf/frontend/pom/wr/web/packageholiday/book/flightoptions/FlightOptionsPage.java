package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.flightoptions;

import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.CabinAndSeatAncillaryComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.LuggageAncillaryComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.PriceBreakDownComponent;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class FlightOptionsPage
{

   public final BackToYourHolidayComponent backToYourHoliday;

   public final LuggageAncillaryComponent luggageComponent;

   public final CabinAndSeatAncillaryComponent cabinSeatComponent;

   public final ProgressionbarNavigationComponent navigationComponent;

   public final PriceBreakDownComponent breakdownComponent;

   public final AlternateFlightComponent alternateFlightComponent;

   public final AlternateFlightFilterComponent alternateFlightFilterComponent;

   public final WebElementWait wait;

   private final Map<String, WebElement> flightMap;

   public FlightOptionsPage()
   {
      backToYourHoliday = new BackToYourHolidayComponent();
      luggageComponent = new LuggageAncillaryComponent();
      cabinSeatComponent = new CabinAndSeatAncillaryComponent();
      navigationComponent = new ProgressionbarNavigationComponent();
      breakdownComponent = new PriceBreakDownComponent();
      wait = new WebElementWait();
      alternateFlightComponent = new AlternateFlightComponent();
      alternateFlightFilterComponent = new AlternateFlightFilterComponent();
      flightMap = new HashMap<>();
   }

   public Map<String, WebElement> getFlightComponents()
   {
      flightMap.putAll(cabinSeatComponent.getCabinComponents());
      flightMap.putAll(luggageComponent.getLuggageComponents());
      flightMap.putAll(alternateFlightComponent.getFlightSummaryComponents());
      flightMap.putAll(alternateFlightComponent.getAlternateFlightComponents());
      return flightMap;
   }
}
