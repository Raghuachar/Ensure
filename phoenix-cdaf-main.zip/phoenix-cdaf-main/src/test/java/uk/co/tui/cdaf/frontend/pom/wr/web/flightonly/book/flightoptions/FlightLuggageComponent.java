package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class FlightLuggageComponent extends AbstractPage
{
   private final WebElementWait wait;

   public String luggageDiffPrice, selectedLuggageWeight, totPriceAfterFormat;

   @FindBy(css = "[aria-label='luggage ancillary'] [class*='whatsIncluded']")
   protected WebElement luggageDescription;

   @FindBy(css = "[aria-label='luggage ancillary'] p[class*='price']+button")
   protected List<WebElement> luggageUpgradeButton;

   @FindBy(css = "div[class*='luggageDescription']")
   protected WebElement checkInAllowanceDescription;

   @FindBy(css = "[aria-label='luggage ancillary'] [aria-label='simple-popup'] a")
   protected WebElement moreInformationLink;

   @FindBy(css = "[aria-label='luggage ancillary']")
   private WebElement luggageSection;

   @FindBy(xpath = "(//*[@aria-label='luggage ancillary']//*[@class='cards__selectedText'])[1]")
   private List<WebElement> luggageSelectedText;

   @FindBy(css = "[aria-label='luggage ancillary'] p[class*='price']")
   private List<WebElement> luggageCardPrice;

   @FindBy(xpath = "//*[@aria-label='luggage ancillary']//p[contains(@class,'price')]/../..//*[contains(@class,'weight')]")
   private List<WebElement> luggageCardWeight;

   @FindBy(xpath = "//*[text()='0kg' and contains(@class,'cards__weight')]/../..//*[@class='cards__tick']")
   private List<WebElement> zeroKgLugaggeSelected;

   @FindBy(xpath = "//*[text()='40kg' and contains(@class,'cards__weight')]/../..//*[@class='cards__tick']")
   private List<WebElement> fourtyKgLugaggeSelected;

   @FindBy(xpath = "//*[text()='25kg' and contains(@class,'cards__weight')]/../..//*[@class='cards__tick']")
   private List<WebElement> twentyFiveKgLugaggeSelected;

   public FlightLuggageComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getLuggageSectionComponent()
   {
      return wait.getWebElementWithLazyWait(luggageSection);
   }

   public List<WebElement> getLuggageUpgradeButton()
   {
      return wait.getWebElementWithLazyWait(luggageUpgradeButton);
   }

   public boolean isLuggageSectionDisplayed()
   {
      return WebElementTools.isPresent(getLuggageSectionComponent());
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getFlightLuggageComponent()
   {
      return new HashMap<>()
      {
         {
            put("Luggage Description", luggageDescription);
            put("Luggage upgrade Radio button", luggageUpgradeButton.get(0));
            put("Total Check-in Allowance:0kg", checkInAllowanceDescription);
            put("Luggage specific Information Link", moreInformationLink);
         }
      };
   }

   public void selectAlternateLuggage()
   {
      if (!getLuggageUpgradeButton().isEmpty())
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.click(getLuggageUpgradeButton().get(0));
         luggageDiffPrice = WebElementTools.getElementText(luggageCardPrice.get(0));
         selectedLuggageWeight = WebElementTools.getElementText(luggageCardWeight.get(0));
      }
   }

   public boolean isAlternateLuggageButtonDisplayed()
   {
      return !getLuggageUpgradeButton().isEmpty();
   }

   public String getTextForSelectedLuggage()
   {
      return WebElementTools.getElementText(luggageSelectedText.get(0));
   }

   public boolean isZeroKgLuggageCardSelected()
   {
      return !zeroKgLugaggeSelected.isEmpty();
   }

   public boolean isFourtyKgLuggageCardSelected()
   {
      return !fourtyKgLugaggeSelected.isEmpty();
   }

   public boolean isTwentyFiveLuggageCardSelected()
   {
      return !twentyFiveKgLugaggeSelected.isEmpty();
   }

   public boolean isPriceMatched(String totalPriceBeforeUpgrade, String totPriceAfterUpdate)
   {
      try
      {
         luggageDiffPrice = luggageDiffPrice.replaceAll("[^0-9.]+", StringUtils.EMPTY);
         totalPriceBeforeUpgrade =
                  totalPriceBeforeUpgrade.replaceAll("[^0-9.]+", StringUtils.EMPTY);
         totPriceAfterUpdate = totPriceAfterUpdate.replaceAll("[^0-9.]+", StringUtils.EMPTY);
         double totPriceAfterAddition =
                  Double.parseDouble(totalPriceBeforeUpgrade) + Double.parseDouble(
                           luggageDiffPrice);
         DecimalFormat format = new DecimalFormat("##.00");
         totPriceAfterFormat = format.format(totPriceAfterAddition);
         return totPriceAfterFormat.equalsIgnoreCase(totPriceAfterUpdate);
      }
      catch (Exception e)
      {
         return false;
      }
   }

   public boolean isLugaggeWeightMatched(List<WebElement> flightExtrasElement)
   {
      try
      {
         String weight = selectedLuggageWeight.trim().replaceAll("[^0-9]+", StringUtils.EMPTY)
                  + "kg luggage × 1";
         WebElement matchedElement = flightExtrasElement.stream()
                  .filter(element -> StringUtils
                           .containsIgnoreCase(WebElementTools.getElementText(element), weight))
                  .findFirst().orElse(null);
         return Objects.nonNull(matchedElement);
      }
      catch (Exception e)
      {
         return false;
      }
   }

}
