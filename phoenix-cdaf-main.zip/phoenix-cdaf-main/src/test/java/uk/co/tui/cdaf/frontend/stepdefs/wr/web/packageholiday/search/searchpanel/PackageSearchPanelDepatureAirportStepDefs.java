package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.airport.Airport;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults.SearchResultsFiltersStepDefs;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;

import java.util.Map;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class PackageSearchPanelDepatureAirportStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchResultsFiltersStepDefs.class);

   public final SearchResultsComponent searchResultsComponent;

   public final SearchResultsPage searchResultsPage;

   private final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent;

   public PackageSearchPanelDepatureAirportStepDefs()
   {
      departureAirportOrDestinationComponent =
               new DepartureAirportAndDestinationAndDatesComponent();
      searchResultsComponent = new SearchResultsComponent();
      searchResultsPage = new SearchResultsPage();

   }

   @Then("the airport list will show")
   public void the_airport_list_will_show()
   {

      assertTrue("airport list view not displayed",
               getSearchPanel().airport().isOpen());
   }

   @Then("the airports will show in alphabetical order")
   public void the_airports_will_show_in_alphabetical_order()
   {
      assertThat("airports are not show in alphabetical order",
               departureAirportOrDestinationComponent.isVerifyingAirportsInAlphabeticalOrder(),
               is(true));
   }

   @Then("all available airports within the \"any airport\" group will be selected")
   public void all_available_airports_within_the_group_will_be_selected()
   {
      int allSelected = getSearchPanel().airport().getSelectedAirports().size();
      int allAirports = getSearchPanel().airport().getEnabledAirports().size();
      assertThat("all available airports are not selected ", allSelected, equalTo(allAirports));
   }

   @Then("the customer will be able to tick and untick any of these selections")
   public void the_customer_will_be_able_to_tick_and_untick_any_of_these_selections()
   {
      assertThat("Unable to Untick all airports",
               getSearchPanel().airport().setAllAirportsSelected(false).getSelectedAirports()
                        .size(), is(0));
      assertThat("Unable to tick random airport",
               getSearchPanel().airport().selectRandomAirport().getSelectedAirports().size(),
               greaterThan(0));
   }

   @Then("an All Airport box will be visible default state unticked")
   public void an_box_will_be_visible_default_state_unticked()
   {
      assertFalse("airport default state not unticked ",
               getSearchPanel().airport().getAllAirportsCheckbox().isSelected());
   }

   @Then("the following airports will be displayed next to the \"Any Airport\" box")
   public void the_following_airports_will_be_displayed_next_to_the_box(DataTable dataTable)
   {
      Map<String, Integer> map = dataTable.asMap(String.class, Integer.class);
      Integer actual = getSearchPanel().airport().getEnabledAirports().size();
      Integer expected = map.get(ExecParams.getTestExecutionParams().getBrandStr());
      assumeTrue("At least 2 airports should be selected to perform this validation",
               expected != null && expected > 1);
      assertThat("departure airport is not displayed", actual, equalTo(expected));
   }

   @Then("the unavailable airports will be greyed out")
   public void the_unavailable_airports_will_be_greyed_out()
   {
      // TODO: update this case to compare API response with UI representation
      assertThat("Unavailable airports are not greyed out ",
               departureAirportOrDestinationComponent.isAirportsGreyedOutPresent(), is(true));
   }

   @Then("the customer will not be able to click these")
   public void the_customer_will_not_be_able_to_click_these()
   {
      try
      {
         departureAirportOrDestinationComponent.clickAirportsGreyedOut();
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.INFO, "Unable to click Greyed Out element");
      }
   }

   @Then("they will be able to select any number of these")
   public void they_will_be_able_to_select_any_number_of_these()
   {
      departureAirportOrDestinationComponent.selectedSingleAirport();
      departureAirportOrDestinationComponent.getcheckedAirtportNames();
      assertTrue("Second Airport was not selected",
               departureAirportOrDestinationComponent.selectedSecondAirport());
   }

   @Then("when they close the airports list the search panel field will show the name of the first airport they selected")
   public void when_they_close_the_airports_list_the_search_panel_field_will_show_the_name_of_the_first_airport_they_selected()
   {
      Airport airport = getSearchPanel().airport();
      String firstSelectedAirport = airport.getEnabledAirports().get(0).getText();
      airport.setAllAirportsSelected(true).confirmSelection();
      String airportComponentLable = getSearchPanel().getSelectedAirtports();
      assertThat("Departure airport dropdown list not open  ", airportComponentLable,
               containsString(firstSelectedAirport));
   }

   @Then("it will show + number more if multiple airports have been selected")
   public void it_will_show_number_more_if_multiple_airports_have_been_selected()
   {
      String airportComponentLable = getSearchPanel().getSelectedAirtports();
      assertThat("Departure airport dropdown list not open  ",
               airportComponentLable, containsString(" + "));
   }

   @When("they select the All airports checkbox")
   public void they_select_the_Any_airport_checkbox()
   {
      getSearchPanel().airport().setAllAirportsSelected(true);
   }

   @When("they can clear by selecting Clear all")
   public void they_can_clear_by_selecting_Clear_all()
   {
      getSearchPanel().departure().clearSelection();
   }

   @Then("the airports will show as unselected")
   public void the_airports_will_show_as_unselected()
   {
      assertThat("airports are selected",
               departureAirportOrDestinationComponent.airportsUnSelected(), is(true));
   }

   @Then("the departure airport list will remain open")
   public void the_departure_airport_list_will_remain_open()
   {
      assertThat("Departure airport dropdown list not open",
               departureAirportOrDestinationComponent.dropdownWindowOpened(), is(true));
   }

   @Then("the {string} fields can {string} by selecting the following")
   public void the_fields_can_by_selecting_the_following(String string, String referal)
   {

      String abc = referal.contains("select outside") ? "info icon"
               : referal.contains("X") ? string + " close"
               : referal.contains("DONE")
               && (ExecParams.getTestExecutionParams().isNL())
               ? "Gedaan " + string : "Opslaan " + string;
      assertThat("searchpanel dropdown window not closed",
               departureAirportOrDestinationComponent.searchPanelDropDownCloseBy(abc), is(true));

   }

}
