package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageUpdateBankingEditStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageUpdateBankingEditStepDefs.class);

   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageUpdateBankingEditStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @When("they click the {string} link next to a banking entry")
   public void they_click_the_link_next_to_a_banking_entry(String string)
   {
      LOGGER.log(LogLevel.INFO, "Edit Deatiled Payment List:");
      assertThat("Payment Details List is not present",
               pKgReconcilationPaymentPageComponents.isUpdatePaymentDetails(), is(true));
      pKgReconcilationPaymentPageComponents.clickUpdatePaymentDetailsEdit();
   }

   @Then("the agent can modify the seal bag number or the banking amount within that line item")
   public void the_agent_can_modify_the_seal_bag_number_or_the_banking_amount_within_that_line_item()
   {
      pKgReconcilationPaymentPageComponents.enterDetailUpdateBankingAmount();
      pKgReconcilationPaymentPageComponents.enterDetailSealBagNumber();
   }

   @And("can then save changes via the SAVE CTA that will appear")
   public void can_then_save_changes_via_the_SAVE_CTA_that_will_appear()
   {
      pKgReconcilationPaymentPageComponents.clickEditSave();
      retailpassengerdetailspage.userLogout();
   }

}
