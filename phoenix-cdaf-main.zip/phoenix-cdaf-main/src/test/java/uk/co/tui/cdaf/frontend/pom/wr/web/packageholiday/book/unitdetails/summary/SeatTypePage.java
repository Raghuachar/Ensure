package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class SeatTypePage extends AbstractPage
{

   private final WebElementWait wait;

   @FindBy(css = "[class='ProgressbarNavigation__summaryButton']")
   public WebElement continueButton;

   @FindBy(css = "[id='FligtsSeatsTypeAncillary_component']")
   public WebElement seatTypeComponent;

   @FindBy(css = "[class='UI__optionsWrapper     ']")
   public WebElement seatInformation;

   @FindBy(css = "[aria-label='COM_SEAT']")
   public WebElement radioButton;

   @FindBy(css = "[class='ShowMore__showMoreHighlightedLink']")
   public WebElement showMoreLink;

   @FindBy(css = "[class='PriceDiscountBreakDownV2__optionDescription']")
   public WebElement priceBreakdownText;

   public SeatTypePage()
   {
      wait = new WebElementWait();
   }

   public boolean isSeatTypeComponentDisplayed()
   {
      return WebElementTools.isPresent(seatTypeComponent);
   }

   public boolean isSeatInformationDisplayed()
   {
      return WebElementTools.isPresent(seatInformation);
   }

   public void clickOnRadioButton()
   {
      WebElementTools.click(radioButton);
      wait.forJSExecutionReadyLazy();
   }

   public void clickOnShowMoreLink()
   {
      WebElementTools.click(showMoreLink);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isPriceBrekadownTextDisplayed()
   {
      return WebElementTools.isPresent(priceBreakdownText);
   }

}
