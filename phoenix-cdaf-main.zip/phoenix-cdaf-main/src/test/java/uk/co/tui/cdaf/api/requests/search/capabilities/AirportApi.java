package uk.co.tui.cdaf.api.requests.search.capabilities;

import lombok.SneakyThrows;
import uk.co.tui.cdaf.api.pojo.search.base.Airport;
import uk.co.tui.cdaf.api.pojo.search.legacy.AirportsResponse;
import uk.co.tui.cdaf.api.pojo.search.mfe.AirportData;
import uk.co.tui.cdaf.api.requests.search.parameters.SearchParameters;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import javax.annotation.Nullable;
import java.util.List;
import java.util.stream.Collectors;

public class AirportApi extends BaseApi
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(AirportApi.class);

   @SneakyThrows
   public List<Airport> getAvailableAirports(SearchParameters searchParameters)
   {
      List<Airport> airportData;
      if (!ExecParams.isSitEnv())
      {
         String responseBody = getCapabilitiesResponse(searchParameters, "departureairport")
                  .getBody().asString();
         airportData = objectMapper.readValue(responseBody, AirportData.class).getAirports();
      }
      else
      {
         String responseBody = getCapabilitiesResponse(searchParameters, "departures")
                  .getBody().asString();
         airportData = objectMapper.readValue(responseBody, AirportsResponse.class).getData()
                  .getAirports();
      }

      return airportData.stream()
               .filter(Airport::isAvailable).collect(Collectors.toList());
   }

   public List<Airport> getAirportByNameOrCode(@Nullable TestDataAttributes tda,
            SearchParameters searchParameters)
   {
      List<Airport> availableAirports = getAvailableAirports(searchParameters);

      if (tda == null || tda.getAirportName() == null)
         return availableAirports;

      String airportIdentity = tda.getAirportName();
      List<Airport> collect = availableAirports.stream()
               .filter(airport -> airport.getId().equalsIgnoreCase(airportIdentity)
                        || airport.getName().equalsIgnoreCase(airportIdentity))
               .collect(Collectors.toList());
      if (collect.isEmpty())
      {
         LOGGER.log(LogLevel.ERROR, "Airport with name or code " + airportIdentity +
                  " not found, searching with all available airports");
         return availableAirports;
      }
      return collect;
   }

}
