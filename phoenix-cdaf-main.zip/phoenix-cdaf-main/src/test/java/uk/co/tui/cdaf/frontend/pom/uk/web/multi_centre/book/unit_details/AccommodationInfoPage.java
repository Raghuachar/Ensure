package uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.unit_details;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.datatable.DataTable;
import lombok.SneakyThrows;
import uk.co.tui.cdaf.api.pojo.LocationData;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Selenide.$;

public class AccommodationInfoPage extends AbstractPage
{

   public SelenideElement getAccommodationHeader()
   {
      return $("div.Header__accomodationSection").$("h1");
   }

   public SelenideElement getAccomodationRating()
   {
      return $("div.Header__HeadSpacer").$("span.Header__tuiRatingWrapper")
               .$("span.ratings__rating");
   }

   public String getActualLocationNameString()
   {
      return $("[aria-label='location destination name']").getText();
   }

   @SneakyThrows
   public String getExpectedLocationNameString(DataTable dataTable)
   {
      Object locationMapObject = Selenide.executeJavaScript(
               "return JSON.stringify(jsonData?.packageData?.accommodation?.locationMap);");
      ObjectMapper objectMapper = new ObjectMapper();
      LocationData locationData =
               objectMapper.readValue(
                        Optional.ofNullable(locationMapObject).orElseThrow().toString(),
                        LocationData.class);

      return dataTable.asList().stream()
               .map(locationData::getValueByKey)
               .filter(Objects::nonNull)
               .collect(Collectors.joining(", "));
   }

   public SelenideElement getLocation()
   {
      return $("[aria-label='location destination name']");
   }
}
