package uk.co.tui.cdaf.frontend.pom.wr.search.components.airport;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.selected;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

public class AirportLegacy extends AirportMfe
{
   static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   private static final AutomationLogManager LOGGER = new AutomationLogManager(AirportLegacy.class);

   @Override
   public boolean isOpen()
   {
      return container().isDisplayed();
   }

   @Override
   public Airport setAllAirportsSelected(boolean shouldSelect)
   {
      if (getAllAirportsCheckbox().isSelected() != shouldSelect)
      {
         SelenideElement selectAllCheckbox = container().$("div.SelectAirports__parentGroup")
                  .$("label.inputs__CheckboxTextAligned ");
         selectAllCheckbox.click();
      }
      if (shouldSelect)
         getAllAirportsCheckbox().should(selected, WAIT_TIMEOUT);
      else
         getAllAirportsCheckbox().shouldNot(selected, WAIT_TIMEOUT);
      return this;
   }

   @NotNull
   public SelenideElement getAllAirportsCheckbox()
   {
      return container().$("div.SelectAirports__parentCheckbox")
               .$("label.inputs__CheckboxTextAligned").$("input");
   }

   @Override
   public Airport selectRandomAirport()
   {
      List<SelenideElement> allAirports = this.getEnabledAirports();
      int totalCount = allAirports.size();
      int randomIndex = (int) (Math.random() * (totalCount - 1));
      SelenideElement randomAirport = allAirports.get(randomIndex);
      randomAirport.parent().$(".inputs__box").click();
      String selected = randomAirport.parent().$(".inputs__text").getText();
      LOGGER.log("Random airport was selected: " + selected);
      return this;
   }

   @Override
   public Airport selectAirportByName(String airportName)
   {
      container().$(byText(airportName)).parent().$("span.inputs__box").click();
      LOGGER.log("Single airport was selected: " + airportName);
      return this;
   }

   @Override
   public Airport clearSelection()
   {
      container().$("a.DropModal__clear").click();
      return this;
   }

   @Override
   public void confirmSelection()
   {
      container().$("button.DropModal__apply").click();
   }

   @Override
   public List<String> getSelectedAirports()
   {
      List<String> collect = this.getEnabledAirports().asDynamicIterable().stream()
               .filter(SelenideElement::isSelected)
               .map(selenideElement -> selenideElement.parent().$(".inputs__text").getText())
               .map(String::toLowerCase).distinct().collect(Collectors.toList());
      LOGGER.log("Selected airports: " + collect);
      return collect;
   }

   public ElementsCollection getEnabledAirports()
   {
      return container().$(".SelectAirports__childrenGroup")
               .should(appear, WAIT_TIMEOUT)
               .$$("input[type='checkbox']:not([disabled])");
   }

   private SelenideElement container()
   {
      return $("div.DropModal__dropModalContent").should(appear, WAIT_TIMEOUT);
   }
}
