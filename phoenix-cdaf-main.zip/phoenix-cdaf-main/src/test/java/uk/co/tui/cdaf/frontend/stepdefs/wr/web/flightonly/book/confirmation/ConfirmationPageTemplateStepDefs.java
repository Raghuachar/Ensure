package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.confirmation;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.ConfirmationPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions.PaymentOptionPage;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class ConfirmationPageTemplateStepDefs
{
   static AutomationLogManager LOGGER =
            new AutomationLogManager(ConfirmationPageTemplateStepDefs.class);

   private final FlightOnlyPageNavigation pageNavigation;

   private final PaymentOptionPage paymentOptionPage;

   private final ConfirmationPage confirmationPage;

   public ConfirmationPageTemplateStepDefs()
   {
      pageNavigation = new FlightOnlyPageNavigation();
      paymentOptionPage = new PaymentOptionPage();
      confirmationPage = new ConfirmationPage();
   }

   @Given("the customer is on the WR FO {string}")
   public void the_customer_is_on_the_WR_FO(String pageName)
   {
      pageNavigation.navigateToPaymentOptionsPage();
   }

   @When("the confirm their payment")
   public void the_confirm_their_payment()
   {
      paymentOptionPage.wait.forJSExecutionReadyLazy();
      paymentOptionPage.paymentOptionComponent.clickPaymentMethod();
      paymentOptionPage.paymentOptionComponent.clickOnPayButton();
      paymentOptionPage.wait.forJSExecutionReadyLazy();
      paymentOptionPage.paymentProviderPage.enterCardDetails();
   }

   @Then("they should be navigated to the WR FO Booking Confirmation Page")
   public void they_should_be_navigated_to_the_WR_FO_Booking_Confirmation_Page()
   {
      boolean isDisplayed = confirmationPage.isBookingRefTitleDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Booking Ref Title is not displayed", isDisplayed, true), isDisplayed, is(true));
   }

   @Then("the following components should display:")
   public void the_following_components_should_display(final List<String> components)
   {
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element =
                     confirmationPage.getConfirmationComponents().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("confirmation page should be displayed with following items.")
   public void confirmation_page_should_be_displayed_with_following_items(List<String> items)
   {
      pageNavigation.wait.forJSExecutionReadyLazy();
      pageNavigation.wait.forJSExecutionReadyLazy();
      the_following_components_should_display(items);
   }

   @Then("the booking page should be displayed with booking reference")
   public void the_booking_should_be_successful()
   {
      String bookRefId = confirmationPage.getBookRefId();
      LOGGER.log(LogLevel.INFO, "Booking refernce number:" + bookRefId);
      if (!bookRefId.matches("[0-9]{7,11}"))
         assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                  "Booking Ref id is not displayed", bookRefId, true), false, is(true));

   }

   @And("booking reference number should be displayed")
   public void booking_reference_number_should_be_displayed()
   {
      the_booking_should_be_successful();
   }

   @Then("Compare search results values with confirmation page values")
   public void compare_search_results_values_with_confirmation_page_values()
   {
      Map<String, String> searchvalue = searchStoreValues.getSearchValues();
      String confirmationpageValue;
      confirmationpageValue = confirmationPage.confirmationPageComponents("First");
      assertThat("Pax error message is not matched",
               searchvalue.get("PAX").trim().equalsIgnoreCase(confirmationpageValue), is(true));
   }
}
