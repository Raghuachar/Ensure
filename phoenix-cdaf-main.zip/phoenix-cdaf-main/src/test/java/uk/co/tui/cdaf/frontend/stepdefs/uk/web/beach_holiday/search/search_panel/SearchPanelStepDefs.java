package uk.co.tui.cdaf.frontend.stepdefs.uk.web.beach_holiday.search.search_panel;

import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelPage;
import uk.co.tui.cdaf.frontend.utils.DOMElement;
import uk.co.tui.cdaf.frontend.utils.DOMElement.ByType;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class SearchPanelStepDefs
{

   private final WebElementWait wait = new WebElementWait();

   private final SearchPanelPage searchPanelPage = new SearchPanelPage();

   private final SearchPanelComponent searchPanelComponent = new SearchPanelComponent();

   @Then("^\"([^\"]*)\" dropmenu title \"([^\"]*)\" is displayed$")
   public void dropmenu_title_is_displayed(String searchPanelField, String dropModalTitle)
   {
      if (searchPanelField.contains("Airport"))
      {
         assertThat(DOMElement.isElementExist(ByType.ARIA_LABEL, "airports header"), is(true));
         wait.waitForAWhile(500);
      }
      else if (searchPanelField.contains("Destination") || searchPanelField.contains("Hotel"))
      {
         assertThat(DOMElement.isElementExist(ByType.ARIA_LABEL, "destinations header"), is(true));
         wait.waitForAWhile(500);
      }
      else if (searchPanelField.contains("When"))
      {
         assertThat(DOMElement.isElementExist(ByType.ARIA_LABEL, "Departure date header"),
                  is(true));
      }
      else if (searchPanelField.contains("Room"))
      {
         assertThat(getSearchPanel().getPaxAndRoomsdurationComponentLable(), not(emptyString()));
      }
   }

   @Then("^Rooms & Guest dropmenu title is displayed$")
   public void checkPaxHeader()
   {
      assertThat(getSearchPanel().getPaxAndRoomsdurationComponentLable(), not(emptyString()));
   }

   @Then("^\"([^\"]*)\" field \"([^\"]*)\" value is displayed$")
   public void field_airport_value_is_displayed(String searchPanelField, String fieldValue)
   {
      if (searchPanelField.contains("Airport"))
      {
         assertThat(DOMElement.matchTextSpanTag(fieldValue).get(0).isDisplayed()
                  || DOMElement.matchTextSpanTag(fieldValue).get(1).isDisplayed(), is(true));
      }
      else if (searchPanelField.contains("Destination") || searchPanelField.contains("Hotel"))
      {
         assertThat(searchPanelComponent.getDestinationForGivenValue(fieldValue), is(true));
      }
      else if (searchPanelField.contains("When"))
      {
         assertThat(DOMElement.isPagePresent(fieldValue), is(true));
      }
      else if (searchPanelField.contains("Room"))
      {
         assertThat(getSearchPanel().paxAndRooms().getLabels(), hasItemInArray(fieldValue));
      }
   }

   @Then("^Rooms & Guest field \"([^\"]*)\" value is displayed$")
   public void paxSubComponentLabelsValues(String fieldValue)
   {
      assertThat(getSearchPanel().paxAndRooms().getLabels(), hasItemInArray(fieldValue));
   }

   @Then("^\"([^\"]*)\" field \"([^\"]*)\" link is displayed$")
   public void field_link_is_displayed(String searchPanelField, String link)
   {
      wait.forJSExecutionReadyLazy();
      if (searchPanelField.contains("Airport"))
      {
         assertThat(DOMElement.isElementExist(ByType.ARIA_LABEL, link + " airports"), is(true));
      }
      else if (searchPanelField.contains("Destination") || searchPanelField.contains("Hotel"))
      {
         assertThat(DOMElement.isElementExist(ByType.ARIA_LABEL, link + " destinations"), is(true));
      }
      else if (searchPanelField.contains("When"))
      {
         assertThat(DOMElement.isElementExist(ByType.ARIA_LABEL, link + " Departure date"),
                  is(true));
      }
   }

   @Then("^\"([^\"]*)\" is displayed in country overlay$")
   public void is_displayed_in_country_overlay(String countryName)
   {
      for (WebElement element : DOMElement.matchTextSpanTag(countryName))
      {
         wait.waitForAWhile(1000);
         String destinationName = element.getText();
         if (destinationName.contains("Destinations in"))
         {
            element.isDisplayed();
            assertThat(element.getText(), is(equals(countryName)));
         }
      }
   }

   @Then("^the customer should be able to view the following \"([^\"]*)\" in Calendar overlay$")
   public void the_customer_should_be_able_to_view_the_following_in_Calendar_overlay(String arg1)
   {
      throw new PendingException();
   }

   @Then("^the \"([^\"]*)\" drop down list should have below mentioned values$")
   public void the_drop_down_list_should_have_below_mentioned(String searchPanelField,
            List<String> values)
   {
      if (searchPanelField.contains("Duration"))
      {
         assertThat(searchPanelComponent.isDurationValuesPresent(values), is(true));
      }
      else if (searchPanelField.contains("Room"))
      {
         assertThat(searchPanelComponent.isNumberOfRoomsValuesPresent(values), is(true));
      }
   }

   @Then("^the Rooms & Guest drop down list should have below mentioned values$")
   public void checkPaxRoomAvailableValues(DataTable values)
   {
      List<String> actualResult =
               getSearchPanel().paxAndRooms().getRoomSelector().getOptions().texts();
      String[] expectedResult = values.asLists().stream().flatMap(List::stream).map(String::trim)
               .toArray(String[]::new);
      assertThat(actualResult, Matchers.containsInRelativeOrder(expectedResult));
   }

   @Then("the {string} drop down list should have below mentioned values for fc")
   public void the_drop_down_list_should_have_below_mentioned_values_for_fc(String searchPanelField,
            List<String> values)
   {
      assertThat(searchPanelComponent.isDurationValuesPresentForFc(values), is(true));
   }

   @When("^the customer clicks on Rooms & Guests logo$")
   public void the_customer_clicks_on_Rooms_Guests_logo()
   {
      getSearchPanel().paxAndRooms();
   }

   @Then("^the customer clicks the Number of Rooms drop down$")
   public void the_customer_clicks_the_Number_of_Rooms_drop_down()
   {
      getSearchPanel().paxAndRooms().getRoomSelector().click();
   }

   @When("they view the Search Panel fields")
   public void they_view_the_Search_Panel_fields()
   {
      // Implementation not required
   }

   @And("the customer selects {int} Adult, {int} Children without entering child age")
   public void the_customer_selects_Adult_Children_without_entering_child_age(int adult, int child)
   {
      getSearchPanel().paxAndRooms().setAdultsNumber(adult, 1);
      String childAgeDefaultValue = WebDriverRunner.url().contains("sit") ? "-1" : "Kies leeftijd";
      for (int i = 0; i < child; i++)
      {
         getSearchPanel().paxAndRooms().addChild(childAgeDefaultValue, 1);
      }
   }

   @When("the customer selects the Done button on the Rooms & Guest Overlay")
   public void the_customer_selects_the_Done_button_on_the_Rooms_Guest_Overlay()
   {
      getSearchPanel().paxAndRooms().confirmSelection();
   }

   @Then("the Search button should be enabled")
   public void the_Search_button_should_be_enabled()
   {
      boolean searchBtnEnabled = getSearchPanel().isSearchButtonEnabled();
      assertTrue("Search button is enabled:", searchBtnEnabled);
   }

   @Then("the Search button should be disabled")
   public void the_Search_button_should_be_disabled()
   {
      boolean searchBtnEnabled = getSearchPanel().isSearchButtonEnabled();
      assertFalse("Search button is enabled:", searchBtnEnabled);
   }

   @And("the following error message should be displayed:")
   public void the_following_error_message_should_be_displayed(DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String expected = map.get(getTestExecutionParams().getBrandStr());
      String actual = getSearchPanel().paxAndRooms().getErrorMessage();
      assertThat(actual, equalToIgnoringCase(expected));
      getSearchPanel().paxAndRooms().confirmSelection();
   }

   @And("the customer has selected the more than 9 passenger")
   public void the_customer_has_selected_the_more_than_passenger()
   {
      getSearchPanel().paxAndRooms().clearSelection().addChild("10", 1).setAdultsNumber(9, 1);
   }

   @Then("^the following max passenger error message is displayed")
   public void the_following_max_passenger_error_message_is_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = map.get(getTestExecutionParams().getBrandStr());
         actual = searchPanelPage.getErrorMessage();
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY, expected +
                           " is not matched", actual, expected),
                  StringUtils.equalsIgnoreCase(expected.toLowerCase(), actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Then("Rooms & Guest clear \"([^\"]*)\" value is displayed$")
   public void roomAndGuestClearLinkValue(String linkLable)
   {
      assertThat(getSearchPanel().paxAndRooms().getClearLink().getText(),
               equalToIgnoringCase(linkLable));
   }

   @Then("Rooms & Guest confirm \"([^\"]*)\" value is displayed$")
   public void field_link_is_displayed(String buttonLable)
   {
      assertThat(getSearchPanel().paxAndRooms().getConfirmButton().getText(),
               equalToIgnoringCase(buttonLable));
   }
}
