package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.HideSeatTypeComponent;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class HideSeatTypeComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public HideSeatTypeComponent hideSeatTypeComponent;

   public HideSeatTypeComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      hideSeatTypeComponent = new HideSeatTypeComponent();
   }

   @Given("that a customer is making a TUI PP Booking")
   public void that_a_customer_is_making_a_TUI_PP_Booking()
   {
      packageNavigation.navigateTosummaryPage();
      hideSeatTypeComponent.isTUIPartPlaneFlight();
   }

   @Then("the Seat Type component should not be visible")
   public void the_Seat_Type_component_should_not_be_visible()
   {
      if (!hideSeatTypeComponent.isTUIPartPlaneFlight())
      {
         assertThat("The Seat Type component is not displayed",
                  hideSeatTypeComponent.isSeatTypeComponentPresent(), is(false));
      }
   }

   @Given("that the customer has completed a TUI PP booking")
   public void that_the_customer_has_completed_a_TUI_PP_booking()
   {
      packageNavigation.navigateToConfirmationPage();
      hideSeatTypeComponent.isTUIPartPlaneFlight();
   }

   @When("the BCP is displayed")
   public void the_BCP_is_displayed()
   {
      assertThat("The BCP is not displayed", hideSeatTypeComponent.isBCPDisplayed(), is(true));
   }

   @Then("the Seat type should not be visible to the customer")
   public void the_Seat_type_should_not_be_visible_to_the_customer()
   {
      assertThat("The Seat Type component is not displayed on BCP",
               hideSeatTypeComponent.isSeatTypeComponentPresentBCP(), is(false));
   }
}
