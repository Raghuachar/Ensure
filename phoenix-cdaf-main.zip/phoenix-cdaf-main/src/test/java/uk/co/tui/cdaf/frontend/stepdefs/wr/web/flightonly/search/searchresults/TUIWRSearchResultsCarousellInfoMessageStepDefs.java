package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults.SearchResults;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TUIWRSearchResultsCarousellInfoMessageStepDefs
{

   private final SearchResults searchresults;

   public TUIWRSearchResultsCarousellInfoMessageStepDefs()
   {
      searchresults = new SearchResults();
   }

   @Given("a customer is on the Hybris Flight Only site for any domain")
   public void a_customer_is_on_the_Hybris_Flight_Only_site_for_any_domain()
   {
      searchresults.visit();
   }

   @Given("they are on the Flight Only search results page")
   public void they_are_on_the_Flight_Only_search_results_page()
   {
      assertThat("Search Results Are visible", searchresults.isOutboundSearchResultsPresent(),
               is(true));
      assertThat("Search Results Are visible", searchresults.isReturnSearchResultsPresent(),
               is(true));
   }

   @When("they scroll to a date in either the Inbound or Outbound carousel that is earlier than {int}th Oct, {int}")
   public void they_scroll_to_a_date_in_either_the_Inbound_or_Outbound_carousel_that_is_earlier_than_th_Oct(
            Integer day, Integer year)
   {
      assertThat("Carousel has dates before " + day + "of oct" + year,
               searchresults.hasCaroucelItemsBeforeInventoryStartDate(), is(true));
   }

   @Then("they will see the date and the text {string} below \\(as per UI)")
   public void they_will_see_the_date_and_the_text_below_as_per_UI(String string)
   {
      assertThat("Info text is shown", searchresults.caroucelItemsBeforeInventoryStartDateHasInfo(),
               is(true));
   }

   @Then("no price will be displayed")
   public void no_price_will_be_displayed()
   {
      assertThat("Info text is shown",
               searchresults.caroucelItemsBeforeInventoryStartDateHasNoPrice(), is(true));
   }

   @Given("a customer is on the Hybris Tuifly.be site")
   public void a_customer_is_on_the_Hybris_Tuifly_be_site()
   {
      WebDriverUtils.getDriver()
               .get(new SearchDataHelper().getBookingData("crossOverInfo", "be_fo")
                        .getSearchresURL());
   }

   @Given("they are on the flight only search results page")
   public void they_are_on_the_flight_only_search_results_page()
   {
      assertThat("Search Results Are visible", searchresults.isOutboundSearchResultsPresent(),
               is(true));
      assertThat("Search Results Are visible", searchresults.isReturnSearchResultsPresent(),
               is(true));
   }

   @When("the customer selects info on a date earlier than inventaris date in the outbound or return carousels")
   public void the_customer_selects_info_on_a_date_earlier_than_inventaris_date_in_the_outbound_or_return_carousels()
   {
      searchresults.clickOnInfoLinkInCaroucel();
   }

   @Then("an Info message will appear")
   public void an_Info_message_will_appear()
   {
      assertThat("Info modal message appears", searchresults.checkIfInfoModalMessageIsVisible(),
               is(true));
   }

   @Then("a CTA with a text will be visible")
   public void a_CTA_with_a_text_will_be_visible()
   {
      assertThat("CTA text is visible", searchresults.checkIfInfoModalCTAIsVisible(), is(true));
   }

   @Given("a customer is on the Hybris Tuifly.fr site")
   public void a_customer_is_on_the_Hybris_Tuifly_fr_site()
   {
      WebDriverUtils.getDriver()
               .get(new SearchDataHelper().getBookingData("crossOverInfo", "fr_fo")
                        .getSearchresURL());
      searchresults.setSearchLegacyUrl();
   }

   @Given("a customer is on the Hybris Tuifly.ma site")
   public void a_customer_is_on_the_Hybris_Tuifly_ma_site()
   {
      WebDriverUtils.getDriver()
               .get(new SearchDataHelper().getBookingData("crossOverInfo", "ma_fo")
                        .getSearchresURL());
      searchresults.setSearchLegacyUrl();
   }

   @Given("a customer is on the Hybris Tui.nl\\/vliegtickets site")
   public void a_customer_is_on_the_Hybris_Tui_nl_vliegtickets_site()
   {
      WebDriverUtils.getDriver()
               .get(new SearchDataHelper().getBookingData("crossOverInfo", "nl_fo")
                        .getSearchresURL());
      searchresults.setSearchLegacyUrl();
   }

   @Given("I am on the Hybris tuifly.be site")
   public void i_am_on_the_Hybris_tuifly_be_site()
   {
      WebDriverUtils.getDriver()
               .get(new SearchDataHelper().getBookingData("crossOverInfo", "be_fo")
                        .getSearchresURL());
      searchresults.setSearchLegacyUrl();
   }

   @Given("I have selected info on a date earlier than inventaris date in the outbound or return carousels")
   public void i_have_selected_info_on_a_date_earlier_than_inventaris_date_in_the_outbound_or_return_carousels()
   {
      searchresults.clickOnInfoLinkInCaroucel();
   }

   @When("I click on the CTA")
   public void i_click_on_the_CTA()
   {
      searchresults.clickOnCTALinkInCaroucel();
   }

   @Then("I will be redirected to tuifly.be homepage on the legacy site")
   public void i_will_be_redirected_to_tuifly_be_homepage_on_the_legacy_site()
   {
      assertThat("Site is redirected to Legacy site",
               searchresults.isRedirected(searchresults.getSearchLegacyUrl()), is(true));
   }

   @Then("I will remain in the same tab\\/window")
   public void i_will_remain_in_the_same_tab_window()
   {
      assertThat("No new tab has been opened", searchresults.isOnSameTab(), is(true));
   }

   @Then("my search criteria will not be retained from Hybris")
   public void my_search_criteria_will_not_be_retained_from_Hybris()
   {
      assertThat("Search criteria will not be retained from hybris",
               searchresults.isRedirected(searchresults.getSearchLegacyUrl()), is(true));
   }

   @Given("I am on the Hybris tuifly.fr site")
   public void i_am_on_the_Hybris_tuifly_fr_site()
   {
      WebDriverUtils.getDriver()
               .get(new SearchDataHelper().getBookingData("crossOverInfo", "fr_fo")
                        .getSearchresURL());
      searchresults.setSearchLegacyUrl();
   }

   @Then("I will be redirected to tuifly.fr homepage on the legacy site")
   public void i_will_be_redirected_to_tuifly_fr_homepage_on_the_legacy_site()
   {
      assertThat("Site is redirected to Legacy site",
               searchresults.isRedirected(searchresults.getSearchLegacyUrl()), is(true));
   }

   @Given("I am on the Hybris tuifly.ma site")
   public void i_am_on_the_Hybris_tuifly_ma_site()
   {
      WebDriverUtils.getDriver()
               .get(new SearchDataHelper().getBookingData("crossOverInfo", "ma_fo")
                        .getSearchresURL());
      searchresults.setSearchLegacyUrl();
   }

   @Then("I will be redirected to tuifly.ma homepage on the legacy site")
   public void i_will_be_redirected_to_tuifly_ma_homepage_on_the_legacy_site()
   {
      assertThat("Site is redirected to Legacy site",
               searchresults.isRedirected(searchresults.getSearchLegacyUrl()), is(true));
   }

   @Given("I am on the Hybris tui.nl\\/vliegtickets site")
   public void i_am_on_the_Hybris_tui_nl_vliegtickets_site()
   {
      WebDriverUtils.getDriver()
               .get(new SearchDataHelper().getBookingData("crossOverInfo", "nl_fo")
                        .getSearchresURL());
      searchresults.setSearchLegacyUrl();
   }

   @Then("I will be redirected to tui.nl\\/vliegtickets homepage on the legacy site")
   public void i_will_be_redirected_to_tui_nl_vliegtickets_homepage_on_the_legacy_site()
   {
      assertThat("Site is redirected to Legacy site",
               searchresults.isRedirected(searchresults.getSearchLegacyUrl()), is(true));
   }
}
