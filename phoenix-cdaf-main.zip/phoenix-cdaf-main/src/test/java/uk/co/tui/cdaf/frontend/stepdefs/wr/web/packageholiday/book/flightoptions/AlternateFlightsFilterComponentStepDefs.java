package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.flightoptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class AlternateFlightsFilterComponentStepDefs
{
   public final FlightOptionsPage flightOptionsPage;

   public AlternateFlightsFilterComponentStepDefs()
   {
      flightOptionsPage = new FlightOptionsPage();
   }

   @When("they select the filter component")
   public void they_select_the_filter_component()
   {
      flightOptionsPage.alternateFlightFilterComponent.clickOnFilterIcon();
   }

   @Then("they will be presented with the Flight Times filter options for both Going Out and Going Back journies")
   public void they_will_be_presented_with_the_Flight_Times_filter_options_for_both_Going_Out_and_Going_Back_journies()
   {
      boolean actual =
               flightOptionsPage.alternateFlightFilterComponent.isFilterComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight Filter component wasn't displayed", actual, true), actual,
               is(true));
   }

   @Then("the timeslot options will be unchecked by default")
   public void the_timeslot_options_will_be_unchecked_by_default()
   {
      boolean actual =
               flightOptionsPage.alternateFlightFilterComponent.isAlternateFlightsTimingsDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight Timings component wasn't displayed", actual, true), actual,
               is(true));
   }

   @Given("they have selected the filter component")
   public void they_have_selected_the_filter_component()
   {
      flightOptionsPage.alternateFlightFilterComponent.clickOnFilterIcon();
   }

   @When("they select a timeslot for Outbound \\(Going out) flights")
   public void they_select_a_timeslot_for_Outbound_Going_out_flights()
   {
      flightOptionsPage.alternateFlightFilterComponent.clickOnTimingsCheckbox();
   }

   @Then("only available flights with an outbound departure time falling within that time period will display")
   public void only_available_flights_with_an_outbound_departure_time_falling_within_that_time_period_will_display()
   {
      boolean actual =
               flightOptionsPage.alternateFlightFilterComponent.isGoingOutTimingFLightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight Going Out Timings component wasn't displayed", actual, true),
               actual, is(true));
   }

   @When("they select a timeslot for Return \\(Going back) flights")
   public void they_select_a_timeslot_for_Return_Going_back_flights()
   {
      flightOptionsPage.alternateFlightFilterComponent.clickOnTimingsCheckbox();
   }

   @Then("only available flights with an return departure time falling within that time period will display")
   public void only_available_flights_with_an_return_departure_time_falling_within_that_time_period_will_display()
   {
      boolean actual =
               flightOptionsPage.alternateFlightFilterComponent.isGoingOutTimingFLightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight Going Out Timings component wasn't displayed", actual, true),
               actual, is(true));
   }

   @When("they select multiple timeslots across Outbound, Return or both")
   public void they_select_multiple_timeslots_across_Outbound_Return_or_both()
   {
      flightOptionsPage.alternateFlightFilterComponent.clickOnTimingsCheckbox();
   }

   @Then("available flights with departure times falling in both selected Outbound AND selected Return timeslots will be displayed")
   public void available_flights_with_departure_times_falling_in_both_selected_Outbound_AND_selected_Return_timeslots_will_be_displayed()
   {
      boolean actual =
               flightOptionsPage.alternateFlightFilterComponent.isGoingOutTimingFLightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight Going Out Timings component wasn't displayed", actual, true),
               actual, is(true));
   }

   @Given("they have selected timeslots to be filtered")
   public void they_have_selected_timeslots_to_be_filtered()
   {
      boolean actual =
               flightOptionsPage.alternateFlightFilterComponent.isGoingOutTimingFLightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight Going Out Timings component wasn't displayed", actual, true),
               actual, is(true));
   }

   @When("those timeslots are unselected")
   public void those_timeslots_are_unselected()
   {
      flightOptionsPage.alternateFlightFilterComponent.clickOnTimingsCheckbox();
   }

   @Then("that timeslot filter is not longer applied")
   public void that_timeslot_filter_is_not_longer_applied()
   {
      flightOptionsPage.alternateFlightFilterComponent.clickOnTimingsCheckbox();
   }

   @When("the customer selected {string}")
   public void the_customer_selected(String string)
   {
      flightOptionsPage.alternateFlightFilterComponent.clearAllLink();
   }

   @Then("all selected timeslot filters will be dropped")
   public void all_selected_timeslot_filters_will_be_dropped()
   {
      boolean actual =
               flightOptionsPage.alternateFlightFilterComponent.isAlternateFlightsTimingsDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight Timings component wasn't displayed", actual, true), actual,
               is(true));
   }

   @Then("all available available alternative flights will be available for selection")
   public void all_available_available_alternative_flights_will_be_available_for_selection()
   {
      boolean actual =
               flightOptionsPage.alternateFlightFilterComponent.isGoingOutTimingFLightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight Going Out Timings component wasn't displayed", actual, true),
               actual, is(true));
   }

}
