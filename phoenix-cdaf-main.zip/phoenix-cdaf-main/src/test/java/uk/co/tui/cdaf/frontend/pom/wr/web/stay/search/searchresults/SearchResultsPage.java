package uk.co.tui.cdaf.frontend.pom.wr.web.stay.search.searchresults;

public class SearchResultsPage
{
   public final SearchResultCardComponent searchResultCardComponent;

   public SearchResultsPage()
   {
      searchResultCardComponent = new SearchResultCardComponent();
   }

}
