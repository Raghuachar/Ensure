package uk.co.tui.cdaf.frontend.pom.wr.web.stay.book;

import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.stay.book.yourholiday.SummaryPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.stay.search.searchresults.SearchResultsPage;

import static com.codeborne.selenide.Selenide.open;

public class StayPageNavigation
{
   public final SearchResultsPage searchResultsPage;

   public final SummaryPage summaryPage;

   public final PageErrorHandler errorHandler;

   private final NordicsPassengerDetailsPage nordicPassengerPage;

   public StayPageNavigation()
   {
      errorHandler = new PageErrorHandler();
      searchResultsPage = new SearchResultsPage();
      summaryPage = new SummaryPage();
      nordicPassengerPage = new NordicsPassengerDetailsPage();
   }

   public void navigateToSearchResultPage()
   {
      // TODO: remove hardcoded url
      open("https://sncuser:U2FsZXMmQ29udGVudERvbWFpbg==@tuinr-slsstg-alb-tbepkg-2120086277.eu-central-1.elb.amazonaws.com/destinations/packages?airports%5B%5D=PMI&units%5B%5D=&when=01-11-2021&until=&choiceSearch=false&flexibility=true&monthSearch=false&flexibleDays=3&flexibleMonths=&noOfAdults=2&noOfChildren=0&childrenAge=&duration=7&searchRequestType=ins&searchType=aosearch&sp=true&multiSelect=true&room=&isVilla=false&reqType=&sortBy=");
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToUnitdetailsPage()
   {
      navigateToSearchResultPage();
      searchResultsPage.searchResultCardComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPasengerDetailsPage()
   {
      navigateToUnitdetailsPage();
      summaryPage.navigationComponent.selectYourHoliday();
      summaryPage.pricebreakdown.clickBooknowButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPaymentOptionsPage()
   {
      navigateToPasengerDetailsPage();
      nordicPassengerPage.fillThePassengerInformationAndProceed();
      errorHandler.isPageLoadingCorrectly();
   }
}
