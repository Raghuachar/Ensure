package uk.co.tui.cdaf.frontend.pom.wr.search_result;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.SearchResultAttributes;

import java.time.Duration;
import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static org.junit.Assert.assertTrue;

public class SearchResutlNavigation
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SearchResutlNavigation.class);

   public List<SearchResultAttributes> getAllSearchResultAttributes()
   {
      return SearchResultExtractor.extractFromElements(getSearchResults(false));
   }

   private ElementsCollection getSearchResults(boolean onlyCurrentlyLoadedOnPage)
   {
      if (!onlyCurrentlyLoadedOnPage)
         doScrolling();
      return $$("section.ResultListItemV2__resultItem");
   }

   private void doScrolling()
   {
      SelenideElement resultQuantityTextElement = $("div.FilterPanelV2__holidayCounts > span");
      assertTrue("Impossible to do scrolling since number of results element was not found",
               resultQuantityTextElement.exists());
      int count = Integer.parseInt(resultQuantityTextElement.getText());
      int currentIteration = 0;
      while (!$(".UI__noMoreHolidays").exists() && currentIteration < count)
      {
         LOGGER.log(
                  "There are " + count + " search results, scrolling to load more, since 10 is shown by default");
         $(".UI__loadMoreResults").scrollTo();
         $("img.UI__preloader").should(Condition.disappear, Duration.ofSeconds(30));
         currentIteration++;
      }
   }
}
