package uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class MAFObookingComponenets extends AbstractPage
{
   @FindBy(css = ".GlobalHeader__siteHeader")
   private WebElement globalHeader;

   @FindAll({ @FindBy(css = "footer .footerSection > div"),
            @FindBy(css = ".GlobalFooter__sections") })
   private WebElement globalFooter;

   @FindBy(css = ".InsuranceAndExtras__insuranceBorder .sections__level3")
   private WebElement insurancethirdparty;

   @FindBy(css = ".Flights__searchPanelContainer.Flights__flightOnlySearchPanelContainer")
   private WebElement searchPanelConatiner;

   public Object isHeaderPresent()
   {
      WebElementTools.mouseHover(globalHeader);
      return WebElementTools.isPresent(globalHeader);
   }

   public Object isFooterPresent()
   {
      WebElementTools.scrollTo(globalFooter);
      return WebElementTools.isPresent(globalFooter);
   }

   public Object isInsurancePresent()
   {
      return WebElementTools.isPresent(insurancethirdparty);
   }

   public boolean isSearchPanelConatinerPresent()
   {
      return WebElementTools.isPresent(searchPanelConatiner);
   }

}
