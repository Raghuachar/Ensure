package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class LoadingPage extends AbstractPage
{

   final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();

   private final WebElementWait wait;

   private final PageErrorHandler pageError;

   @FindBy(css = "[class='ContinueButton__continue ContinueButton__continueBottom']")
   public WebElement continueButton;

   @FindBy(css = "[class='PassengerPageLoadingComponent__overlay']")
   public WebElement loadingPageOverlay;

   @FindBy(css = "[id='PaymentType__component']")
   public WebElement paymentPage;

   public LoadingPage()
   {
      wait = new WebElementWait();
      pageError = new PageErrorHandler();
   }

   public void clickOnPassengerContinueButton()
   {
      WebElementTools.click(continueButton);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isLoadingPageDisplayed()
   {
      return WebElementTools.isPresent(loadingPageOverlay);
   }

   public void fillThePassengerDetails()
   {
      pageError.isNordicPageLoadedCorrectly();
      nordicPassengerPage.setNordicsPaxDetails();
      nordicPassengerPage.selectPassengerTitle();
      nordicPassengerPage.enterAdultDOB();
      nordicPassengerPage.enterChildDOB();
      nordicPassengerPage.enterFirstName();
      nordicPassengerPage.enterLastName();
      nordicPassengerPage.enterHouseNumber();
      nordicPassengerPage.enterAdressAndContactWR();
      wait.forJSExecutionReadyLazy();
      nordicPassengerPage.selectImportantInfoCheckbox();
      wait.forJSExecutionReadyLazy();
   }

   public boolean isPaymentPageLoaded()
   {
      return WebElementTools.isPresent(paymentPage);
   }
}
