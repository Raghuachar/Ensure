package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.List;

import static com.codeborne.selenide.Selenide.$$;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent.wasAccommodationOpenned;

public class SearchResultsCardComponentV2 extends AbstractPage
{
   @FindBy(css = "#responsiveSearchResults__component .SearchResults__resultsList .ResultListItemV2__resultItem")
   private List<WebElement> packageCards;

   @FindAll({ @FindBy(css = "[class='stylesRoomTypesV4__priceCompareContainer'] div"),
            @FindBy(xpath = "//div[@class='stylesRoomTypesV4__priceCompareContainer']//div[@aria-label='limited availability']") })
   private List<WebElement> yourRoomAvailability;

   public boolean reviewSearchCard()
   {
      return !packageCards.isEmpty();
   }

   public void isRoomAvailability()
   {
      ElementsCollection filter = $$("div.ResultsListItem__continue").filter(Condition.visible);
      filter.asDynamicIterable()
               .forEach(visibleAccomodationBtns ->
               {
                  visibleAccomodationBtns.scrollIntoView("{block: 'center'}").click();
                  if (yourRoomAvailability.isEmpty())
                     Selenide.back();
               });
      assertTrue("No valid search results were found", wasAccommodationOpenned());
   }
}
