package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults.SearchResults;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TUIWRSearchResultsAlternativeAirportsStepDefs
{

   private final SearchResults searchresults;

   public TUIWRSearchResultsAlternativeAirportsStepDefs()
   {
      searchresults = new SearchResults();
      WebDriverUtils utils = new WebDriverUtils();
   }

   @Given("search results are available including nearby departure airports")
   public void search_results_are_available_including_nearby_departure_airports()
   {
      searchresults.visit();
      assertThat("Search Results are not displayed", searchresults.isOutboundSearchResultsPresent(),
               is(true));
      assertThat("Checkbox alternative airports in Searchresults page is ticked",
               searchresults.isTickPresent(), is(true));
   }

   @When("I view a card that is from a nearby airport")
   public void i_view_a_card_that_is_from_a_nearby_airport()
   {
      try
      {
         searchresults.clickAlternativeFlight();
      }
      catch (Exception e)
      {
         assertThat("FlightCard with Alternative Airport is clickable", true, is(false));
      }

   }

   @Then("the following text will be visible {string}")
   public void the_following_text_will_be_visible(String string)
   {
      try
      {
         assertThat("Alternative airport text is visible",
                  searchresults.hasAlternativeFlightBadge(), is(true));
      }
      catch (Exception e)
      {
         assertThat("Alternative Airport card is selected", true, is(false));
      }
   }

}
