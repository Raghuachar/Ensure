package uk.co.tui.cdaf.frontend.pom.wr.search.components.airport;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;

import java.util.List;

public interface Airport
{
   boolean isOpen();

   Airport clearSelection();

   Airport setAllAirportsSelected(boolean shouldSelect);

   Airport selectRandomAirport();

   Airport selectAirportByName(String airport);

   SelenideElement getAllAirportsCheckbox();

   ElementsCollection getEnabledAirports();

   List<String> getSelectedAirports();

   void confirmSelection();
}
