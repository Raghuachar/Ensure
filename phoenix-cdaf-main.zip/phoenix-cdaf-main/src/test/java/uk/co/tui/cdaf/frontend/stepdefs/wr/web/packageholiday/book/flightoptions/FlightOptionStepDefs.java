package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.flightoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class FlightOptionStepDefs
{
   static AutomationLogManager LOGGER = new AutomationLogManager(FlightOptionStepDefs.class);

   public final PackageNavigation packageNavigation;

   public final FlightOptionsPage flightOptionPage;

   private String totalPriceBeforeUpgrade, cabinTypeDiffPrice;

   private boolean isPriceMatched;

   private Map<String, WebElement> flightMap;

   public FlightOptionStepDefs()
   {
      packageNavigation = new PackageNavigation();
      flightOptionPage = new FlightOptionsPage();
   }

   @Given("the {string} is on the package flight options spoke page")
   public void the_is_on_the_package_flight_options_spoke_page(String customer)
   {
      packageNavigation.navigateToFlightPage();
   }

   @And("they are presented with the Luggage component with the following info:")
   public void they_are_presented_with_the_Luggage_component_with_the_following_info(
            List<String> components)
   {
      flightOptionPage.wait.forJSExecutionReadyLazy();
      flightMap = flightOptionPage.getFlightComponents();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = flightMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("a View All Passengers CTA is displayed")
   public void a_View_All_Passengers_CTA_is_displayed()
   {
      boolean isDisplayed = flightOptionPage.luggageComponent.isViewAllpassengerButtonDisplayed();
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "View All passenger button is not displayed", isDisplayed, true),
               isDisplayed, is(true));
   }

   @And("the default luggage included in that selection is highlighted")
   public void the_default_luggage_included_in_that_selection_is_highlighted()
   {
      boolean selected = flightOptionPage.luggageComponent.isZeroKgLuggageCardSelected();
      assertThat(ReportFormatter.generateReportStatementForComponentCheck(
               "default luggage card is not higlihted", selected, true), selected, is(true));
   }

   @And("they select an upgraded Luggage amount CTA")
   public void they_select_an_upgraded_Luggage_amount_CTA()
   {
      totalPriceBeforeUpgrade = flightOptionPage.navigationComponent.getTotalPriceValue();
      flightOptionPage.luggageComponent.selectAlternateLuggage();
   }

   @And("that Luggage amount is now highlighted as selected")
   public void that_Luggage_amount_is_now_highlighted_as_selected(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      flightOptionPage.wait.forJSExecutionReadyLazy();
      flightOptionPage.wait.forJSExecutionReadyLazy();
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = flightOptionPage.luggageComponent.getTextForSelectedLuggage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Selected luggage card doesn't have the expected text", actual,
                           expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Given("they are presented with the Cabin Class component with the following info:")
   public void they_are_presented_with_the_Cabin_Class_component_with_the_following_info(
            List<String> components)
   {
      flightOptionPage.wait.forJSExecutionReadyLazy();
      flightMap = flightOptionPage.getFlightComponents();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = flightMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("the price is updated and reflected in the Book Now component on both Hub and Spoke pages")
   public void the_price_is_updated_and_reflected_in_the_Book_Now_component_on_both_Hub_and_Spoke_pages()
   {
      String totalPriceAfterUpgrade = flightOptionPage.navigationComponent.getTotalPriceValue();
      isPriceMatched = flightOptionPage.luggageComponent.isPriceMatched(totalPriceBeforeUpgrade,
               totalPriceAfterUpgrade);
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Total price is not updated after alternate luggage selection",
               totalPriceAfterUpgrade,
               flightOptionPage.luggageComponent.totPriceAfterFormat), isPriceMatched, is(true));
   }

   @And("the price is updated and reflected in the Price Breakdown on the Hub page")
   public void the_price_is_updated_and_reflected_in_the_Price_Breakdown_on_the_Hub_page()
   {
      String totalPriceAfterUpgrade = flightOptionPage.breakdownComponent.getTotlPriceValue();
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Total price is not updated in breakdown after alternate luggage selection",
                        totalPriceAfterUpgrade,
                        flightOptionPage.luggageComponent.totPriceAfterFormat),
               isPriceMatched, is(true));
   }

   @And("they select the upgraded Cabin Class")
   public void they_select_the_upgraded_Cabin_Class()
   {
      totalPriceBeforeUpgrade = flightOptionPage.navigationComponent.getTotalPriceValue();
      cabinTypeDiffPrice = flightOptionPage.cabinSeatComponent.getFlyCabinDifferencePrice();
      LOGGER.log(LogLevel.INFO,
               "total price and difference price of cabin:" + totalPriceBeforeUpgrade + " "
                        + cabinTypeDiffPrice);
      flightOptionPage.cabinSeatComponent.selectFlyCabinType();
   }

   @And("that class is now highlighted as selected")
   public void that_class_is_now_highlighted_as_selected(io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      flightOptionPage.wait.forJSExecutionReadyLazy();
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = flightOptionPage.luggageComponent.getTextForSelectedLuggage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Selected luggage card doesn't have the expected text", actual,
                           expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("the selection is also displayed on the Hub page component")
   public void the_selection_is_also_displayed_on_the_Hub_page_component()
   {
      flightOptionPage.wait.forJSExecutionReadyLazy();
      double calculatedPrc = flightOptionPage.cabinSeatComponent
               .priceAfterCabinUpgrade(totalPriceBeforeUpgrade, cabinTypeDiffPrice);
      String totPriceAfterUpgrade = flightOptionPage.navigationComponent.getTotalPriceValue();
      totPriceAfterUpgrade = totPriceAfterUpgrade.replaceAll("[^\\d\\.]+", StringUtils.EMPTY);
      boolean flag = String.valueOf(calculatedPrc).equalsIgnoreCase(totPriceAfterUpgrade);
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Price increase is not reflected in hub page", totPriceAfterUpgrade,
                        calculatedPrc),
               flag, is(true));
   }

   @And("they are navigated to the flights Page")
   public void they_are_navigated_to_the_flights_Page()
   {
      boolean isDisplayd = flightOptionPage.backToYourHoliday.isFlightPageDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Flight page is not loaded", isDisplayd, true), isDisplayd, is(true));
   }

   @And("they are presented with the following Flight Components")
   public void they_are_presented_with_the_following_Flight_Components(List<String> components)
   {
      flightOptionPage.wait.forJSExecutionReadyLazy();
      flightMap = flightOptionPage.getFlightComponents();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = flightMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

}
