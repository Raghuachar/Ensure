package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.roomOptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.roomoptions.RoomOptionsPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RoomOptionsStepDefs
{
   private static final double DELTA = 0.01;

   private final RoomOptionsPage roomOptionsPage;

   private final ThreadLocal<Double> totalPrice = new ThreadLocal<>();

   private final WebElementWait wait;

   public RoomOptionsStepDefs()
   {
      roomOptionsPage =  new RoomOptionsPage();
      wait = new WebElementWait();
   }

   @And("user navigates back from Room options page to Summary page")
   public void user_navigates_back_from_room_options_page_to_summary_page()
   {
      roomOptionsPage.navigateBackToSummaryPage();
   }

   @And("user selects first available alternative room")
   public void user_selects_first_available_alternative_room()
   {
      roomOptionsPage.selectFirstAvailableAltRoom();
      wait.forJSExecutionReadyLazy();
   }

   @And("user selects first available alternative board")
   public void user_selects_first_available_alternative_board()
   {
      roomOptionsPage.selectFirstAvailableAltBoard();
      wait.forJSExecutionReadyLazy();
   }

   @Then("insurance price decrease banner is displayed to user and contains the message")
   public void insurance_price_decrease_message_is_displayed_to_user_and_contains_the_message()
   {
      totalPrice.set(roomOptionsPage.progressbarComponent.getTotalPriceDoubleValue());
      roomOptionsPage.progressbarComponent.getTotalPriceDoubleValue();
      String insurancePriceChangeMessage = roomOptionsPage.getInsurancePriceChangeMessage().getText().trim();
      assertTrue("Price change arrow isn't displayed", roomOptionsPage.isPriceChangeIconDisplayed());
      assertTrue("Price decrease message isn't displayed or not as expected",
               insurancePriceChangeMessage.contains("De prijs van je gekozen verzekering is gedaald met")
                        && insurancePriceChangeMessage.contains("€")
                        && insurancePriceChangeMessage.contains(" totaal."));
      assertEquals("Price change tool tip isn't displayed or not as expected",
               "Waarom gebeurt dit?", roomOptionsPage.getPriceChangeToolTip().getText());
   }

   @And("insurance price increase banner is displayed to user and contains the message")
   public void insurance_price_increase_message_is_displayed_to_user_and_contains_the_message()
   {
      Double newTotalPrice = roomOptionsPage.progressbarComponent.getTotalPriceDoubleValue();
      if ((newTotalPrice - totalPrice.get()) > DELTA)
      {
         String insurancePriceChangeMessage = roomOptionsPage.getInsurancePriceChangeMessage().getText().trim();
         assertTrue("Price change arrow isn't displayed",
                  roomOptionsPage.isPriceChangeIconDisplayed());
         assertTrue("Price increase message isn't displayed or not as expected",
                  insurancePriceChangeMessage.contains("De prijs van je gekozen verzekering is gestegen met")
                           && insurancePriceChangeMessage.contains("€")
                           && insurancePriceChangeMessage.contains(" totaal."));
         assertEquals("Price change tool tip isn't displayed or not as expected",
                  "Waarom gebeurt dit?", roomOptionsPage.getPriceChangeToolTip().getText());
      }
      totalPrice.set(newTotalPrice);
   }

   @And("user remembers insurance price difference and navigates back from Room options page to Summary page")
   public void user_remains_insurance_price_difference_and_navigates_back_from_room_options_page_to_summary_page()
   {
      Double newTotalPrice = roomOptionsPage.progressbarComponent.getTotalPriceDoubleValue();
      if ((totalPrice.get() - newTotalPrice) > DELTA)
      {
         RoomOptionsPage.insPriceDiffDouble.set(roomOptionsPage.getInsurancePriceDifference());
         roomOptionsPage.navigateBackToSummaryPage();
      }
   }
}
