package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class PackageSoldOutErrorPage extends AbstractPage
{
   @FindBy(css = "#soldouterrorpage_media_banner-browseMediaBannerComp > div > div > div > div > section > div.herobanner__content.undefined > div > section > div > section > div.ContentBox__textBoxcontent > div:nth-child(2) > a > div > button")
   private WebElement homepageButton;

   public void selectHomePageButton()
   {
      WebElementTools.click(homepageButton);
   }

}
