package uk.co.tui.cdaf.frontend.pom.wr.web.shared;

import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HomePage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

public class CommonPagesImplementation extends AbstractPage
{
   private final HomePage homePage;

   public CommonPagesImplementation()
   {
      homePage = new HomePage();
   }

   public void launchWRHomepage()
   {
      homePage.visit();
   }

   public String getTranslationCode(String language, String country)
   {

      return country + "-" + language;
   }

}
