package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.book.flightoptions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.flightoptions.VIPAlternativeFlightOptionsComponent;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

public class AlternativeFlightsComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public final VIPAlternativeFlightOptionsComponent alternateFlightsComponent;

   public AlternativeFlightsComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      alternateFlightsComponent = new VIPAlternativeFlightOptionsComponent();
   }

   @Given("the customer is on the Flight Page")
   public void the_customer_is_on_the_Flight_Page()
   {
      packageNavigation.navigateToFlightPage();
   }

   @When("they are presented with the available alternative flights cards")
   public void they_are_presented_with_the_available_alternative_flights_cards()
   {
      boolean actual = alternateFlightsComponent.isAlternateFlightsComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight options component wasnt displayed", actual, true), actual,
               is(true));
   }

   @Then("the cards display the following information:")
   public void the_cards_display_the_following_information(
            io.cucumber.datatable.DataTable dataTable)
   {
      alternateFlightsComponent.getVipAlternateFlightsComponentsMap();
   }

   @Given("that the customer is on the Flight Page")
   public void that_the_customer_is_on_the_Flight_Page()
   {
      packageNavigation.navigateToFlightPage();
   }

   @Given("there are no alternative flights available for the selected date")
   public void there_are_no_alternative_flights_available_for_the_selected_date()
   {
      boolean actual = alternateFlightsComponent.isAlternateFlightsAvailable();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Alternate Flights Available wasnt displayed", actual, true), actual, is(true));
   }

   @Then("the existing flight card is displayed in a selected state")
   public void the_existing_flight_card_is_displayed_in_a_selected_state()
   {
      boolean actual = alternateFlightsComponent.isAvailableFlightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Available Flight wasnt displayed", actual, true), actual, is(true));
   }

   @Given("there are alternative flights available for the selected date")
   public void there_are_alternative_flights_available_for_the_selected_date()
   {
      boolean actual = alternateFlightsComponent.isAlternateFlightsComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Alternate Flight options component wasnt displayed", actual, true), actual,
               is(true));
   }

   @Given("click on view alternate flight link")
   public void click_on_view_alternate_flight_link()
   {
      alternateFlightsComponent.clickOnViewAlternateFlightsLink();
   }

   @When("they click on the SelectCTA")
   public void they_click_on_the_SelectCTA()
   {
      alternateFlightsComponent.clickOnSelectButton();
   }

   @Then("that Flight card is now displayed in a selected state")
   public void that_Flight_card_is_now_displayed_in_a_selected_state()
   {
      boolean actual = alternateFlightsComponent.isSelectedFlightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Selected Flight options component wasnt displayed", actual, true), actual,
               is(true));
   }

   @Then("the new flight card is displayed under YOUR SELECTED FLIGHTS")
   public void the_new_flight_card_is_displayed_under_YOUR_SELECTED_FLIGHTS()
   {
      boolean actual = alternateFlightsComponent.isSelectedFlightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Selected Flight options component wasnt displayed", actual, true), actual,
               is(true));
   }

   @Then("the newly selected date is displayed centrally in the week of available dates")
   public void the_newly_selected_date_is_displayed_centrally_in_the_week_of_available_dates()
   {
      String[] expected = alternateFlightsComponent.getExpectedDates();
      String[] actual = alternateFlightsComponent.getActualDates();
      assertThat("New Price updated in date section component wasnt displayed", actual,
               equalTo(expected));
   }

   @Then("new costs of the flights are updated in the Total Price component")
   public void new_costs_of_the_flights_are_updated_in_the_Total_Price_component()
   {
      // Will implement this step once it is available
      throw new PendingException();
   }

   @Then("the alternative date options are adjusted to reflect the new differences in price")
   public void the_alternative_date_options_are_adjusted_to_reflect_the_new_differences_in_price()
   {
      // will implement this step once available
   }

   @Given("an alternative flight has been selected")
   public void an_alternative_flight_has_been_selected()
   {
      boolean actual = alternateFlightsComponent.isSelectedFlightDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Selected Flight options component wasnt displayed", actual, true), actual,
               is(true));
   }

   @When("they select Apply changes and go backlink")
   public void they_select_Apply_changes_and_go_backlink()
   {
      alternateFlightsComponent.clickOnApplyButton();
   }

   @Then("they are navigated to the Customise Page")
   public void they_are_navigated_to_the_Customise_Page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @Then("can see their newly selected flight card within YOUR FLIGHTS")
   public void can_see_their_newly_selected_flight_card_within_YOUR_FLIGHTS()
   {
      boolean actual = alternateFlightsComponent.isSelectedFlightInSummaryDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "Selected Flight in Summary component wasnt displayed", actual, true), actual,
               is(true));
   }

   @Then("alert message {string} is displayed in alternative flights component")
   public void alert_message_is_displayed_in_alternative_flights_component(String message)
   {
      assertThat("Alerts message is not as expected", alternateFlightsComponent.getAlertsMessageText(),
               Matchers.equalToIgnoringCase(message));
   }
}
