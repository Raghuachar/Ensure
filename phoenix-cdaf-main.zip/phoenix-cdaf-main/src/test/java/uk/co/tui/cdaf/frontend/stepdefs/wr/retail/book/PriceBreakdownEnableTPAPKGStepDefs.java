package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PriceBreakdownEnableTPAPKGStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   public PriceBreakdownEnableTPAPKGStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @Given("that the TPA or CSC agent acting on behalf of TPA is on BtoB Bookflow")
   public void that_the_TPA_or_CSC_agent_acting_on_behalf_of_TPA_is_on_BtoB_Bookflow()
   {
      retailpackagenavigation.retailLogin();

   }

   @When("they view the passenger details page")
   public void they_view_the_passenger_details_page()
   {
      retailpassengerdetailspage.navigateToPassengerPage();
      retailpassengerdetailspage.fillThePassengerDetailsForTPPriceBreakdown();
   }

   @Then("they can see the price overview at the bottom of the page")
   public void they_can_see_the_price_overview_at_the_bottom_of_the_page()
   {
      retailpassengerdetailspage.expandPriceBreakdown();
      assertThat("price overview at the bottom of the page",
               retailpassengerdetailspage.detailPriceBreakdown(),
               is(true));
      retailpassengerdetailspage.selectContinueBookingWR();
   }

}
