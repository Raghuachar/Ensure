package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;

public class MultipleRoomTypeInHolidaySummaryComponent extends AbstractPage
{

   public final WebElementWait wait;

   private final HashMap<String, WebElement> roomTypeMap;

   @FindBy(xpath = "(//a[@href='/h/nl/book/flow/roomoptions'])[1]")
   private WebElement expandHolidaySummaryComponent;

   @FindBy(xpath = "(//div[@aria-label='room option 2']//*[@class='buttons__button buttons__senary buttons__fill'])")
   private WebElement selectroom;

   @FindBy(xpath = "(//*[@class='buttons__button buttons__primary buttons__fill buttons__large BackToYourHolidayButtonComponent__backButtonClass'])")
   private WebElement backToSummaryPage;

   @FindBy(css = "#holidaySummary__component > div > div > div.sections__slabContent > div > div > div.PriceSummaryPanel__rightAlignComponent > div:nth-child(2) > ul:nth-child(2) > li > span.PriceSummaryPanel__extraSummaryCategory")
   private WebElement firstRoomTypeDescription;

   @FindBy(css = "#holidaySummary__component > div > div > div.sections__slabContent > div > div > div.PriceSummaryPanel__rightAlignComponent > div:nth-child(2) > ul:nth-child(2) > li > span.PriceSummaryPanel__extraSummaryPrice")
   private WebElement included;

   @FindBy(css = "#holidaySummary__component > div > div > div.sections__slabContent > div > div > div.PriceSummaryPanel__rightAlignComponent > div:nth-child(2) > ul:nth-child(3) > li:nth-child(1) > span.PriceSummaryPanel__extraSummaryCategory")
   private WebElement secondRoomTypeDescription;

   @FindBy(css = "#holidaySummary__component > div > div > div.sections__slabContent > div > div > div.PriceSummaryPanel__rightAlignComponent > div:nth-child(2) > ul:nth-child(3) > li:nth-child(1) > span.PriceSummaryPanel__extraSummaryPrice")
   private WebElement secondRoomIncluded;

   @FindBy(css = "#holidaySummary__component > div > div > div.sections__slabContent > div > div > div.PriceSummaryPanel__rightAlignComponent > div:nth-child(2) > ul:nth-child(3) > li:nth-child(2)")
   private WebElement boardBasisName;

   @FindBy(css = "#holidaySummary__component > div > div > div.sections__slabContent > div > div > div.PriceSummaryPanel__rightAlignComponent > div:nth-child(2) > ul:nth-child(3) > li:nth-child(2) > span")
   private WebElement boardBasisIncluded;

   public MultipleRoomTypeInHolidaySummaryComponent()
   {
      wait = new WebElementWait();
      roomTypeMap = new HashMap<>();
   }

   public void NavigateRoomOptions()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(expandHolidaySummaryComponent);
      wait.forClickable(selectroom);
      WebElementTools.click(selectroom);
      wait.forClickable(backToSummaryPage);
      WebElementTools.click(backToSummaryPage);
   }

   public void VerifyRoomUpgrades()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(expandHolidaySummaryComponent);
      wait.forJSExecutionReadyLazy();
   }

   public void clickOnIconToExpandHolidaySummary()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(expandHolidaySummaryComponent);
      wait.forJSExecutionReadyLazy();
   }

   public HashMap<String, WebElement> getRoomTypeComps()
   {
      roomTypeMap.put("Room Type Description", firstRoomTypeDescription);
      roomTypeMap.put("included", included);
      roomTypeMap.put("Another Room Type Description", secondRoomTypeDescription);
      roomTypeMap.put("second Room Included", secondRoomIncluded);
      roomTypeMap.put("Board Basis Name", boardBasisName);
      roomTypeMap.put("Board Basis Included", boardBasisIncluded);
      return roomTypeMap;
   }
}
