package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$x;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class EditSearchPackages
{

   public boolean isSearchPanelSummaryComp()
   {
      return $x("//section[@class='EditSearch__editSearchWrapper']").isDisplayed();
   }

   public boolean editSearchButton()
   {
      return $x("//button[contains(text(),'Suche Anpassen')]").isDisplayed();
   }

   public boolean isSearchPanelDisplayed()
   {
      return ($(".SearchPanel__searchPanelContainer").isDisplayed() && editSearchButtonAfterEdit());
   }

   public boolean clearSearchLink()
   {
      return $("[aria-label = 'clear search'] a").isDisplayed();
   }

   public boolean editSearchButtonAfterEdit()
   {
      return $x("//button[contains(text(),'Suche')]").isDisplayed();
   }

   public void modifySearch()
   {
      getSearchPanel().airport().clearSelection().selectRandomAirport().confirmSelection();
      getSearchPanel().destination().clearSelection().selectRandomDestination().confirmSelection();
      getSearchPanel().departure().clearSelection().selectRandomDate().confirmSelection();
      getSearchPanel().selectRandomDuration();
      getSearchPanel().paxAndRooms().clearSelection().selectRandomPaxAndRooms().confirmSelection();
      getSearchPanel().doSearch();
   }

}
