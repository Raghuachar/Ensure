package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SortByComponent;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.assertTrue;

public class SortByGuestReviewStepDefs
{
   public final SearchResultsPage searchResultsPage;

   private final PackageNavigation packageNavigation;

   public SortByComponent sortByComponent;

   public SortByGuestReviewStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
      packageNavigation = new PackageNavigation();
      sortByComponent = new SortByComponent();
   }

   @Given("the Customer\\/Agent is viewing the Search results page")
   public void the_is_viewing_the_Search_results_page()
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @Given("they are interacting with the Sort by filter")
   public void they_are_interacting_with_the_Sort_by_filter()
   {
      sortByComponent.isSortByDisplayed();
   }

   @When("they select the dropdown")
   public void they_select_the_dropdown()
   {
      sortByComponent.selectSortBy();
   }

   @Then("they shall see a new Guest rating \\(high - low) option after the Price - high to low option")
   public void they_shall_see_a_new_Guest_rating_high_low_option_after_the_Price_high_to_low_option()
   {
      assertTrue("Sort By rating is not present", sortByComponent.isSortByGuestPresent());
   }

   @When("they select the {string} option")
   public void they_select_the_option(String string)
   {
      sortByComponent.clickOnSortByDropdown(string);
   }

   @Then("all the packages on the Search Results page shall be ordered in Guest Reviews high to low order")
   public void all_the_packages_on_the_Search_Results_page_shall_be_ordered_in_Guest_Reviews_high_to_low_order()
   {
      List<Double> originalList = sortByComponent.getDescendingGuestRatings();
      List<Double> sortedList = originalList.stream().sorted(Collections.reverseOrder())
               .collect(Collectors.toList());
      MatcherAssert.assertThat(originalList, Matchers.is(sortedList));
   }
}
