package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.confirmation;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.ConfirmationPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class ExcursionComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   private final ConfirmationPage confirmationPage;

   public ExcursionComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      confirmationPage = new ConfirmationPage();
   }

   @Given("the customer is on the FO Booking Confirmation Page")
   public void customerOnFOBookingConfirmationPage()
   {
      packageNavigation.navigateToConfirmationPage();
   }

   @When("the customer selects to view excursions available to them")
   public void the_customer_selects_to_view_excursions_available_to_them()
   {
      WebElementTools
               .javaScriptScrollToElement(confirmationPage.excursionComponent.getExploreButton());
      confirmationPage.excursionComponent.clickOnExploreButton();
   }

   @Then("they should be navigated to the following link in a new tab:")
   public void they_should_be_navigated_to_the_following_link_in_a_new_tab(List<String> links)
   {
      confirmationPage.wait.forJSExecutionReadyLazy();
      boolean matched = confirmationPage.excursionUrlVerification(links.get(0));
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "It doesn't navigated to required page by clicking explore from excursion",
               confirmationPage.utils.getCurrentURL(), links.get(0)), matched, is(true));
   }

}
