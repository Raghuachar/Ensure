package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.bookingsearch;

import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import uk.co.tui.cdaf.frontend.pom.wr.retail.bookingsearch.BookingSearchPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static org.junit.Assert.*;

public class BookingSearchListStepDefs
{
   public final BookingSearchPage bookingSearchPage;

   public final WebElementWait wait;

   public BookingSearchListStepDefs()
   {
      bookingSearchPage = new BookingSearchPage();
      wait = new WebElementWait();
   }

   @Given("they view the booking search section")
   public void they_view_the_booking_search_section()
   {
      assertTrue("Booking search section is not displayed",
               bookingSearchPage.getRetrieveWithoutReferenceSection().isDisplayed());
   }

   @When("they entered a search criteria")
   public void they_have_entered_a_search_criteria()
   {
      assertTrue("Booking search lead passenger surname field is not displayed",
               bookingSearchPage.getLeadPassengerSurnameField().isDisplayed());

      bookingSearchPage.getLeadPassengerSurnameField().type("name");
   }

   @When("they click on search button")
   public void they_click_on_search_button()
   {
      assertTrue("Booking search button is not displayed",
               bookingSearchPage.getSearchButton().isDisplayed());

      bookingSearchPage.getSearchButton().click();
   }

   @When("they will be able to view the booking search results")
   public void they_will_be_able_to_view_the_booking_search_results()
   {
      assertTrue("Booking search results is not displayed",
               bookingSearchPage.getBookingSearchListResults().isDisplayed());
   }

   @When("they will be able to see table header")
   public void they_will_be_able_to_see_table_header()
   {
      List<SelenideElement> elements = bookingSearchPage.getBookingSearchListHeader();

      assertFalse("Header elements not found on the page", Objects.isNull(elements));
   }

   @Then("they can see a view CTA next to each result")
   public void they_can_see_a_view_CTA_next_to_each_result()
   {
      boolean isViewPresentInRow = bookingSearchPage.checkBookingSearchResultCTA();

      assertTrue("VIEW anchor tag is not present in a row.", isViewPresentInRow);
   }

   @When("have clicked the View CTA next to a search result")
   public void have_clicked_the_View_CTA_next_to_a_search_result()
   {
      boolean searchResultCTAClicked = bookingSearchPage.clickBookingSearchResultCTA();

      assertTrue("VIEW anchor tag is not clicked", searchResultCTAClicked);
   }

   @Then("the booking summary page would be open in new tab")
   public void the_new_tab_window_will_be_created()
   {
      WebElementTools.switchToBrowserTab(1);

      String currentUrl = WebDriverRunner.getWebDriver().getCurrentUrl();
      MatcherAssert.assertThat("Booking summary is not opened in new tab", currentUrl,
               Matchers.containsString("/your-account/managemybooking/yourbooking"));
   }

   @Then("they will be able view Sorting dropdown")
   public void they_will_be_able_view_Sorting_dropdown()
   {
      assertTrue("Booking search sorting dropdown is not displayed",
               bookingSearchPage.getBookingListSortDropDown().isDisplayed());
   }

   @Then("they will be able view sorting dropdown list")
   public void they_will_be_able_view_sorting_dropdown_list_as_following()
   {
      bookingSearchPage.getBookingListSortDropDown().click();

      List<SelenideElement> optionElements = bookingSearchPage.getBookingListSortDropDownOptions();
      List<String> actualOptions = new ArrayList<>();
      for (SelenideElement optionElement : optionElements)
      {
         actualOptions.add(optionElement.getValue());
      }

      List<String> expectedOptions = Arrays.asList("ascending", "descending");
      assertEquals("Sorting dropdown list has a wrong value", expectedOptions, actualOptions);
   }

   @When("they click the sorting dropdown option for Surname Z-A")
   public void they_click_the_sorting_dropdown_option_for_Surname_Z_A()
   {
      boolean foundOption = bookingSearchPage.clickSelectedOption("descending");

      assertTrue("Not able to click the sorting dropdown option Surname Z-A.", foundOption);
   }

   @Then("the search results with be organized by surname starting with Z ending with A")
   public void the_search_results_with_be_organized_by_surname_starting_with_Z_ending_with_A()
   {
      wait.forJSExecutionReadyLazy();
      boolean sortedDescending = bookingSearchPage.areResultsSortedDescending();

      assertTrue("Search results table not sorted  by Surname Z-A.", sortedDescending);
   }

   @When("they click the sorting dropdown option for Surname A-Z")
   public void they_click_the_sorting_dropdown_option_for_Surname_A_Z()
   {
      boolean foundOption = bookingSearchPage.clickSelectedOption("ascending");

      assertTrue("search results Table not sorted by Surname A-Z.", foundOption);
   }

   @Then("the search results with be organized by surname starting with A ending with Z")
   public void the_search_results_with_be_organized_by_surname_starting_with_A_ending_with_Z()
   {
      wait.forJSExecutionReadyLazy();
      boolean sortedAscending = bookingSearchPage.areResultsSortedAscending();

      assertTrue("Search results table not sorted  by Surname A-Z", sortedAscending);
   }

   @Given("they can see the search button")
   public void they_can_see_the_search_button()
   {
      assertTrue("booking search button is not displayed",
               bookingSearchPage.getSearchButton().isDisplayed());
   }

   @Given("they click on the on search button without entering the data")
   public void they_click_on_the_on_search_button_without_entering_the_data()
   {
      bookingSearchPage.getSearchButton().click();
   }

   @Then("they will view the validation error at top of booking search section")
   public void they_will_view_the_validation_error_at_top_of_booking_search_section_as_following()
   {
      assertTrue("Booking search empty field error is not displayed",
               bookingSearchPage.getEmptyFieldsError().isDisplayed());
   }

   @Then("the agent will see the Pagination underneath the list of results")
   public void the_agent_will_see_the_Pagination_underneath_the_list_of_results()
   {
      assertTrue("Booking search Pagination is not displayed",
               bookingSearchPage.getPagination().isDisplayed());
   }

   @Then("the Pagination will display the number of pages that are available")
   public void the_Pagination_will_display_the_number_of_pages_that_are_available()
   {
      MatcherAssert.assertThat("Booking search Pagination items not displayed",
               bookingSearchPage.getPaginationListSize(), Matchers.greaterThan(0));

   }

   @When("they are viewing the Pagination under the list of results")
   public void they_are_viewing_the_Pagination_under_the_list_of_results()
   {
      assertTrue("Pagination under the list of results not displayed",
               bookingSearchPage.getPagination().isDisplayed());
   }

   @Then("they can see the link to Next Page in the Pagination")
   public void they_can_see_the_link_to_in_the_Pagination()
   {
      assertTrue("Link to Next Page in the Pagination not visible",
               bookingSearchPage.getNextPageLink().isDisplayed());
   }

   @Then("this will navigate the Agent to the next page")
   public void this_will_navigate_the_Agent_to_the_next_page()
   {
      int currentPageNumber = bookingSearchPage.getCurrentPageNumber();
      bookingSearchPage.getNextPageLink().click();

      int newPageNumber = bookingSearchPage.getCurrentPageNumber();
      MatcherAssert.assertThat("Not able to Navigate to next page.", newPageNumber,
               Matchers.greaterThan(currentPageNumber));
   }

   @When("they have clicked to visit another page")
   public void they_have_clicked_to_visit_another_page()
   {
      bookingSearchPage.getNextPageLink().click();
   }

   @Then("the Previous page link will appear before page 1")
   public void the_Previous_page_link_will_appear_before_page()
   {
      assertTrue("Previous page link not appeared before page 1",
               bookingSearchPage.getPreviousPageLink().isDisplayed());
   }

   @Then("clicking this will Navigate the Agent back a page in the results")
   public void clicking_this_will_Navigate_the_Agent_back_a_page_in_the_results()
   {
      int currentPageNumber = bookingSearchPage.getCurrentPageNumber();
      bookingSearchPage.getNextPageLink().click();
      bookingSearchPage.getPreviousPageLink().click();
      int newCurrentPageNumber = bookingSearchPage.getCurrentPageNumber();

      assertEquals("Not able to navigate to previous page.", currentPageNumber,
               newCurrentPageNumber);
   }

   @Then("they can use the Pagination to view a results page")
   public void they_can_use_the_Pagination_to_view_a_results_page()
   {
      int currentPageNumber = bookingSearchPage.getCurrentPageNumber();
      bookingSearchPage.getNextPageLink().click();
      int newPageNumber = bookingSearchPage.getCurrentPageNumber();

      MatcherAssert.assertThat("Unable to navigate using pagination.", newPageNumber,
               Matchers.greaterThan(currentPageNumber));
   }

   @Then("they can click to a page number directly")
   public void they_can_click_to_a_page_number_directly()
   {
      int pageNumberToClick = 2;
      bookingSearchPage.clickPageNumber(pageNumberToClick);
      int currentPageNumber = bookingSearchPage.getCurrentPageNumber();

      assertEquals("Unable to click on page number.", 2, currentPageNumber);
   }

   @Then("they can navigate back to the first or previous results page")
   public void they_can_navigate_back_to_the_first_or_previous_results_page()
   {
      int pageNumberToClick = 2;
      bookingSearchPage.clickPageNumber(pageNumberToClick);
      int initialPageNumber = bookingSearchPage.getCurrentPageNumber();
      pageNumberToClick = 1;
      bookingSearchPage.clickPageNumber(pageNumberToClick);
      int pageNumberAfterClickingOnFirstPage = bookingSearchPage.getCurrentPageNumber();

      assertNotEquals("Unable to navigate", initialPageNumber, pageNumberAfterClickingOnFirstPage);
      assertEquals("Unable to navigate", 1, pageNumberAfterClickingOnFirstPage);

      int currentPageNumber = bookingSearchPage.getCurrentPageNumber();
      pageNumberToClick = 2;
      bookingSearchPage.clickPageNumber(pageNumberToClick);
      bookingSearchPage.getPreviousPageLink().click();
      int newPageNumber = bookingSearchPage.getCurrentPageNumber();

      assertEquals("Unable to navigate back to the first or previous results page",
               currentPageNumber, newPageNumber);
   }

   @Then("they can see a table with maximum {int} search results listed on each page")
   public void they_can_see_a_table_with_maximum_search_results_listed_on_each_page(Integer int1)
   {
      MatcherAssert.assertThat("Table has more than maximum results",
               bookingSearchPage.getBookingSearchRows().size(), Matchers.lessThanOrEqualTo(int1));
   }

   @Then("navigating to the next page with the Pagination will again display maximum {int} results")
   public void navigating_to_the_next_page_with_the_Pagination_will_again_display_maximum_results(
            Integer int1)
   {
      bookingSearchPage.getNextPageLink().click();

      MatcherAssert.assertThat("Table has more than maximum results",
               bookingSearchPage.getBookingSearchRows().size(), Matchers.lessThanOrEqualTo(int1));
   }
}
