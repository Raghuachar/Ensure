package uk.co.tui.cdaf.api.pojo.search.legacy.airport;

import uk.co.tui.cdaf.api.pojo.search.base.Airport;

import java.util.List;

@lombok.Data
public class Data
{
   private List<Airport> airports;

   private Object airportGroups;
}
