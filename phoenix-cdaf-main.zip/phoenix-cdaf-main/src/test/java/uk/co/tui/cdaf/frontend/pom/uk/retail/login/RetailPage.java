package uk.co.tui.cdaf.frontend.pom.uk.retail.login;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.utils.ConfigurationService;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static uk.co.tui.cdaf.utils.ConfigurationConstants.*;

public class RetailPage extends AbstractPage
{
   private static final AutomationLogManager LOGGER = new AutomationLogManager(RetailPage.class);

   WebElementWait wait = new WebElementWait();

   ////////////////////// Path//////////////////////////////
   @FindAll({ @FindBy(xpath = "//button[contains(text(),'LOGIN')]"),
            @FindBy(css = ".ThirdPartyLogin__pageHeading") })
   private WebElement loginHeader;

   @FindAll({ @FindBy(xpath = ".//*[@name='agentNumber']"),
            @FindBy(xpath = ".//*[@name='userName']"), @FindBy(css = "[name*='user']"),
            @FindBy(css = "#userNameInput") })
   private WebElement agentID;

   @FindAll({ @FindBy(xpath = ".//*[@name='agentPassword'] | .//*[@name='userPassword']"),
            @FindBy(css = "[name*='pass']"), @FindBy(css = "#passwordInput") })
   private WebElement agentPassword;

   @FindBy(css = ".inputs__textInput input")
   private WebElement changeagentID;

   @FindAll({ @FindBy(xpath = ".//*[@name='submit-button']"),
            @FindBy(css = ".ThirdPartyLogin__loginButton"),
            @FindBy(css = "#submitButton"),
            @FindBy(xpath = ".//*[@name='submit-button']"),
            @FindBy(css = "[type='button']") })
   private WebElement loginButton;

   ////////////////// Methods/////////////////////////////////
   public boolean isRetailLoginPage()
   {
      return WebElementTools.isPresent(loginHeader);
   }

   public void inhouseAgentLogin()
   {
      if (!$("span.RetailHeader__agencyDisplayFormat").isDisplayed())
      {
         agentIdPassword(
                  ConfigurationService.getHybrisProperty(RETAIL_WR_INHOUSE_USERNAME),
                  ConfigurationService.getHybrisProperty(RETAIL_WR_INHOUSE_PASSWORD));
         signInButton();
      }
   }

   public void thirdPartyLogin()
   {
      if (!$("span.RetailHeader__agencyDisplayFormat").isDisplayed())
      {
         enterThridPartyCredentials();
         signInButton();
      }
   }

   public void enterThridPartyCredentials()
   {
      String brand = ExecParams.getTestExecutionParams().getBrandStr();
      agentIdPassword(
               ConfigurationService.getHybrisProperty(brand + THIRDPARTY_USERNAME),
               ConfigurationService.getHybrisProperty(brand + THIRDPARTY_PASSWORD));
      agentReference();
   }

   private void agentIdPassword(String id, String pass)
   {
      agentID.sendKeys(id);
      agentPassword.sendKeys(pass);
      LOGGER.log(LogLevel.INFO, "Agent ID Entered: " + id);
      LOGGER.log(LogLevel.INFO, "Agent Password Entered: " + pass);
   }

   public void changeagentId(String Changeid)
   {
      WebElementTools.clickElementJavaScript(changeagentID);
      changeagentID.sendKeys(Changeid);
      LOGGER.log(LogLevel.INFO, "ChangeAgentID Entered: " + Changeid);
   }

   public void agentReference()
   {
      $("input#agentref").setValue("AAA");
      LOGGER.log(LogLevel.INFO, "Agent reference number: AAA");
   }

   public void signInButton()
   {
      BrowserCookies.closePrivacyPopUp();
      $(loginButton).click();
   }

}
