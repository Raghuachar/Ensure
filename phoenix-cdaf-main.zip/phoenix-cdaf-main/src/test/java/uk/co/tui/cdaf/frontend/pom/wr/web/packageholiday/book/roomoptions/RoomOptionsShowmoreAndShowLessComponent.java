package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.roomoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class RoomOptionsShowmoreAndShowLessComponent
{
   public final WebElementWait wait;

   @FindBy(css = "[#roomTypesV2__component > div > div]")
   private WebElement roomOptionsComponent;

   @FindBy(css = "[#roomTypesV2__component > div > div > section > div.RoomTypesV2__showMore > button]")
   private WebElement showMoreRoomOptions;

   @FindBy(css = "[#roomTypesV2__component > div > div > section > div.RoomTypesV2__showMore > button > div]")
   private WebElement showMoreRoomOptionsLink;

   @FindBy(css = "[#roomTypesV2__component > div > div > section > div.RoomTypesV2__showMore > button]")
   private WebElement showLessRoomOptionsLink;

   public RoomOptionsShowmoreAndShowLessComponent()
   {
      wait = new WebElementWait();
   }

   public boolean isRoomOptionsComponentDisplayed()
   {
      return WebElementTools.isPresent(roomOptionsComponent);
   }

   public boolean isShowMoreRoomOptionsButtonDisplayed()
   {
      return WebElementTools.isPresent(showMoreRoomOptions);
   }

   public void clickOnShowMoreRoomOptionsLink()
   {
      WebElementTools.click(showMoreRoomOptionsLink);
   }

   public void clickOnShowLessRoomOptionsLink()
   {
      WebElementTools.click(showLessRoomOptionsLink);
   }
}
