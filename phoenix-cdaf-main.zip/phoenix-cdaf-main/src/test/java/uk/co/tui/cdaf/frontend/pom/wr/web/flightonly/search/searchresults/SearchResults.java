package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class SearchResults extends AbstractPage
{
   private static final AutomationLogManager LOGGER = new AutomationLogManager(SearchResults.class);

   public static HashMap<String, Object> searchResultsJson;

   private final WebElementWait wait;

   private final HashMap<String, WebElement> searchOutboundCardMap;

   private final HashMap<String, WebElement> searchReturnCardMap;

   private final HashMap<String, WebElement> searchSummaryPanelMap;

   private final HashMap<String, WebElement> searchResultsTitle;

   private final HashMap<String, String> searchSummaryPanelValues;

   @FindBy(css = "#flightSearchResultHeading__component h1")
   private WebElement searchResHeading;

   @FindBy(css = "#flightSearchResultHeading__component label span.inputs__text")
   private WebElement searchResCheckBoxText;

   @FindBy(css = "#flightSearchResultHeading__component span.inputs__box")
   private WebElement altAirportsCheckBox;

   @FindBy(css = ".Outbound__title:nth-of-type(1)+div+div+div .Selectable__selectableCard")
   private List<WebElement> searchResCardsOutbound;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+div+div+div .Selectable__selectableCard"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+div+div+div .Selectable__selectableCard") })
   private List<WebElement> searchResCardsReturn;

   @FindBy(css = ".inventory-info")
   private List<WebElement> carouselItemsBeforeInventoryStartDate;

   @FindBy(css = ".CrossOverModal__crossOverModal")
   private WebElement infoMessageModal;

   @FindBy(css = ".CrossOverModal__linkContent")
   private WebElement infoMessageCTA;

   @FindBy(css = ".Title__header h1")
   private WebElement searchResultsPageTitle;

   @FindBy(css = ".Title__header [aria-label='checkbox']")
   private WebElement searchResultsCheckbox;

   @FindBy(css = ".Selectable__selectableCard")
   private List<WebElement> selectableCard;

   @FindAll({ @FindBy(css = ".DateCarousel__next"), @FindBy(css = ".DateCarousel__spinner") })
   private List<WebElement> searchResCarousal;

   @FindBy(xpath = "//div[contains(@class,'FlightInformation__otherAirportText')]/ancestor::div[contains(@class,'Selectable__selectableCard')]//button")
   private List<WebElement> ativeAirportCards;

   @FindBy(css = ".Selectable__selected .FlightInformation__otherAirportText")
   private List<WebElement> searchAlternativeFlightBadge;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem"),
            @FindBy(css = ".Outbound__title:nth-child(1)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem") })
   private List<WebElement> outboundDatesAvailable;

   @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not([class*='disabled']):not([class*='activeTab'])>span>span")
   private List<WebElement> outboundDates;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-child(2)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem") })
   private List<WebElement> returnDatesAvailable;

   @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not([class*='disabled']):not([class*='activeTab'])>span>span")
   private List<WebElement> returnDates;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not([class*='disabled'])>span>span"),
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab .DataCarouselItem__tabFlightDate"),
            @FindBy(css = ".Outbound__title:nth-child(1)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab .DataCarouselItem__tabFlightDate") })
   private List<WebElement> outboundDateVisible;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab .DataCarouselItem__tabFlightPrice"),
            @FindBy(css = ".Outbound__title:nth-child(1)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab .DataCarouselItem__tabFlightPrice") })
   private List<WebElement> outboundPriceVisible;

   @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not([class*='disabled']) .DataCarouselItem__tabFlightPrice")
   private List<WebElement> outboundPriceAvailable;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab .DataCarouselItem__tabFlightDate"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab .DataCarouselItem__tabFlightDate") })
   private List<WebElement> returnDateVisible;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab .DataCarouselItem__tabFlightPrice"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab .DataCarouselItem__tabFlightPrice") })
   private List<WebElement> returnPriceVisible;

   @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not([class*='disabled']) .DataCarouselItem__tabFlightPrice")
   private List<WebElement> returnPriceAvailable;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__disabled .DataCarouselItem__tabFlightDate"),
            @FindBy(css = ".Outbound__title:nth-child(1)+.DateCarousel__timelineCarousel .DataCarouselItem__disabled .DataCarouselItem__tabFlightDate") })
   private List<WebElement> outboundDisabledDateVisible;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__disabled .DataCarouselItem__tabFlightPrice"),
            @FindBy(css = ".Outbound__title:nth-child(1)+.DateCarousel__timelineCarousel .DataCarouselItem__disabled .DataCarouselItem__tabFlightPrice") })
   private List<WebElement> outboundDisabledPriceVisible;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DataCarouselItem__disabled .DataCarouselItem__tabFlightDate"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DataCarouselItem__disabled .DataCarouselItem__tabFlightDate") })
   private List<WebElement> returnDisabledDateVisible;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DataCarouselItem__disabled .DataCarouselItem__tabFlightPrice"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DataCarouselItem__disabled .DataCarouselItem__tabFlightPrice") })
   private List<WebElement> returnDisabledPriceVisible;

   @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DateCarousel__prev")
   private WebElement outboundPrevArrow;

   @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DateCarousel__next")
   private WebElement outboundNextArrow;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DateCarousel__prev"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DateCarousel__prev") })
   private WebElement returnPrevArrow;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DateCarousel__next"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DateCarousel__next") })
   private WebElement returnNextArrow;

   @FindBy(css = ".SelectedDate__selectedDate+.FlightCardsList__flightCardsList")
   private List<WebElement> searchCards;

   @FindBy(css = ".SelectedDate__selectedDate")
   private List<WebElement> selectedDate;

   @FindAll({
            @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[1]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='Journey__time']/span")

   })
   private List<WebElement> outboundTimes;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[1]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='Journey__departure']//p")
   private WebElement outboundDepAirport;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[1]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='Journey__arrival']//p")
   private WebElement outboundArrAirport;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[2]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='Journey__departure']//p")
   private WebElement returnDepAirport;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[2]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='Journey__arrival']//p")
   private WebElement returnArrAirport;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[1]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='JourneyIndicator__journeyIndicatorContainer']/span")
   private WebElement outboundjourneyIndicator;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[2]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='JourneyIndicator__journeyIndicatorContainer']/span")
   private WebElement returnjourneyIndicator;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[1]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='JourneyIndicator__journeyIndicatorContainer']")
   private WebElement outboundjourneyDuration;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[2]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='JourneyIndicator__journeyIndicatorContainer']")
   private WebElement returnjourneyDuration;

   @FindBy(xpath = "(//div[@class='FlightCardsList__flightCardsList'])[1]//button")
   private WebElement outboundSelectFlightButton;

   @FindBy(xpath = "(//div[@class='FlightCardsList__flightCardsList'])[2]//button")
   private WebElement returnSelectFlightButton;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']//*[@class='FlightCardsList__flightCardsList'][1]//*[@class='price__value']")
   private WebElement outboundPrice;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']//*[@class='FlightCardsList__flightCardsList'][1]//*[@class='price__currency']")
   private WebElement outboundCurrency;

   @FindBy(xpath = "//div[contains(@class, 'Standard__tooltiptext') and contains(text(),'fee')]")
   private List<WebElement> bookingFeeTooltip;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']//*[@class='FlightCardsList__flightCardsList'][2]//*[@class='price__value']")
   private WebElement returnPrice;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']//*[@class='FlightCardsList__flightCardsList'][2]//*[@class='price__currency']")
   private WebElement returnCurrency;

   @FindBy(xpath = "//*[@id='flightsearchresults__component']/h2[1]/following-sibling::*[@class='FlightCardsList__flightCardsList']//*[@class='Journey__time']/span")
   private List<WebElement> returnTimes;

   @FindBy(css = "#flightsummarypanel__component")
   private WebElement summaryPanelContainer;

   @FindBy(xpath = "//div[contains(@class, 'Components__descriptionItem')]/div[1]")
   private List<WebElement> descriptionItems;

   @FindAll({ @FindBy(css = "div[class='Column__col Column__auto AffixIcon__affixIcon']"),
            @FindBy(css = ".Column__col.Column__auto.Text__affixIcon") })
   private WebElement yourFlightLogo;

   @FindBy(xpath = "//*[@id='flightsummarypanel__component']/div//span")
   private List<WebElement> summaryPanelLabels;

   @FindBy(xpath = "//span[contains(text(),'PRICE')]")
   private WebElement summaryPanelPriceBreakdownLabel;

   @FindAll({ @FindBy(css = ".Components__SummaryBlock:nth-of-type(2) span"),
            @FindBy(xpath = "//span[contains(text(),'RETURN')]") })
   private WebElement summaryPanelReturnLabel;

   @FindAll({ @FindBy(xpath = "//*[@id='flightsummarypanel__component']/div//span"),
            @FindBy(xpath = "//*[@id='flightsummarypanel__component']/div//p") })
   private List<WebElement> summaryPanelSelectionTexts;

   @FindBy(css = ".SummaryPanel__text")
   private WebElement yourFlightText;

   @FindBy(css = ".Components__SummaryBlock div")
   private WebElement paxTextSummaryPanel;

   @FindBy(xpath = "//div[contains(text(),'TOTAL')]")
   private WebElement totalPriceLabelSummaryPanel;

   @FindBy(xpath = "//div[contains(text(),'taxes')]")
   private WebElement taxesLabelSummaryPanel;

   @FindBy(css = "#flightsearchresults__component .carousel__prevBtn.DateCarousel__carouselControls")
   private WebElement leftArrowNavigation;

   @FindBy(css = "#flightsearchresults__component .carousel__controls.carousel__nextBtn.DateCarousel__carouselControls")
   private WebElement rightArrowNavigation;

   @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .carousel__prevBtn.DateCarousel__carouselControls")
   private WebElement leftArrowNavigationReturn;

   @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .carousel__nextBtn.DateCarousel__carouselControls")
   private WebElement rightArrowNavigationReturn;

   @FindBy(css = "#flightsearchresults__component  div:nth-child(2) .DataCarouselItem__tabFlightDate")
   private WebElement firstDateInOutboundCarousal;

   @FindBy(css = ".Outbound__title:nth-of-type(2)+div .carousel__frame .DataCarouselItem__tabFlightDate")
   private WebElement firstDateInReturnCarousal;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab"),
            @FindBy(css = ".Outbound__title:nth-child(1)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab"),
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__activeTab>span[class='DataCarouselItem__tabFlightDate']>span") })
   private WebElement outboundHighlightedDate;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem.DataCarouselItem__activeTab"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem.DataCarouselItem__activeTab") })
   private WebElement returnHighlightedDate;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(1)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not(.DataCarouselItem__disabled):not(.DataCarouselItem__activeTab)"),
            @FindBy(css = ".Outbound__title:nth-child(1)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not(.DataCarouselItem__disabled):not(.DataCarouselItem__activeTab)") })
   private List<WebElement> outboundAvailableAltDates;

   @FindAll({
            @FindBy(css = ".Outbound__title:nth-of-type(2)+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not(.DataCarouselItem__disabled):not(.DataCarouselItem__activeTab)"),
            @FindBy(css = ".FlightCardsList__flightCardsList+.Outbound__title+.DateCarousel__timelineCarousel .DataCarouselItem__dateCarouselItem:not(.DataCarouselItem__disabled):not(.DataCarouselItem__activeTab)") })
   private List<WebElement> returnAvailableAltDates;

   @FindBy(xpath = "//h2[contains(text(),'OUTBOUND')]/following-sibling::div[3]//*[@class='FlightInformation__selectionStatus']/p[contains(text(),'SELECTED')]")
   private WebElement outboundSearchCardSelected;

   @FindBy(xpath = "//h2[contains(text(),'Return')]/following-sibling::div[3]//*[@class='FlightInformation__selectionStatus']/p[contains(text(),'SELECTED')]")
   private WebElement returnSearchCardSelected;

   @FindBy(xpath = "//h2[contains(text(),'OUTBOUND')]/following-sibling::div[3]//*[@class='Journey__departure']//*[@class='Components__flightTime']")
   private List<WebElement> outboundFlightDepTime;

   @FindBy(xpath = "//h2[contains(text(),'Return')]/following-sibling::div[3]//*[@class='Journey__departure']//*[@class='Components__flightTime']")
   private List<WebElement> returnFlightDepTime;

   @FindAll({ @FindBy(xpath = "(//span[contains(@class,'selectedIndicator')])[1]"),
            @FindBy(xpath = "//h2[contains(text(),'OUTBOUND')]/following-sibling::div[3]//*[@class='Selectable__selectedIndicator']") })
   private WebElement outboundFlightSelectedTick;

   @FindBy(xpath = "//h2[contains(text(),'RETURN')]/following-sibling::div[3]//*[@class='Selectable__selectedIndicator']")
   private WebElement returnFlightSelectedTick;

   @FindAll({ @FindBy(xpath = "(//*[@class='FlightInformation__selectionStatus']//p)[1]"),
            @FindBy(xpath = "//h2[contains(text(),'OUTBOUND')]/following-sibling::div[3]//*[@class='FlightInformation__selectionStatus']//p") })
   private WebElement outboundFlightSelectedText;

   @FindAll({ @FindBy(xpath = "(//*[@class='FlightInformation__selectionStatus']//p)[2]"),
            @FindBy(xpath = "//h2[contains(text(),'RETURN')]/following-sibling::div[3]//*[@class='FlightInformation__selectionStatus']//p") })
   private WebElement returnFlightSelectedText;

   @FindAll({
            @FindBy(xpath = "//h2[contains(text(),'OUTBOUND')]/following-sibling::*[@class='FlightCardsList__flightCardsList']//span[text()='Direct']/ancestor::*[contains(@class,'FlightCard__flightCardRow')]//button"),
            @FindBy(xpath = "(//*[@id='flightsearchresults__component']//div[contains(@class,'FlightCardsList')])[1]//span[text()='Direct']/ancestor::*[contains(@class,'FlightCard__flightCardRow')]//button") })
   private WebElement outboundDierctFlightSelectButton;

   @FindAll({
            @FindBy(xpath = "//h2[contains(text(),'RETURN')]/following-sibling::*[@class='FlightCardsList__flightCardsList']//span[text()='Direct']/ancestor::*[contains(@class,'FlightCard__flightCardRow')]//button"),
            @FindBy(xpath = "(//*[@id='flightsearchresults__component']//div[contains(@class,'FlightCardsList')])[2]//span[text()='Direct']/ancestor::*[contains(@class,'FlightCard__flightCardRow')]//button") })
   private WebElement returnDierctFlightSelectButton;

   @FindAll({
            @FindBy(xpath = "//h2[contains(text(),'OUTBOUND')]/following-sibling::*[@class='FlightCardsList__flightCardsList']//span[text()='Stopover']/ancestor::*[contains(@class,'FlightCard__flightCardRow')]//button"),
            @FindBy(xpath = "(//*[@id='flightsearchresults__component']//div[contains(@class,'FlightCardsList')])[1]//span[text()='Stopover']/ancestor::*[contains(@class,'FlightCard__flightCardRow')]//button") })
   private WebElement outboundStopOverFlightSelectButton;

   @FindAll({
            @FindBy(xpath = "//h2[contains(text(),'RETURN')]/following-sibling::*[@class='FlightCardsList__flightCardsList']//span[text()='Stopover']/ancestor::*[contains(@class,'FlightCard__flightCardRow')]//button"),
            @FindBy(xpath = "(//*[@id='flightsearchresults__component']//div[contains(@class,'FlightCardsList')])[2]//span[text()='Stopover']/ancestor::*[contains(@class,'FlightCard__flightCardRow')]//button") })
   private WebElement returnStopOverFlightSelectButton;

   @FindBy(css = ".Components__SummaryBlock:nth-child(2) .Components__title+div>div div")
   private List<WebElement> outboundFlightSummaryDetails;

   @FindAll({
            @FindBy(xpath = ".//*[contains(@class,'continueButton')]"),
            @FindBy(xpath = ".//*[contains(text(),'CONTINUE')]")
   })
   private WebElement continueButton;

   @FindBy(css = "#flightsearchresults__component  h2  div  div")
   private List<WebElement> flightsNA;

   @FindBy(css = ".ErrorModals__flightErrorContent")
   private WebElement invalidFlightErrorMessage;

   @FindBy(css = ".ErrorModals__applyButton")
   private WebElement invalidFlightErrorOKButton;

   @FindBy(css = ".Components__SummaryBlock:nth-child(3) .Components__title+div>div div")
   private List<WebElement> returnFlightSummaryDetails;

   @FindBy(css = "span[class*='hurryuptext']")
   private List<WebElement> returnXSeatsLeft;

   @FindBy(css = "#flightsummarypanel__priceBreakdown div div div:nth-child(2) span:first-of-type")
   private List<WebElement> summaryPriceBreakdownDetails;

   @FindAll({ @FindBy(xpath = "//button[contains(text(),'CONTINUE')]"),
            @FindBy(css = "button[class*='continueButton']") })
   private WebElement ContinueToFlightsButton;

   @FindBy(css = ".SummaryPanel__content")
   private WebElement summarypanelMobile;

   @FindBy(css = ".Modal__opened  [aria-label='modal close']")
   private WebElement infoMessageModalClose;

   @FindBy(css = ".Modal__opened")
   private WebElement infoMessageModalOpen;

   @FindBy(css = "[class*='Column__col Column__col-4 Components__value']")
   private List<WebElement> totalPrice;

   @FindBy(css = "[class*='Column__col Column__col-4 Components__value']")
   private List<WebElement> ppPrice;

   private String searchLegacyUrl;

   public SearchResults()
   {
      searchOutboundCardMap = new HashMap<>();
      searchReturnCardMap = new HashMap<>();
      searchSummaryPanelMap = new HashMap<>();
      searchResultsTitle = new HashMap<>();
      searchLegacyUrl = "";
      searchSummaryPanelValues = new HashMap<>();
      // setSearchComponentsMap();
      wait = new WebElementWait();
   }

   public static void searchResultsjourneySummary()
   {
      try
      {
         searchResultsJson = (HashMap<String, Object>) WebDriverUtils
                  .executeScript("return searchResultsJson.flightViewData[0].journeySummary");
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, e.getMessage());
      }
   }

   public void viewSearchResultsPage()
   {
      WebElementTools.scrollToCenter(searchResHeading);
   }

   public boolean isOutboundSearchResultsPresent()
   {
      return !searchResCardsOutbound.isEmpty();
   }

   public boolean isSelectableCardPresent()
   {
      return !selectableCard.isEmpty();
   }

   public void clickAlternativeFlight()
   {
      wait.forJSExecutionReadyLazy();
      WebElement selectableButton = WebElementTools.getFirstElement(ativeAirportCards);
      WebElementTools.javaScriptScrollToElement(selectableButton);
      WebElementTools.clickElementJavaScript(selectableButton);
   }

   public boolean hasAlternativeFlightBadge()
   {
      return WebElementTools
               .isDisplayed(WebElementTools.getFirstElement(searchAlternativeFlightBadge));
   }

   public boolean isReturnSearchResultsPresent()
   {
      return !searchResCardsReturn.isEmpty();
   }

   public boolean hasCaroucelItemsBeforeInventoryStartDate()
   {
      return !carouselItemsBeforeInventoryStartDate.isEmpty();
   }

   public boolean caroucelItemsBeforeInventoryStartDateHasInfo()
   {
      wait.forJSExecutionReadyLazy();
      ArrayList<Boolean> infoTexts = new ArrayList<>();
      carouselItemsBeforeInventoryStartDate.forEach(caroucelItem ->
      {
         WebElementTools.scrollToCenter(caroucelItem);
         infoTexts.add(caroucelItem.getText().contains("Info"));
      });
      return !infoTexts.contains(false);
   }

   public boolean caroucelItemsBeforeInventoryStartDateHasNoPrice()
   {
      wait.forJSExecutionReadyLazy();
      ArrayList<Boolean> infoTexts = new ArrayList<>();
      carouselItemsBeforeInventoryStartDate.forEach(caroucelItem ->
      {
         WebElementTools.scrollToCenter(caroucelItem);
         infoTexts.add(!(caroucelItem.getText().matches(".*\\d.*")));
      });
      return !infoTexts.contains(false);
   }

   public boolean checkIfInfoModalMessageIsVisible()
   {
      wait.forJSExecutionReadyLazy();
      return infoMessageModal.isDisplayed();
   }

   public boolean checkIfInfoModalCTAIsVisible()
   {
      wait.forJSExecutionReadyLazy();
      return infoMessageCTA.isDisplayed();
   }

   public void clickOnInfoLinkInCaroucel()
   {
      wait.forJSExecutionReadyLazy();
      carouselItemsBeforeInventoryStartDate.get(0).click();
   }

   public void clickOnCTALinkInCaroucel()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(infoMessageCTA);
      WebElementTools.clickElementJavaScript(infoMessageCTA);
   }

   public boolean isRedirected(String url)
   {
      String currentUrl = WebDriverUtils.getDriver().getCurrentUrl();
      return currentUrl.contains(url);
   }

   public boolean isOnSameTab()
   {
      List<String> browserTabs = new ArrayList<>(WebDriverUtils.getDriver().getWindowHandles());
      return browserTabs.size() <= 1;
   }

   public boolean checkHeaderText(String headerRegex)
   {
      return Pattern.matches(headerRegex, searchResHeading.getText());
   }

   public boolean checkCheckBoxText(String expectedText)
   {
      return StringUtils.equalsIgnoreCase(expectedText, searchResCheckBoxText.getText());
   }

   public boolean isTickPresent()
   {
      return WebElementTools.isPresent(altAirportsCheckBox);
   }

   public boolean isOutboundCarousalPresent()
   {
      return WebElementTools.isPresent(searchResCarousal.get(0));
   }

   public boolean isReturnCarousalPresent()
   {
      return WebElementTools.isPresent(searchResCarousal.get(1));
   }

   public boolean checkNOutboundDates(int numberOfDays)
   {
      int counter = 0;
      for (WebElement webElement : outboundDatesAvailable)
      {
         if (WebElementTools.isVisible(webElement))
         {
            counter++;
         }
      }
      return counter == numberOfDays || counter == numberOfDays + 1;
   }

   public boolean checkNReturnDates(int numberOfDays)
   {
      int counter = 0;
      for (WebElement webElement : returnDatesAvailable)
      {
         if (WebElementTools.isVisible(webElement))
         {
            counter++;
         }
      }
      return counter == numberOfDays || counter == numberOfDays + 1;
   }

   public boolean isOutboundSelectedDateInCentre()
   {
      return outboundDatesAvailable.get(3).getAttribute("class").contains("activeTab");
   }

   public boolean isReturnSelectedDateInCentre()
   {
      return returnDatesAvailable.get(3).getAttribute("class").contains("activeTab");
   }

   public boolean outboundDatePriceVisible()
   {
      return WebElementTools
               .isPresent(outboundDateVisible.stream().filter(WebElement::isDisplayed).findFirst()
                        .get())
               && WebElementTools.isPresent(
               outboundPriceVisible.stream().filter(WebElement::isDisplayed).findFirst().get());
   }

   public List<String> getOutboundPriceAvailableList()
   {
      return outboundPriceAvailable.stream().map(WebElement::getText).collect(Collectors.toList());
   }

   public String getOutboundCurrency()
   {
      return outboundCurrency.getText();
   }

   public boolean returnDatePriceVisible()
   {
      return WebElementTools
               .isPresent(returnDateVisible.stream().filter(WebElement::isDisplayed).findFirst()
                        .get())
               && WebElementTools.isPresent(
               returnPriceVisible.stream().filter(WebElement::isDisplayed).findFirst().get());
   }

   public List<String> getReturnPriceAvailableList()
   {
      return returnPriceAvailable.stream().map(WebElement::getText).collect(Collectors.toList());
   }

   public String getReturnCurrency()
   {
      return returnCurrency.getText();
   }

   public boolean outboundDisabledDatePriceVisible()
   {
      return WebElementTools.isPresent(
               outboundDisabledDateVisible.stream().filter(WebElement::isDisplayed).findFirst()
                        .get())
               && WebElementTools.isPresent(outboundDisabledPriceVisible.stream()
               .filter(WebElement::isDisplayed).findFirst().get());
   }

   public boolean returnDisabledDatePriceVisible()
   {
      return WebElementTools.isPresent(
               returnDisabledDateVisible.stream().filter(WebElement::isDisplayed).findFirst()
                        .get())
               && WebElementTools.isPresent(
               returnDisabledPriceVisible.stream().filter(WebElement::isDisplayed).findFirst()
                        .get());
   }

   public boolean isOutboundCarousalNavigationArrowsPresent()
   {
      return WebElementTools.isPresent(outboundPrevArrow)
               && WebElementTools.isPresent(outboundNextArrow);
   }

   public boolean isReturnCarousalNavigationArrowsPresent()
   {
      return WebElementTools.isPresent(returnPrevArrow)
               && WebElementTools.isPresent(returnNextArrow);
   }

   public void viewOutboundSearchCards()
   {
      WebElementTools.scrollToCenter(searchCards.get(0));
   }

   public void viewReturnSearchCards()
   {
      WebElementTools.scrollToCenter(searchCards.get(1));
   }

   public boolean searchCardsBelowOutboundDate()
   {
      return WebElementTools.isPresent(searchCards.get(0));
   }

   public boolean searchCardsBelowReturnDate()
   {
      return WebElementTools.isPresent(searchCards.get(1));
   }

   public boolean checkOutboundDateFormat(String dateregex)
   {
      return Pattern.matches(dateregex, selectedDate.get(0).getText());
   }

   public boolean checkReturnDateFormat(String dateregex)
   {
      return Pattern.matches(dateregex, selectedDate.get(1).getText());
   }

   public HashMap<String, WebElement> getOutboundSearchCardComponentsMap()
   {
      return searchOutboundCardMap;
   }

   public HashMap<String, WebElement> getReturnSearchCardComponentsMap()
   {
      return searchReturnCardMap;
   }

   public HashMap<String, WebElement> getSummaryPanelMap()
   {
      return searchSummaryPanelMap;
   }

   public HashMap<String, WebElement> getSearchResultsTitle()
   {
      return searchResultsTitle;
   }

   public String getSearchLegacyUrl()
   {
      return searchLegacyUrl;
   }

   public void viewSummaryPanel()
   {
      WebElementTools.scrollToCenter(summaryPanelContainer);
   }

   public boolean isPrevDatesPresentOutboundCarousal()
   {
      return WebElementTools.isPresent(leftArrowNavigation);
   }

   public boolean isPrevDatesPresentReturnCarousal()
   {
      return WebElementTools.isPresent(leftArrowNavigation);
   }

   public void clickLeftArrow()
   {
      WebElementTools.click(leftArrowNavigation);
   }

   public void clickRightArrow()
   {
      WebElementTools.click(rightArrowNavigation);

   }

   public void clickLeftArrowReturn()
   {
      WebElementTools.click(leftArrowNavigationReturn);
   }

   public void clickRightArrowReturn()
   {
      WebElementTools.click(rightArrowNavigationReturn);
   }

   public boolean isAfterDatesPresentOutboundCarousal()
   {
      return WebElementTools.isPresent(rightArrowNavigation);
   }

   public boolean isAfterDatesPresentReturnCarousal()
   {
      return WebElementTools.isPresent(rightArrowNavigation);
   }

   public String getFirstAvailableDateInOutboundCarousal()
   {

      return WebElementTools
               .getElementText(wait.getWebElementWithLazyWait(firstDateInOutboundCarousal));
   }

   public String getFirstAvailableDateInReturnCarousal()
   {
      return WebElementTools
               .getElementText(wait.getWebElementWithLazyWait(firstDateInReturnCarousal));
   }

   public boolean isOutboundAlternateDateAvailable()
   {
      for (int i = 0; i < 7; i++)
      {
         if (!outboundAvailableAltDates.isEmpty() && i > 3)
         {
            return true;
         }
         else
         {
            clickRightArrow();
            // clickLeftArrow();
            wait.forJSExecutionReadyLazy();
         }
      }
      return false;
   }

   public boolean isReturnAlternateDateAvailable()
   {
      for (int i = 0; i < 7; i++)
      {
         if (!returnAvailableAltDates.isEmpty() && i > 3)
         {
            return true;
         }
         else
         {
            clickRightArrowReturn();
            wait.forJSExecutionReadyLazy();
         }
      }
      return false;

   }

   public void selectAlternateOutboundDate()
   {
      WebElementTools.clickElementJavaScript(outboundAvailableAltDates.get(0));
   }

   public void selectAlternateReturnDate()
   {
      WebElementTools.clickElementJavaScript(returnAvailableAltDates.get(0));
   }

   public String getSelectedOutboundDate()
   {
      return WebElementTools.getElementTextByInnerHtml(outboundHighlightedDate);
   }

   public String getSelectedReturnDate()
   {
      return WebElementTools.getElementTextByInnerHtml(returnHighlightedDate);
   }

   public String getOutboundSelectedDateHeader()
   {
      return WebElementTools.getElementText(selectedDate.get(0));
   }

   public String getReturnSelectedDateHeader()
   {
      return WebElementTools.getElementText(selectedDate.get(1));
   }

   public boolean isOutboundSearchCardSelected()
   {
      return WebElementTools.isPresent(outboundSearchCardSelected);
   }

   public boolean isReturnSearchCardSelected()
   {
      return WebElementTools.isPresent(returnSearchCardSelected);
   }

   public void selectOutboundFlight()
   {
      WebElementTools.clickElementJavaScript(outboundSelectFlightButton);
   }

   public void selectReturnFlight()
   {
      WebElementTools.click(wait.getWebElementWithLazyWait(returnSelectFlightButton));
   }

   public boolean isOutboundResultsOrdered()
   {
      SimpleDateFormat parser = new SimpleDateFormat("HH:mm");
      for (int i = 0; i < outboundFlightDepTime.size() - 1; i++)
      {
         try
         {
            if (parser.parse(outboundFlightDepTime.get(i).getText())
                     .after(parser.parse(outboundFlightDepTime.get(i + 1).getText())))
            {
               return false;
            }
         }
         catch (ParseException e)
         {
            return false;
         }
      }
      return true;
   }

   public boolean isReturnResultsOrdered()
   {
      SimpleDateFormat parser = new SimpleDateFormat("HH:mm");
      for (int i = 0; i < returnFlightDepTime.size() - 1; i++)
      {
         try
         {
            if (parser.parse(returnFlightDepTime.get(i).getText())
                     .after(parser.parse(outboundFlightDepTime.get(i + 1).getText())))
            {
               return false;
            }
         }
         catch (ParseException e)
         {
            return false;
         }
      }
      return true;
   }

   public boolean isOutboundTickDisplayed()
   {
      return WebElementTools
               .isDisplayed(wait.getWebElementWithLazyWait(outboundFlightSelectedTick));
   }

   public boolean isReturnTickDisplayed()
   {
      return WebElementTools.isDisplayed(wait.getWebElementWithLazyWait(returnFlightSelectedTick));
   }

   public String getOutboundFlightSlectedText()
   {
      return WebElementTools.getElementText(outboundFlightSelectedText);
   }

   public String getReturnFlightSlectedText()
   {
      return WebElementTools.getElementText(returnFlightSelectedText);
   }

   public void selectOutboundDirectFlight()
   {
      WebElementTools.click(outboundDierctFlightSelectButton);
      wait.forJSExecutionReadyLazy();
   }

   public void selectOutboundStopOverFlight()
   {
      WebElementTools.click(outboundStopOverFlightSelectButton);
      wait.forJSExecutionReadyLazy();
   }

   public void selectReturnDirectFlight()
   {
      WebElementTools.click(returnDierctFlightSelectButton);
      wait.forJSExecutionReadyLazy();
   }

   public void clickContinuButton()
   {
      WebElementTools.clickElementJavaScript(continueButton);
   }

   public void selectReturnStopOverFlight()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(returnStopOverFlightSelectButton);
   }

   public void viewFLightSummaryPanel()
   {
      WebElementTools.scrollToCenter(summaryPanelContainer);
   }

   public boolean checkStickynessOFContinueButton()
   {

      WebDriverUtils.executeScript("window.scrollTo(0, document.body.scrollHeight)", "");
      return WebElementTools.isVisible(ContinueToFlightsButton);

   }

   public boolean checkCollapssedSummaryPanel()
   {

      WebDriverUtils.executeScript("window.scrollTo(0, document.body.scrollHeight)", "");
      return WebElementTools.getElementAttribute(summarypanelMobile, "aria-hidden").equals("true");

   }

   public boolean checkSummaryPanel()
   {
      return WebElementTools.isPresent(summaryPanelContainer);
   }

   public void setSearchResultsTitle()
   {
      try
      {
         searchResultsTitle.put("title", searchResultsPageTitle);
         searchResultsTitle.put("checkbox", searchResultsCheckbox);
      }
      catch (Exception e)
      {

      }
   }

   public void setSearchLegacyUrl()
   {
      try
      {
         searchLegacyUrl = (String) WebDriverUtils.executeScript("return legacySiteUrl");
      }
      catch (Exception e)
      {

      }

   }

   public void setSearchComponentsMap()
   {
      try
      {
         searchOutboundCardMap.put("Departure Time", outboundTimes.get(0));
         searchOutboundCardMap.put("Arrival Time", outboundTimes.get(1));
         searchOutboundCardMap.put("Departure Airport & Code", outboundDepAirport);
         searchOutboundCardMap.put("Arrival Airport & Code", outboundArrAirport);
         searchOutboundCardMap.put("Flight Duration", outboundjourneyDuration);
         searchOutboundCardMap.put("Select Flight CTA", outboundSelectFlightButton);
         searchOutboundCardMap.put("Direct or Stop Over label", outboundjourneyIndicator);
         searchOutboundCardMap.put("Price", outboundPrice);

         searchReturnCardMap.put("Departure Time", returnTimes.get(0));
         searchReturnCardMap.put("Arrival Time", returnTimes.get(1));
         searchReturnCardMap.put("Departure Airport & Code", returnDepAirport);
         searchReturnCardMap.put("Arrival Airport & Code", returnArrAirport);
         searchReturnCardMap.put("Flight Duration", returnjourneyDuration);
         searchReturnCardMap.put("Select Flight CTA", returnSelectFlightButton);
         searchReturnCardMap.put("Direct or Stop Over label", returnjourneyIndicator);
         searchReturnCardMap.put("Price", returnPrice);

         searchSummaryPanelMap.put("Aircraft Logo", yourFlightLogo);
         searchSummaryPanelMap.put("YOUR FLIGHT title", yourFlightText);
         searchSummaryPanelMap.put("OUTBOUND sub title", summaryPanelLabels.get(1));
         searchSummaryPanelMap.put("No outbound flight selected  text",
                  summaryPanelSelectionTexts.get(1));
         searchSummaryPanelMap.put("RETURN sub title", summaryPanelLabels.get(2));
         searchSummaryPanelMap.put("No return flight selected text",
                  summaryPanelSelectionTexts.get(2));
         searchSummaryPanelMap.put("Outbound Date", outboundFlightSummaryDetails.get(0));
         searchSummaryPanelMap.put("Outbound Departure & Arrival Airport",
                  outboundFlightSummaryDetails.get(1));
         searchSummaryPanelMap.put("Outbound Departure & Arrival Time Depart",
                  outboundFlightSummaryDetails.get(2));
         searchSummaryPanelMap.put("Outbound Duration", outboundFlightSummaryDetails.get(3));
         searchSummaryPanelMap.put("Outbound Direct Flight", outboundFlightSummaryDetails.get(4));
         searchSummaryPanelMap.put("Outbound Price per person",
                  outboundFlightSummaryDetails.get(5));
         searchSummaryPanelMap.put("Return Date", returnFlightSummaryDetails.get(0));
         searchSummaryPanelMap.put("Return Departure & Arrival Airport",
                  returnFlightSummaryDetails.get(1));
         searchSummaryPanelMap.put("Return Departure & Arrival Time Depart",
                  returnFlightSummaryDetails.get(2));
         searchSummaryPanelMap.put("Return Duration", returnFlightSummaryDetails.get(3));
         searchSummaryPanelMap.put("Return Direct Flight", returnFlightSummaryDetails.get(4));
         searchSummaryPanelMap.put("Return Price per person", returnFlightSummaryDetails.get(5));

         searchSummaryPanelMap.put("PRICE BREAKDOWN title", summaryPanelPriceBreakdownLabel);
         // searchSummaryPanelMap.put("Flights", summaryPriceBreakdownDetails.get(0));
         searchSummaryPanelMap.put("Airport taxes", summaryPriceBreakdownDetails.get(0));
         searchSummaryPanelMap.put("Price per person", summaryPriceBreakdownDetails.get(1));
      }
      catch (Exception e)
      {
      }
   }

   public void setSearchComponentsMapAfterFlightSelection()
   {
      wait.forJSExecutionReadyLazy();
      try
      {
         searchSummaryPanelMap.put("YOUR FLIGHT title", yourFlightText);
         searchSummaryPanelMap.put("PAX", paxTextSummaryPanel);
         searchSummaryPanelMap.put("OUTBOUND sub title", summaryPanelLabels.get(1));
         searchSummaryPanelMap.put("RETURN sub title", summaryPanelReturnLabel);
         searchSummaryPanelMap.put("TOTAL PRICE", totalPriceLabelSummaryPanel);
         searchSummaryPanelMap.put("includes taxes & charges", taxesLabelSummaryPanel);
         searchSummaryPanelMap.put("Continue CTA", ContinueToFlightsButton);
      }
      catch (Exception e)
      {
      }
      try
      {
         searchSummaryPanelMap.put("Outbound Date", outboundFlightSummaryDetails.get(0));
         searchSummaryPanelMap.put("Outbound Departure & Arrival Airport",
                  outboundFlightSummaryDetails.get(1));
         searchSummaryPanelMap.put("Outbound Departure & Arrival Time Depart",
                  outboundFlightSummaryDetails.get(2));
         searchSummaryPanelMap.put("Outbound Duration", outboundFlightSummaryDetails.get(3));
         searchSummaryPanelMap.put("Outbound Direct Flight", outboundFlightSummaryDetails.get(4));
         searchSummaryPanelMap.put("Outbound Price per person",
                  outboundFlightSummaryDetails.get(5));
      }
      catch (Exception e)
      {
      }
      try
      {
         searchSummaryPanelMap.put("Return Date", returnFlightSummaryDetails.get(0));
         searchSummaryPanelMap.put("Return Departure & Arrival Airport",
                  returnFlightSummaryDetails.get(1));
         searchSummaryPanelMap.put("Return Departure & Arrival Time Depart",
                  returnFlightSummaryDetails.get(2));
         searchSummaryPanelMap.put("Return Duration", returnFlightSummaryDetails.get(3));
         searchSummaryPanelMap.put("Return Direct Flight", returnFlightSummaryDetails.get(4));
         searchSummaryPanelMap.put("Return Price per person", returnFlightSummaryDetails.get(5));
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, e.getMessage());
      }
   }

   public WebElement getOutboundFlightButton()
   {
      return wait.getWebElementWithLazyWait(outboundSelectFlightButton);
   }

   public WebElement getInboundFlightButton()
   {
      return wait.getWebElementWithLazyWait(returnSelectFlightButton);
   }

   public boolean isOutboundFlightButtonDisplyed()
   {
      return WebElementTools.isPresent(getOutboundFlightButton());
   }

   public boolean isInboundFlightButtonDisplyed()
   {
      return WebElementTools.isPresent(getInboundFlightButton());
   }

   public WebElement getContinueToFlightButton()
   {
      return wait.getWebElementWithLazyWait(ContinueToFlightsButton);
   }

   public List<WebElement> getOutboundDates()
   {
      return wait.getWebElementWithLazyWait(outboundDates);
   }

   public List<WebElement> getInboundDates()
   {
      return wait.getWebElementWithLazyWait(returnDates);
   }

   public String getOutboundFlightNAText()
   {
      return flightsNA.get(0).getText();
   }

   public String getInvalidFlightErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      return invalidFlightErrorMessage.getText().replaceAll("\\n", " ");
   }

   public void clickOkCloseErrorPopup()
   {
      WebElementTools.click(invalidFlightErrorOKButton);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isPopupClosed()
   {
      return WebElementTools.isVisible(invalidFlightErrorOKButton);
   }

   public boolean isReturnFlightRetained()
   {
      if (!returnFlightSummaryDetails.isEmpty())
      {
         return WebElementTools.isDisplayed(returnFlightSummaryDetails.get(0));
      }
      return false;
   }

   public boolean isOutboundFlightRetained()
   {
      if (!outboundFlightSummaryDetails.isEmpty())
      {
         return WebElementTools.isDisplayed(outboundFlightSummaryDetails.get(0));
      }
      return false;

   }

   public Boolean getLimitedAvailableSeatsThreshold()
   {
      searchResultsjourneySummary();
      Boolean limitedAvailableSeatsThreshold =
               (Boolean) searchResultsJson.get("limitedAvailableSeatsThreshold");
      Long availableSeats = (Long) searchResultsJson.get("availableSeats");
      return limitedAvailableSeatsThreshold && availableSeats > 0;
   }

   public boolean isVisibleSeatsAvailable(Boolean availableSeatsThreshold)
   {
      if (availableSeatsThreshold)
      {
         return WebElementTools.isDisplayed(returnXSeatsLeft.get(0));
      }
      else
      {
         return true;
      }
   }

   public WebElement getOutboundNextArrow()
   {
      return outboundNextArrow;
   }

   public WebElement getInboundNextArrow()
   {
      return returnNextArrow;
   }

   public WebElement getInfoMessageModalElement()
   {
      return infoMessageModalOpen;
   }

   public WebElement getInfoMessageModalCloseElement()
   {
      return infoMessageModalClose;
   }

   public void hoverOnPriceWithBookingFeeNode()
   {
      wait.waitForElementToBePresent(outboundPrice);
      WebElementTools.mouseHover(outboundPrice);
   }

   public boolean bookingFeeMessageIsShown()
   {
      WebElement standardTooltip = outboundPrice.findElement(By.xpath("./../.."));
      return ((WebElementTools.getElementAttribute(standardTooltip, "class")
               .contains("Standard__tooltip")) && !bookingFeeTooltip.isEmpty());
   }

   public boolean bookingFeeMessageIsShownInSummary()
   {
      WebElement bookingFee =
               descriptionItems.get(descriptionItems.indexOf(totalPriceLabelSummaryPanel) - 1);
      return WebElementTools.getElementText(bookingFee).contains("Fee");
   }

   public void searchSummaryComponents() throws InterruptedException
   {
      searchSummaryPanelValues.put("PP_Price", ppPrice.get(0).getText());
      searchSummaryPanelValues.put("Total_Price", totalPrice.get(1).getText());
      searchSummaryPanelValues.put("PAX", paxTextSummaryPanel.getText());
      searchSummaryPanelValues.put("Outbound_Date", outboundFlightSummaryDetails.get(0).getText());
      searchStoreValues.setSearchValues(searchSummaryPanelValues);
   }
}
