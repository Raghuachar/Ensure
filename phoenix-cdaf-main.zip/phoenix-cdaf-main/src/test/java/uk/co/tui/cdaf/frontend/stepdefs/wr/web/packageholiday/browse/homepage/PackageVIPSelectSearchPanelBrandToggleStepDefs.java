package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.browse.homepage;

import com.codeborne.selenide.Selenide;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HeaderComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class PackageVIPSelectSearchPanelBrandToggleStepDefs
{

   public final PackageNavigation packageNavigation;

   public final SearchResultsPage searchResultsPage;

   public final WebElementWait wait;

   public final FlightOnlyHomePage foHomePage;

   private final Map<String, WebElement> searchMap;

   private final SearchPanelComponent searchPanelComponent;

   private final HeaderComponent headercomp;

   public PackageVIPSelectSearchPanelBrandToggleStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchPanelComponent = new SearchPanelComponent();
      searchResultsPage = new SearchResultsPage();
      searchMap = new HashMap<>();
      headercomp = new HeaderComponent();
      WebDriverUtils webDriverUtils = new WebDriverUtils();
      wait = new WebElementWait();
      foHomePage = new FlightOnlyHomePage();
   }

   @Given("the {string} is on the Package Holidays homepage")
   public void the_is_on_the_Package_Holidays_homepage(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
   }

   @When("they are viewing the Search Panel")
   public void they_are_viewing_the_Search_Panel()
   {
      assertThat(searchPanelComponent.isSearchPanelContainerPresent(), is(true));
   }

   @Then("they can see toggle functionality to search for TUI products OR VIP products above the search input fields")
   public void they_can_see_toggle_functionality_to_search_for_TUI_products_OR_VIP_products_above_the_search_input_fields(
            List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchPanelComponent.getBrandToggleComponents());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("the TUI Holidays radio button is checked by default")
   public void the_TUI_Holidays_radio_button_is_checked_by_default()
   {
      assertThat("The TUI Holidays radio button is NOT checked by default",
               headercomp.isRadiobuttonCheckedByDefault(), is(true));
   }

   @And("they selected VIP Selection")
   public void they_selected_VIP_Selection()
   {
      headercomp.isVipButtonSelected();
   }

   @And("they move away from the homepage \\(Search or otherwise; anywhere on the website)")
   public void they_move_away_from_the_homepage_Search_or_otherwise_anywhere_on_the_website()
   {
      packageNavigation.navigateFromHomePageToSearchResultPage();
   }

   @When("they navigate back to the homepage through a means OTHER than browser back")
   public void they_navigate_back_to_the_homepage_through_a_means_OTHER_than_browser_back()
   {
      wait.forJSExecutionReadyLazy();
      headercomp.clickOnHolidayTabTop();
   }

   @Then("the selection is reset to {string}")
   public void the_selection_is_reset_to(String string)
   {
      wait.forJSExecutionReadyLazy();
      assertThat("The TUI Holidays radio button is NOT checked by default",
               headercomp.isResetToTuiHoliday(), is(true));
   }

   @And("they've successfully made a {string} search")
   public void they_ve_successfully_made_a_search(String user)
   {
      wait.forJSExecutionReadyLazy();
      if (user.equalsIgnoreCase("TUI Holidays"))
      {
         assertThat("The TUI Holidays radio button is NOT checked by default",
                  headercomp.isRadiobuttonCheckedByDefault(), is(true));
      }
      else
      {
         headercomp.isVipButtonSelected();
      }
      packageNavigation.navigateFromHomePageToSearchResultPage();
      wait.forJSExecutionReadyLazy();
   }

   @When("they Select the browser back button")
   public void they_Select_the_browser_back_button()
   {
      Selenide.back();
   }

   @Then("the previously entered search data is retained in the search fields {string}")
   public void the_previously_entered_search_data_is_retained_in_the_search_fields(String user)
   {
      wait.forJSExecutionReadyLazy();
      if (user.equalsIgnoreCase("TUI Holidays"))
      {
         wait.forJSExecutionReadyLazy();
         assertThat("The TUI Holidays radio button is NOT checked by default",
                  headercomp.isRadiobuttonCheckedByDefault(), is(true));
      }
      else
      {
         wait.forJSExecutionReadyLazy();
         assertThat("VIP Selection radio button is NOT checked by default",
                  headercomp.isResetToVipSelection(), is(true));
      }
   }
}
