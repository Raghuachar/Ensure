package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.passenger;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails.PassengerDetailsPage;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PassengerDetailsPageStepDefs
{
   private final PassengerDetailsPage passengerPage;

   private final PassengerDetailsPage passengerDetailsPage;

   private final FlightOnlyPageNavigation flightOnlyNavigation;

   public PassengerDetailsPageStepDefs()
   {
      passengerPage = new PassengerDetailsPage();
      passengerDetailsPage = new PassengerDetailsPage();
      flightOnlyNavigation = new FlightOnlyPageNavigation();
   }

   @And("the passenger page should be displayed with following items")
   public void the_passenger_page_should_be_displayed_with_following_items(List<String> items)
   {
      passengerPage.wait.forJSExecutionReadyLazy();
      items.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element =
                     passengerPage.getPassengerComponents().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("they click on continue button in passenger details page")
   public void they_click_on_continue_button_in_passenger_details_page()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.fillThePassengerDetailsForWr();
      flightOnlyNavigation.searchPanelComponent.closePrivacyPopUp();
   }

   @And("they enter less than 2 letters in the First Name")
   public void they_enter_less_than_2_letters_in_the_First_Name()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.setvalidationPaxDetailsForWr(1);
   }

   @And("an error message should display for FirstName as follows")
   public void an_error_message_should_display_for_FirstName_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getFirstNameErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "First Name field error message is not matched", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("they enter more than 40 letters in the First Name")
   public void they_enter_more_than_40_letters_in_the_First_Name()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.setvalidationPaxDetailsForWr(41);
   }

   @And("they enter less than 2 letters in the Last Name")
   public void they_enter_less_than_2_letters_in_the_Last_Name()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.setvalidationPaxDetailsForWr(1);
   }

   @And("an error message should display for LastName as follows")
   public void an_error_message_should_display_for_LastName_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getLastNameErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Last Name field error message is not matched", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("they enter more than 32 letters in the Last Name")
   public void they_enter_more_than_32_letters_in_the_Last_Name()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.setvalidationPaxDetailsForWr(33);
   }

   @And("the customer selects outside the field")
   public void When_the_customer_selects_outside_the_field()
   {
      passengerDetailsPage.passengerFormComponent.clikOnOutSideOfTheField();
   }

   @And("an error message should display for bus as follows")
   public void an_error_message_should_display_for_bus_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getBusAddressErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Bus Address error message is not matched", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("they enter less than 2 letters in the Address field")
   public void they_enter_less_than_2_letters_in_the_Address_field()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.setValidationAddressForWr(1);
   }

   @And("they enter less than 60 letters in the Address field")
   public void they_enter_less_than_60_letters_in_the_Address_field()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.setValidationAddressForWr(61);
   }

   @Then("an error message should display for street and city as follows")
   public void an_error_message_should_display_for_street_and_city_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getStreetErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Street field error message is not same", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("they enter Invalid emailid in Email Field on the passenger details page")
   public void they_enter_Invalid_emailid_in_Email_Field_on_the_passenger_details_page()
   {
      passengerDetailsPage.passengerFormComponent.enterInvalidEmailAddress("emailaddress");
   }

   @And("an error message should display for EmailAddress as follows")
   public void an_error_message_should_display_for_EmailAddress_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getEmailAddressErrorMessage("");
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Email Address field error message is not matched", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("they enter Invalid mobile number in Mobile Field on the passenger details page")
   public void they_enter_Invalid_mobile_number_in_Mobile_Field_on_the_passenger_details_page()
   {
      passengerDetailsPage.passengerFormComponent.enterInvalidMobilePhone();
   }

   @And("an error message should display for Mobile as follows")
   public void an_error_message_should_display_for_Mobile_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getMobileErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Mobile field error message is not same", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("they enter Invalid postcode field on the passenger details page")
   public void they_enter_Invalid_postcode_field_on_the_passenger_details_page()
   {
      passengerDetailsPage.passengerFormComponent.enterInvalidPostCode();
   }

   @And("an error message should display for postcode as follows")
   public void an_error_message_should_display_for_postcode_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getPostCodeErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Postcode field error message is not same", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("an error message should display for Address as follows")
   public void an_error_message_should_display_for_Address_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getStreetErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Address field error message is not same", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("an error message should display for Housenumber as follows")
   public void an_error_message_should_display_for_Housenumber_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         actual = passengerDetailsPage.passengerFormComponent.getHouseNumErrorMessage();
         expected = map.get(getTestExecutionParams().getBrandStr());
         assertThat(
                  ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                           "Address field error message is not same", actual, expected),
                  StringUtils.equalsIgnoreCase(expected, actual), is(true));
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @And("Compare search results values with passenger details page value")
   public void compare_search_results_values_with_passenger_details_page_value()
   {
      Map<String, String> searchValue = searchStoreValues.getSearchValues();
      String passengerValue;
      passengerValue = passengerDetailsPage.passengerDetailsValues("first");
      assertThat("Total price error message is not matched",
               searchValue.get("Total_Price").trim().equalsIgnoreCase(passengerValue), is(true));
   }

   @And("they enter more than {int} letters in the Address field")
   public void they_enter_more_than_60_letters_in_the_Address_field(Integer int1)
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.setValidationAddressForWr(61);
   }

   @And("they enter Invalid House Number on the Housenumber")
   public void they_enter_Invalid_postcode_field_on_the_Housenumber()
   {

      passengerDetailsPage.passengerFormComponent.enterInvalidHousenumber();
   }

   @And("they enter more than {int} letters in the Bus")
   public void they_enter_more_than_60_letters_in_the_Bus(Integer int1)
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.setValidationBusForWr(61);
   }

}
