package uk.co.tui.cdaf.frontend.stepdefs.uk.web.beach_holiday.search.search_results;

import io.cucumber.java.en.Then;

public class OpenBoardBasisOptionFcStepDefs
{

   @Then("the dropdown opens")
   public void the_dropdown_opens()
   {
      // TODO: remove step in Scenario or implement it here
      // This step to open Board Basis dropdown list has been taken care in the
      // previous step
   }

}
