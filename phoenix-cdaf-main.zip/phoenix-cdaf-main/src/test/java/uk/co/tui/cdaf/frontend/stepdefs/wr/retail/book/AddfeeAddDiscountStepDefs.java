package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;

public class AddfeeAddDiscountStepDefs
{
   public final RetailPackageNavigation retailpackagenavigation;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   public final SearchResultsPage searchResultsPage;

   public final RetailPage retailPage = new RetailPage();

   public AddfeeAddDiscountStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      retailpackagenavigation = new RetailPackageNavigation();
   }

   @Given("the customer is on the retail bookflow page")
   public void the_customer_is_on_the_BE_bookflow_page()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();
      retailpackagenavigation.addPassengerDetailsandwaitforAddFeetype();
   }

   @When("they click on fee type drop down")
   public void they_click_on_fee_type_drop_down()
   {
      retailpassengerdetailspage.addFeeType();
   }

   @Then("they see Fee as fee type for selection")
   public void they_see_Sales_Fee_as_fee_type_for_selection()
   {
      retailpackagenavigation.selectfeeType();
      retailpassengerdetailspage.selectContinueBookingWR();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }

   @Given("the customer is on the NL bookflow page")
   @And("they enter a discount value less than the total customer cost")
   public void the_customer_is_on_the_NL_bookflow_page()
   {
      retailPage.inhouseAgentLogin();
      retailpackagenavigation.addPassengerDetailsandwaitforAddFeetype();
   }

   @Then("they see Calamiteitenfonds as fee type for selection")
   public void they_see_Calamiteitenfonds_as_fee_type_for_selection()
   {
      retailpackagenavigation.calamiteitenfonds();
      retailpassengerdetailspage.userLogout();
   }

   /* discount */
   @When("they enter a discount value more than the total customer cost")
   public void they_enter_a_discount_value_more_than_the_total_customer_cost()
   {
      retailpassengerdetailspage.addFeeType();
      retailpackagenavigation.discountMoreThentotal();
   }

   @Then("they should be able to view an {string}")
   public void they_should_be_able_to_view_an(String string)
   {
      retailpassengerdetailspage.getdiscountErrMsg().equalsIgnoreCase(string);
      retailpassengerdetailspage.userLogout();
   }

   @Given("the agent is on the discount component")
   public void the_agent_is_on_the_discount_component()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();
      retailpackagenavigation.addPassengerDetailsandwaitforAddFeetype();
   }

   @When("they enter a discount value")
   public void they_enter_a_discount_value()
   {
      retailpassengerdetailspage.addFeeType();
      retailpackagenavigation.discountMoreThentotal();
   }

   @Then("they should not be able to input more than the total customer cost")
   public void they_should_not_be_able_to_input_more_than_the_total_customer_cost()
   {

      retailpassengerdetailspage.getdiscountErrMsg()
               .equalsIgnoreCase(
                        "The discount amount cannot exceed the holiday worth. Please check");
      retailpassengerdetailspage.userLogout();
   }

   @When("they click on apply CTA button")
   public void they_click_on_apply_CTA_button()
   {
      retailpassengerdetailspage.addFeeType();
      retailpackagenavigation.discountLessthantotal();
   }

   @Then("they should be able to submit and apply that discount the booking")
   public void they_should_be_able_to_submit_and_apply_that_discount_the_booking()
   {
      retailpassengerdetailspage.selectContinueBookingWR();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }

}
