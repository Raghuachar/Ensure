package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class PackageSEODBComponents extends AbstractPage
{
   public final WebElementWait wait;

   @FindAll({ @FindBy(css = ".AuthoriseReconciliation__modalContent"),
            @FindBy(css = "[aria-label='title']") })
   private WebElement authoriseModalHeading;

   @FindBy(css = "[aria-label='dateTime']")
   private WebElement dateTimeTh;

   @FindBy(css = "[aria-label='discrepancyAmountMethod']")
   private WebElement discrepancyAmountMethodTh;

   @FindBy(css = "[aria-label='reason']")
   private WebElement reasonTh;

   @FindBy(css = "[aria-label='recon date']")
   private WebElement reconDateTimestamp;

   @FindBy(css = "[aria-label='recon method type']")
   private WebElement reconAmountMethod;

   @FindBy(css = "[aria-label='recon reason']")
   private WebElement reconReason;

   @FindBy(css = ".AuthoriseReconciliation__autShowMore")
   private WebElement reconReasonShowMore;

   @FindBy(css = ".Modal__primary")
   private WebElement authoriseModalCloseButton;

   @FindBy(css = ".Modal__secondry")
   private WebElement authoriseModalSubmitButton;

   @FindBy(css = ".inputs__errorMessage")
   private WebElement selectReasonErrorMessage;

   @FindBy(css = ".UI__diarySubmitErrorWrapper")
   private WebElement seodbGenericError;

   @FindBy(css = "[aria-label='agent name icon']")
   private WebElement agentNameIcon;

   @FindBy(css = "[aria-label='agent name']")
   private WebElement agentName;

   @FindBy(css = "[aria-label='store icon']")
   private WebElement storeIcon;

   @FindBy(css = "[aria-label='store number']")
   private WebElement storeNumber;

   @FindBy(css = "[aria-label='date icon']")
   private WebElement dateIcon;

   @FindBy(css = "[aria-label='current date']")
   private WebElement currentDate;

   public PackageSEODBComponents()
   {
      wait = new WebElementWait();
   }

   public boolean isModalHeading()
   {
      return WebElementTools.isPresent(authoriseModalHeading);
   }

   public boolean isDateTime()
   {
      return WebElementTools.isPresent(dateTimeTh);
   }

   public boolean isDiscrepancyAmountMethod()
   {
      return WebElementTools.isPresent(discrepancyAmountMethodTh);
   }

   public boolean isReason()
   {
      return WebElementTools.isPresent(reasonTh);
   }

   public boolean isReconDateTimestamp()
   {
      return WebElementTools.isPresent(reconDateTimestamp);
   }

   public boolean isReconAmountMethod()
   {
      return WebElementTools.isPresent(reconAmountMethod);
   }

   public boolean isReconReason()
   {
      return WebElementTools.isPresent(reconReason);
   }

   public boolean isReconReasonShowMore()
   {
      return WebElementTools.isPresent(reconReasonShowMore);
   }

   public boolean isAuthoriseModalCloseButton()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(authoriseModalCloseButton);
   }

   public boolean isAuthoriseModalSubmitButton()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(authoriseModalSubmitButton);
   }

   public boolean isSelectReasonErrorMessagePresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(selectReasonErrorMessage);
   }

   public boolean isSeodbGenericErrorPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(seodbGenericError);
   }

   public boolean isAgentNameIcon()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(agentNameIcon);
   }

   public boolean isAgentName()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(agentName);
   }

   public boolean isStoreIcon()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(storeIcon);
   }

   public boolean isStoreNumber()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(storeNumber);
   }

   public boolean isDateIcon()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(dateIcon);
   }

   public boolean isCurrentDate()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(currentDate);
   }
}
