package uk.co.tui.cdaf.frontend.pom.uk.web.hotel_only.search.search_panel;

import com.codeborne.selenide.Condition;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;

public class HotelOnlySearchPanel extends AbstractPage
{

   public void clickOnRecentSearchLink()
   {
      $(".List__recentSearches header").should(Condition.appear).shouldBe(Condition.enabled)
               .click();
      $("[aria-label='recent search item link']").should(Condition.appear, Duration.ofSeconds(30))
               .click();
   }

}
