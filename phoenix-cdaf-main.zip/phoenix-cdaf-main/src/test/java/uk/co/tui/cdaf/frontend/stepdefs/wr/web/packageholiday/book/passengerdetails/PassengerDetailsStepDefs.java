package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.passengerdetails;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.HolidaySummaryComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.ImportantInformationComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.PassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.PriceBreakDownComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.book.extraoptions.MultiSelectInsuranceComponent;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PassengerDetailsStepDefs
{
   private static final double DELTA = 0.01;

   private final PackageNavigation packageNavigation;

   private final UnitDetailsPage unitDetailsPage;

   private final HolidaySummaryComponent paxHolSumComp;

   private final ImportantInformationComponent impInfoComp;

   public PassengerDetailsPage passengerPage;

   public PassengerDetailsStepDefs()
   {
      passengerPage = new PassengerDetailsPage();
      packageNavigation = new PackageNavigation();
      unitDetailsPage = new UnitDetailsPage();
      paxHolSumComp = new HolidaySummaryComponent();
      impInfoComp = new ImportantInformationComponent();
   }

   @Given("the customer is on the package passenger details page")
   public void the_customer_is_on_the_package_passenger_details_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @And("following component options should display on passenger page")
   public void following_component_options_should_display_on_passenger_page(List<String> components)
   {
      passengerPage.wait.forJSExecutionReadyLazy();
      final Map<String, WebElement> passengerMap = passengerPage.getPassengerPageComponents();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = passengerMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("the passenger details page will be displayed")
   public void the_passenger_details_page_will_be_displayed()
   {
      passengerPage.navigationComponent.isPageDisplayed();
   }

   @And("they click on the Customise Holiday breadcrumb")
   public void they_click_on_the_Customise_Holiday_breadcrumb()
   {
      passengerPage.navigationComponent.clickOnCustomiseHolidayBreadCrumb();
   }

   @And("user can compare search results values with passenger details page")
   public void user_can_compare_search_results_values_with_passenger_details_page()
   {
      String passengerpPageValues;
      passengerpPageValues = unitDetailsPage.progressbarComponent.getTotalPriceValue();
      assertThat("Total Price is not matched with Summary details page",
               searchStoreValues.getTotalPrice().trim().equalsIgnoreCase(passengerpPageValues),
               is(true));
      passengerpPageValues = unitDetailsPage.progressbarComponent.getPerPersonPriceElement();
      assertThat("Per Person Price is not matched with Summary details page",
               searchStoreValues.getPerPersonPrice().trim().equalsIgnoreCase(passengerpPageValues),
               is(true));
   }

   @And("the passenger page should be displayed")
   public void the_passenger_page_should_be_displayed()
   {
      boolean isDisplayed = passengerPage.navigationComponent.isPageDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Passenger details page wasn't loaded", isDisplayed, true), isDisplayed, is(true));
   }

   @When("Navigate back to passenger details page")
   public void navigate_back_to_passenger_details_page()
   {
      passengerPage.navigationComponent.ClickOnBackToPaxpage();
   }

   @Then("passenger details should be displayed")
   public void passenger_details_should_be_displayed()
   {

      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      nordicPassengerPage.verifyPassengerDetails();
   }

   @And("within the Booking Charges section user will be able to see the line item in passenger details page")
   public void within_the_Booking_Charges_section_user_will_be_able_to_see_the_line_item_in_passenger_details_page()
   {
      assertTrue("Reservation fee is not displayed", passengerPage.isReservationFeeDisplayed());
   }

   @When("user navigates to Passenger Details page")
   public void user_navigates_to_pax_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @And("insurance price is displayed in Holiday summary of the PAX page")
   public void insurance_price_is_displayed_in_holiday_summary_of_pax_page()
   {
      Double priceBreakDownInsurancePrice =
               paxHolSumComp.getInsurancePriceDouble();
      assertTrue("Insurance price in Holiday summary of PAX page should be displayed",
               priceBreakDownInsurancePrice > 0);
      assertEquals("Insurance total prices in Extras page and in Holiday summary of PAX page are different",
               MultiSelectInsuranceComponent.selectedInsurancesPrice.get(), priceBreakDownInsurancePrice, DELTA);
   }

   @Then("Important Information component is displayed with title {string}")
   public void important_information_component_is_displayed(String title)
   {
      assertEquals("Important Information component title is not as expected", title,
               impInfoComp.getImpInfoCompTitle());
   }

   @And("Discounts Terms & Conditions section is displayed with title")
   public void discounts_terms_conditions_section_is_displayed_with_title(DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String actual = impInfoComp.getDiscountSectionTitle();
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertThat("Discount Terms & Conditions section title is not as expected", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @And("Discounts Terms & Conditions section contains discount expiry date messages")
   public void discounts_terms_conditions_section_contains_discount_expiry_date_messages()
   {
      SoftAssertions softAssert = new SoftAssertions();

      List<String> discountsMessages = impInfoComp.getDiscountsMessages();
      List<String> discountsTypesApplied = PriceBreakDownComponent.discountsTypesApplied.get();

      discountsMessages.forEach(message -> {
         discountsTypesApplied.forEach(discount -> {
            if ("Vroegboekkorting".equalsIgnoreCase(discount) || "Gratis nachten".equalsIgnoreCase(discount)) {
               softAssert.assertThat(
                        message.contains("De vroegboekkorting is geldig voor reserveringen gemaakt tot") ||
                                 message.contains("Gratis nacht voor reserveringen gemaakt tot"))
                        .as("Discount message doesn't contain message expected").isTrue();
            }
         });
      });

      if (discountsTypesApplied.size() == 1 && discountsMessages.size() > 1) {
         softAssert.fail("Extra discount message is shown in Discounts Terms & Conditions section of PAX page");
      }

      softAssert.assertAll();
   }
}
