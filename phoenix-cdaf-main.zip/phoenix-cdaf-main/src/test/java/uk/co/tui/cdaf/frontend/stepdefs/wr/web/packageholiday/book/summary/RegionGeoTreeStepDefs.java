package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.RegionGeoTreePage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class RegionGeoTreeStepDefs
{
   public final PackageNavigation packageNavigation;

   public RegionGeoTreePage regionGeoTreePage;

   public RegionGeoTreeStepDefs()
   {
      packageNavigation = new PackageNavigation();
      regionGeoTreePage = new RegionGeoTreePage();
   }

   @Given("that the customer in on the the Customise page")
   public void that_the_customer_in_on_the_the_Customise_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they view the Holiday Summary component")
   public void they_view_the_Holiday_Summary_component()
   {
      assertThat("Summary Component is Not Displayed",
               regionGeoTreePage.isSummaryComponentPresent(), is(true));
   }

   @Then("the geo tree should display as Resort,  Destination, Region, Country in customise page")
   public void the_geo_tree_should_display_as_Resort_Destination_Region_Country_in_customise_page()
   {
      assertThat("Geo Tree is Not Displayed in Customise Page",
               regionGeoTreePage.isSummaryGeoTreePresent(), is(true));
   }

   @Given("that the customer has navigated to the pax details page")
   public void that_the_customer_has_navigated_to_the_pax_details_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @When("they view their Holiday summary")
   public void they_view_their_Holiday_summary()
   {
      regionGeoTreePage.clickOnHolidaySummaryComponent();
   }

   @Then("the geo tree should display as Resort,  Destination, Region, Country in pax details page")
   public void the_geo_tree_should_display_as_Resort_Destination_Region_Country_in_pax_details_page()
   {
      assertThat("Geo Tree is Not Displayed in Pax details Page",
               regionGeoTreePage.isPaxGeoTreePresent(), is(true));
   }

   @Given("the customer has navigated to the Payment page")
   public void the_customer_has_navigated_to_the_Payment_page()
   {
      packageNavigation.navigateToPaymentPage();
   }

   @When("they view the Holiday summary")
   public void they_view_the_Holiday_summary()
   {
      regionGeoTreePage.clickOnHolidaySummaryComponent();
   }

   @Then("the geo tree should display as Resort,  Destination, Region, Country in payment page")
   public void the_geo_tree_should_display_as_Resort_Destination_Region_Country_in_payment_page()
   {
      assertThat("Geo Tree is Not Displayed in Pax details Page",
               regionGeoTreePage.isPaymentGeoTreePresent(), is(true));
   }

   @Given("that the customer has completed their booking")
   public void that_the_customer_has_completed_their_booking()
   {
      packageNavigation.navigateToConfirmationPage();
   }

   @When("the Booking confirmation page is displayed")
   public void the_Booking_confirmation_page_is_displayed()
   {
      assertThat("Confirmation Component is Not Displayed",
               regionGeoTreePage.isConfirmationComponentPresent(), is(true));
   }

   @Then("the geo tree should display as Resort,  Destination, Region, Country in the booking confirmation")
   public void the_geo_tree_should_display_as_Resort_Destination_Region_Country_in_the_booking_confirmation()
   {
      assertThat("Geo Tree is Not Displayed in Confirmation Page",
               regionGeoTreePage.isConfirmationGeoTreePresent(), is(true));
   }
}
