package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.browse.homepage.searchPanel;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;

public class SearchPanelDepartureAirportSelectionStepDefs
{
   private final FlightOnlyHomePage homepage;

   public SearchPanelDepartureAirportSelectionStepDefs()
   {
      homepage = new FlightOnlyHomePage();
   }

   @Given("a customer is on the homepage")
   public void a_customer_is_on_the_homepage()
   {
      homepage.visit();
   }

   @And("they clicked in the {string} field in the TUIfly search panel")
   public void they_clicked_in_the_field_in_the_TUIfly_search_panel(String string)
   {
      homepage.clickDepartureAirportField();
   }

   @When("they view the airport options")
   public void they_view_the_airport()
   {
      homepage.validateDepartureAirportsDropdown();
   }

   @Then("they will see the nearby airports in alphabetical order")
   public void they_will_see_the_nearby_airports_in_alphabetical_order()
   {
      // Write code here that turns the phrase above into concrete actions
      homepage.validateOrderListDepartureNearbyAirports();
   }

   @Then("they will see the {string} and {string} CTA's on the page.")
   public void they_will_see_the_and_CTA_s_on_the_page(String string, String string2)
   {
      homepage.validateClearAllDoneForAirportsDropdown(string, string2);
   }
}
