package uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.agent_types;

public enum BussinessType
{
   THIRD,
   INHOUSE,
   B2C;

   public static BussinessType fromString(String typeString)
   {
      for (BussinessType type : BussinessType.values())
      {
         if (type.name().equalsIgnoreCase(typeString))
         {
            return type;
         }
      }
      throw new IllegalArgumentException(
               "Invalid entry: " + typeString + "\nAcceptable Bussiness types:\nthird\nb2c\ninhouse");
   }
}
