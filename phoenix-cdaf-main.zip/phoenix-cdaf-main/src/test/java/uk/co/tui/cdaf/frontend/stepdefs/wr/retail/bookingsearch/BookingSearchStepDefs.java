package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.bookingsearch;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.bookingsearch.BookingSearchPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;

public class BookingSearchStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(BookingSearchStepDefs.class);

   public final RetailPackageNavigation retailPackageNavigation;

   public final BookingSearchPage bookingSearchPage;

   private SelenideElement selectedCalendarModalDate = null;

   private LocalDate currentMonthYearViewDate = null;

   public BookingSearchStepDefs()
   {
      retailPackageNavigation = new RetailPackageNavigation();
      bookingSearchPage = new BookingSearchPage();
   }

   @After("@OPSW-60992")
   public void after()
   {
      selectedCalendarModalDate = null;
      currentMonthYearViewDate = null;
   }

   @Given("the Agent is on the 'Booking Search' page")
   public void the_agent_is_on_the_booking_search_page()
   {
      if (isExecutedLocally())
      {
         bookingSearchPage.visit();
      }
      else
      {
         retailPackageNavigation.retailLoginChangeagent();
         bookingSearchPage.navigateToBookingSearchPage();
      }

      assertTrue("booking search component is not displayed",
               bookingSearchPage.getBookingSearch().isDisplayed());
   }

   @And("they navigate to the 'Booking Search' page")
   public void they_navigate_to_the_booking_search_page()
   {
      bookingSearchPage.closePopupAndNavigateToBookingSearchPage();
   }

   @Given("they view the tab 'Use Booking Reference'")
   public void they_view_the_tab_use_booking_reference()
   {
      bookingSearchPage.getRetrieveByBookingReferenceTab().click();
   }

   @Given("they view the tab 'Retrieve without Booking Reference'")
   public void they_view_the_tab_retrieve_without_booking_reference()
   {
      bookingSearchPage.getRetrieveWithoutBookingReferenceTab().click();
   }

   @Then("they will see the field header 'Accommodation Name'")
   public void they_will_see_the_field_header_accommodation_name()
   {
      assertTrue("accommodation field does not have a label",
               bookingSearchPage.getAccommodationFieldLabel().isDisplayed());

      assertFalse("accommodation field label does not have a correct value",
               bookingSearchPage.getAccommodationFieldLabel().text().isEmpty());
   }

   @Then("they will see the placeholder 'Hotel Name' in the input field")
   public void they_will_see_the_placeholder_hotel_name_in_the_input_field()
   {
      String placeholder =
               bookingSearchPage.getAccommodationFieldInput().getAttribute("placeholder");

      assertFalse("accommodation field input's placeholder has a wrong value",
               placeholder != null && placeholder.isEmpty());
   }

   @Then("they will see the input field for accommodations")
   public void they_will_see_the_input_field_for_accommodations()
   {
      assertTrue("accommodation field input is not displayed",
               bookingSearchPage.getAccommodationFieldInput().isDisplayed());
   }

   @Then("they shall be able to manually enter characters in Accommodation field")
   public void they_shall_be_able_to_manually_enter_characters_in_accommodation_field()
   {
      bookingSearchPage.getAccommodationFieldInput().type("test");

      assertEquals("accommodation field input has a wrong value", "test",
               bookingSearchPage.getAccommodationFieldInput().getAttribute("value"));
   }

   @When("they enters {string} in the Accommodation field")
   public void they_enters_in_the_accommodation_field(String string)
   {
      bookingSearchPage.getAccommodationFieldInput().type(string);
   }

   @Then("a drop down list with accommodation names should not be displayed")
   public void a_drop_down_list_with_accommodation_names_should_not_be_displayed()
   {
      assertFalse("displays the accommodation suggestions, but should not", bookingSearchPage
               .getAccommodationFieldSuggestions().shouldNot(Condition.appear).isDisplayed());
   }

   @Then("a drop down list showing all available accommodation names shall be displayed")
   public void a_drop_down_list_showing_all_available_accommodation_names_shall_be_displayed()
   {
      assertTrue("does not display the accommodation suggestions", bookingSearchPage
               .getAccommodationFieldSuggestions().should(Condition.appear).isDisplayed());
   }

   @Then("they select the {string} option from available list")
   public void they_select_the_option_from_available_list(String selectedOptionString)
   {
      List<SelenideElement> options = bookingSearchPage.getAccommodationFieldSuggestions().$$("li");

      SelenideElement selectedOption = options.stream()
               .filter(option -> option.text().contains(selectedOptionString)).findFirst()
               .orElse(null);

      MatcherAssert
               .assertThat(String.format(
                        "selected option '%s' was not found in the suggestion dropdown",
                        selectedOptionString), selectedOption, is(notNullValue()));

      selectedOption.click();
   }

   @Then("selected option {string} will be displayed in Accommodation field like hotel, resorts and villas")
   public void selected_option_will_be_displayed_in_accommodation_field_like_hotel_resorts_and_villas(
            String selectedOption)
   {
      assertEquals("accommodation field input's value is not empty", "",
               bookingSearchPage.getAccommodationFieldInput().getAttribute("value"));

      assertEquals(
               "accommodation field input's placeholder value is not the selected accommodation",
               selectedOption,
               bookingSearchPage.getAccommodationFieldInput().getAttribute("placeholder"));
   }

   @When("they have not already selected any accommodation")
   public void they_have_not_already_selected_any_accommodation()
   {
      assertEquals("accommodation field input's value is not empty", "",
               bookingSearchPage.getAccommodationFieldInput().getAttribute("value"));

      // TODO: there is no possibility to fully test this case, since the selected
      // value is stored as a placeholder.
      // And we don't know in test, the default value of the placeholder itself.
   }

   @When("they click on the Accommodation field")
   public void they_click_on_the_accommodation_field()
   {
      bookingSearchPage.getAccommodationFieldInput().click();
   }

   @Then("they will be able to view the Search Tip Modal")
   public void they_will_be_able_to_view_the_search_tip_modal()
   {
      assertTrue("Search Tip Modal was not displayed",
               bookingSearchPage.getAccommodationFieldSearchTipModal().isDisplayed());
   }

   @Then("the modal will contain the following text: 'You can search for holiday collections or hotel names'")
   public void the_modal_will_contain_the_following_text_you_can_search_for_holiday_collections_or_hotel_names()
   {
      assertFalse("Search Tip Modal does not have the correct text content",
               bookingSearchPage.getAccommodationFieldSearchTipModal().text().isEmpty());
   }

   @Then("the text will be preceded by a search icon")
   public void the_text_will_be_preceded_by_a_search_icon()
   {
      assertTrue("the Search Tip Modal's text is not preceded by a search icon",
               bookingSearchPage.isSearchIconPrecedesTheSearchTipModalText());
   }

   @Then("the Accommodation field shall contain the value {string}")
   public void the_accommodation_field_shall_contain_the_value(String expectedValue)
   {
      assertEquals("accommodation field input's value is not correct", expectedValue,
               bookingSearchPage.getAccommodationFieldInput().getAttribute("value"));
   }

   @Then("the following informational message shall be displayed: 'No matches found'")
   public void the_following_informational_message_shall_be_displayed()
   {
      SelenideElement noMatch =
               bookingSearchPage.getAccommodationFieldNoMatch().should(Condition.appear);

      assertTrue("no match error is not displayed", noMatch.isDisplayed());

      assertFalse("no match error does not have the correct text",
               bookingSearchPage.getAccommodationFieldNoMatch().text().isEmpty());
   }

   @When("they view Destination airport field header")
   public void they_view_destination_airport_field_header()
   {
      assertTrue("Destination airport field header is not displayed",
               bookingSearchPage.getAirportFieldLabel().isDisplayed());
   }

   @Then("they will be able to see header 'Destination airport code'")
   public void they_will_be_able_to_see_header_destination_airport_code()
   {
      assertFalse("airport field label does not have a correct value",
               bookingSearchPage.getAirportFieldLabel().text().isEmpty());
   }

   @When("they view Destination airport field")
   public void they_view_destination_airport_field()
   {
      assertTrue("Destination airport field is not displayed",
               bookingSearchPage.getAirportField().isDisplayed());
   }

   @Then("they will be able to see the Input Field for Destination airport")
   public void they_will_be_able_to_see_the_input_field_for_destination_airport()
   {
      assertTrue("Input Field for Destination airport is not displayed",
               bookingSearchPage.getAirportFieldInput().isDisplayed());
   }

   @Then("they will be able to see 'Airport code' as placeholder")
   public void they_will_be_able_to_see_airport_code_as_placeholder()
   {
      String placeholder = bookingSearchPage.getAirportFieldInput().getAttribute("placeholder");
      assertTrue("airport field input's placeholder has a wrong value",
               placeholder != null && !placeholder.isEmpty());
   }

   @And("they have not already selected any Destination airport code")
   public void they_have_not_already_selected_any_destination_airport_code()
   {
      assertEquals("airport field input's value is not empty", "",
               bookingSearchPage.getAirportFieldInput().getAttribute("value"));
      // TODO: there is no possibility to fully test this case, since the selected
      // value is stored as a placeholder.
      // And we don't know in test, the default value of the placeholder itself.
      // So, the step definition will be changed once the possibility of clearing the
      // field is added
   }

   @When("they click on the Destination airport code field")
   public void they_click_on_the_destination_airport_code_field()
   {
      bookingSearchPage.getAirportFieldInput().click();
   }

   @And("they will be able to view Search Tip Modal")
   public void they_will_be_able_to_view_search_tip_modal()
   {
      assertTrue("Search Tip Modal is not displayed",
               bookingSearchPage.getAirportFieldSearchTipModal().isDisplayed());
   }

   @Then("the following Destination airport code field tooltip shall be displayed {string}")
   public void the_following_destination_airport_code_field_tooltip_shall_be_displayed(
            String tooltipText)
   {
      assertTrue("Destination airport code field tooltip is not displayed",
               bookingSearchPage.getAirportFieldSearchTipModalText().isDisplayed());
      assertFalse("Destination airport code field tooltip does not have the correct text content",
               bookingSearchPage.getAirportFieldSearchTipModal().text().isEmpty());
   }

   @And("this will be preceded by a search icon")
   public void this_will_be_preceded_by_a_search_icon()
   {
      assertTrue("Search tip icon is not displayed",
               bookingSearchPage.getAirportFieldSearchTipModalIcon().isDisplayed());
   }

   @Then("they shall be able to manually enter characters in Destination airport field")
   public void they_shall_be_able_to_manually_enter_characters_in_destination_airport_field()
   {
      bookingSearchPage.getAirportFieldInput().type("test");
      assertEquals("the characters are not entered in Destination airport field", "test",
               bookingSearchPage.getAirportFieldInput().getAttribute("value"));
   }

   @When("agent enters 3 or more characters in the Destination airport field")
   public void agent_enters_or_more_characters_in_the_destination_airport_field()
   {
      bookingSearchPage.getAirportFieldInput().type("ANR");
      assertEquals("the characters are not entered in the Destination airport field", "ANR",
               bookingSearchPage.getAirportFieldInput().getAttribute("value"));
   }

   @Then("a drop down list showing all available airport codes and names shall be displayed")
   public void a_drop_down_list_showing_all_available_airport_codes_and_names_shall_be_displayed()
   {
      assertTrue("Available airport suggestions is not displayed",
               bookingSearchPage.getAirportFieldSuggestions().should(Condition.appear)
                        .isDisplayed());
   }

   @Then("they can select the option")
   public void they_can_select_the_option()
   {
      List<SelenideElement> options = bookingSearchPage.getAirportFieldSuggestions().$$("ul li");
      assertFalse("the option is not selected", options.get(0).text().isEmpty());
   }

   @Then("they select the {string} option from available airport list")
   public void they_select_the_option_from_available_airport_list(String selectedOptionString)
   {
      List<SelenideElement> options = bookingSearchPage.getAirportFieldSuggestions().$$("ul li");

      SelenideElement selectedOption = options.stream()
               .filter(option -> option.text().contains(selectedOptionString)).findFirst()
               .orElse(null);

      MatcherAssert
               .assertThat(String.format(
                        "selected option '%s' was not found in the suggestion dropdown",
                        selectedOptionString), selectedOption, is(notNullValue()));

      selectedOption.click();
   }

   @Then("selected {string} option will be displayed in Destination airport field")
   public void selected_option_will_be_displayed_in_destination_airport_field(String selectedOption)
   {
      assertEquals("Destination airport field input's value is not empty", "",
               bookingSearchPage.getAirportFieldInput().getAttribute("value"));

      assertEquals(
               "Destination airport field input's placeholder value is not the selected accommodation",
               selectedOption,
               bookingSearchPage.getAirportFieldInput().getAttribute("placeholder"));
   }

   @When("they enters {string} in the Airport field")
   public void they_enters_not_existing_airport_code_in_the_airport_field(String string)
   {
      bookingSearchPage.getAirportFieldInput().type(string);
   }

   @Then("the Destination airport field shall contain the value {string}")
   public void the_destination_airport_field_shall_contain_the_value(String expectedValue)
   {
      assertEquals("the Destination airport field input's value is not correct", expectedValue,
               bookingSearchPage.getAirportFieldInput().getAttribute("value"));
   }

   @And("the following informational message for Airport field shall be displayed: 'No matches found'")
   public void the_following_informational_message_for_airport_field_shall_be_displayed()
   {
      SelenideElement noMatch = bookingSearchPage.getAirportFieldNoMatch().should(Condition.appear);

      assertTrue("no match error is not displayed", noMatch.isDisplayed());

      assertFalse("no match error does not have the correct text",
               bookingSearchPage.getAirportFieldNoMatch().text().isEmpty());
   }

   @Then("they can see the retrieve booking Input box")
   public void they_can_see_the_retrieve_booking_input_box()
   {
      assertTrue("Retrieve by Booking Reference input is not displayed",
               bookingSearchPage.getRetrieveBookingByBookingReferenceInput().isDisplayed());
   }

   @Then("they can see the 'Log in to your booking' CTA button")
   public void they_can_see_the_log_it_to_your_booking_cta_button()
   {
      assertTrue("'Log in to your booking' button is not displayed",
               bookingSearchPage.getLoginToYourBookingCTAButton().isDisplayed());
   }

   @When("they click on the 'Log in to your booking' CTA button")
   public void they_click_on_the_log_in_to_your_booking_cta_button()
   {
      bookingSearchPage.getLoginToYourBookingCTAButton().click();
   }

   @Then("the retrieve booking Input box will be highlighted in red")
   public void the_retrieve_booking_input_box_will_be_highlighted_in_red()
   {
      assertTrue("Retrieve by Booking Reference input is not highlighted in red", bookingSearchPage
               .getRetrieveBookingByBookingReferenceInput()
               .has(Condition.cssClass("inputs__error")));
   }

   @Then("the error 'Please enter your booking reference' will be displayed")
   public void the_error_please_enter_your_booking_reference_will_be_displayed()
   {
      assertTrue("'Please enter your booking reference' error is not displayed",
               bookingSearchPage.getRetrieveBookingByBookingReferenceInputErrorMessage()
                        .isDisplayed());

      assertFalse("'Please enter your booking reference' error is empty", bookingSearchPage
               .getRetrieveBookingByBookingReferenceInputErrorMessage().text().isEmpty());
   }

   @Then("'Booking retrieval failed' error will be shown")
   public void booking_retrieval_failed_error_will_be_shown()
   {
      assertTrue("'Booking retrieval failed' error is not displayed",
               bookingSearchPage.getBookingRetrievalFailedErrorMessage().isDisplayed());

      assertFalse("'Booking retrieval failed' error is empty",
               bookingSearchPage.getBookingRetrievalFailedErrorMessage().text().isEmpty());
   }

   @When("they enter {string} into the retrieve booking Input box")
   public void they_enter_into_the_retrieve_booking_input_box(String bookingReference)
   {
      bookingSearchPage.getRetrieveBookingByBookingReferenceInput().type(bookingReference);
   }

   @Then("the booking summary for that booking will open in the same tab")
   public void the_booking_summary_for_that_booking_will_open_in_the_same_tab()
   {
      String currentUrl = WebDriverRunner.getWebDriver().getCurrentUrl();

      assertTrue("Booking summary is not opened in the same tab",
               currentUrl.contains("/retail/travel/nl/your-account/managemybooking/yourbooking"));
   }

   @When("they view the Calendar Field")
   public void they_view_the_calendar_field()
   {
      assertTrue("Calendar Start Date Field is not displayed",
               bookingSearchPage.getStartDateField().isDisplayed());
   }

   @Then("they will see the Calendar Field label as 'Start Date'")
   public void they_will_see_the_calendar_field_label_as_start_date()
   {
      assertFalse("Calendar Start Date Field Label is empty",
               bookingSearchPage.getStartDateFieldLabel().text().isEmpty());
   }

   @Then("they will see the Calendar tooltip icon beside Calendar Field label")
   public void they_will_see_the_calendar_tooltip_icon_beside_calendar_field_label()
   {
      assertTrue("Calendar Start Date Field is not displayed",
               bookingSearchPage.getStartDateFieldLabelTooltip().isDisplayed());
   }

   @Then("they will see the Calendar Field with Calendar Icon")
   public void they_will_see_the_calendar_field_with_calendar_icon()
   {
      assertTrue("Calendar Start Date Field input is not displayed",
               bookingSearchPage.getStartDateFieldInput().isDisplayed());

      assertTrue("Calendar Start Date Field input does not have a Calendar Icon",
               bookingSearchPage.getStartDateFieldInputCalendarIcon().isDisplayed());
   }

   @Then("they will see the Calendar Field placeholder 'DD\\/MM\\/YYYY'")
   public void they_will_see_the_calendar_field_placeholder_dd_mm_yyyy()
   {
      String placeholder = bookingSearchPage.getStartDateFieldInput().getAttribute("placeholder");

      assertTrue("Calendar Start Date Field input does not have a default placeholder",
               placeholder != null && !placeholder.isEmpty());
   }

   @When("when they hover the mouse over the Calendar tooltip icon")
   public void when_they_hover_the_mouse_over_the_calendar_tooltip_icon()
   {
      bookingSearchPage.getStartDateFieldLabelTooltip().hover();
   }

   @Then("they will be able to see the information in the Calendar tooltip")
   public void they_will_be_able_to_see_the_information_in_the_calendar_tooltip()
   {
      assertTrue("Calendar tooltip text is not displayed",
               bookingSearchPage.getStartDateFieldTooltipText().should(Condition.appear)
                        .isDisplayed());

      assertFalse("Calendar tooltip text is empty", bookingSearchPage.getStartDateFieldTooltipText()
               .should(Condition.appear).text().isEmpty());
   }

   @When("they click on the Calendar Field input")
   public void they_click_on_the_calendar_field_input()
   {
      bookingSearchPage.getStartDateFieldInput().click();
   }

   @Then("they can see the Calendar Modal")
   public void they_can_see_the_calendar_modal()
   {
      assertTrue("Calendar Modal is not displayed",
               bookingSearchPage.getCalendarModal().should(Condition.appear).isDisplayed());
   }

   @When("they view the Calendar Modal")
   public void they_view_the_calendar_modal()
   {
      they_can_see_the_calendar_modal();
   }

   @Then("they can see Calendar Modal Header")
   public void they_can_see_Calendar_Modal_Header()
   {
      assertTrue("Calendar Modal Header is not displayed",
               bookingSearchPage.getCalendarModalHeader().isDisplayed());

      assertFalse("Calendar Modal Header title is empty",
               bookingSearchPage.getCalendarModalHeader().$(".drop-modal-title").text().isEmpty());
   }

   @Then("they can see Calendar Modal Close icon \\(X)")
   public void they_can_see_Calendar_Modal_Close_icon_X()
   {
      assertTrue("Calendar Modal Close Icon is not displayed",
               bookingSearchPage.getCalendarModalHeaderCloseButtonIcon().isDisplayed());
   }

   @Then("they see the Calendar Modal Footer")
   public void they_see_the_calendar_modal_footer()
   {
      assertTrue("Calendar Modal Footer is not displayed",
               bookingSearchPage.getCalendarModalFooter().isDisplayed());
   }

   @Then("they can see 'Clear all' button")
   public void they_can_see_button()
   {
      assertTrue("'Clear all' was not displayed in the Calendar Modal Footer",
               bookingSearchPage.getCalendarModalFooterClearAllButton().isDisplayed());
   }

   @Then("they can see 'Done' button beside 'Clear all' button")
   public void they_can_see_button_beside_button()
   {
      assertTrue(
               "'Done' button was not displayed next to 'Clear all' button in the Calendar Modal Footer",
               bookingSearchPage.getCalendarModalFooter().$(".clear-button + .done-button")
                        .isDisplayed());
   }

   @When("they click on the Calendar Modal Close icon")
   public void they_click_on_the_calendar_modal_close_icon()
   {
      bookingSearchPage.getCalendarModalHeaderCloseButton().click();
   }

   @Then("the Calendar Modal will be closed")
   public void the_calendar_modal_will_be_closed()
   {
      assertFalse("Calendar Modal is displayed",
               bookingSearchPage.getCalendarModal().should(Condition.disappear).isDisplayed());
   }

   @Then("they can see month table on the Calendar modal")
   public void they_can_see_month_table_on_the_calendar_modal()
   {
      assertTrue("Calendar Month Table is not displayed",
               bookingSearchPage.getCalendarTable().isDisplayed());
   }

   @Then("they can see the Month\\/Year dropdown on the Calendar modal")
   public void they_can_see_the_month_year_dropdown_on_the_calendar_modal()
   {
      assertTrue("Calendar Month Year select dropdown is not displayed",
               bookingSearchPage.getCalendarMonthYearSelectDropdown().isDisplayed());
   }

   @Then("they can select the month from the dropdown in a range of +\\/- {int} years")
   public void they_can_select_the_month_from_the_dropdown_in_a_range_of_years(int expectedYears)
   {
      List<String> optionValues = new ArrayList<>();
      ElementsCollection options =
               bookingSearchPage.getCalendarMonthYearSelectDropdown().$$("option");

      for (SelenideElement option : options)
      {
         optionValues.add(option.getAttribute("value"));
      }

      int expectedMonthsBeforeTheCurrentDate, expectedMonthsAfterTheCurrentDate;
      expectedMonthsBeforeTheCurrentDate = expectedMonthsAfterTheCurrentDate = expectedYears * 12;

      int totalMonthCountToDisplay =
               expectedMonthsBeforeTheCurrentDate + 1 + expectedMonthsAfterTheCurrentDate;

      assertEquals("Wrong number of months displayed in the month\\/year dropdown",
               totalMonthCountToDisplay, optionValues.size(), 0);

      List<String> expectedOptionValues = new ArrayList<>();
      Calendar calendar = Calendar.getInstance();
      calendar.add(Calendar.MONTH, -(expectedMonthsBeforeTheCurrentDate + 1));

      for (int i = 0; i < totalMonthCountToDisplay; i++)
      {
         calendar.add(Calendar.MONTH, 1);
         expectedOptionValues.add(String.format("%04d-%02d", calendar.get(Calendar.YEAR),
                  calendar.get(Calendar.MONTH) + 1));
      }

      assertEquals("Wrong values displayed in the month\\/year dropdown", expectedOptionValues,
               optionValues);
   }

   @When("they select the different month from the Month\\/Year dropdown, which is {int} months from the current date")
   public void they_select_the_different_month_from_the_month_year_dropdown_which_is_months_from_the_current_date(
            int deltaMonthsFromCurrentDate)
   {
      String selectedDate = this.getFormattedDateForSelect(deltaMonthsFromCurrentDate);
      bookingSearchPage.getCalendarMonthYearSelectDropdown().selectOptionByValue(selectedDate);
   }

   @Then("they can see the selected month's table, which is {int} months from the current date")
   public void they_can_see_the_selected_month_s_table_which_is_months_from_the_current_date(
            int deltaMonthsFromCurrentDate)
   {
      String selectedDate = this.getFormattedDateForSelect(deltaMonthsFromCurrentDate);
      String selectedMonth = selectedDate.split("-")[1];
      String selectedYear = selectedDate.split("-")[0];

      assertTrue("Calendar Month Table is not displayed",
               bookingSearchPage.getCalendarTable().isDisplayed());

      assertTrue("Calendar Days are not displayed",
               bookingSearchPage.getCalendarTableDays().isDisplayed());

      Calendar calendar = Calendar.getInstance();
      calendar.setFirstDayOfWeek(Calendar.MONDAY);
      calendar.set(Integer.parseInt(selectedYear), Integer.parseInt(selectedMonth) - 1, 1);

      int i = 0;

      do
      {
         SelenideElement day = bookingSearchPage.getCalendarTableDays().$$("time").get(i);
         String dayDatetime = day.getAttribute("datetime");

         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
         String formattedDate = dateFormat.format(calendar.getTime());

         assertEquals("Wrong day is displayed in the month table", formattedDate, dayDatetime);

         calendar.add(Calendar.DAY_OF_MONTH, 1);
         i++;
      } while (calendar.get(Calendar.DAY_OF_MONTH) > calendar
               .getActualMinimum(Calendar.DAY_OF_MONTH));
   }

   @Then("they can see the Previous and Next arrows")
   public void they_can_see_the_previous_and_next_arrows()
   {
      assertTrue("Calendar Previous Month Arrow is not displayed",
               bookingSearchPage.getCalendarPreviousMonthArrow().isDisplayed());

      assertTrue("Calendar Next Month Arrow is not displayed",
               bookingSearchPage.getCalendarNextMonthArrow().isDisplayed());
   }

   @When("they click on any day in the Calendar month table")
   public void they_click_on_any_day_in_the_calendar_month_table()
   {
      selectedCalendarModalDate = bookingSearchPage.getRandomCalendarDay();
      selectedCalendarModalDate.click();
   }

   @Then("they see the selected day highlighted")
   public void they_see_the_selected_day_highlighted()
   {
      assertTrue("Selected date is not highlighted",
               selectedCalendarModalDate.has(Condition.cssClass("selected")));
   }

   @When("they click on the 'Done' button in the Calendar Modal Footer")
   public void they_click_on_the_button_in_the_calendar_modal_footer()
   {
      bookingSearchPage.getCalendarModalFooterDoneButton().click();
   }

   @Then("the selected date will be set in the Calendar Field")
   public void the_selected_date_will_be_set_in_the_calendar_field() throws ParseException
   {
      String expectedDate =
               formatISODateToStartDateInputFormat(
                        selectedCalendarModalDate.getAttribute("datetime"));

      assertEquals("Wrong date is selected in the Calendar Field", expectedDate,
               bookingSearchPage.getStartDateFieldInput().getAttribute("value"));
   }

   @Then("they can see the Lead surname input label")
   public void they_can_see_the_lead_surname_title_input_label()
   {
      assertTrue("Lead surname input label is not displayed",
               bookingSearchPage.getSurnameFieldLabel().isDisplayed());
   }

   @Then("they can see the Lead surname input field")
   public void they_can_see_the_lead_surname_input_field()
   {
      assertTrue("Lead surname input field is not displayed",
               bookingSearchPage.getSurnameFieldInput().isDisplayed());
   }

   @And("the Lead surname is a free text field")
   public void it_is_a_free_text_field()
   {
      assertEquals("Lead surname input field is not a free text field", "text",
               bookingSearchPage.getSurnameFieldInput().attr("type"));
   }

   @And("they click on the surname field")
   public void they_click_on_the_surname_field()
   {
      bookingSearchPage.getSurnameFieldInput().click();
   }

   @Then("they should be able to enter {int} characters")
   public void they_should_be_able_to_enter_characters(int charactersAmount)
   {
      SelenideElement surnameInput = bookingSearchPage.getSurnameFieldInput();

      for (int i = 0; i < charactersAmount; i++)
      {
         surnameInput.sendKeys("a");
      }

      assertEquals("The length of the entered text for surname field is wrong",
               Objects.requireNonNull(surnameInput.getAttribute("value")).length(),
               charactersAmount);
   }

   @And("a agent enters a special character in surname field")
   public void a_agent_enters_a_special_character_in_surname_field()
   {
      bookingSearchPage.getSurnameFieldInput().type("$");
   }

   @When("viewing the available search criteria")
   public void viewing_the_available_search_criteria()
   {
      assertTrue("Booking search criteria section is not displayed",
               bookingSearchPage.getRetrieveWithoutReferenceSection().isDisplayed());
   }

   @Then("they can see the Holiday Type label")
   public void they_can_see_the_holiday_type_label()
   {
      assertTrue("Holiday Type label is not displayed",
               bookingSearchPage.getHolidayTypeFieldLabel().isDisplayed());
   }

   @Then("they can see the Holiday Type Dropdown field")
   public void they_can_see_the_holiday_type_dropdown_field()
   {
      assertTrue("Holiday type dropdown is not displayed",
               bookingSearchPage.getHolidayTypeFieldSelect().isDisplayed());
   }

   @And("they view the page header")
   public void they_view_the_page_header()
   {
      assertTrue("the page header is not displayed",
               bookingSearchPage.getPageHeader().isDisplayed());
   }

   @Then("the page header contains the \"Retrieve a booking\" title")
   public void the_page_header_contains_the_title()
   {
      assertFalse("the page header title is empty",
               bookingSearchPage.getPageHeader().text().isEmpty());

      LOGGER.log(LogLevel.WARN,
               String.format(
                        "Booking Search component header translation should be checked manually."
                                 + " Expected: \"%s\". Actual: \"%s\"",
                        "Retrieve a booking", bookingSearchPage.getPageHeader().text()));
   }

   @And("they view the page tabs")
   public void they_view_the_page_tabs()
   {
      assertTrue("the page tabs wrapper is not displayed",
               bookingSearchPage.getPageTabsWrapper().isDisplayed());
   }

   @Then("they will see the 'Use Booking Reference' tab is the default tab")
   public void they_will_see_the_use_booking_reference_tab_is_the_default_tab()
   {
      assertTrue("the 'Use Booking Reference' tab is not the default tab",
               bookingSearchPage.isRetrieveByRefTabActive());
   }

   @Then("they will be navigated to the page tab for searching without a booking reference")
   public void they_will_be_navigated_to_the_page_tab_for_searching_without_a_booking_reference()
   {
      assertTrue("tab content for searching without a booking reference is not displayed",
               bookingSearchPage.getRetrieveWithoutReferenceSection().isDisplayed());
   }

   @Then("they can see Clear Search Anchor")
   public void they_can_see_clear_search_anchor()
   {
      assertTrue("Clear Search Anchor is not displayed",
               bookingSearchPage.getClearButton().isDisplayed());
   }

   @Then("they can see Search button")
   public void they_can_see_search_button()
   {
      assertTrue("Search button is not displayed",
               bookingSearchPage.getSearchButton().isDisplayed());
   }

   @And("the source market is MA")
   public void the_source_market_is_ma()
   {
      String currentUrl = WebDriverRunner.getWebDriver().getCurrentUrl();

      MatcherAssert.assertThat("the source market is not MA", currentUrl,
               Matchers.containsString("tuiretail-ma-dev"));
   }

   @Then("the Destination Airport code field will become a free text box \\(not a suggestion box)")
   public void the_destination_airport_code_field_will_become_a_free_text_box()
   {
      bookingSearchPage.getAirportFieldInput().type("ANR");

      assertFalse("the Destination Airport suggestion box is displayed",
               bookingSearchPage.getAirportFieldSuggestions().isDisplayed());
   }

   @Then("they can only see 'Flight only' as an option")
   public void they_can_only_see_flight_only_as_an_option()
   {
      assertTrue("Not only one option for the Holiday Type select is present",
               bookingSearchPage.isOnlyOneHolidayTypeOptionPresent());
   }

   @And("this will be the default holiday type")
   public void this_will_be_the_default_holiday_type()
   {
      String expectedValue = "FLIGHT_ONLY";

      String actualValue = bookingSearchPage.getHolidayTypeFieldSelect().getValue();

      assertEquals("the Holiday Type default value is not correct", expectedValue, actualValue);
   }

   @Then("the the Accommodation Name search box will be greyed out")
   public void the_the_accommodation_name_search_box_will_be_greyed_out()
   {
      assertTrue("Accommodation Name search box is not disabled",
               bookingSearchPage.getAccommodationFieldInput().shouldBe(Condition.disabled)
                        .isDisplayed());
   }

   @And("they will be able to see 'All' as default selected in dropdown")
   public void they_will_be_able_to_see_all_as_default_selected_in_dropdown()
   {
      String expectedValue = "ALL";

      String actualValue = bookingSearchPage.getHolidayTypeFieldSelect().getValue();

      assertEquals("the Holiday Type select default value is not the 'All' value", expectedValue,
               actualValue);
   }

   @When("they select 'Flight only' as the holiday type")
   public void they_select_flight_only_as_the_holiday_type()
   {
      String value = "FLIGHT_ONLY";
      SelenideElement selectedOption = bookingSearchPage.getHolidayTypeFieldSelectOptions().stream()
               .filter(option -> Objects.requireNonNull(option.getValue()).contains(value))
               .findFirst()
               .orElse(null);

      MatcherAssert.assertThat(
               String.format("selected option '%s' was not found in the dropdown", selectedOption),
               selectedOption, is(notNullValue()));

      bookingSearchPage.getHolidayTypeFieldSelect().sendKeys(selectedOption.text());
   }

   @Then("the the Accommodation Name search box will be cleared and greyed out")
   public void the_the_accommodation_name_search_box_will_be_cleared_and_greyed_out()
   {
      SelenideElement accommodationFieldInput = bookingSearchPage.getAccommodationFieldInput();

      assertTrue("Accommodation Name search box is not empty",
               accommodationFieldInput.text().isEmpty());

      assertTrue("Accommodation Name search box is not disabled",
               accommodationFieldInput.shouldBe(Condition.disabled).isDisplayed());
   }

   @Then("the Destination Airport code will remain as a suggestion box")
   public void the_destination_airport_code_will_remain_as_a_suggestion_box()
   {
      bookingSearchPage.getAirportFieldInput().type("000");

      assertTrue("the Destination Airport suggestion box is not displayed", bookingSearchPage
               .getAirportFieldAutocompleteWrapper().should(Condition.appear).isDisplayed());
   }

   @When("they view License Field")
   public void they_view_license_field()
   {
      assertTrue("License Field is not displayed",
               bookingSearchPage.getLicenseField().isDisplayed());
   }

   @Then("they will be able to see the Input Field for License")
   public void they_will_be_able_to_see_the_input_field_for_license()
   {
      assertTrue("License Input Field is not displayed",
               bookingSearchPage.getLicenseFieldInput().isDisplayed());
   }

   @Then("they will be able enter only numbers")
   public void they_will_be_able_enter_only_numbers()
   {
      bookingSearchPage.getLicenseFieldInput().type("123test");

      assertEquals("License field input has a wrong value", "123",
               bookingSearchPage.getLicenseFieldInput().getAttribute("value"));
   }

   @Given("they have previously selected Start Date")
   public void they_have_previously_selected_start_date()
   {
      they_click_on_the_calendar_field_input();
      they_click_on_any_day_in_the_calendar_month_table();
      they_click_on_the_button_in_the_calendar_modal_footer();
   }

   @When("they click on the 'Clear all' button in the Calendar Modal Footer")
   public void they_click_on_the_clear_all_button_in_the_calendar_modal_footer()
   {
      bookingSearchPage.getCalendarModalFooterClearAllButton().click();
   }

   @Then("the Calendar month table will do not have any day highlighted")
   public void the_calendar_month_table_will_do_not_have_any_day_highlighted()
   {
      assertTrue("Selected date is highlighted",
               bookingSearchPage.getCalendarTableDays().$$("time.selected").isEmpty());
   }

   @Then("the Calendar Field will be set to its default value \\(empty)")
   public void the_calendar_field_will_be_set_to_its_default_value_empty()
   {
      assertEquals("Calendar Field input has a wrong value", "",
               bookingSearchPage.getStartDateFieldInput().getAttribute("value"));
   }

   @Then("they see the Current month view")
   public void they_see_the_current_month_view()
   {
      this.currentMonthYearViewDate = LocalDate.now();
      String currentYearMonth = this.getFormattedCurrentYearMonth(currentMonthYearViewDate);

      assertFalse(
               "Current month view is not displayed in the Calendar month table, current date: "
                        + currentYearMonth,
               bookingSearchPage.getCalendarTableDays()
                        .$$("time[datetime*='" + currentYearMonth + "']")
                        .isEmpty());
   }

   @When("they click on the Previous month arrow")
   public void they_click_on_the_previous_month_arrow()
   {
      bookingSearchPage.getCalendarPreviousMonthArrow().click();
   }

   @When("they click on the Next month arrow")
   public void they_click_on_the_next_month_arrow()
   {
      bookingSearchPage.getCalendarNextMonthArrow().click();
   }

   @Then("they can see the Previous month view")
   public void they_can_see_the_previous_month_view()
   {
      this.currentMonthYearViewDate = this.currentMonthYearViewDate.minusMonths(1);
      String currentMonthYear = this.getFormattedCurrentYearMonth(this.currentMonthYearViewDate);

      assertFalse(
               "Previous month view is not displayed in the Calendar month table, previous date: "
                        + currentMonthYear,
               bookingSearchPage.getCalendarTableDays()
                        .$$("time[datetime*='" + currentMonthYear + "']")
                        .isEmpty());
   }

   @Then("they can see the Next month view")
   public void they_can_see_the_next_month_view()
   {
      this.currentMonthYearViewDate = this.currentMonthYearViewDate.plusMonths(1);
      String currentMonthYear = this.getFormattedCurrentYearMonth(this.currentMonthYearViewDate);

      assertFalse(
               "Next month view is not displayed in the Calendar month table, previous date: "
                        + currentMonthYear,
               bookingSearchPage.getCalendarTableDays()
                        .$$("time[datetime*='" + currentMonthYear + "']")
                        .isEmpty());
   }

   @When("they select the month from the Month\\/Year dropdown, which is {int} years from the current date")
   public void they_select_the_month_from_the_month_year_dropdown_which_is_years_from_the_current_date(
            int monthsFromCurrentDate)
   {
      String selectedDate = this.getFormattedDateForSelect(monthsFromCurrentDate * 12);
      bookingSearchPage.getCalendarMonthYearSelectDropdown().selectOptionByValue(selectedDate);
   }

   @Then("they can see the Previous month arrow is disabled")
   public void they_can_see_the_previous_month_arrow_is_disabled()
   {
      assertTrue(
               "Previous month arrow is not disabled when the first month is selected in the month\\/year dropdown",
               bookingSearchPage.getCalendarPreviousMonthArrow().shouldBe(Condition.disabled)
                        .isDisplayed());
   }

   @Then("they can see the Next month arrow is disabled")
   public void they_can_see_the_next_month_arrow_is_disabled()
   {
      assertTrue(
               "Next month arrow is not disabled when the last month is selected in the month\\/year dropdown",
               bookingSearchPage.getCalendarNextMonthArrow().shouldBe(Condition.disabled)
                        .isDisplayed());
   }

   @Then("they can see the Previous month arrow is enabled")
   public void they_can_see_the_previous_month_arrow_is_enabled()
   {
      assertTrue(
               "Previous month arrow is not enabled when the first month is not selected in the month\\/year dropdown",
               bookingSearchPage.getCalendarPreviousMonthArrow().shouldBe(Condition.enabled)
                        .isDisplayed());
   }

   @Then("they can see the Next month arrow is enabled")
   public void they_can_see_the_next_month_arrow_is_enabled()
   {
      assertTrue(
               "Next month arrow is not enabled when the last month is not selected in the month\\/year dropdown",
               bookingSearchPage.getCalendarNextMonthArrow().shouldBe(Condition.enabled)
                        .isDisplayed());
   }

   public boolean isExecutedLocally()
   {
      String pageUrl = ExecParams.getTestExecutionParams().getUrlStr();
      return StringUtils.containsIgnoreCase(pageUrl, "localhost");
   }

   private String getFormattedDateForSelect(int deltaMonthsFromCurrentDate)
   {
      Calendar calendar = Calendar.getInstance();
      calendar.add(Calendar.MONTH, deltaMonthsFromCurrentDate);

      return String.format("%04d-%02d", calendar.get(Calendar.YEAR),
               calendar.get(Calendar.MONTH) + 1);
   }

   private String formatISODateToStartDateInputFormat(String isoDate) throws ParseException
   {
      SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
      SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");

      Date date = inputFormat.parse(isoDate);
      return outputFormat.format(date);
   }

   private String getFormattedCurrentYearMonth(LocalDate date)
   {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
      return date.format(formatter);
   }
}
