package uk.co.tui.cdaf.frontend.pom.wr.web.stay.search.searchresults;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class SearchResultCardComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[class*='packageInfo'] button")
   private List<WebElement> continueButton;

   public SearchResultCardComponent()
   {
      wait = new WebElementWait();
   }

   public List<WebElement> getContinueButton()
   {
      return wait.getWebElementWithLazyWait(continueButton);
   }

   public void clickOnContinueButton()
   {
      WebElementTools.clickElementJavaScript(getContinueButton().get(0));
   }
}
