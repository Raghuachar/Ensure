package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;
import org.hamcrest.Matchers;
import org.junit.Assume;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.api.requests.search.PackageSearchApi;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.RoomComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.AlternateFlightsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.codeborne.selenide.Selenide.open;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.number.OrderingComparison.greaterThan;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class RoomAndGuestAutoAllocationStepDefs
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(RoomAndGuestAutoAllocationStepDefs.class);

   public final PackageNavigation packageNavigation;

   public final SearchPanel searchPanel;

   public final SearchResultsPage searchResultsPage;

   public final SearchResultsComponent searchResultComponent;

   public final ProgressionbarNavigationComponent progressBarComponent;

   public final UnitDetailsPage unitPage;

   private final PageErrorHandler errorHandler;

   private final Map<String, WebElement> searchMap;

   private final UnitDetailsPage unitDetailsPage;

   private final Map<String, WebElement> unitMap;

   private final SearchPanelComponent searchPanelComponent;

   private final WebElementWait wait;

   private final AlternateFlightsPage alternateFlightsPage;

   private final RoomComponent roomComponent;

   private final SearchDataHelper searchDataHelper;

   private String room, boardbasis;

   private int search;

   public RoomAndGuestAutoAllocationStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchPanelComponent = new SearchPanelComponent();
      searchPanel = SearchPanelFactory.getSearchPanel();
      wait = new WebElementWait();
      errorHandler = new PageErrorHandler();
      unitPage = new UnitDetailsPage();
      searchResultsPage = new SearchResultsPage();
      searchResultComponent = new SearchResultsComponent();
      progressBarComponent = new ProgressionbarNavigationComponent();
      alternateFlightsPage = new AlternateFlightsPage();
      searchMap = new HashMap<>();
      unitDetailsPage = new UnitDetailsPage();
      unitMap = new HashMap<>();
      roomComponent = new RoomComponent();
      searchDataHelper = new SearchDataHelper();
   }

   @Then("they can see that the option {string} is selected by default")
   public void they_can_see_that_the_option(String value)
   {
      assertThat(getSearchPanel().paxAndRooms().clearSelection().getRoomSelector()
               .getSelectedOptionText(), is(value));
   }

   @Then("{string} adults are allocated to the 'Adults' field by default")
   public void adults_are_allocated_to_the_field_by_default(String numberOfAdults)
   {
      String actualAdultNumber = getSearchPanel().paxAndRooms().clearSelection().getAdultSelector(1)
               .getText();
      assertThat(actualAdultNumber, equalTo(numberOfAdults));
   }

   @Given("they left the number of rooms option as {string} in their initial search")
   public void they_left_the_number_of_rooms_option_as_in_their_initial_search(String string)
   {
      searchPanel.paxAndRooms().getRoomSelector().selectOption(string);
   }

   @Given("they manually selected the number of rooms they wanted ex {int}")
   public void they_manually_selected_the_number_of_rooms_they_wanted_ex(Integer int1)
   {
      searchPanel.paxAndRooms().selectNumberOfRooms(int1).confirmSelection();
   }

   // TODO: cleanup, this step definition fully or partially duplicates step definitions from the list bellow:
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel.MFESearchPanelDepartureAirportStepDefs.java
   //        the_is_on_the_Belgium_Dutch_page(String, String)
   //        the_is_on_the_Belgium_French_page(String, String)
   //        the_is_on_the_Netherlands_page(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.RoomAndGuestAutoAllocationStepDefs.java
   //        is_on_the_page(String)
   //        they_re_on_the_page(String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.B2BVipSelectSingleAccommodationSearch.java
   //        the_is_on_the_page_VIP_Select_package(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage.B2BTUIVIPBrandToggleFlipStepDefs.java
   //        the_is_on_the_page(String, String)
   @Given("Customer or Agent is on the {string} page")
   public void is_on_the_page(String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Homepage"))
      {
         packageNavigation.navigateToHoldaySearchPage();
      }
      else if (respectivePage.equalsIgnoreCase("Search Results"))
      {
         PackageSearchApi.openSearchResultsPage();
      }
      else if (respectivePage.equalsIgnoreCase("Unit details"))
      {
         PackageSearchApi.openSearchResultsPage();
         searchResultComponent.selectFirstAvailableResultCard();
         searchPanel.openFromUnitDetails();
      }
      else if (respectivePage.equalsIgnoreCase("Single accommodation"))
      {
         packageNavigation.deepLinkSingleAccomadation();
      }
   }

   // TODO: cleanup, this step definition fully or partially duplicates step definitions from the list bellow:
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel.MFESearchPanelDepartureAirportStepDefs.java
   //        the_is_on_the_Belgium_Dutch_page(String, String)
   //        the_is_on_the_Belgium_French_page(String, String)
   //        the_is_on_the_Netherlands_page(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.RoomAndGuestAutoAllocationStepDefs.java
   //        is_on_the_page(String)
   //        they_re_on_the_page(String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel.B2BVipSelectSingleAccommodationSearch.java
   //        the_is_on_the_page_VIP_Select_package(String, String)
   //  uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.browse.homepage.B2BTUIVIPBrandToggleFlipStepDefs.java
   //        the_is_on_the_page(String, String)
   @Given("they're on the {string} page")
   public void they_re_on_the_page(String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Homepage"))
      {
         packageNavigation.navigateToHoldaySearchPage();
      }
      else if (respectivePage.equalsIgnoreCase("Search Results"))
      {
         packageNavigation.navigateToSelectedRoomsSearchResultPage();
      }
      else if (respectivePage.equalsIgnoreCase("Unit details"))
      {
         packageNavigation.navigateSelectedRoomsUnitDetailsPage();
      }
   }

   @Then("they can see that the option {string}")
   public void they_can_see_that_the_option_t_mind(String string)
   {
      assertThat(searchPanelComponent.isDefaultRoomValuePresent(string), is(true));
   }

   @Then("it is selectable")
   public void it_is_selectable()
   {
      searchPanel.paxAndRooms().getRoomSelector().selectOptionByValue("default");
      searchPanel.paxAndRooms().confirmSelection();
   }

   @Then("they can successfully carry our a new search with this selected")
   public void they_can_successfully_carry_our_a_new_search_with_this_selected()
   {
      searchPanelComponent.clickOnSearchButton();
   }

   @Given("they selected the {int} rooms for their initial search")
   public void selectNumberOfRooms(int numberOfRooms)
   {
      searchPanel.paxAndRooms().selectNumberOfRooms(numberOfRooms).confirmSelection();
      searchPanel.doSearch();
   }

   @Then("it is populated with the number of rooms they searched for")
   public void it_is_populated_with_the_number_of_rooms_they_searched_for()
   {
      TestDataAttributes parameter = searchDataHelper.getSearchParameters();
      assertThat(searchPanel.paxAndRooms().getRoomSelector().getSelectedOptionText(),
               is(parameter.getRoomCount()));
   }

   @And("{string} has conducted a package search")
   public void has_conducted_a_package_search(String string)
   {
      searchPanelComponent.clickOnSearchButton();
   }

   @Given("the {string} is interacting with the {string} field in {string} search panel")
   public void the_is_interacting_with_the_field_in_search_panel(String agent, String roomGuest,
            String respective)
   {
      if (respective.equalsIgnoreCase("Main"))
         packageNavigation.navigateToHoldaySearchPage();
      else if (respective.equalsIgnoreCase("Edit"))
      {
         open(PackageSearchApi.uriBuilder());

         errorHandler.isPageLoadingCorrectly();
         String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
         LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
      }

   }

   @And("{string} is selected in the number of rooms dropdown")
   public void is_selected_in_the_number_of_rooms_dropdown(String noOfRooms)
   {
      searchPanel.paxAndRooms().clearSelection().confirmSelection();
      assertThat(noOfRooms + " is not displaying in room & guests",
               searchPanelComponent.isDefaultRoomValuePresent(noOfRooms), is(false));
   }

   @When("they select more infants than adults")
   public void they_select_more_infants_than_adults()
   {
      searchPanel.paxAndRooms().clearSelection().setAdultsNumber(1, 1)
               .addChild("0", 1)
               .addChild("0", 1);
   }

   @Then("an inline error appears which reads:")
   public void an_inline_error_appears_which_reads(io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String brandStr = ExecParams.getTestExecutionParams().getBrandStr();
      String expected = map.get(brandStr);
      String actual = searchPanel.paxAndRooms().getErrorMessage();
      assertThat("amendtotal price tool tip message is not matched", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @Given("the {string} has entered their search criteria in the {string} search panel")
   public void the_has_entered_their_search_criteria_in_the_search_panel(String string,
            String searchpanel)
   {
      if (searchpanel.equalsIgnoreCase("Main"))
      {
         packageNavigation.navigateToHoldaySearchPage();
      }
      else if (searchpanel.equalsIgnoreCase("Edit"))
      {
         packageNavigation.navigateToSelectedRoomsSearchResultPage();
      }
      searchPanel.searchDefaults();
   }

   @Given("they have entered equal to or less than {int} passengers")
   public void they_have_entered_equal_to_or_less_than_passengers(Integer int1)
   {
      searchPanel.paxAndRooms().setAdultsNumber(int1, 1).confirmSelection();
   }

   @Given("pax and rooms have default values selected")
   public void paxAndRoomsDefault()
   {
      getSearchPanel().paxAndRooms().clearSelection();
   }

   @When("they select the 'SEARCH' cta")
   public void they_select_the_cta()
   {
      getSearchPanel().doSearch();
   }

   @Then("the search results page loads with a series of results")
   public void the_search_results_page_loads_with_a_series_of_results()
   {
      searchPanelComponent.holidays_present();
   }

   @Given("they have selected 9 passengers in 4 rooms")
   public void they_have_entered_equal_to_or_less_than_passenger()
   {
      getSearchPanel().paxAndRooms().setAdultsNumber(6, 1).selectNumberOfRooms(4)
               .confirmSelection();
   }

   @Then("P&A has automatically, successfully allocated each passenger to a room")
   public void p_A_has_automatically_successfully_allocated_each_passenger_to_a_room()
   {
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      errorHandler.isPageLoadingCorrectly();
      LOGGER.log(LogLevel.INFO,
               "Unit details page url:" + WebDriverUtils.getDriver().getCurrentUrl());
   }

   @And("a maximum of four rooms are allocated")
   public void a_maximum_of_four_rooms_are_allocated()
   {
      assertThat(roomComponent.verifyNoOfRooms(), is(true));
   }

   @Given("the {string} has entered their search criteria in the search panel")
   public void the_has_entered_their_search_criteria_in_the_search_panel(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
      getSearchPanel().searchDefaults();
   }

   @Given("they have selected the 'SEARCH' cta")
   public void they_SEARCH_cta()
   {
      getSearchPanel().doSearch();
   }

   @When("they review results where only one room has been allocated")
   public void they_review_results_where_only_one_room_has_been_allocated()
   {
      searchResultComponent.selectSearchCardWithAlternateRoom();
      wait.forComplexPageLoad();
   }

   @Then("the out-and-out cheapest room\\(s) available is automatically allocated")
   public void the_out_and_out_cheapest_room_s_available_is_automatically_allocated()
   {
      searchPanelComponent.checkCheapestRoom();
   }

   @And("they have not selected the number of rooms they want")
   public void they_have_not_selected_the_number_of_rooms_they_want()
   {
      searchPanel.searchWithParameters();
      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   @And("they re on the Customise Holiday page within the bookflow")
   public void they_re_on_the_Customise_Holiday_page_within_the_bookflow()
   {
      room = searchResultsPage.searchResultComponent.getRoomDetails();
      boardbasis = searchResultsPage.searchResultComponent.getBoardBasis();
      LOGGER.log(LogLevel.INFO, "Room " + room + "boardbasis" + boardbasis);
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
      wait.forJSExecutionReadyLazy();
      unitPage.progressbarComponent.clickOnContinueButton();
   }

   @When("they review the {string}")
   public void they_review_the(String string)
   {
      wait.forJSExecutionReadyLazy();
      alternateFlightsPage.clickOnViewAlternativeFlightLink();
      if (string.contains("Dates carousel"))
         assertThat("Dates component is not dsipayed",
                  alternateFlightsPage.isDateCarouselIsPresent(), is(true));
      else
         assertThat("Dates component is not dsipayed",
                  alternateFlightsPage.isAlternativeFlightIsPresent(), is(true));
   }

   @Then("the only {string} available are those that have the auto allocated room types available for that package")
   public void the_only_available_are_those_that_have_the_auto_allocated_room_types_available_for_that_package(
            String string)
   {
      if (string.contains("Dates carousel"))
         assertThat("Dates component is not dsipayed", alternateFlightsPage.isCarouselIsPresent(),
                  is(true));
      if (string.contains("Alt flight cards"))
         alternateFlightsPage.alternativeFlightsButtonIsDisplayed();
      alternateFlightsPage.verifyRoomAndBoard(room, boardbasis);
   }

   @Given("the {string} entered their search criteria in the search panel")
   public void the_entered_their_search_criteria_in_the_search_panel(String string)
   {
      searchPanel.selectWithParameters();
   }

   @When("the P&A cannot auto allocate enough rooms to allocate all passengers to a room, up to a MAXIMUM of four rooms")
   public void the_P_A_cannot_auto_allocate_enough_rooms_to_allocate_all_passengers_to_a_room_up_to_a_MAXIMUM_of_four_rooms()
   {
      assertThat("Default Room Value is missing",
               searchPanelComponent.isDefaultRoomValuePresent("0"), is(true));
   }

   @Then("they're presented with the as is All Gone page \\(Not the all gone with alternatives page)")
   public void they_re_presented_with_the_as_is_All_Gone_page_Not_the_all_gone_with_alternatives_page()
   {
      assertTrue(searchPanelComponent.isAllGone());
   }

   @Given("the {string} has conducted a multi pax search")
   public void the_has_conducted_a_multi_pax_search(String string)
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @When("they review a search card")
   public void they_review_a_search_card()
   {
      assertThat("Search Result card component AccommInfo is present",
               searchResultsPage.searchResultComponent.visibileAccomInfoComponent(), is(true));
   }

   @Then("they can see the following below:")
   public void they_can_see_the_following_below(List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchResultComponent.getSearchCardRoom());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            LOGGER.log(LogLevel.INFO, element);
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("they review a search card which has been allocated at least two rooms which are different in type")
   public void they_review_a_search_card_which_has_been_allocated_at_least_two_rooms_which_are_different_in_type()
   {
      assertThat(
               "search card which has not been allocated at least two rooms which are different in type",
               searchResultsPage.searchResultComponent.getSearchCardWithRoomType(searchMap),
               is(true));
   }

   @And("they are on separate line items")
   public void they_are_on_separate_line_items()
   {
      assertThat("Search Result card room type is not there on separate line items",
               searchResultsPage.searchResultComponent.getRoomOptions().size(), greaterThan(0));
   }

   @Given("Search for multiple rooms")
   public void search_for_multiple_rooms()
   {
      packageNavigation.navigateToMultiRoomSearchResultPage();
   }

   @Then("the room type\\(s) that have rooms remaining will display the following message:")
   public void the_room_type_s_that_have_or_less_rooms_remaining_will_display_the_following_message(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      expected = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
                  ? map.get((BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
                  + (BDDSiteIdResolver.getSiteRTId().toLowerCase()))
                  : map.get(BDDSiteIdResolver.getSiteRTId().toLowerCase());
      actual = searchResultsPage.searchResultComponent.getRoomsLeft();

      String roomCount = actual.split(" ")[1];
      String roomsData = actual.split(" ")[2];

      String finalExpect = getExpectedData(expected, roomCount, roomsData);

      assertThat("amendtotal price tool tip message is not matched", finalExpect,
               Matchers.equalToIgnoringCase(actual));
   }

   private String getExpectedData(String expected, String roomCount, String roomsData)
   {
      return expected.replace("x", roomCount).replace("y", roomsData);
   }

   @When("they hover or click on the {string} tooltip")
   public void they_hover_or_click_on_the_tooltip(String string)
   {
      searchResultComponent.clickOnRoomLAIToolTip();
   }

   @Then("the following message will be displayed:")
   public void the_following_message_will_be_displayed(io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
                  ? map.get((BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
                  + (BDDSiteIdResolver.getSiteRTId().toLowerCase()))
                  : map.get(BDDSiteIdResolver.getSiteRTId().toLowerCase());
         actual = searchResultsPage.searchResultComponent.getRoomsLeftToolTiptext();
         assertThat(
                  ReportFormatter.generateReportStatement(
                           org.apache.commons.lang3.StringUtils.EMPTY,
                           "amendtotal price tool tip message is not matched", actual, expected),
                  org.apache.commons.lang3.StringUtils.equalsIgnoreCase(expected, actual),
                  is(true));
         LOGGER.log("Expected :" + expected + "\n Actual :" + actual);
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Given("search for single rooms")
   public void search_for_single_rooms()
   {
      packageNavigation.navigateToSelectedRoomsSearchResultPage();
   }

   @Then("the room type\\(s) for french that have rooms remaining will display the following message:")
   public void the_room_type_s_for_french_that_have_or_less_rooms_remaining_will_display_the_following_message(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String expected = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
               ? map.get((BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
               + (BDDSiteIdResolver.getSiteRTId().toLowerCase()))
               : map.get(BDDSiteIdResolver.getSiteRTId().toLowerCase());
      String actual = searchResultsPage.searchResultComponent.getRoomsLeft();
      String roomCount = actual.split(" ")[2];
      String roomsData = actual.split(" ")[3];
      String finalExpect = getExpectedData(expected, roomCount, roomsData);
      assertThat("amendtotal price tool tip message is not matched", actual,
               Matchers.equalToIgnoringCase(finalExpect));
   }

   @Given("rooms have been auto allocated Package search to fulfill the party composition")
   public void rooms_have_been_auto_allocated_Package_search_to_fulfill_the_party_composition()
   {
      searchResultsPage.searchResultComponent.getRoomOptions();
   }

   @Then("they can see all of the room types auto allocated on the search results page")
   public void they_can_see_all_of_the_room_types_auto_allocated_on_the_search_results_page()
   {
      String roomTypeSearch =
               searchResultsPage.searchResultComponent.getRoomOptions().get(0).getText();
      search = roomTypeSearch.split(",").length;
   }

   @Then("they've selected a package from the search results page")
   public void they_ve_selected_a_package_from_the_search_results_page()
   {
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectRandomResultCard();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
   }

   @When("they review the {string} component on the unit details page")
   public void they_review_the_component_on_the_unit_details_page(String string)
   {
      assertTrue(roomComponent.verifyNoOfRooms());
   }

   @Given("rooms have been auto allocated single accom search to fulfill the party composition")
   public void rooms_have_been_auto_allocated_single_accom_search_to_fulfill_the_party_composition()
   {
      assertThat("single accom search Destination field are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDestinationDisplayed(),
               is(true));
   }

   @Then("they can see all of the room types auto allocated on the single accom page")
   public void they_can_see_all_of_the_room_types_auto_allocated_on_the_single_accom_page()
   {
      assertThat("single accom search Destination field are not displayed",
               searchResultsPage.singleAccommodationComponent.isUnitElementDisplayed(), is(true));
   }

   @Then("they've selected a package from the single accom results page")
   public void they_ve_selected_a_package_from_the_single_accom_results_page()
   {
      searchResultsPage.singleAccommodationComponent.selectDateCell();
   }

   @When("they review the YOUR ROOMS component on the unit details page")
   public void they_review_the_YOUR_ROOMS_component_on_the_unit_details_page()
   {
      assertThat(roomComponent.verifyNoOfRooms(), is(true));
   }

   @Given("the {string} has entered the single accom search criteria in the {string} search panel")
   public void the_has_entered_the_single_accom_search_criteria_in_the_search_panel(String string,
            String searchpanel)
   {
      if (searchpanel.equalsIgnoreCase("Main"))
      {
         packageNavigation.navigateToHoldaySearchPage();
         TestDataAttributes parameter = new SearchDataHelper().getSearchParameters();
         String suggestion = parameter.getSuggestion();
         searchPanel.selectDefaults();
         searchPanel.destinationSuggestions(suggestion).selectSuggestionFromList(suggestion);
      }
      else if (searchpanel.equalsIgnoreCase("Edit"))
      {
         packageNavigation.navigateToSingleAccomSearchResultPage();
      }
   }

   @And("they have a added a specific hotel in the Hotel or Destination field")
   public void they_have_a_added_a_specific_hotel_in_the_Hotel_or_Destination_field()
   {
      assertThat("single accom search Destination field are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDestinationDisplayed(),
               is(true));
   }

   @Then("the single accom search results page loads")
   public void the_single_accom_search_results_page_loads()
   {
      assertThat("single accom search results page are not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomDisplayed(), is(true));
   }

   @Given("the Customer or Agent has conducted a package search")
   public void the_Customer_Agent_has_conducted_a_package_search()
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanel.selectWithParameters();
   }

   @And("they did not selected the number of rooms they want")
   public void they_did_not_selected_the_number_of_rooms_they_want()
   {
      assertThat(searchPanelComponent.isDefaultRoomPresent("Geen voorkeur"), is(true));
   }

   @And("there's at least one infant on the search request \\(Aged between {int} and {int} years old)")
   public void there_s_at_least_one_infant_on_the_search_request_Aged_between_and_years_old(
            Integer minAge, Integer maxAge)
   {
      int randomAgeInt = new Random().nextInt((maxAge - minAge) + 1) + minAge;
      searchPanel.paxAndRooms().addChild(String.valueOf(randomAgeInt), 1).confirmSelection();
   }

   @When("the backend automatically allocates rooms in the response")
   public void the_backend_automatically_allocates_rooms_in_the_response()
   {
      searchResultsPage.searchPanelComponent.searchPanel.doSearch();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   @Then("the infant {int}{int} years is never allocated to a room without an adult {int}+ years")
   public void the_infant_years_is_never_allocated_to_a_room_without_an_adult_years(Integer int1,
            Integer int2, Integer int3)
   {
      roomComponent.infantWithAdult();
   }

   @And("they are viewing a room card within the YOUR ROOM\\(S) component")
   public void they_are_viewing_a_room_card_within_the_YOUR_ROOM_S_component()
   {
      assertThat("Additional Rooms are not present",
               roomComponent.isAdditionalRoomAccordionDisplayed(), is(true));
   }

   @And("there is more than one image available for the room")
   public void there_is_more_than_one_image_available_for_the_room()
   {
      roomComponent.isMoreThanOneRoomRoomImage();
   }

   @When("selecting a chevron on the image card")
   public void selecting_a_chevron_on_the_image_card()
   {
      roomComponent.clickOnChevron();
   }

   @Then("there will be a carousel of images for that room available for a rotation")
   public void there_will_be_a_carousel_of_images_for_that_room_available_for_a_rotation()
   {
      roomComponent.carouselImages();
   }

   @When("they select the camera icon on the room image")
   public void they_select_the_camera_icon_on_the_room_image()
   {
      roomComponent.clickONCameraIcon();
   }

   @Then("the room modal is displayed with the following information:")
   public void the_room_modal_is_displayed_with_the_following_information(List<String> components)
   {
      SoftAssertions softly = new SoftAssertions();
      softly.assertThat(roomComponent.getCameraIconXCloseModalLink().isDisplayed())
               .as("'X' close modal link component not displayed").isTrue();
      softly.assertThat(roomComponent.getFirstRoomHighlight().isDisplayed())
               .as("Main/first room image component not displayed").isTrue();
      softly.assertThat(roomComponent.getModalRoomChevron().isDisplayed())
               .as("A chevron if there is more than 1 room image component not displayed").isTrue();
      softly.assertThat(roomComponent.getCarouselFrame().isDisplayed())
               .as("Image carousel when more than one image is available for the room component not displayed")
               .isTrue();
      softly.assertAll();
   }

   @When("they select {string} close modal link")
   public void they_select_close_modal_link(String string)
   {
      wait.forJSExecutionReadyLazy();
      roomComponent.XCloseIsPresent();
      wait.forJSExecutionReadyLazy();
   }

   @Then("the image modal will close")
   public void the_image_modal_will_close()
   {
      roomComponent.clickONXClose();
   }

   @And("the Unit Details page will be displayed")
   public void the_Unit_Details_page_will_be_displayed()
   {
      unitDetailsPage.isHotelDetailsPageDisplayed();
   }
}
