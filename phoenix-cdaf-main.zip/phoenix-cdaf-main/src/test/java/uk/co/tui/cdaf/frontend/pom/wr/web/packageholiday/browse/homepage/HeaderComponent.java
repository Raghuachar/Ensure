package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class HeaderComponent extends AbstractPage
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(HeaderComponent.class);

   @FindAll({ @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(1) span"),
            @FindBy(css = ".MainNavigation__mainNavigation ul li:nth-child(1) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(1) a") })
   private WebElement holidaysLabel;

   @FindAll({ @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(2) span"),
            @FindBy(css = ".MainNavigation__mainNavigation ul li:nth-child(2) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(2) a") })
   private WebElement cruisesLabel;

   @FindAll({ @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(3) span"),
            @FindBy(css = ".MainNavigation__mainNavigation ul li:nth-child(3) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(3) a") })
   private WebElement flightsLabel;

   @FindAll({ @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(4) span"),
            @FindBy(css = ".MainNavigation__mainNavigation ul li:nth-child(4) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(4) a") })
   private WebElement hotlonlyLabel;

   @FindAll({ @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(5) span"),
            @FindBy(css = ".MainNavigation__mainNavigation ul li:nth-child(5) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(5) a") })
   private WebElement dealsLabel;

   @FindAll({ @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(6) span"),
            @FindBy(css = ".MainNavigation__mainNavigation ul li:nth-child(6) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(6) a") })
   private WebElement destinationsLabel;

   @FindAll({ @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(7) span"),
            @FindBy(css = ".MainNavigation__mainNavigation ul li:nth-child(7) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(7) a") })
   private WebElement extrasLabel;

   @FindAll({ @FindBy(css = "[aria-label*='global header']"), @FindBy(css = "#header__component") })
   private WebElement headerComp;

   @FindAll({ @FindBy(css = ".TopBar__topbarWrapper ul li:nth-child(1) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(8) a") })
   private WebElement questionsLabel;

   @FindAll({ @FindBy(css = ".TopBar__topbarWrapper ul li:nth-child(2) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(9) a") })
   private WebElement blogLabel;

   @FindAll({ @FindBy(css = ".TopBar__topbarWrapper ul li:nth-child(3) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(10) a") })
   private WebElement shortlistLabel;

   @FindAll({ @FindBy(css = ".TopBar__topbarWrapper ul li:nth-child(4) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(11) a") })
   private WebElement travelInformationLabel;

   @FindAll({ @FindBy(css = ".TopBar__topbarWrapper ul li:nth-child(5) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(12) a") })
   private WebElement accountBookingLabel;

   @FindAll({ @FindBy(css = "[aria-label='burger menu main']")

   })
   private WebElement burgerMenu;

   @FindBy(css = "[aria-label='Shortlist Icon']")
   private WebElement shortlistIcon;

   @FindBy(css = "[aria-label='CA Icon']")
   private WebElement accountBookingIcon;

   @FindBy(css = "#header__component .Logo__brandLogo.Logo__th > a > img")
   private WebElement tuiLogoIcon;

   @FindBy(css = ".LanguageCountrySelector__countrySwitcher button")
   private WebElement countrySwitcherLink;

   @FindBy(css = "div#choiceSearch__component label:nth-child(1) > span.inputs__circle.inputs__alignmiddle")
   private WebElement radioButtonDefault;

   @FindBy(xpath = "//span[contains(.,'VIP Selection')]")
   private WebElement vipSelection;

   @FindBy(css = "span[aria-label='menu-Vakanties']")
   private WebElement clickOnHolidayTab;

   @FindBy(css = ".UI__rating span")
   private WebElement rating;

   @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(2) span")
   private WebElement flights;

   @FindBy(css = "[class*='MainNavigation__mainNavigation'] ul li:nth-child(3) span")
   private WebElement links;

   @FindBy(xpath = "(//span[@class='LinkItem__utilityNavLink']//a)[1]")
   private WebElement travelInformation;

   @FindBy(xpath = "(//span[@class='LinkItem__utilityNavLink']//a)[2]")
   private WebElement retrievebooking;

   @FindBy(xpath = "//span[@aria-label='next customer link']")
   private WebElement nextcustomer;

   @FindBy(xpath = "(//span[@class='RetailHeader__agencyDisplayFormat'])[2]")
   private WebElement agentlink;

   @FindBy(css = ".RetailHeader__logout")
   private WebElement logoutlink;

   @FindBy(css = "span.cl-selector__lang")
   private WebElement language;

   public WebElement getTuiLogoIcon()
   {
      return tuiLogoIcon;
   }

   public WebElement getShortlistIcon()
   {
      return shortlistIcon;
   }

   public WebElement getAccountBookingIcon()
   {
      return accountBookingIcon;
   }

   public WebElement getHolidaysLabel()
   {
      return holidaysLabel;
   }

   public WebElement getCruisesLabel()
   {
      return cruisesLabel;
   }

   public WebElement getFlightsLabel()
   {
      return flightsLabel;
   }

   public WebElement getHotlonlyLabel()
   {
      LOGGER.log(LogLevel.INFO, "Hotel label value:" + hotlonlyLabel.getText());
      return hotlonlyLabel;
   }

   public WebElement getDealsLabel()
   {
      return dealsLabel;
   }

   public WebElement getDestinationsLabel()
   {
      return destinationsLabel;
   }

   public WebElement getExtrasLabel()
   {
      return extrasLabel;
   }

   public SelenideElement getHeaderComp()
   {
      return $("div.oh-navigation-wrapper");
   }

   public WebElement getQuestionsLabel()
   {
      return questionsLabel;
   }

   public WebElement getBlogLabel()
   {
      return blogLabel;
   }

   public WebElement getShortlistLabel()
   {
      return shortlistLabel;
   }

   public WebElement getTravelInformationLabel()
   {
      return travelInformationLabel;
   }

   public WebElement getAccountBookingLabel()
   {
      return accountBookingLabel;
   }

   public WebElement getBurgerMenu()
   {
      return burgerMenu;
   }

   public WebElement getCountrySwitcherLink()
   {
      return countrySwitcherLink;
   }

   public boolean isRadiobuttonCheckedByDefault()
   {
      return WebElementTools.isPresent(radioButtonDefault);
   }

   public void isVipButtonSelected()
   {
      WebElementTools.click(vipSelection);
   }

   public boolean isResetToTuiHoliday()
   {
      return WebElementTools.isPresent(radioButtonDefault);
   }

   public boolean isResetToVipSelection()
   {
      return WebElementTools.isPresent(vipSelection);
   }

   public void clickOnHolidayTabTop()
   {
      WebElementTools.click(clickOnHolidayTab);
   }

   public boolean selectVipSelection()
   {
      if (vipSelection.isSelected())
      {
         return true;
      }
      else
      {
         vipSelection.click();
      }
      return false;
   }

   public boolean selectTuiSelection()
   {
      if (radioButtonDefault.isSelected())
      {
         return true;
      }
      else
      {
         radioButtonDefault.click();
      }
      return false;
   }

   public String getRatingText()
   {
      return WebElementTools.getElementText(rating);
   }

   public WebElement getFlightLabel()
   {
      return flights;
   }

   public WebElement getLinksLabel()
   {
      return links;
   }

   public WebElement travelInformationLabel()
   {
      return travelInformation;
   }

   public WebElement retrievebookingLabel()
   {
      return retrievebooking;
   }

   public WebElement nextCustomerLabel()
   {
      return nextcustomer;
   }

   public WebElement agentlinkLabel()
   {
      return agentlink;
   }

   public WebElement logoutlinkLabel()
   {
      return logoutlink;
   }

   public SelenideElement getCountryLabel()
   {
      return $$(".cl-selector__lang, .LanguageCountrySelector__languageText").first();
   }

   public boolean getCountryLabels()
   {
      return getCountryLabel().isDisplayed();
   }
}
