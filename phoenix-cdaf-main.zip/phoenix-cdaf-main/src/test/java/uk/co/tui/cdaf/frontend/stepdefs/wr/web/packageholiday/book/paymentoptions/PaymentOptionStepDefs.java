package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.paymentoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.paymentoptions.PaymentOptionsPage;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class PaymentOptionStepDefs
{
   public final PaymentOptionsPage paymentPage;

   private final PackageNavigation packageNavigation;

   private final PageErrorHandler errorHandler;

   private final WebElementWait wait;

   public PaymentOptionStepDefs()
   {
      paymentPage = new PaymentOptionsPage();
      packageNavigation = new PackageNavigation();
      wait = new WebElementWait();
      errorHandler = new PageErrorHandler();
   }

   @And("following component options should display on payment page")
   public void following_component_options_should_display_on_payment_page(List<String> components)
   {
      paymentPage.wait.forJSExecutionReadyLazy();
      Map<String, WebElement> paymentMap = paymentPage.getPaymentPageComponents();
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = paymentMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("they continue to booking page")
   public void they_continue_to_booking_page()
   {
      wait.forJSExecutionReadyLazy();
      wait.waitForAWhile(50000);
      paymentPage.paymentTypeComponent.selectFullPay();
      paymentPage.paymentOptionsComponent.clickPaymentMethod();
      paymentPage.paymentOptionsComponent.clickOnPayButton();
      wait.waitForAWhile(50000);
      wait.forJSExecutionReadyLazy();
      paymentPage.pspPage.enterCardDetails();
      wait.forJSExecutionReadyLazy();
      errorHandler.isPageLoadingCorrectly();
   }

   @Given("the {string} is on the package Payment page")
   public void the_is_on_the_package_Payment_page(String customer)
   {
      packageNavigation.navigateToPaymentPage();
   }

   @When("they click on the Checkout breadcrumb")
   public void they_click_on_the_Checkout_breadcrumb()
   {
      paymentPage.navigationComponent.clickOnCheckoutBreadCrumb();
   }

   @And("the payment option page should be displayed")
   public void the_payment_option_page_should_be_displayed()
   {
      boolean isDisplayed = paymentPage.navigationComponent.isPageDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Payment page wasn't loaded", isDisplayed, true), isDisplayed, is(true));
   }

}
