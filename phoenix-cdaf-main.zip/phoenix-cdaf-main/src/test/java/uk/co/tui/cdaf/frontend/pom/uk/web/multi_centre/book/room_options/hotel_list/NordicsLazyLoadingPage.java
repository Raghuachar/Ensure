package uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.room_options.hotel_list;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class NordicsLazyLoadingPage extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = ".SearchResults__resultsList [aria-label='accomodation name']")
   public List<WebElement> hotelsSize;

   @FindBy(css = ".UI__loadMoreResults")
   private WebElement toLast;

   @FindBy(css = ".UI__loadMoreResults p")
   private WebElement showing;

   @FindBy(css = ".UI__noMoreHolidays")
   private WebElement noMoreHotelsToshow;

   public NordicsLazyLoadingPage()
   {
      wait = new WebElementWait();
   }

   public boolean isElementDisplayed(WebElement element)
   {
      return WebElementTools.isPresent(element);
   }

   public Long getNoOfResult()
   {
      wait.forJSExecutionReadyLazy();
      return (Long) WebDriverUtils.executeScript("return jsonData.searchResult.endecaResultsCount");
   }

   public void scrollToLast()
   {
      WebElementTools.scrollTo(toLast);
      wait.forJSExecutionReadyLazy();
   }

   public WebElement getHotelWebElement(String compName)
   {
      compName = compName.trim().replace(" ", "");
      if (StringUtils.containsIgnoreCase(compName, "showing"))
      {
         return showing;
      }
      else if (StringUtils.containsIgnoreCase(compName, "noMoreHotelsToshow"))
      {
         return noMoreHotelsToshow;
      }
      else
      {
         return null;
      }
   }

   public void noMoreResult()
   {
      WebElementTools.scrollTo(noMoreHotelsToshow);
   }

}
