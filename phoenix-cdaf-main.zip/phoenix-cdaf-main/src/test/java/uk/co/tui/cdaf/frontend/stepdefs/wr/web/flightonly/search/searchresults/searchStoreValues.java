package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults;

import java.util.HashMap;

public class searchStoreValues
{
   private static HashMap<String, String> searchValues;

   private static String perPersonPrice;

   private static String totalPrice;

   public static HashMap<String, String> getSearchValues()
   {
      return searchValues;
   }

   public static void setSearchValues(HashMap<String, String> searchValues)
   {
      searchStoreValues.searchValues = searchValues;
   }

   public static String getPerPersonPrice()
   {
      return perPersonPrice;
   }

   public static void setPerPersonPrice(String perPersonPrice)
   {
      searchStoreValues.perPersonPrice = perPersonPrice;
   }

   public static String getTotalPrice()
   {
      return totalPrice;
   }

   public static void setTotalPrice(String totalPrice)
   {
      searchStoreValues.totalPrice = totalPrice;
   }

}
