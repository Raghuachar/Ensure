package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

public class AlternateFlightsPage extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[class='ProgressbarNavigation__summaryButton']")
   public WebElement continueButton;

   @FindBy(css = "[aria-label='Your accommodation']")
   public WebElement yourAccommodationComponent;

   @FindBy(css = "[id='HubAndSpokeSummaryRoomType_component']")
   public WebElement diffRoomComponent;

   @FindBy(css = "[id='YourFlightsSummary__component']")
   public WebElement yourFlightComponent;

   @FindBy(css = "[aria-label='show alt flights']")
   public WebElement viewAltFlightsLink;

   @FindBy(css = "[class='SummaryRoomComponent__selected SummaryRoomComponent__roomWrapper']")
   public WebElement selectedRoomComponent;

   @FindBy(css = "[id='PriceDiscountBreakDownV2__component']")
   public WebElement priceBreakdownText;

   @FindBy(css = ".SummaryRoomComponent__wrapper:nth-child(2) [aria-label='button']")
   public WebElement alternateRoomSelectButton;

   @FindBy(css = "[aria-label='alternative flight dates']")
   public WebElement dateCarousel;

   @FindAll({ @FindBy(css = "[aria-label='Direct Flights']"),
            @FindBy(css = "[aria-label='Indirect Flights']") })
   public WebElement alternativeFlights;

   @FindBy(css = "[class='carousel__carouselContainer']")
   public WebElement carouselDate;

   @FindBy(css = "[class='RoomAndBoard__info']")
   public List<WebElement> roomAndBoard;

   public AlternateFlightsPage()
   {
      wait = new WebElementWait();
   }

   public void LaunchApplication()
   {
      visit();
      wait.forJSExecutionReadyLazy();
   }

   public void clickOnBookAccomContinueButton()
   {
      WebElementTools.click(continueButton);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isYourAccommodationComponentDisplayed()
   {
      return WebElementTools.isPresent(yourAccommodationComponent);
   }

   public boolean isDiffRoomComponentDisplayed()
   {
      return WebElementTools.isPresent(diffRoomComponent);
   }

   public boolean isSelectedRoomDisplayed()
   {
      return WebElementTools.isPresent(selectedRoomComponent);
   }

   public boolean isYourFlightComponentDisplayed()
   {
      return WebElementTools.isPresent(yourFlightComponent);
   }

   public void clickOnViewAlternativeFlightLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(viewAltFlightsLink);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isAltFlightsComponentDisplayed()
   {
      return $(".AlternativeFlights__selectedSection").isDisplayed();
   }

   public void clickOnAltRoomButton()
   {
      WebElementTools.click(alternateRoomSelectButton);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isPriceBrekadownTextDisplayed()
   {
      return WebElementTools.isPresent(priceBreakdownText);
   }

   public boolean isDateCarouselIsPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(dateCarousel);
   }

   public boolean isAlternativeFlightIsPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(alternativeFlights);
   }

   public boolean isCarouselIsPresent()
   {
      return WebElementTools.isPresent(carouselDate);
   }

   public void alternativeFlightsButtonIsDisplayed()
   {
      assertTrue("alternative Flights component is not dsipayed", isAltFlightsComponentDisplayed());
   }

   public void verifyRoomAndBoard(String room, String boardbasis)
   {
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY, "Room are displayed",
                        room,
                        WebElementTools.getElementText(roomAndBoard.get(0)).replace("1× ", "")),
               StringUtils.equalsIgnoreCase(room,
                        WebElementTools.getElementText(roomAndBoard.get(0)).replace("1× ", "")),
               is(true));
      assertThat(
               ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                        "board basis are displayed",
                        boardbasis.replace("(", ""),
                        WebElementTools.getElementText(roomAndBoard.get(1))),
               StringUtils.contains(boardbasis.replace("(", "").replace(")", ""),
                        WebElementTools.getElementText(roomAndBoard.get(1)).toLowerCase()),
               is(true));
   }

}
