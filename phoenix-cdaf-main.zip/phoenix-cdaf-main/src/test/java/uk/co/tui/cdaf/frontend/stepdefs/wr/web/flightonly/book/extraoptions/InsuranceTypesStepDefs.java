package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.extraoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class InsuranceTypesStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(InsuranceTypesStepDefs.class);

   private final ExtraOptionsPage extraOptionsPage;

   private final WebElementWait wait;

   private String totalPriceBeforeUpgrade;

   public InsuranceTypesStepDefs()
   {
      extraOptionsPage = new ExtraOptionsPage();
      wait = new WebElementWait();
   }

   @When("they navigate to the Insurance Selection on the Insurance Component")
   public void they_navigate_to_the_Insurance_Selection_on_the_Insurance_Component()
   {
      extraOptionsPage.insuranceComponent.viewInsurance();
   }

   @Then("the component should display the following for each insurance type available to them:")
   public void the_component_should_display(List<String> components)
   {
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = extraOptionsPage.insuranceComponent
                     .getInsuranceTypeComponents().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("the insurance type accordions should be in a closed state")
   public void the_insurance_type_accordions_should_be_in_a_closed_state()
   {
      assertThat("insurance type accordions should be in a closed state",
               extraOptionsPage.insuranceComponent.getInsuranceDefaultClosed(), is(false));

   }

   @Then("the default selection should be I don't need insurance")
   public void the_default_selection_should_be_I_don_t_need_insurance()
   {
      assertThat("I don't need insurance default selected",
               extraOptionsPage.insuranceComponent.getInsuranceSeleted(), is(true));
   }

   @When("the Price Panel is before upgarding with the insurance")
   public void And_the_Price_Panel_is_upgarding_with_the_insurance()
   {
      totalPriceBeforeUpgrade = extraOptionsPage.pricePanelComponent.getTotalPriceValue();
      LOGGER.log(LogLevel.INFO, "totalPriceBeforeUpgrade" + totalPriceBeforeUpgrade);
   }

   @And("the selected insurance amount should get added to the total price")
   public void the_selected_insurance_amount_should_get_added_to_the_total_price()
   {

      wait.forJSExecutionReadyLazy();
      String totalPriceAfterUpgrade = extraOptionsPage.pricePanelComponent.getTotalPriceValue();
      LOGGER.log(LogLevel.INFO, "totalPriceAfterUpgrade" + totalPriceAfterUpgrade);
      assertThat(ReportFormatter.generateReportStatement("TotalPrice",
                        "values are same after luggage upgrade", totalPriceAfterUpgrade,
                        totalPriceBeforeUpgrade),
               StringUtils.equalsIgnoreCase(totalPriceAfterUpgrade, totalPriceBeforeUpgrade),
               is(false));

   }

}
