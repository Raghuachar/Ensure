package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.Selenide;
import io.cucumber.datatable.DataTable;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchCustom;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;
import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class SingleAccommodationComponent extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SingleAccommodationComponent.class);

   private static final String TRATING_REGEX = "\"tRating\":(.+?),";

   public final SearchPanelComponent searchPanelComponent;

   public final SearchCustom searchCustom;

   private final Map<String, WebElement> searchCardMap;

   private final WebElementWait wait;

   private final WebDriverUtils webDriverUtils;

   @FindBy(css = "[id='accomDetails__component']")
   private WebElement accomDetails;

   @FindBy(css = "[aria-label='input label']")
   private WebElement homepageDisplayed;

   @FindBy(css = ".UI__title")
   private WebElement unitName;

   @FindBy(css = ".Image__imgContainer")
   private WebElement hotelImage;

   @FindBy(css = ".UI__rating")
   private WebElement tRating;

   @FindBy(css = ".UI__locationBreadCrumb")
   private WebElement country;

   @FindBy(css = "[aria-label='departure-airports']")
   private WebElement departureAirport;

   @FindBy(css = "[aria-label='departure-airports'] option:enabled:not([value*='All'])")
   private List<WebElement> defaultSelection;

   @FindBy(css = "[aria-label='departure-airports'] option:disabled:not([value*='All'])")
   private WebElement depAirportGreyOut;

   @FindBy(css = "[aria-label='departure-airports'] option:enabled:not([value*='All'])")
   private WebElement selectdepartureAirport;

   @FindBy(css = "[aria-label='boardBasis']")
   private WebElement boardBasis;

   @FindBy(css = "[aria-label='boardBasis'] option:enabled:not([value*='Any'])")
   private List<WebElement> defaultSelectionAny;

   @FindBy(css = "[aria-label='boardBasis'] option:enabled:not([value*='Any'])")
   private WebElement selectBoardBasis;

   @FindBy(css = "[aria-label='boardBasis'] option:enabled:not([value*='Any'])")
   private List<WebElement> selectBoardBasisValue;

   @FindBy(css = "[class *='UI__lowPriceCell'] a span:nth-child(1)")
   private WebElement cheapestPrice;

   @FindBy(css = "#datesPrices > div > div.UI__indicators > p:nth-child(2)")
   private WebElement infoAndAllPriceDesc;

   @FindBy(css = "#datesPrices > div > div.UI__calendar > table > thead > tr")
   private WebElement weekRunningDays;

   @FindBy(css = ".UI__price")
   private List<WebElement> priceSelection;

   @FindBy(css = ".UI__calendar .UI__row .UI__date")
   private WebElement dateInCell;

   @FindBy(css = ".UI__monthSelector .UI__monthSelectList")
   private WebElement monthDropdown;

   @FindBy(css = ".UI__monthSelector .UI__monthNavigator svg")
   private WebElement navigationIcon;

   @FindBy(css = " .UI__calendar .UI__lowPriceCell .UI__date")
   private WebElement dateColouredGreen;

   @FindBy(css = " .UI__monthSelectList")
   private WebElement multipleMonths;

   @FindBy(css = ".UI__monthSelector .UI__monthNavigator svg")
   private List<WebElement> selectMonthNav;

   @FindBy(css = "#datesPrices > div > div.UI__monthSelector > div > div > select > option:nth-child(1)")
   private WebElement availableMonths;

   @FindBy(css = ".ProgressbarNavigation__progressBarNavigation")
   private WebElement unitDetailsPage;

   @FindBy(css = "#datesPrices > div > div.UI__indicators > p:nth-child(1)")
   private WebElement dotAndLowestPriceDesc;

   @FindBy(css = "[class='UI__allGoneBanner '] h1")
   private WebElement allGonePage;

   @FindBy(css = ".productIdentifier__productLogo ")
   private WebElement productLabel;

   @FindBy(css = "[aria-label='location destination name']")
   private WebElement destination;

   @FindBy(css = "[aria-label='alert-message']")
   private WebElement alertMessage;

   @FindBy(css = "[aria-label='alternate months link']")
   private List<WebElement> alternativeMonths;

   @FindBy(css = "[aria-label='single accom calendar']")
   private WebElement singleAccomCalendar;

   @FindBy(css = "[class='UI__monthSelector'] select")
   private WebElement monthSelector;

   @FindBy(css = "[class='SearchResults__noFade resultsWrapper']")
   private WebElement alternativeHotelCard;

   @FindBy(css = ".FilterPanelV2__alternateAllGoneHeader")
   private WebElement alternativeAllGoneHeader;

   @FindBy(css = "[aria-label='holiday count'] span")
   private WebElement hoildayCount;

   @FindBy(css = "[aria-label='alternate months container'] p")
   private WebElement availabilityMessage;

   @FindBy(css = "[aria-label='duration'] span+span")
   private List<WebElement> duration;

   @FindBy(css = "[class='SortResults__selectWrapper'] span+select option")
   private List<WebElement> sortByOptions;

   @FindBy(css = "[class='flitersPanel']")
   private WebElement searchResultsFilters;

   @FindBy(css = "[class='alerts__iconContent']")
   private WebElement iconContent;

   @FindBy(css = "[class=DeepLinkGenerator__deepLinkGenerator]")
   private WebElement deepLinkComponentIsnotDisplayed;

   @FindBy(css = "[id='accomDetails__component']")
   private List<WebElement> singleAccomDetails;

   @FindBy(css = "[aria-label='select destinations']")
   private List<WebElement> destinationLabel;

   @FindBy(css = ".UI__monthSelector .UI__monthSelectList option[value='0']")
   private WebElement leaveEarlierOption;

   @FindBy(css = "div.UI__mainTextContainer")
   private WebElement legacyMsgText;

   @FindBy(css = "div.UI__linkContent")
   private WebElement legacyHyperLinkText;

   public SingleAccommodationComponent()
   {
      wait = new WebElementWait();
      webDriverUtils = new WebDriverUtils();
      searchCardMap = new HashMap<>();
      searchPanelComponent = new SearchPanelComponent();
      searchCustom = new SearchCustom();
   }

   public boolean isSingleAccomDisplayed()
   {
      return WebElementTools.isPresent(accomDetails);
   }

   public void browserBack()
   {
      Selenide.back();
   }

   public boolean isHomePageDisplayed()
   {
      return WebElementTools.isPresent(getHomePage());
   }

   public WebElement getHomePage()
   {
      return wait.getWebElementWithLazyWait(homepageDisplayed);
   }

   public Map<String, WebElement> getHotelCardDetailsWebElement(List<String> compName)
   {
      wait.forJSExecutionReadyLazy();
      Map<String, WebElement> mapList = new HashMap<>();
      for (String comp : compName)
      {
         String compKey = StringUtils.lowerCase(comp.trim());
         if (containsText(compKey, "Unit name"))
            mapList.put(compKey, unitName);
         if (containsText(compKey, "Hotel image"))
            mapList.put(compKey, hotelImage);
         if (containsText(compKey, "T rating") && isCompAvailable(TRATING_REGEX))
            mapList.put(compKey, tRating);
         if (containsText(compKey, "Destination & country"))
            mapList.put(compKey, country);

      }
      return mapList;
   }

   public boolean isCompAvailable(String regex)
   {
      return webDriverUtils.findTagValue(getDriver().getPageSource(), regex) != null;
   }

   public boolean containsText(String compKey, String text)
   {
      return StringUtils.containsIgnoreCase(compKey, text);
   }

   public boolean isElementDisplayed(WebElement element)
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(element);
   }

   public boolean isDepartureAirportDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(departureAirport);
   }

   public void selectDepartureAirportDropdown()
   {
      WebElementTools.click(departureAirport);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isDefaultSelectionDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(defaultSelection.get(0));
   }

   public void selectDepartureAirport()
   {
      WebElementTools.click(selectdepartureAirport);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isGreyedOutOptionDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(depAirportGreyOut);
   }

   public String getCheapestPriceForSingleAccomm()
   {
      try
      {
         return WebElementTools.getElementText(cheapestPrice).trim();
      }
      catch (Exception e)
      {
         return StringUtils.EMPTY;
      }
   }

   public boolean isBoardBasisDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(boardBasis);
   }

   public void selectBoardBasisDropdown()
   {
      WebElementTools.click(boardBasis);
      wait.forJSExecutionReadyLazy();
   }

   public boolean isDefaultSelectionAnyDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(defaultSelectionAny.get(0));
   }

   public void selectBoardBasis()
   {
      WebElementTools.click(selectBoardBasis);
      wait.forJSExecutionReadyLazy();
   }

   public void selectBoardBasisValue()
   {
      if (selectBoardBasisValue.size() > 1)
         WebElementTools.click(selectBoardBasisValue.get(1));
      else
         WebElementTools.click(selectBoardBasisValue.get(0));
      wait.forJSExecutionReadyLazy();
   }

   public boolean isLowestPriceDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(cheapestPrice);
   }

   public boolean isUnitElementDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(unitName);
   }

   public boolean isWeekrunningDaysPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(weekRunningDays);
   }

   public boolean isPriceinEuroPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(priceSelection.get(1));
   }

   public boolean isDatePresentInCell()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(dateInCell);
   }

   public boolean isMonthDropdownPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(monthDropdown);
   }

   public boolean isNavigationIconPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(navigationIcon);
   }

   public boolean isMultipleMonthsDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(multipleMonths);
   }

   public void selectMonthNav()
   {
      WebElementTools.click(selectMonthNav.get(1));
      wait.forJSExecutionReadyLazy();

   }

   public void selectMonthDropdown()
   {
      WebElementTools.click(monthDropdown);
      wait.forJSExecutionReadyLazy();

   }

   public boolean isMonthsPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(availableMonths);
   }

   public void selectDateCell()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(priceSelection.get(1));
      wait.forJSExecutionReadyLazy();
   }

   public boolean isNavigatedToUnitDetailsPage()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(unitDetailsPage);
   }

   public boolean isGreenDotAndLowestPriceDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(dotAndLowestPriceDesc);
   }

   public boolean isDateColouredGreen()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(dateColouredGreen);
   }

   public boolean isInfoAndAllPriceDescDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(infoAndAllPriceDesc);
   }

   public boolean isAllGonePageDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(allGonePage);
   }

   public boolean isAllGoneAlternativePageDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(alertMessage);
   }

   public Map<String, WebElement> getAllGoneAlternativeComponents()
   {
      wait.forJSExecutionReadyLazy();
      searchCardMap.put("Unit image with product label", productLabel);
      searchCardMap.put("Unit name", unitName);
      searchCardMap.put("destination", destination);
      searchCardMap.put(
               "Were sorry, there is no availability for this hotel on the dates you selected. Please see our other available dates or hotels.",
               alertMessage);
      searchCardMap.put("We have availability at this hotel for these months:",
               availabilityMessage);
      return searchCardMap;

   }

   public String getUnitName()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(unitName);
   }

   public List<Dimension> isAvailableDepartureMonths()
   {
      wait.forJSExecutionReadyLazy();
      List<Dimension> alternative = new ArrayList<>();
      if (!alternativeMonths.isEmpty())
         alternativeMonths.forEach(action ->
         {
            Dimension alternativeMonths = action.getSize();
            alternative.add(alternativeMonths);
         });
      return alternative;
   }

   public void clickOnAvailableDepartureMonths()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(alternativeMonths.get(0));
   }

   public boolean isSingleAccomCalenderDisplayed()
   {
      return WebElementTools.isPresent(singleAccomCalendar);
   }

   public void clickOnChangeMonthSelector()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.selectDropDownByIndex(monthSelector, 0);
   }

   public boolean alternativeHotelCard()
   {
      return WebElementTools.isDisplayed(alternativeHotelCard);
   }

   public Map<String, WebElement> getAlternativeHotelsComponents()
   {
      searchCardMap.put("Are you flexible on your hotel?", alternativeAllGoneHeader);
      searchCardMap.put("[Number] holidays found in [Destination] region", hoildayCount);
      searchCardMap.put("Durations available", duration.get(0));
      searchCardMap.put("Sort by dropdown and options", sortByOptions.get(0));
      searchCardMap.put("Search result filters", searchResultsFilters);
      return searchCardMap;
   }

   public Map<String, WebElement> getIconErrorMsgComponent()
   {
      searchCardMap.put("Icon", alternativeAllGoneHeader);
      searchCardMap.put(
               "We re sorry, there is no availability for this hotel on the dates you selected. Please see our other available dates or hotels.",
               iconContent);
      return searchCardMap;
   }

   public void alternativeMonthsInDeeplink(String data)
   {
      if (searchCustom.getCheckoutDays().equals("true"))
      {
         Matcher r =
                  Pattern.compile("when=(.+?)&until")
                           .matcher(WebDriverUtils.getDriver().getCurrentUrl());
         if (r.find())
         {
            String updatedUrl = getDriver().getCurrentUrl().replace(r.group(1), data);
            open(updatedUrl);
         }
      }
   }

   public void deeplinkGenerator(String deeplink)
   {
      String updatedUrl = getDriver().getCurrentUrl().concat(deeplink);
      open(updatedUrl);
   }

   public boolean alternativePastMonth()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(alternativeMonths.get(0));
   }

   public boolean hotelCard()
   {
      return WebElementTools.isDisplayed(destination);
   }

   public String getPastAvailaibityMonth()
   {
      return WebElementTools.getElementText(alternativeMonths.get(0));
   }

   public boolean isDeepLinkComponentIsnotDisplayed()
   {
      return WebElementTools.isDisplayed(deepLinkComponentIsnotDisplayed);
   }

   public String getVRating()
   {
      return WebElementTools.getElementText(tRating);
   }

   public boolean verifyingSingleAccomSearchCard()
   {
      boolean flag = false;
      for (int i = 0; i < singleAccomDetails.size(); i++)
      {
         flag = singleAccomDetails.get(0).isDisplayed();
         if (!flag)
            break;
      }
      return flag;
   }

   public boolean verifySingleAccomRegionInLocation(DataTable dataTable)
   {
      boolean value = false;
      final List<String> names = dataTable.asList();
      final List<String> locations = Arrays.asList(accomDetails.getText().split(","));
      LOGGER.log(LogLevel.INFO, locations);
      if (names.size() == locations.size())
      {
         value = true;
      }
      return value;
   }

   public boolean isSingleAccomDestinationDisplayed()
   {
      return $("div[aria-label='single-accom-details']").isDisplayed();
   }

   public boolean isLeaveEarlierOptionDisplayed()
   {
      selectMonthDropdown();
      return WebElementTools.isPresent(leaveEarlierOption);
   }

   public void clickOnLeaveEarlierOption()
   {
      WebElementTools.click(leaveEarlierOption);
   }

   public String getLegacyMsgText()
   {
      return WebElementTools.getElementText(legacyMsgText);
   }

   public String getLegacyHyperLinkText()
   {
      return WebElementTools.getElementText(legacyHyperLinkText);
   }

   public boolean isLegacyMsgDisplayed()
   {
      return WebElementTools.isPresent(legacyMsgText);
   }
}
