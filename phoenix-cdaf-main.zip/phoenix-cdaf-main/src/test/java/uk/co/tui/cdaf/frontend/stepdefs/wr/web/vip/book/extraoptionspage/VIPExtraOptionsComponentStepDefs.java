package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.book.extraoptionspage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.extraOptions.VIPExtraOptionsPage;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class VIPExtraOptionsComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public final VIPExtraOptionsPage vipExtraOptionsPage;

   public VIPExtraOptionsComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      vipExtraOptionsPage = new VIPExtraOptionsPage();
   }

   @Given("that that the customer is on the Customise page")
   public void that_that_the_customer_is_on_the_Customise_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they navigate to the Extras page")
   public void they_navigate_to_the_Extras_page()
   {
      packageNavigation.navigateToExtrasPage();
   }

   @Then("they are presented with the following Extra Options Page components:")
   public void they_are_presented_with_the_following_Extra_Options_Page_components(
            List<String> components)
   {
      vipExtraOptionsPage.getVipExtraOptionsPageComponentsMap();
   }

   @And("insurance component is not displaying")
   public void insurance_component_is_not_displaying()
   {
      assertThat("Insurance component is displayed",
               vipExtraOptionsPage.isInsuranceComponentDisplayed(), is(false));
   }
}
