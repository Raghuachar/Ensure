package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import static com.codeborne.selenide.Selenide.executeJavaScript;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class MarketingPermissionTPBtoBStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   RetailPassengerDetailsPage retailPassengerPage;

   public MarketingPermissionTPBtoBStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailPassengerPage = new RetailPassengerDetailsPage();

   }

   @Given("that the agent is on the Passenger Details Page")
   public void that_the_agent_is_on_the_Passenger_Details_Page()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();

   }

   @When("they scroll down the page in passenger details")
   public void they_scroll_down_the_page_in_passenger_details()
   {
      executeJavaScript("window.scrollBy(0, 500)");
   }

   @Then("they are able to see that there is no marketing permissions component visible")
   public void they_are_able_to_see_that_there_is_no_marketing_permissions_component_visible()
   {
      assertThat("marketingPermissions is not present",
               retailPassengerPage.marketingPermissions().isDisplayed(), is(false));
   }

   @Given("that the agent is on the TP Passenger Details Page")
   public void that_the_agent_is_on_the_TP_Passenger_Details_Page()
   {
      retailpackagenavigation.loginToRetailThirdParty();
      retailpackagenavigation.navigateToPassengerPage();

   }

   @When("they are presented with the passenger details fields")
   public void they_are_presented_with_the_passenger_details_fields()
   {
      retailPassengerPage.passengerDetailisDisplayed();

   }

   @Then("they should see the following data attributes to be populated:")
   public void they_should_see_the_following_data_attributes_to_be_populated(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Gender displayed",
               WebElementTools.isPresent(retailPassengerPage.getGenderTitle()), is(true));
      assertThat("Firstname displayed",
               WebElementTools.isPresent(retailPassengerPage.getFirstnameTitle()), is(true));
      assertThat("Surname  displayed",
               WebElementTools.isPresent(retailPassengerPage.getSurnameTitle()), is(true));
      assertThat("TelephoneNumber displayed",
               WebElementTools.isPresent(retailPassengerPage.getTelephoneNumberTitle()), is(true));
      assertThat("EmailAddress  displayed",
               WebElementTools.isPresent(retailPassengerPage.getEmailAddressTitle()), is(true));
      retailPassengerPage.fillThePassengerDetailsThirdparty();

   }

   @Then("they can see that there are no fields for capturing passenger address")
   public void they_can_see_that_there_are_no_fields_for_capturing_passenger_address()
   {
      retailPassengerPage.passengeraddressisnotDisplayed();

   }

   @Given("that the agent is on the TP retail Passenger Details Page")
   public void that_the_agent_is_on_the_TP_retail_Passenger_Details_Page()
   {
      retailpackagenavigation.loginToRetailThirdParty();
      retailpackagenavigation.navigateToPassengerPage();
   }

}
