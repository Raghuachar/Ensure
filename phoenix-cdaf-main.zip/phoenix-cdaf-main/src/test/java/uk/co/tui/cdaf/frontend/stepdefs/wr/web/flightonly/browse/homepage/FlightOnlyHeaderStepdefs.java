package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.browse.homepage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.CommonPagesImplementation;
import uk.co.tui.cdaf.utils.ConfigurationConstants;
import uk.co.tui.cdaf.utils.ConfigurationService;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.transformer.WesternRegionComponents;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FlightOnlyHeaderStepdefs
{
   private final FlightOnlyHomePage homepage;

   private final CommonPagesImplementation wrCommonPage;

   private String translationCode;

   public FlightOnlyHeaderStepdefs()
   {
      homepage = new FlightOnlyHomePage();
      wrCommonPage = new CommonPagesImplementation();
   }

   @Given("a {string} is on the TUI fly homepage")
   public void a_is_on_the_TUI_fly_homepage(String string)
   {
      homepage.visit();
   }

   @When("they view the TUI Fly Global Header")
   public void they_view_the_TUI_Fly_Global_Header()
   {
      homepage.viewHeader();

   }

   @Then("the following options should be displayed in this order in TUI Fly Global Header:")
   public void the_following_options_should_be_displayed_in_this_order_in_TUI_Fly_Global_Header(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<WesternRegionComponents> headerComp = dataTable.asList(WesternRegionComponents.class);

      headerComp.forEach(row -> assertThat(
               row.getComponent() + " Label is not displayed/not in order \n Expected: "
                        + row.getTranslationValue(translationCode.split("-")[1]) + "\n Actual: "
                        + homepage.getHeaderLabel(row.getComponent()),
               homepage.checkHeaderLabel(homepage.getHeaderLabel(row.getComponent()),
                        row.getTranslationValue(translationCode.split("-")[1])),
               is(true)));
   }

   @When("they have selected {string} language on {string} TUIFLY website")
   public void they_have_selected_language_on_website(String language, String country)
   {
      translationCode = wrCommonPage.getTranslationCode(language, country);
      homepage.changeCountryLanguage(language, country);
      if (ConfigurationService.getProperty(ConfigurationConstants.SELENIUM_BROWSER)
               .contains("mobile"))
      {
         homepage.clickBurgerMenu();
      }
      homepage.setHeaderLabelMap();
      homepage.setHeaderCompMap();
   }

   @Then("they will see the following secondary options in this order in TUI fly header:")
   public void they_will_see_the_following_secondary_options_in_this_order_in_TUI_fly_header(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<WesternRegionComponents> headerComp = dataTable.asList(WesternRegionComponents.class);

      headerComp.forEach(row -> assertThat(
               row.getComponent() + " Label is not displayed/not in order \n Expected: "
                        + row.getTranslationValue(translationCode.split("-")[1]) + "\n Actual: "
                        + homepage.getHeaderLabel(row.getComponent()),
               homepage.checkHeaderLabel(homepage.getHeaderLabel(row.getComponent()),
                        row.getTranslationValue(translationCode.split("-")[1])),
               is(true)));
   }

   @Then("they will see the following options in this order in TUI fly Burger Menu:")
   public void they_will_see_the_following_options_in_this_order_in_TUI_fly_Burger_Menu(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<WesternRegionComponents> headerComp = dataTable.asList(WesternRegionComponents.class);

      headerComp.forEach(row -> assertThat(
               row.getComponent() + " Label is not displayed/not in order \n Expected: "
                        + row.getTranslationValue(translationCode.split("-")[1]) + "\n Actual: "
                        + homepage.getHeaderLabel(row.getComponent()),
               homepage.checkHeaderLabel(homepage.getHeaderLabel(row.getComponent()),
                        row.getTranslationValue(translationCode.split("-")[1])),
               is(true)));
   }

   @When("they view the TUIFLY WR Global Header")
   public void they_view_the_TUIFLY_WR_Global_Header()
   {
      homepage.viewHeader();
      homepage.setHeaderLabelMap();
      homepage.setHeaderCompMap();
   }

   @Then("I will see the following Icons in TUIFLY header as per prod:")
   public void i_will_see_the_following_Icons_in_TUIFLY_header_as_per_prod(List<String> icons)
   {

      icons.forEach(component ->
      {
         try
         {
            assertThat(component + " componenet is not displayed",
                     WebElementTools.isPresent(homepage.getHeaderPageMap().get(component)),
                     is(true));
         }
         catch (Exception e)
         {
            assertThat(component + " componenet is not displayed", is(false), is(true));
         }

      });
   }

   @Then("they will see a logo for TUI fly \\(as per the visuals)")
   public void they_will_see_a_logo_for_TUI_fly_as_per_the_visuals()
   {
      assertThat(" TUI FLY Logo is not displayed", homepage.checkTUIFLYLogo(), is(true));
   }

   @Then("they will see a Language & Country selector on TUIFLY \\(as per the visuals)")
   public void they_will_see_a_Language_Country_selector_on_TUIFLY_as_per_the_visuals()
   {
      assertThat(" TUI FLY Language & Country selector is not displayed",
               WebElementTools.isPresent(homepage.getHeaderComponent().getCountrySwitcherLink()),
               is(true));
   }

   @Given("a {string} is viewing the TUI Fly header")
   public void a_is_viewing_the_TUI_Fly_header(String string)
   {
      homepage.viewHeader();
   }

   @When("they click the country flag or language code in the TUI Fly header")
   public void they_click_the_country_flag_or_language_code_in_the_TUI_Fly_header()
   {
      homepage.clickCountryChangeLink();
   }

   @Then("the country and language selector will open in a modal \\(design attached)")
   public void the_country_and_language_selector_will_open_in_a_modal_design_attached()
   {
      assertThat(" TUI FLY Language & Country selector is not displayed", WebElementTools.isPresent(
               homepage.getHeaderComponent().getClOverlayComp().getOverlayText()), is(true));
   }

   @Given("a {string} has opened the country and language selector")
   public void a_has_opened_the_country_and_language_selector(String string)
   {
      homepage.clickCountryChangeLink();
   }

   @When("they view the country and language selector modal")
   public void they_view_the_country_and_language_selector_modal()
   {
      homepage.getCountrySelectorInView();
   }

   @Then("they should see the following in country and language selector modal:")
   public void they_should_see_the_following_in_country_and_language_selector_modal(
            List<String> items)
   {
      assertThat("Text componenet is not displayed",
               WebElementTools.isPresent(homepage.getHeaderComponent().getCountryLangSelectorComp()
                        .getOverlayText()), is(true));
      assertThat("Country Dropdown label is not displayed",
               WebElementTools.isPresent(homepage.getHeaderComponent().getCountryLangSelectorComp()
                        .getCountryLabelInModal()), is(true));
      assertThat("Country Dropdown is not displayed",
               WebElementTools.isPresent(homepage.getHeaderComponent().getCountryLangSelectorComp()
                        .getSelectedCountry()), is(true));
      assertThat("Language Dropdown label componenet is not displayed",
               WebElementTools.isPresent(homepage.getHeaderComponent().getCountryLangSelectorComp()
                        .getLanguageLabelInModal()), is(true));
      assertThat("Language dropdown componenet is not displayed",
               WebElementTools.isPresent(homepage.getHeaderComponent().getCountryLangSelectorComp()
                        .getSelectedlanguage()), is(true));
   }

   @When("they view the country list dropdown in country and language selector")
   public void they_view_the_country_list_dropdown_in_country_and_language_selector()
   {

      homepage.getCountrySelectorInView();
   }

   @Then("the following options should be displayed in alphabetically with corresponding flag displayed next to each name:")
   public void the_following_options_should_be_displayed_in_alphabetically_with_corresponding_flag_displayed_next_to_each_name(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Countries in dropdowns is not as per requirement",
               homepage.validateCountriesInDropdown(), is(true));

   }

   @When("they view the language list dropdown in country and language selector")
   public void they_view_the_language_list_dropdown_in_country_and_language_selector()
   {
      homepage.getCountrySelectorInView();
   }

   @Then("the following language options should be displayed in this order:")
   public void the_following_language_options_should_be_displayed_in_this_order(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Languages in dropdowns is not as per requirement",
               homepage.validateLanguagesInDropdown(), is(true));
   }

   @When("they select a country in country and language selector")
   public void they_select_a_country_in_country_and_language_selector()
   {
      homepage.clickCountryInDropdown();
   }

   @Then("a tick will be displayed next to the country")
   public void a_tick_will_be_displayed_next_to_the_country()
   {
      assertThat(" Tick for Country is not displayed", WebElementTools.isPresent(
                        homepage.getHeaderComponent().getCountryLangSelectorComp().getCountryTick()),
               is(true));
   }

   @When("they select a language in country and language selector")
   public void they_select_a_language_in_country_and_language_selector()
   {
      homepage.clickLanguageInDropdown();
   }

   @Then("a tick will be displayed next to the language")
   public void a_tick_will_be_displayed_next_to_the_language()
   {
      assertThat(" Tick for Language is not displayed", WebElementTools.isPresent(
                        homepage.getHeaderComponent().getCountryLangSelectorComp().getCountryTick()),
               is(true));
   }

}
