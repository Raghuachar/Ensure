package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FlightSummaryComponent extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(FlightSummaryComponent.class);

   private static String departureDate;

   private static String date;

   private final WebElementWait wait;

   @FindBy(css = "[aria-label='confirmation holiday summary']")
   private WebElement flightSummary;

   @FindBy(css = "[aria-label='pax composition']")
   private WebElement paxComposition;

   @FindBy(css = "[aria-label='price per person']")
   private WebElement perPersonPrice;

   @FindBy(css = "[aria-label*='Out']")
   private WebElement outboundSection;

   @FindBy(css = "[aria-label*='Rtn']")
   private WebElement inboundSection;

   @FindBy(css = "[aria-label='flight seats']")
   private List<WebElement> flightSeats;

   @FindBy(css = "[aria-label='flight luggage']")
   private List<WebElement> flightLuggage;

   @FindAll({ @FindBy(css = "[aria-label*='Out: flight Details'] p"),
            @FindBy(xpath = "//div[contains(@aria-label,'flight Details')]/p[1]") })
   private List<WebElement> flightDetailsInfo;

   public FlightSummaryComponent()
   {
      wait = new WebElementWait();
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getFlightSummaryComponents()
   {
      return new HashMap<>()
      {
         {
            put("Flight Summary", flightSummary);
            put("Pax composition", paxComposition);
            put("Per person price", perPersonPrice);
            put("Outbound", outboundSection);
            put("Inbound", inboundSection);
            put("Flight seats", flightSeats.get(0));
            put("Flight luggage", flightLuggage.get(0));
         }
      };
   }

   public void setDepartureMonthYear()
   {
      try
      {
         wait.forJSExecutionReadyLazy();
         wait.waitForAWhile(2000);
         wait.waitForElementToBePresent(getFlightDetails());
         List<WebElement> flightDates = getFlightDetails();
         String departureMonthYear = WebElementTools.getElementText(flightDates.get(0)).trim();
         String holidayText = WebElementTools.getElementText(flightDates.get(0)).trim();
         String[] holidayTextSplit = holidayText.split(" ");
         date = convertMonthShortToFullText(holidayTextSplit[2]) + " " + holidayTextSplit[3];
         if (date.contains("."))
         {
            date = date.replace(".", "");
         }
      }
      catch (ParseException e)
      {
         LOGGER.log(LogLevel.ERROR, "Exception:" + e);
      }
   }

   public String getDepartureMonthYear()
   {
      return date;
   }

   public String convertMonthShortToFullText(String monthName) throws ParseException
   {
      SimpleDateFormat formatter = new SimpleDateFormat("MMMM");
      Date date = formatter.parse(monthName);
      return formatter.format(date);
   }

   public List<WebElement> getFlightDetails()
   {
      return wait.getWebElementWithLazyWait(flightDetailsInfo);
   }

   public void setDepatureDate()
   {
      List<WebElement> flightDates = getFlightDetails();
      departureDate = WebElementTools.getElementText(flightDates.get(0)).trim();
      String[] newDate = departureDate.split(" ");
      departureDate = newDate[1];
      if (departureDate.startsWith("0"))
      {
         String[] departureDateVal = newDate[1].split("0");
         departureDate = departureDateVal[1];
      }
   }

   public String getDepartureDate()
   {
      return departureDate;
   }

   public String getOutboundFlightDepDate()
   {
      setDepatureDate();
      return getDepartureDate();

   }

   public String getFlightDepartureMonthYear()
   {
      setDepartureMonthYear();
      return getDepartureMonthYear();
   }

}
