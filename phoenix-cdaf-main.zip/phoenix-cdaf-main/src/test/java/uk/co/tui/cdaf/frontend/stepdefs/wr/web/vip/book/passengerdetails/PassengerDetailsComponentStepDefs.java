package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.book.passengerdetails;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.passengerdetails.PassengerDetailsPage;

import java.util.List;

public class PassengerDetailsComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public final PassengerDetailsPage passengerDetailsPage;

   public PassengerDetailsComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      passengerDetailsPage = new PassengerDetailsPage();
   }

   @Given("that that the customer is on the VIP Customise page")
   public void that_that_the_customer_is_on_the_VIP_Customise_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they select to continue to the VIP Passenger Details page")
   public void they_select_to_continue_to_the_VIP_Passenger_Details_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @Then("they are presented with the following VIP components:")
   public void they_are_presented_with_the_following_VIP_components(List<String> components)
   {
      passengerDetailsPage.getVipSummaryComponentsMap();
   }
}
