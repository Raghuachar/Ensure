package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class PackagePreviousReconciliationsPageComponents extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackagePreviousReconciliationsPageComponents.class);

   public final WebElementWait wait;

   @FindBy(css = "[aria-label='previousReconciliation']")
   private WebElement previousReconciliationLink;

   @FindBy(css = ".buttons__search")
   private WebElement searchButton;

   @FindAll({ @FindBy(css = "[aria-label='button']"),
            @FindBy(css = ".buttons__button buttons__search buttons__fill Search__seodbSectionSplit") })
   private WebElement seodbSearchButton;

   @FindBy(css = ".ReconcilePaymentTable__seodbTableWrapper")
   private WebElement searchResultContainer;

   @FindBy(css = "[aria-label='total discrepancies label']")
   private WebElement totalDiscrepanciesLabel;

   @FindBy(css = "[aria-label='total discrepancies amount']")
   private WebElement totalDiscrepanciesAmount;

   @FindBy(css = ".Search__seodbSearchSectionWrapper")
   private WebElement searchBar;

   @FindBy(css = "[aria-label=\"text input\"]")
   private List<WebElement> dateInput;

   @FindAll({ @FindBy(css = ".DatePicker__cell"), @FindBy(css = ".DatePicker__available") })
   private List<WebElement> availableDates;

   @FindBy(css = ".Search__seodbSectionSplitEditSearch")
   private List<WebElement> selectedDates;

   @FindBy(css = ".Search__seodbSectionSplit")
   private WebElement editSearchCTA;

   @FindBy(css = "[aria-label='backToReconcilePaymentsPage']")
   private WebElement backToReconciliationPage;

   @FindAll({ @FindBy(css = ".UI__diarySubmitErrorWrapper h4") })
   private WebElement previousSameDateSearchErrorMessages;

   @FindAll({ @FindBy(css = ".UI__diarySubmitErrorWrapper p") })
   private WebElement previousReconciliationSameDateSearchErrorsBOX;

   public PackagePreviousReconciliationsPageComponents()
   {
      wait = new WebElementWait();
   }

   public void navigateToPreviousReconciliationPage()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(previousReconciliationLink);
   }

   public void clickSearchButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(searchButton);
   }

   public boolean isSearchResultContainer()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(searchResultContainer);
   }

   public boolean isTotalDiscrepanciesLabel()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(totalDiscrepanciesLabel);
   }

   public boolean isTotalDiscrepanciesAmount()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(totalDiscrepanciesAmount);
   }

   public void searchBarDisplayed()
   {
      WebElementTools.isDisplayed(searchBar);
   }

   public void selectDates()
   {
      WebElementTools.mouseOverAndClick(dateInput.get(0));
      WebElementTools.click(availableDates.get(0));
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(dateInput.get(1));
      WebElementTools.click(availableDates.get(1));
   }

   public void clickOnSearchCTA()
   {
      WebElementTools.mouseOverAndClick(searchButton);
   }

   public void clickOnSeodbSearchCTA()
   {
      WebElementTools.mouseOverAndClick(seodbSearchButton);
   }

   public boolean isFromDateDisplayed()
   {
      return WebElementTools.isDisplayed(selectedDates.get(0));
   }

   public boolean isToDateDisplayed()
   {
      return WebElementTools.isDisplayed(selectedDates.get(1));
   }

   public boolean isEditSearchCTADisplayed()
   {
      return WebElementTools.isDisplayed(editSearchCTA);
   }

   public boolean isFromDateInputVisible()
   {
      return WebElementTools.isDisplayed(dateInput.get(0));
   }

   public boolean isToDateInputVisible()
   {
      return WebElementTools.isDisplayed(dateInput.get(1));
   }

   public void selectNewDates()
   {
      WebElementTools.mouseOverAndClick(dateInput.get(0));
      WebElementTools.click(availableDates.get(2));
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(dateInput.get(1));
      WebElementTools.click(availableDates.get(3));
   }

   public void selectNewDatesToDateOPtion()
   {
      WebElementTools.mouseOverAndClick(dateInput.get(0));
      WebElementTools.click(availableDates.get(2));
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(dateInput.get(1));
      WebElementTools.click(availableDates.get(2));
   }

   public void clickBackToReconciliationPageLink()
   {
      LOGGER.log(LogLevel.INFO, "BackToReconciliationPageLink is present in Header:");
      WebElementTools.mouseOverAndClick(backToReconciliationPage);
   }

   public boolean isSeodbSameDateSearchErrorMeassgaes()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(previousSameDateSearchErrorMessages);
   }

   public boolean isSeodbSameDateSearchErrorsBox()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(previousReconciliationSameDateSearchErrorsBOX);
   }

}
