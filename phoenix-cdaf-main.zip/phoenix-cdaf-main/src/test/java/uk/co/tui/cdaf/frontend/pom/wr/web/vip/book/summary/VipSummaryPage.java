package uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.summary;

import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class VipSummaryPage
{
   public final VIPFlightAndLuggageComponent flightAndLuggage;

   public final VIPFuelProtectionComponent fuelProtection;

   public final VIPLuggageComponent vipLuggageComponent;

   public final VIPCabinClassComponent vipCabinClassComponent;

   public final WebElementWait wait;

   public VipSummaryPage()
   {
      flightAndLuggage = new VIPFlightAndLuggageComponent();
      fuelProtection = new VIPFuelProtectionComponent();
      vipLuggageComponent = new VIPLuggageComponent();
      vipCabinClassComponent = new VIPCabinClassComponent();
      wait = new WebElementWait();
   }
}
