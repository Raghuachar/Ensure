package uk.co.tui.cdaf.api.pojo.search.mfe;

import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RoomManager
{
   private final List<Room> rooms;

   public RoomManager()
   {
      this.rooms = new ArrayList<>();
   }

   public void addRoom(Room room)
   {
      rooms.add(room);
   }

   /**
    * Adds rooms to the room manager based on the test data attributes
    * It's presumed that number of rooms is always 1 and all adults and children are in the same room
    */
   public void addRooms(@Nullable TestDataAttributes testDataAttributes)
   {
      if (testDataAttributes == null)
      {
         addRoom(new Room(1, "2", "0", ""));
         return;
      }
      addFirstRoom(testDataAttributes);
      String roomCountStr = testDataAttributes.getRoomCount();
      if (roomCountStr != null && !roomCountStr.isEmpty() && !"1".equals(roomCountStr))
      {
         int roomCount = Integer.parseInt(roomCountStr) - 1;
         for (int i = 1; i <= roomCount; i++)
         {
            addRoom(new Room(i + 1, "1", "0", ""));
         }
      }
   }

   private void addFirstRoom(@NotNull TestDataAttributes testDataAttributes)
   {
      String adults = Optional.ofNullable(testDataAttributes.getNoOfAdults()).orElse("2");
      String children = Optional.ofNullable(testDataAttributes.getNoOfChildren()).orElse("0");
      String childrenAges = Optional.ofNullable(testDataAttributes.getChildrenAge()).orElse("");
      addRoom(new Room(1, adults, children, childrenAges));
   }

   public String getAddultsNumber()
   {
      return rooms.get(0).getAdults();
   }

   public String getChildrensNumber()
   {
      return rooms.get(0).getKids();
   }

   public String getChildrensAge()
   {
      return rooms.get(0).getKidsAges();
   }

   public List<Room> getRooms()
   {
      return this.rooms;
   }
}
