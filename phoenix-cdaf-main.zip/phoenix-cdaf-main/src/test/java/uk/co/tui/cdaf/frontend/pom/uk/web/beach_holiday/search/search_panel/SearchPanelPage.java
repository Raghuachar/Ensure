package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel;

import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class SearchPanelPage extends AbstractPage
{
   public SearchPanelComponent searchPanelComponent = new SearchPanelComponent();

   public String getErrorMessage()
   {
      try
      {
         return WebElementTools.getElementText(searchPanelComponent.getErrorElement().get(0))
                  .trim();
      }
      catch (Exception e)
      {
         return StringUtils.EMPTY;
      }
   }

}
