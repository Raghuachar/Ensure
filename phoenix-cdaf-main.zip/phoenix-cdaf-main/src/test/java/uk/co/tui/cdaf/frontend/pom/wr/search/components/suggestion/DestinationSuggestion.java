package uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion;

import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.Destination;

import java.util.List;

public interface DestinationSuggestion
{

   List<SelenideElement> getAllSuggestionElements();

   SelenideElement getSearchAllDestinationBtn();

   SelenideElement getNoMatchElement();

   Destination clickAllDestinationBtn();

   void selectSuggestionFromList(String suggestion);
}
