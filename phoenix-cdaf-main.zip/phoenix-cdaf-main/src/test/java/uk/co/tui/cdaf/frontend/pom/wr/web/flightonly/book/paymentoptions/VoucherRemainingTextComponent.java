package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class VoucherRemainingTextComponent extends AbstractPage
{
   @FindBy(css = "#voucherCode__component > div > div > div:nth-child(2) > div.VoucherCode__voucherCodeList > div:nth-child(2) > span")
   private WebElement voucherRemainingText;

   public boolean isVoucherRemainingTextDisplayed()
   {
      return WebElementTools.isPresent(voucherRemainingText);
   }
}
