package uk.co.tui.cdaf.api.pojo.search.legacy;

import uk.co.tui.cdaf.api.pojo.search.legacy.airport.Data;

@lombok.Data
public class AirportsResponse
{
   private String error;

   private int errorCode;

   private Data data;

}

