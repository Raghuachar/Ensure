package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import com.codeborne.selenide.Selenide;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.hamcrest.Matchers;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HeaderComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.browse.homepage.HomePageCommon;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PackagesitesLanguageSetUpForB2CNB2BStepDefs
{
   private final PackageNavigation packageNavigation;

   private final HeaderComponent headercomp;

   private final HomePageCommon homepageShared;

   private final WebElementWait wait;

   AutomationLogManager LOGGER =
            new AutomationLogManager(PackagesitesLanguageSetUpForB2CNB2BStepDefs.class);

   private String lang;

   public PackagesitesLanguageSetUpForB2CNB2BStepDefs()
   {
      packageNavigation = new PackageNavigation();
      headercomp = new HeaderComponent();
      homepageShared = new HomePageCommon();
      wait = new WebElementWait();
   }

   @Given("the customer or retail agent is on the TUI.nl site")
   public void the_customer_or_retail_agent_is_on_the_TUI_nl_site()
   {
      packageNavigation.retailLogin();
   }

   @When("they view content on the site")
   public void they_view_content_on_the_site()
   {
      lang = getTestExecutionParams().getLocaleStr().toLowerCase();

   }

   @Then("then Dutch \\(NL) content will be be shown")
   public void then_Dutch_NL_content_will_be_be_shown()
   {
      String[] var = lang.split("=");
      LOGGER.log(LogLevel.INFO, var[1]);
      assertThat("retail agent is NOT on the TUI.nl site", var[1].trim().equalsIgnoreCase("'NL'"),
               is(true));
   }

   @Given("the customer or retail agent is on the TUI.be or VIP Selection site")
   public void the_customer_or_retail_agent_is_on_the_TUI_be_or_VIP_Selection_site()
   {
      packageNavigation.navigateToHoldaySearchPage();
   }

   @When("they select to view content in Dutch on the site")
   public void they_select_to_view_content_in_Dutch_on_the_site()
   {
      LOGGER.log(LogLevel.INFO, headercomp.getCountryLabel().getText());
      assertThat("retail agent is NOT on the TUI.be site",
               "NL".trim().equalsIgnoreCase(headercomp.getCountryLabel().getText()), is(true));
   }

   @Given("then Flemish \\(NL-BE) content will be shown")
   public void then_Flemish_NL_BE_content_will_be_shown()
   {
      lang = getTestExecutionParams().getLocaleStr().toLowerCase();
      String[] var = lang.split("=");
      LOGGER.log(LogLevel.INFO, var[1]);
      assertThat("retail agent is NOT on the TUI.BE site",
               var[1].trim().equalsIgnoreCase("'NL_BE'"), is(true));
   }

   @When("they select to view content in French on the site")
   public void they_select_to_view_content_in_French_on_the_site()
   {
      homepageShared.changeLanguageFrench();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      LOGGER.log(LogLevel.INFO, headercomp.getCountryLabel().getText());
      assertThat("retail agent is NOT on the TUI.Fr site",
               "FR".trim().equalsIgnoreCase(headercomp.getCountryLabel().getText()), is(true));
   }

   @Then("then Walloon \\(FR-BE) content will be be shown")
   public void then_Walloon_FR_BE_content_will_be_be_shown()
   {
      lang = getTestExecutionParams().getLocaleStr().toLowerCase();
      String[] var = lang.split("=");
      LOGGER.log(LogLevel.INFO, var[1]);
      assertThat("retail agent is NOT on the TUI.FR site",
               var[1].trim().equalsIgnoreCase("'FR_BE'"), is(true));
   }

   @Given("the customer is on the tui.be or VIP selection website")
   public void the_customer_is_on_the_tui_be_or_VIP_selection_website()
   {
      packageNavigation.navigateToHoldaySearchPage();
   }

   @When("they select the {string} languages in the language selector")
   public void they_select_the_languages_in_the_language_selector(String languages)
   {
      if (languages.equalsIgnoreCase("Dutch"))
      {
         wait.forJSExecutionReadyLazy();
         assertThat("retail agent is NOT on the TUI.be site",
                  "NL".trim().equalsIgnoreCase(headercomp.getCountryLabel().getText()), is(true));
      }
      else if (languages.equalsIgnoreCase("French"))
      {
         homepageShared.changeLanguageFrench();
         wait.forJSExecutionReadyLazy();
         assertThat("retail agent is NOT on the TUI.be site",
                  "FR".trim().equalsIgnoreCase(headercomp.getCountryLabel().getText()), is(true));
      }
      else
      {
         LOGGER.log(LogLevel.INFO, "No language selected");
      }
   }

   @Then("they will be presented with the {string} language content on the page")
   public void they_will_be_presented_with_the_language_content_on_the_page(String site)
   {
      String locale = Selenide.executeJavaScript("return locale;");
      assert locale != null;
      assertThat("retail agent is NOT on the TUI.FR site",
               locale.toUpperCase().trim(),
               Matchers.equalTo(site.toUpperCase().trim()));
   }

   @When("they select the {string} language in the language selector")
   public void they_select_the_language_in_the_language_selector(String languages)
   {
      if (languages.equalsIgnoreCase("Dutch"))
      {
         homepageShared.changeLanguageDutch();
         wait.forJSExecutionReadyLazy();
         LOGGER.log(LogLevel.INFO, headercomp.getCountryLabel().getText());
         assertThat("retail agent is NOT on the TUI.be site",
                  "NL".trim().equalsIgnoreCase(headercomp.getCountryLabel().getText()), is(true));
      }
      else if (languages.equalsIgnoreCase("French"))
      {
         homepageShared.changeLanguageFrench();
         wait.forJSExecutionReadyLazy();
         LOGGER.log(LogLevel.INFO, headercomp.getCountryLabel().getText());
         assertThat("retail agent is NOT on the TUI.fr site",
                  "FR".trim().equalsIgnoreCase(headercomp.getCountryLabel().getText()), is(true));
      }
   }

   @Then("the {string} language code will display in the language selector component in the page header")
   public void the_language_code_will_display_in_the_language_selector_component_in_the_page_header(
            String site)
   {
      if (site.contains(getTestExecutionParams().getBrandStr()))
      {
         lang = getTestExecutionParams().getLocaleStr().toLowerCase();
         String[] var = lang.split("=");
         LOGGER.log(LogLevel.INFO, var[1]);
         assertThat("retail agent is NOT on the TUI.BE site",
                  var[1].trim().equalsIgnoreCase("'NL_BE'"), is(true));
      }
      else if (site.contains(getTestExecutionParams().getBrandStr()))
      {
         lang = getTestExecutionParams().getLocaleStr().toLowerCase();
         String[] var = lang.split("=");
         LOGGER.log(LogLevel.INFO, var[1]);
         assertThat("retail agent is NOT on the TUI.FR site",
                  var[1].trim().equalsIgnoreCase("'FR_BE'"), is(true));
      }
   }

   @Then("the {string} language code will be contained in the page URL")
   public void the_language_code_will_be_contained_in_the_page_URL(String site)
   {
      String homePageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, homePageURL);
      assertThat("retail agent is NOT on the TUI.BE site", homePageURL.trim(),
               Matchers.containsString(site));
   }

   @Given("the agent has logged into the NL Package B2B website")
   public void the_agent_has_logged_into_the_NL_Package_B_B_website()
   {
      packageNavigation.navigateToHoldaySearchPage();
   }

   @When("they view the content within the website")
   public void they_view_the_content_within_the_website()
   {
      String homePageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, homePageURL);
      assertThat("retail agent is NOT on the TUI.NL site", homePageURL.trim().contains("nl/"),
               is(true));
   }

   @Then("the language will display as Dutch")
   public void the_language_will_display_as_Dutch()
   {
      lang = getTestExecutionParams().getLocaleStr().toLowerCase();
      String[] var = lang.split("=");
      LOGGER.log(LogLevel.INFO, var[1]);
      assertThat("retail agent is NOT on the TUI.nl site", var[1].trim().equalsIgnoreCase("'NL'"),
               is(true));
   }

   @And("the Agent will not be able to change the language")
   public void the_Agent_will_not_be_able_to_change_the_language()
   {
      try
      {
         String changeLanguage = headercomp.getCountryLabel().getText();
         LOGGER.log(LogLevel.INFO, changeLanguage);
         assertThat("Agent will be able to change the language",
                  changeLanguage.trim().equalsIgnoreCase("'NL'"), is(false));
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.INFO,
                  "the Agent will not be able to change the language for NL: " + e.getMessage());
      }
   }

   @And("the language selector component will not be displayed in the Header")
   public void the_language_selector_component_will_not_be_displayed_in_the_Header()
   {
      assertThat("the language selector component for NL is displayed in the Header",
               headercomp.getCountryLabels(), is(false));
   }

   @Given("the agent has logged into the BE Package B2B website")
   public void the_agent_has_logged_into_the_BE_Package_B_B_website()
   {
      packageNavigation.navigateToHoldaySearchPage();
   }

   @When("they view the  BE content within the website")
   public void they_view_the_BE_content_within_the_website()
   {
      LOGGER.log(LogLevel.INFO, headercomp.getCountryLabel().getText());
      assertThat("retail agent is NOT on the TUI.fr site",
               "NL".trim().equalsIgnoreCase(headercomp.getCountryLabel().getText()), is(true));
   }

   @Then("the language will display as Flemish \\(Dutch)")
   public void the_language_will_display_as_Flemish_Dutch()
   {
      lang = getTestExecutionParams().getLocaleStr().toLowerCase();
      String[] var = lang.split("=");
      LOGGER.log(LogLevel.INFO, var[1]);
      assertThat("retail agent is NOT on the TUI.BE site",
               var[1].trim().equalsIgnoreCase("'NL_BE'"), is(true));
   }

   @Then("the {string} code will display as the language code in the Header")
   public void the_code_will_display_as_the_language_code_in_the_Header(String string)
   {
      assertThat("retail agent is NOT on the TUI.fr site",
               "NL".trim().equalsIgnoreCase(headercomp.getCountryLabel().getText()), is(true));
   }

   @When("they select the two letter language code in the header")
   public void they_select_the_two_letter_language_code_in_the_header()
   {
      WebElementTools.clickElementJavaScript(headercomp.getCountrySwitcherLink());
   }

   @Then("the {string} languages will be displayed for the agent to choose from")
   public void the_languages_will_be_displayed_for_the_agent_to_choose_from(String string)
   {
      homepageShared.validateLanguagesInDropdownForPackage();
   }
}
