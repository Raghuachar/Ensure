package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.AlternateFlightsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class AlternateFlightsStepDefs
{
   public final AlternateFlightsPage alternateFlightsPage;

   public AlternateFlightsStepDefs()
   {
      alternateFlightsPage = new AlternateFlightsPage();
   }

   @Given("that the customer is on customise holiday page")
   public void that_the_customer_is_on_customise_holiday_page()
   {
      alternateFlightsPage.LaunchApplication();
      alternateFlightsPage.clickOnBookAccomContinueButton();
   }

   @When("they view the your accommodation component")
   public void they_view_the_your_accommodation_component()
   {
      assertThat("Your accommodation component not found",
               alternateFlightsPage.isYourAccommodationComponentDisplayed(), is(true));
   }

   @Then("they can view the current room and board that has been selected")
   public void they_can_view_the_current_room_and_board_that_has_been_selected()
   {
      assertThat("Your accommodation component not found",
               alternateFlightsPage.isSelectedRoomDisplayed(), is(true));
   }

   @Then("an overview of the different options that are available to choose from")
   public void an_overview_of_the_different_options_that_are_available_to_choose_from()
   {
      assertThat("Your accommodation component not found",
               alternateFlightsPage.isDiffRoomComponentDisplayed(), is(true));
   }

   @Given("that the customer is viewing the your flight component")
   public void that_the_customer_is_viewing_the_your_flight_component()
   {
      assertThat("Your flight component not found",
               alternateFlightsPage.isYourFlightComponentDisplayed(), is(true));
   }

   @When("they click the view alternative flights link")
   public void they_click_the_view_alternative_flights_link()
   {
      alternateFlightsPage.clickOnViewAlternativeFlightLink();
   }

   @Then("the alternative flights component will drop down")
   public void the_alternative_flights_component_will_drop_down()
   {
      assertThat("Your alternate flight component not found",
               alternateFlightsPage.isAltFlightsComponentDisplayed(), is(true));
   }

   @Then("will display alternative flights that can be selected")
   public void will_display_alternative_flights_that_can_be_selected()
   {
      assertThat("Your alternate flight container not found",
               alternateFlightsPage.isAltFlightsComponentDisplayed(), is(true));
   }

   @Given("that the customer is viewing the your room component on the customise holiday page")
   public void that_the_customer_is_viewing_the_component_on_the_customise_holiday_page()
   {
      assertThat("Your alternate room not found", alternateFlightsPage.isSelectedRoomDisplayed(),
               is(true));
   }

   @When("they click on the SELECT CTA on an alternative room card")
   public void they_click_on_the_select_CTA_on_an_alternative_room_card()
   {
      alternateFlightsPage.clickOnAltRoomButton();
   }

   @Then("the room on the booking will change")
   public void the_room_on_the_booking_will_change()
   {
      assertThat("Your alternate room not found", alternateFlightsPage.isSelectedRoomDisplayed(),
               is(true));
   }

   @Then("the price breakdown will be updated to reflect any price changes")
   public void the_price_breakdown_will_be_updated_to_reflect_any_price_changes()
   {
      assertThat("Price breakdown text is not displayed",
               alternateFlightsPage.isPriceBrekadownTextDisplayed(), is(true));
   }
}
