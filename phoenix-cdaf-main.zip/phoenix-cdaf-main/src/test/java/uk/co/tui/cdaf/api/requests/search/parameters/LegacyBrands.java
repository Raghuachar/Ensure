package uk.co.tui.cdaf.api.requests.search.parameters;

import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.Brands;

public enum LegacyBrands
{
   TUI_BE,
   TUI_NL,
   VIP_BE;

   public static LegacyBrands fromBrand(Brands brand){
      switch(brand){
         case BE:
            return TUI_BE;
         case NL:
            return TUI_NL;
         case VIP:
            return VIP_BE;
         default:
            throw new IllegalArgumentException("Invalid Brand: " + brand);
      }
   }
}
