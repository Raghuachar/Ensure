package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class RetailHomepageComponents
{
   @FindBy(css = ".UI__choiceSearchPanel")
   private WebElement searchpanel;

   public boolean isHomePagePresent()
   {
      return WebElementTools.isPresent(searchpanel);
   }
}
