package uk.co.tui.cdaf.frontend.pom.wr.web.shared.browse.homepage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.List;

public class HeaderComponent extends AbstractPage
{

   private final CountryLanguageSelector clOverlayComp;

   @FindAll({ @FindBy(css = ".MainNavigation__mainNavigationWrapper ul li:nth-child(1) a"),
            @FindBy(css = ".scrollers__scroll div:nth-child(1) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })
   private WebElement holidaysLabel;

   @FindAll({ @FindBy(css = ".MainNavigation__mainNavigationWrapper ul li:nth-child(2) a"),
            @FindBy(css = ".scrollers__scroll div:nth-child(2) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })
   private WebElement cruisesLabel;

   @FindAll({ @FindBy(css = ".MainNavigation__mainNavigationWrapper ul li:nth-child(4) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(4) a") })
   private WebElement hotlonlyLabel;

   @FindAll({ @FindBy(css = ".MainNavigation__mainNavigationWrapper ul li:nth-child(4) a"),
            @FindBy(css = ".scrollers__scroll div:nth-child(4) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })

   private WebElement dealsVipLabel;

   @FindAll({ @FindBy(css = ".MainNavigation__mainNavigationWrapper ul li:nth-child(5) a"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(5) a") })

   private WebElement dealsLabel;

   @FindAll({ @FindBy(css = ".MainNavigation__mainNavigationWrapper ul li:nth-child(3) a"),
            @FindBy(css = ".scrollers__scroll div:nth-child(3) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })
   private WebElement flightsLabelInPackage;

   @FindAll({ @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(3) a.MenuItem__menuLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(3) ul li a.GlobalHeaderAccordion__headingLink") })
   private WebElement destinationsLabel;

   @FindAll({ @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(5) a.MenuItem__menuLink"),
            @FindBy(css = ".scrollers__scroll div:nth-child(5) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })
   private WebElement destinationsVipLabel;

   @FindAll({ @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(5) a.MenuItem__menuLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(5) ul li a.GlobalHeaderAccordion__headingLink") })
   private WebElement extrasLabel;

   @FindAll({ @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(6) a.MenuItem__menuLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(6) ul li a.GlobalHeaderAccordion__headingLink") })
   private WebElement extrasVipLabel;

   @FindAll({ @FindBy(css = "#globalHeader__component") })
   private WebElement headerComp;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(1) a.StandardLink__standardLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(6) ul li a.GlobalHeaderAccordion__headingLink") })
   private WebElement questionsLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(1) a.StandardLink__standardLink"),
            @FindBy(css = ".scrollers__scroll div:nth-child(7) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })
   private WebElement visitShopVipLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(2) a.StandardLink__standardLink"),
            @FindBy(css = ".scrollers__scroll div:nth-child(8) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })
   private WebElement questionsVipLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(2) a.StandardLink__standardLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(7) ul li a.GlobalHeaderAccordion__headingLink") })
   private WebElement checkinLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(3) a.StandardLink__standardLink"),
            @FindBy(css = ".BurgerMenu__containerScroll div div:nth-child(8) ul li a.GlobalHeaderAccordion__headingLink") })
   private WebElement flyAppLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(4) a.StandardLink__standardLink"),
            @FindBy(css = ".scrollers__scroll div:nth-child(10) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })
   private WebElement travelInformationLabel;

   @FindAll({
            @FindBy(css = ".GlobalHeader__siteHeader ul li:nth-child(5) a.StandardLink__standardLink"),
            @FindBy(css = ".MenuContent__burgerMenuContent ul li:nth-child(12) a") })
   private WebElement accountBookingLabel;

   @FindAll({ @FindBy(css = "[aria-label='burger menu main']") })
   private WebElement burgerMenu;

   @FindAll({

            @FindBy(css = "[aria-label='no of shortlited holidays']"),
            @FindBy(css = "[aria-label='Shortlist Icon']") })
   private WebElement shortlistIcon;

   @FindAll({ @FindBy(css = ".TopBar__topbarWrapper ul li:nth-child(3) a"),
            @FindBy(css = ".scrollers__scroll div:nth-child(9) ul li a.GlobalHeaderAccordion__headingLink.GlobalHeaderAccordion__link") })
   private WebElement shortlistLabel;

   @FindBy(css = "[aria-label='CA Icon']")
   private WebElement accountBookingIcon;

   @FindBy(css = "#globalHeader__component  a > img")
   private WebElement logoIcon;

   @FindBy(css = ".LanguageCountrySelector__countrySwitcher button")
   private WebElement countrySwitcherLink;

   @FindBy(css = "[class='MenuItem__navText']")
   private List<WebElement> VIPheaderLabel;

   @FindBy(css = ".MenuDropDown__dropdownContainer div[aria-hidden='false'] section div[class='MegaMenu__listRow'] li a")
   private List<WebElement> megamenuComponentSubElement;

   @FindBy(css = ".MenuDropDown__dropdownContainer div[aria-hidden='false']")
   private WebElement megamenuComponent;

   public HeaderComponent()
   {
      clOverlayComp = new CountryLanguageSelector();
   }

   public WebElement getLogoIcon()
   {
      return logoIcon;
   }

   public WebElement getShortlistIcon()
   {
      return shortlistIcon;
   }

   public WebElement getAccountBookingIcon()
   {
      return accountBookingIcon;
   }

   public WebElement getCheckinLabel()
   {
      return checkinLabel;
   }

   public WebElement getFlyAppLabel()
   {
      return flyAppLabel;
   }

   public WebElement getFlightsLabelInPackage()
   {
      return flightsLabelInPackage;
   }

   public WebElement getQuestionsLabel()
   {
      return questionsLabel;
   }

   public WebElement getQuestionsVipLabel()
   {
      return questionsVipLabel;
   }

   public WebElement getVisitShopVipLabel()
   {
      return visitShopVipLabel;
   }

   public CountryLanguageSelector getClOverlayComp()
   {
      return clOverlayComp;
   }

   public WebElement getDestinationsLabel()
   {
      return destinationsLabel;
   }

   public WebElement getDestinationsVipLabel()
   {
      return destinationsVipLabel;
   }

   public WebElement getExtrasLabel()
   {
      return extrasLabel;
   }

   public WebElement getExtrasVipLabel()
   {
      return extrasVipLabel;
   }

   public WebElement getHeaderComp()
   {
      return headerComp;
   }

   public WebElement getTravelInformationLabel()
   {
      return travelInformationLabel;
   }

   public WebElement getAccountBookingLabel()
   {
      return accountBookingLabel;
   }

   public WebElement getBurgerMenu()
   {
      return burgerMenu;
   }

   public WebElement getCountrySwitcherLink()
   {
      return countrySwitcherLink;
   }

   public CountryLanguageSelector getCountryLangSelectorComp()
   {
      return clOverlayComp;
   }

   public WebElement getHolidaysLabel()
   {
      return holidaysLabel;
   }

   public WebElement getCruisesLabel()
   {
      return cruisesLabel;
   }

   public WebElement getHotlonlyLabel()
   {

      return hotlonlyLabel;
   }

   public WebElement getDealsLabel()
   {
      return dealsLabel;
   }

   public WebElement getDealsVipLabel()
   {
      return dealsVipLabel;
   }

   public WebElement getShortlistLabel()
   {
      return shortlistLabel;
   }

   public List<WebElement> getVIPheaderLabel()
   {
      return VIPheaderLabel;
   }

   public WebElement getMegamenuComponent()
   {
      return megamenuComponent;
   }

   public List<WebElement> getMegamenuComponentSubElement()
   {
      return megamenuComponentSubElement;
   }

}
