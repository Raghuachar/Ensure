package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;

import static org.junit.Assert.assertEquals;

public class SkipPaymentFRTranslationStepDefs
{
   public final RetailPackageNavigation retailpackagenavigation;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   public final FlightOnlyHomePage foHomePage;

   public final SearchResultsPage searchResultsPage;

   public SkipPaymentFRTranslationStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      foHomePage = new FlightOnlyHomePage();
      searchResultsPage = new SearchResultsPage();
   }

   @Given("that an Agent is on the Payment options page of bookflow")
   public void that_an_Agent_is_on_the_Payment_options_page_of_bookflow()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();
      retailpassengerdetailspage.fillRetailPassengerDetails();

   }

   @And("have changed the page language to French")
   public void have_changed_the_page_language_to_French()
   {
      throw new PendingException();
   }

   @When("they are ready to complete the payment")
   public void they_are_ready_to_complete_the_payment()
   {
      retailpassengerdetailspage.changeLanguageFr();
   }

   @Then("they will see the message  {string}  before the CTA")
   public void they_will_see_the_message_before_the_CTA(String string)
   {
      assertEquals(string, retailpassengerdetailspage.getSkippaymenttext());
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }
}
