package uk.co.tui.cdaf.frontend.utils;

import uk.co.tui.cdaf.utils.ConfigurationHelper;

public class HybrisConfigHelper
{

   public static Integer getTotalGuestsFirstLayout()
   {

      String value = ConfigurationHelper.getTotalGuestsFirstLayout();
      return Integer.parseInt(value);
   }

   public static Integer getValidTotalAdultCount()
   {

      String value = ConfigurationHelper.getValidTotalAdultCount();
      return Integer.parseInt(value);
   }

   public static Integer getValidTotalChildrenCount()
   {

      String value = ConfigurationHelper.getValidTotalChildrenCount();
      return Integer.parseInt(value);
   }

   public static Integer getMaxValidAge()
   {

      String value = ConfigurationHelper.getMaxValidAge();
      return Integer.parseInt(value);
   }

   public static Integer getValidLowestAdultCount()
   {

      String value = ConfigurationHelper.getValidLowestAdultCount();
      return Integer.parseInt(value);
   }

   public static Integer getValidLowestChildrenCount()
   {

      String value = ConfigurationHelper.getValidLowestChildrenCount();
      return Integer.parseInt(value);
   }

   public static Integer getTotalValidPassengerCount()
   {

      String value = ConfigurationHelper.getTotalValidPassengerCount();
      return Integer.parseInt(value);
   }
}
