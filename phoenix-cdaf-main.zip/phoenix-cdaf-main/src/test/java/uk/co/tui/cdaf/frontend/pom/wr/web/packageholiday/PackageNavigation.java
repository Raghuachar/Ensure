package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday;

import uk.co.tui.cdaf.api.requests.search.PackageSearchApi;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details.NordicsPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchCustom;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.paymentoptions.PaymentOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPriceChangeDisplayComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.Package3PAPasswordChange;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HeaderComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.Objects;

import static com.codeborne.selenide.Selenide.open;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class PackageNavigation
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageNavigation.class);

    public final SearchResultsPage searchResultsPage;

   public final UnitDetailsPage unitPage;

   public final SummaryPage summaryPage;

   public final WebDriverUtils utils;

   public final RetailPage retailPage;

   public final FlightOnlyHomePage foHomePage;

   public final PaymentOptionsPage paymentOptionsPage;

   public final RetailPassengerDetailsPage retailpassengerdetails;

   public final UnitDetailsPriceChangeDisplayComponent unitDetailsPriceChangeDisplayComponent;

   public final SearchPanelComponent searchPanelComponents;

   public final SearchCustom searchCustom;

   private final PageErrorHandler errorHandler;

   private final WebElementWait wait;

   private final Package3PAPasswordChange package3PAPasswordChange;

   private final SearchDataHelper searchDataHelper;

   private final SearchPanel searchPanel = getSearchPanel();

   private final HeaderComponent headercomp;

   public PackageNavigation()
   {
      searchResultsPage = new SearchResultsPage();
      errorHandler = new PageErrorHandler();
      wait = new WebElementWait();
      unitPage = new UnitDetailsPage();
      summaryPage = new SummaryPage();
      utils = new WebDriverUtils();
      retailPage = new RetailPage();
      foHomePage = new FlightOnlyHomePage();
      paymentOptionsPage = new PaymentOptionsPage();
      retailpassengerdetails = new RetailPassengerDetailsPage();
      unitDetailsPriceChangeDisplayComponent = new UnitDetailsPriceChangeDisplayComponent();
      package3PAPasswordChange = new Package3PAPasswordChange();
      searchPanelComponents = new SearchPanelComponent();
      searchCustom = new SearchCustom();
      searchDataHelper = new SearchDataHelper();
      headercomp = new HeaderComponent();
   }

   public void retailLogin()
   {
      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
   }

   public void retailLoginFO()
   {
      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
   }

   public void retailLoginChangeagent()
   {
      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
      foHomePage.navigateToHolidayPage();
   }

   public void navigateToSearchResultPage()
   {
      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();

      foHomePage.navigateToHolidayPage();
         TestDataAttributes parameter =
                  searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
         if (parameter == null)
            searchPanel.searchDefaults();
         else
            searchPanel.searchWithParameters(parameter);
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToflexibileSearchResultPage(String flexible)
   {
      TestDataAttributes parameter = searchDataHelper.getSearchParameters();
      if (parameter != null)
         parameter.setFlexibleDays(flexible);
      open(PackageSearchApi.uriBuilder(parameter));
      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToUnitDetailsPage()
   {
      navigateToSearchResultPage();
      searchResultsPage.searchResultComponent.selectRandomResultCard();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
      getSearchPanel().openFromUnitDetails();
   }

   public void navigateToUnitDetailsPageOfContractedPkg()
   {
      navigateToSearchResultPage();
      searchResultsPage.searchResultComponent.selectContractedPackage();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
      getSearchPanel().openFromUnitDetails();
   }

   public void navigateToUnitDetailsPageWithPriceChange()
   {
      navigateToSearchResultPage();
      unitDetailsPriceChangeDisplayComponent.changeprice();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   public void navigateToUnitdetailsPage()
   {
      navigateToSearchResultPage();
      wait.forJSExecutionReadyLazy();
      String accommodation = searchCustom.getAccommodationCode();
      if (Objects.nonNull(accommodation))
      {
         searchResultsPage.searchResultComponent.selectSpecificResultCardByCode(accommodation);
      }
      else
      {
         searchResultsPage.searchResultComponent.selectSearchCardWithAlternateRoom();
      }
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   public void navigateToUnitDetailsWithAltBoard()
   {
      navigateToSearchResultPage();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectSearchCardWithAltBoard();
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   public void navigateToUnitDetailsWithDiscount()
   {
      navigateToSearchResultPage();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectSearchCardWithDiscount();
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   public void navigateToSummaryPage()
   {
      navigateToUnitDetailsPage();
      wait.forJSExecutionReadyLazy();
      unitPage.progressbarComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToSummaryPageOfContractedPkg()
   {
      navigateToUnitDetailsPageOfContractedPkg();
      unitPage.progressbarComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateTosummaryPage()
   {
      navigateToUnitdetailsPage();
      wait.forJSExecutionReadyLazy();
      unitPage.progressbarComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToSummaryWithAltBoard()
   {
      navigateToUnitDetailsWithAltBoard();
      wait.forJSExecutionReadyLazy();
      unitPage.progressbarComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToSummaryWithDiscount()
   {
      navigateToUnitDetailsWithDiscount();
      wait.forJSExecutionReadyLazy();
      unitPage.progressbarComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPassengerPage()
   {
      navigateToSummaryPage();
      wait.forJSExecutionReadyLazy();
      summaryPage.navigationComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPaymentPage()
   {
      final NordicsPassengerDetailsPage nordicPassengerPage = new NordicsPassengerDetailsPage();
      navigateToPassengerPage();
      wait.forJSExecutionReadyLazy();
      nordicPassengerPage.fillThePassengerDetailsForWr();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToFlightPage()
   {
      navigateToSummaryPage();
      wait.forJSExecutionReadyLazy();
      summaryPage.flightSummaryComponent.clickOnFlightLink();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToDetailedBreakdownPage()
   {
      navigateTosummaryPage();
      wait.forJSExecutionReadyLazy();
      summaryPage.priceBreakComponent.clickOnDetailedBreakdownLink();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToExtrasPage()
   {
      navigateToSummaryPage();
      wait.forJSExecutionReadyLazy();
      summaryPage.insExComponent.clickOnChooseInsurance();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToExtrasPageOfContractedPkg()
   {
      navigateToSummaryPageOfContractedPkg();
      summaryPage.insExComponent.clickOnChooseInsurance();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToConfirmationPage()
   {
      navigateToPaymentPage();
      wait.forJSExecutionReadyLazy();
      paymentOptionsPage.paymentTypeComponent.selectFullPay();
      paymentOptionsPage.paymentOptionsComponent.clickPaymentMethod();
      paymentOptionsPage.paymentOptionsComponent.clickOnPayButton();
      wait.forJSExecutionReadyLazy();
      paymentOptionsPage.pspPage.enterCardDetails();
      wait.forJSExecutionReadyLazy();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToHoldaySearchPage()
   {

      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();

      foHomePage.navigateToHolidayPage();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToMultiRoomSearchResultPage()
   {
      open(PackageSearchApi.uriBuilder());
      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToMultiRoomUnitDetailsPage()
   {
      navigateToMultiRoomSearchResultPage();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   public void navigateToSingleAccomSearchResultPage()
   {
      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      foHomePage.navigateToHolidayPage();
      wait.forJSExecutionReadyLazy();
      TestDataAttributes parameter =
               searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
      if (parameter == null)
         searchPanel.searchDefaults();
      else
         searchPanel.searchWithParameters(parameter);
      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   // discounts
   public void addPassengerDetailsandwaitforAddFeetype()
   {
      wait.forJSExecutionReadyLazy();
      retailpassengerdetails.fillThePassengerDetailsForAddFeeType();
      errorHandler.isPageLoadingCorrectly();
   }

   public void skipPaymentsWR()
   {
      String currentUrl = WebDriverUtils.getDriver().getCurrentUrl();
      if (currentUrl.contains("validatepaymentoptions"))
      {
         String NewCurrenturl = currentUrl.replace("validatepaymentoptions", "paymentoptions");
         open(NewCurrenturl);
      }
      wait.forJSExecutionReadyLazy();
      retailpassengerdetails.skippayment();
      errorHandler.isPageLoadingCorrectly();
   }

   public void programchange()
   {
      retailpassengerdetails.discounttabclick();
      retailpassengerdetails.selectProgramChnage();
      retailpassengerdetails.addProgramChnageAmount();
      retailpassengerdetails.selectContinueBookingWR();
      skipPaymentsWR();

   }

   public void navigateFromHomePageToSearchResultPage()
   {
      wait.forJSExecutionReadyLazy();
      BrowserCookies.closePrivacyPopUp();
      TestDataAttributes parameter =
               searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
      if (parameter == null)
         searchPanel.searchDefaults();
      else
         searchPanel.searchWithParameters(parameter);

      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToVipSingleAccomSearchResultPage()
   {
      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
      headercomp.selectVipSelection();

      TestDataAttributes parameter =
               searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
      if (parameter == null)
         searchPanel.searchDefaults();
      else
         searchPanel.searchWithParameters(parameter);
      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToVipSearchResultPage()
   {
      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
      BrowserCookies.closePrivacyPopUp();
      headercomp.selectVipSelection();

      TestDataAttributes parameter =
               searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
      if (parameter == null)
         searchPanel.searchDefaults();
      else
         searchPanel.searchWithParameters(parameter);

      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToVipUnitDetailsPage()
   {
      navigateToVipSearchResultPage();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   public final void navigateToRetailThirdPartyLoginPage()
   {
      searchResultsPage.searchPanelComponent.visit();
      retailPage.enterThridPartyCredentials();
   }

   public final void navigateToChangePasswordPage()
   {
      searchResultsPage.searchPanelComponent.visit();
      wait.forJSExecutionReadyLazy();
      retailPage.enterThridPartyCredentials();
      package3PAPasswordChange.getChangePasswordLabel().click();
      wait.forJSExecutionReadyLazy();
      String changePasswordPage = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "  ChangePassword Page url: " + changePasswordPage);
   }

   public void navigateToSelectedRoomsSearchResultPage()
   {
      TestDataAttributes parameter = searchDataHelper.getSearchParameters();
      open(PackageSearchApi.uriBuilder(parameter));
   }

   public void navigateSelectedRoomsUnitDetailsPage()
   {
      navigateToSelectedRoomsSearchResultPage();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
   }

   public void navigateToUnitDetailsPageWithAltRoom()
   {
      navigateToSearchResultPage();
      wait.forJSExecutionReadyLazy();
      int searchResultSize = searchResultsPage.searchResultComponent.searchResultSize();
      for (int i = 0; i < searchResultSize; i++)
      {
         searchResultsPage.searchResultComponent.selectNthResultCard(i);
         errorHandler.isPageLoadingCorrectly();
         wait.forJSExecutionReadyLazy();
         if (unitPage.roomComponent.isAlternativeRoomsPresent())
         {
            String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
            LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
            break;
         }
         WebDriverUtils.getDriver().navigate().back();
         wait.forJSExecutionReadyLazy();
      }
   }

   public void navigateToSmokeSearchResultPage()
   {
      searchResultsPage.searchPanelComponent.visit();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
      BrowserCookies.closePrivacyPopUp();

      TestDataAttributes parameter =
               searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
      if (parameter == null)
         searchPanel.searchDefaults();
      else
         searchPanel.searchWithParameters(parameter);
      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void deepLinkSingleAccomadation()
   {
      searchResultsPage.searchPanelComponent.visit();
      TestDataAttributes parameter =
               searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
      open(parameter.getLoginUrl());

   }
}
