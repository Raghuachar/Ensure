package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackagePreviousReconciliationsPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePreviousReconciliationsEditSearchStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final PackagePreviousReconciliationsPageComponents pkgPreviousReconPaymentPageComponents;

   public PackagePreviousReconciliationsEditSearchStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      pkgPreviousReconPaymentPageComponents = new PackagePreviousReconciliationsPageComponents();
   }

   @Given("that the agent is viewing previous reconciliations")
   public void that_the_agent_is_viewing_previous_reconciliations()
   {
      packagenavigation.retailLoginChangeagent();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pkgPreviousReconPaymentPageComponents.navigateToPreviousReconciliationPage();
   }

   @When("they press the edit search CTA")
   public void they_press_the_edit_search_CTA()
   {
      pkgPreviousReconPaymentPageComponents.selectDates();
      pkgPreviousReconPaymentPageComponents.clickOnSearchCTA();
      wait.forJSExecutionReadyLazy();
      pkgPreviousReconPaymentPageComponents.clickOnSearchCTA();
      wait.forJSExecutionReadyLazy();
   }

   @Then("the date pickers will become selectable")
   public void the_date_pickers_will_become_selectable()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("From date is visible",
               pkgPreviousReconPaymentPageComponents.isFromDateInputVisible(), is(true));
      assertThat("To date is visible", pkgPreviousReconPaymentPageComponents.isToDateInputVisible(),
               is(true));
   }

   @Then("the agent can choose new dates to search")
   public void the_agent_can_choose_new_dates_to_search()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("Input box available, agent can choose new dates",
               pkgPreviousReconPaymentPageComponents.isEditSearchCTADisplayed(), is(true));
   }

   @When("they have selected new dates to search")
   public void they_have_selected_new_dates_to_search()
   {
      pkgPreviousReconPaymentPageComponents.selectNewDates();
   }

   @When("have pressed the Search CTA")
   public void have_pressed_the_Search_CTA()
   {
      wait.forJSExecutionReadyLazy();
      pkgPreviousReconPaymentPageComponents.clickOnSearchCTA();
   }

   @Then("the new search results will be displayed")
   public void the_new_search_results_will_be_displayed()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("Search results displayed",
               pkgPreviousReconPaymentPageComponents.isSearchResultContainer(), is(true));
   }

   @Then("they will see that the previously selected dates are set as deafult in the date pickers")
   public void they_will_see_that_the_previously_selected_dates_are_set_as_deafult_in_the_date_pickers()
   {
      assertThat("Selected dates are set in from date input",
               pkgPreviousReconPaymentPageComponents.isFromDateInputVisible(), is(true));
      assertThat("Selected dates are set in to date input",
               pkgPreviousReconPaymentPageComponents.isToDateInputVisible(),
               is(true));
   }
}
