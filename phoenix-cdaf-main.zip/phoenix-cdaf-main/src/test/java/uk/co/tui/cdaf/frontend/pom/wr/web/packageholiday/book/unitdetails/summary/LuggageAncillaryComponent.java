package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightLuggageComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.HashMap;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;

public class LuggageAncillaryComponent extends FlightLuggageComponent
{
   private static final double DELTA = 0.01;

   private final AutomationLogManager LOGGER = new AutomationLogManager(
            LuggageAncillaryComponent.class);

   private final Map<String, WebElement> luggageMap;

   public final ProgressionbarNavigationComponent progressbarComponent;

   private final ThreadLocal<Double> totalPrice = new ThreadLocal<>();

   @FindBy(css = "[aria-label='luggage ancillary'] h2")
   protected WebElement yourLuggageTitleText;

   @FindBy(css = "[aria-label='luggage ancillary'] [class*='whatsIncluded'] img")
   protected WebElement luggageiconWithDimension;

   @FindBy(css = "[aria-label='luggage ancillary'] [class*='buttonContainer'] button")
   protected WebElement viewAllPassengerButton;

   public LuggageAncillaryComponent()
   {
      luggageMap = new HashMap<>();
      progressbarComponent = new ProgressionbarNavigationComponent();
   }

   public boolean isViewAllpassengerButtonDisplayed()
   {
      return WebElementTools.isPresent(viewAllPassengerButton);
   }

   public Map<String, WebElement> getLuggageComponents()
   {
      luggageMap.put("YOUR LUGGAGE", yourLuggageTitleText);
      luggageMap.put("Luggage descriptions with USPs", luggageDescription);
      luggageMap.put("Upgrade CTAs", luggageUpgradeButton.get(0));
      luggageMap.put("Check in allowance & Price", checkInAllowanceDescription);
      luggageMap.put("Luggage specific T&Cs link", moreInformationLink);
      luggageMap.put("Luggage Icons with Dimensions", luggageiconWithDimension);
      return luggageMap;
   }

   public void clickShowAllTravelersButton()
   {
      SelenideElement showAllTravelersButton = $(".LuggageAncillary__buttonContainer .buttons__fill");
      if (showAllTravelersButton.isDisplayed())
      {
         showAllTravelersButton.click();
      }
   }

   public void addCheapestLuggageForPassengers(int paxAmount)
   {
      totalPrice.set(progressbarComponent.getTotalPriceDoubleValue());
      clickShowAllTravelersButton();
      ElementsCollection luggageRows = $$(".LuggageAncillary__luggageRow").filterBy(Condition.visible);
      for (int i = 0; i < paxAmount; i++)
      {
         Double newTotalPrice = setNewPrice(luggageRows, i);
         waitForPriceUpdate(newTotalPrice);
      }
   }

   private Double setNewPrice(ElementsCollection luggageRows, int i)
   {
      luggageRows.get(i).$$(".cards__horizontalAncillaryWrapper:not(.cards__selected) .buttons__fill")
               .first().shouldBe(Condition.visible).click();
       return progressbarComponent.getTotalPriceDoubleValue();
   }

   private void waitForPriceUpdate(Double newTotalPrice)
   {
      if ((newTotalPrice - totalPrice.get()) < DELTA)
      {
         LOGGER.log(LogLevel.INFO, "Waiting for the total price to be updated...");
         refresh();
      }
   }
}
