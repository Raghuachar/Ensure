package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SortByComponent;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class EditSearchPanelComponentRedesignMobileStefDefs
{
   public final PackageNavigation packageNavigation;

   public final SortByComponent searchResultsSortBy;

   public final SearchResultsPage searchResultsPage;

   private final SearchResultsComponent searchResultsComponent;

   private final Map<String, WebElement> searchMap;

   private final AutomationLogManager LOGGER =
            new AutomationLogManager(EditSearchPanelComponentRedesignMobileStefDefs.class);

   public EditSearchPanelComponentRedesignMobileStefDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsSortBy = new SortByComponent();
      searchResultsPage = new SearchResultsPage();
      searchResultsComponent = new SearchResultsComponent();
      searchMap = new HashMap<>();
   }

   @Given("the {string} has conducted a package search on a mobile device")
   public void the_has_conducted_a_package_search_on_a_mobile_device(String string)
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @And("the destination\\/hotel searched is equal to or less than {int} characters")
   public void the_destination_hotel_searched_is_equal_to_or_less_than_characters(Integer int1)
   {
      searchResultsPage.searchResultComponent.getLessThanEqual17Characters();
   }

   @And("they are on the Search Results page")
   public void they_are_on_the_Search_Results_page()
   {
      assertThat("Search results page is not displayed",
               searchResultsSortBy.isHolidayCountDisplayed(), is(true));
   }

   @When("they review the Edit search panel")
   public void they_review_the_Edit_search_panel()
   {
      assertThat("Search results page is not displayed",
               searchResultsSortBy.isHolidayCountDisplayed(), is(true));
   }

   @Then("it is closed by default")
   public void it_is_closed_by_default()
   {
      assertThat("closed by default is not displayed displayed",
               searchResultsComponent.isExpandableEditSearchPanelDisplayed(), is(false));
   }

   @And("they can see the Following:")
   public void they_can_see_the_Following(List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchResultComponent.getSearchPanelView());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("they can {string} displays instead of a destination name")
   public void they_can_displays_instead_of_a_destination_name(String string)
   {
      if (string.equalsIgnoreCase(searchResultsPage.searchResultComponent.destinationNotSelected()))
         LOGGER.log(LogLevel.INFO, string + "is displayed");
      else
         assertThat(string + "component not displayed", false, is(true));
   }

   @When("they select the {string} button within the search panel")
   public void they_select_the_button_within_the_search_panel(String string)
   {
      searchResultsPage.searchResultComponent.clickEditSearchMobile();
   }

   @Then("the search panel opens to the as is state")
   public void the_search_panel_opens_to_the_as_is_state()
   {
      assertThat("search panel is not displayed ",
               searchResultsComponent.isExpandableEditSearchPanelDisplayed(), is(true));
   }

}
