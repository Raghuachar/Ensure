package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.passenger;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PassengerDetailsErrorMessagesStepDefs
{

   public PassengerDetailsErrorMessagesStepDefs()
   {
      super();
   }

   @Given("The {string} is logged in")
   public void the_is_logged_in(String customer)
   {
      throw new PendingException();
   }

   @Given("has chosen to increase the minimum characters in a field")
   public void has_chosen_to_increase_the_minimum_characters_in_a_field()
   {
      throw new PendingException();
   }

   @When("the user selects to confirm the change")
   public void the_user_selects_to_confirm_the_change()
   {
      throw new PendingException();
   }

   @Then("the field validation should be updated accordingly")
   public void the_field_validation_should_be_updated_accordingly()
   {
      throw new PendingException();
   }

   @Given("has chosen to decrease the minimum characters in a field")
   public void has_chosen_to_decrease_the_minimum_characters_in_a_field()
   {
      throw new PendingException();
   }

   @Given("has chosen to increase the maximum number of characters in a field")
   public void has_chosen_to_increase_the_maximum_number_of_characters_in_a_field()
   {
      throw new PendingException();
   }

   @Given("has chosen to decrease the maximum number of characters in a field")
   public void has_chosen_to_decrease_the_maximum_number_of_characters_in_a_field()
   {
      throw new PendingException();
   }

   @Given("has chosen to add a special character allowed in a field")
   public void has_chosen_to_add_a_special_character_allowed_in_a_field()
   {
      throw new PendingException();
   }

   @When("the use selects to confirm the change")
   public void the_use_selects_to_confirm_the_change()
   {
      throw new PendingException();
   }

   @Given("has chosen to remove a special character allowed in a field")
   public void has_chosen_to_remove_a_special_character_allowed_in_a_field()
   {
      throw new PendingException();
   }

   @Given("has chosen to edit an error message for a field")
   public void has_chosen_to_edit_an_error_message_for_a_field()
   {
      throw new PendingException();
   }

   @Then("the relevant field error message should be updated accordingly")
   public void the_relevant_field_error_message_should_be_updated_accordingly()
   {
      throw new PendingException();
   }
}
