package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.passengerdetails;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPriceChangeDisplayComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PassengerDetailsPriceChangeComponentStepDefs
{

   public final PackageNavigation packageNavigation;

   public final SummaryPage summaryPage;

   public final UnitDetailsPriceChangeDisplayComponent unitDetailsPriceChangeDisplay;

   public PassengerDetailsPriceChangeComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      summaryPage = new SummaryPage();
      unitDetailsPriceChangeDisplay = new UnitDetailsPriceChangeDisplayComponent();
   }

   @Given("that the customer is on the Customise page")
   public void that_the_customer_is_on_the_Customise_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they navigate to the Passenger Details page")
   public void they_navigate_to_the_Passenger_Details_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @When("there has been a price increase in either unit price or flight price")
   public void there_has_been_a_price_increase_in_either_unit_price_or_flight_price()
   {
      unitDetailsPriceChangeDisplay.isPriceChangeComponentsDisplayed();
   }

   @Then("they will be presented with Price Increase Message")
   public void they_will_be_presented_with_Price_Increase_Message()
   {
      boolean actual = summaryPage.priceChangeAlertComponent.isPriceChangeComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Price change alert component wasn't displayed", actual, true), actual, is(true));
   }

   @Given("that the customer is on the Passenger Details page")
   public void that_the_customer_is_on_the_Passenger_Details_page()
   {
      packageNavigation.navigateToPassengerPage();
   }

   @When("they navigate to the Payments page")
   public void they_navigate_to_the_Payments_page()
   {
      packageNavigation.navigateToPaymentPage();
   }
}
