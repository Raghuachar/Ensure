package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePageTemplateTableHeaderStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackagePageTemplateTableHeaderStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent has navigated to the banking & reconciliation page")
   public void that_the_agent_has_navigated_to_the_banking_reconciliation_page()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

   @When("they view the banking table")
   public void they_view_the_banking_table()
   {
      assertThat("Reconcilation Banking Table Displayed",
               pKgReconcilationPaymentPageComponents.isBankingTablePresent(), is(true));
   }

   @Then("they can see the column headers")
   public void they_can_see_the_column_headers(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Types is displayed",
               pKgReconcilationPaymentPageComponents.isTypesColumnHeaderDisplayed(), is(true));
      assertThat("Payment totals is displayed",
               pKgReconcilationPaymentPageComponents.isPaymentTotalsColumnHeaderDisplayed(),
               is(true));
      assertThat("Banking now is displayed",
               pKgReconcilationPaymentPageComponents.isBankingNowColumnHeaderDisplayed(), is(true));
      assertThat("Discrepancy is displayed",
               pKgReconcilationPaymentPageComponents.isDiscrepancyColumnHeaderDisplayed(),
               is(true));
      assertThat("Currency is displayed",
               pKgReconcilationPaymentPageComponents.isCurrencyColumnHeaderDisplayed(), is(true));
      assertThat("Reason is displayed",
               pKgReconcilationPaymentPageComponents.isReasonColumnHeaderDisplayed(), is(true));
      assertThat("Blank Space is displayed",
               pKgReconcilationPaymentPageComponents.isBlankSpaceColumnHeaderDisplayed(), is(true));
   }
}
