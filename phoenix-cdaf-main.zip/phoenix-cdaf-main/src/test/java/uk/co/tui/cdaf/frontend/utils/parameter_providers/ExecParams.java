package uk.co.tui.cdaf.frontend.utils.parameter_providers;

import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.*;
import uk.co.tui.cdaf.utils.ConfigurationService;

import java.net.URL;
import java.text.MessageFormat;

public class ExecParams
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(ExecParams.class);

   private static final String TEST_EXECUTION_ENVIRONMENT = "env";

   private static final String TEST_EXECUTION_BRAND = "brand";

   private static final String TEST_EXECUTION_LOCALE = "locale";

   private static final String TEST_EXECUTION_AGENT = "agent";

   private static TestExecutionParams testExecutionParams;

   public static TestExecutionParams getTestExecutionParams()
   {
      if (testExecutionParams == null)
      {
         Agents agent = getAgent();
         Brands brand = getTestExecutionBrand();
         Environments env = getTestExecutionEnv();
         Locales locale = getTestExecutionLocale();
         testExecutionParams = new TestExecutionParams(agent, brand, env, locale);
         testExecutionParams.setUrl(UrlProvider.getBaseUrl(testExecutionParams));
      }
      return testExecutionParams;
   }

   public static void nullifyTestExecutionParams()
   {
      testExecutionParams = null;
   }

   private static Environments getTestExecutionEnv()
   {
      String property = ConfigurationService.getProperty(TEST_EXECUTION_ENVIRONMENT);
      return Environments.fromString(property);
   }

   private static Brands getTestExecutionBrand()
   {
      String property = ConfigurationService.getProperty(TEST_EXECUTION_BRAND);
      return Brands.fromString(property);
   }

   private static Locales getTestExecutionLocale()
   {
      String property = ConfigurationService.getProperty(TEST_EXECUTION_LOCALE);
      return Locales.fromString(property);
   }

   public static URL getTemporaryUrl(TestExecutionParams tempParams)
   {
      return UrlProvider.getBaseUrl(tempParams);
   }

   public static String getLanguageCode()
   {
      String language = getTestExecutionParams().getLocaleStr();
      Brands brand = getTestExecutionParams().getBrand();
      if (getTestExecutionParams().isVIPBE())
         brand = Brands.BE;
      return MessageFormat.format("{0}_{1}", language, brand.toString().toUpperCase());
   }
   public static Agents getAgent()
   {
      String property = ConfigurationService.getProperty(TEST_EXECUTION_AGENT);
      return Agents.fromString(property);
   }

   public static boolean isDevEnv()
   {
      return getTestExecutionParams().getEnv().equals(Environments.DEV);
   }

    public static boolean isStngEnv()
    {
       return getTestExecutionParams().getEnv().equals(Environments.STNG);
    }

   public static boolean isSitEnv()
   {
      return getTestExecutionParams().getEnv().equals(Environments.SIT);
   }
}
