package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PacakgePreviousReconciliationDateSearchErrorStepDefs
{
   public final WebElementWait wait = new WebElementWait();

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents =
            new PackageReconcilationPaymentPageComponents();

   @When("they press the search CTA")
   public void they_press_the_search_CTA()
   {
      pKgReconcilationPaymentPageComponents.clickOnSearchCTA();
   }

   @When("have not selected any dates to search")
   public void have_not_selected_any_dates_to_search()
   {
      wait.forJSExecutionReadyLazy();
   }

   @Then("an error message {string} will appear")
   public void an_error_message_will_appear(String string)
   {
      assertThat("Reconcilation Banking Table Displayed",
               pKgReconcilationPaymentPageComponents.isSeodbDateSearchErrorMeassgaes(), is(true));
   }

   @Then("the date boxes will appear in red")
   public void the_date_boxes_will_appear_in_red()
   {
      assertThat("PreviousReconciliation Date Search Error BOX Will appear in Red",
               pKgReconcilationPaymentPageComponents.isSeodbDateSearchErrorsBox(), is(true));
   }

}
