package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.api.requests.search.PackageSearchApi;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import static com.codeborne.selenide.Selenide.open;

public class NextCustomerAndChangeAgentStepDefs
{
   public final RetailPackageNavigation retailpackagenavigation;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   public final FlightOnlyHomePage foHomePage;

   public final SearchResultsPage searchResultsPage;

   public NextCustomerAndChangeAgentStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      foHomePage = new FlightOnlyHomePage();
      searchResultsPage = new SearchResultsPage();
   }

   @Given("the customer is on the Book Confirmation page")
   public void the_customer_is_on_the_Book_Confirmation_page()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
   }


   @Given("the customer is on the Book Confirmation page via API")
   public void customerOnBookConfirmationPageViaAPI()
   {
      completeBookingFoundViaApi();
   }

   private void completeBookingFoundViaApi()
   {
      PackageSearchApi.openSearchResultsPage();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      new ProgressionbarNavigationComponent().clickOnContinueButton();
      retailpassengerdetailspage.selectContinueSummary();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
   }

   @When("they select next customer")
   public void they_select_next_customer()
   {
      retailpassengerdetailspage.nextCustomer();
   }

   @When("they select next customer button")
   public void they_select_next_customer_button()
   {
      retailpassengerdetailspage.nextCustomerButton();
   }

   @Then("complete booking with nextcustomer")
   public void complete_booking_with_nextcustomer()
   {
      foHomePage.navigateToHolidayPage();
      retailpackagenavigation.navigateToPassengerPage();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }

   @Then("complete booking with nextcustomer via API")
   public void completeNextCustomerBookingViaApi()
   {
      completeBookingFoundViaApi();
      retailpassengerdetailspage.userLogout();
   }

   @Given("the customer is on the Retail Inouse home page")
   public void the_customer_is_on_the_Retail_Inouse_home_page()
   {
      retailpackagenavigation.retailLoginChangeagent();
   }

   @When("they click on agent link and select Thirdparty agent")
   public void they_click_on_agent_link_and_select_Thirdparty_agent()
   {
      retailpassengerdetailspage.addTPagent();
   }

   @Then("complete Thirdparty agent booking")
   public void complete_Thirdparty_agent_booking()
   {
      retailpackagenavigation.navigateToPassengerPage();
      retailpassengerdetailspage.fillThePassengerDetailsThirdparty();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();

   }

}
