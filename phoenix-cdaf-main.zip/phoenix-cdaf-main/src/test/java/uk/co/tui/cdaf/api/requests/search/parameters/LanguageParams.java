package uk.co.tui.cdaf.api.requests.search.parameters;

public enum LanguageParams
{
   nl_BE, fr_BE, nl, nl_NL;

   public static LanguageParams fromString(String value)
   {
      for (LanguageParams language : LanguageParams.values())
      {
         if (language.name().equalsIgnoreCase(value.replaceAll("-", "_")))
         {
            return language;
         }
      }
      throw new IllegalArgumentException("Invalid Language: " + value);
   }
}
