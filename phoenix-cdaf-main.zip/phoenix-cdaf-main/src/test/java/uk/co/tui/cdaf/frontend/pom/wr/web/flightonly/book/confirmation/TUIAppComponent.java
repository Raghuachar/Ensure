package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class TUIAppComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[aria-label='My Thomsonapp']")
   private WebElement tuiAppContainer;

   @FindBy(css = "[aria-label='My TUI App heading']")
   private WebElement tuiAppHeading;

   @FindBy(css = "[aria-label='My TUI App heading']+p")
   private WebElement tuiAppDescription;

   @FindBy(css = ".MyTuiApp__appButtons>a:nth-child(1)")
   private WebElement tuiAppStoreIcon;

   @FindBy(css = ".MyTuiApp__appButtons>a:nth-child(2)")
   private WebElement googlePlayIcon;

   public TUIAppComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getTuiAppStoreElement()
   {
      return wait.getWebElementWithLazyWait(tuiAppStoreIcon);
   }

   public void ClickOnTuiAppStore()
   {
      WebElementTools.click(getTuiAppStoreElement());
   }

   public WebElement getGooglePlayElement()
   {
      return wait.getWebElementWithLazyWait(googlePlayIcon);
   }

   public void clickOnGooglePlay()
   {
      WebElementTools.click(getGooglePlayElement());
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getTuiAppComponents()
   {
      return new HashMap<>()
      {
         {
            put("TUI App component", tuiAppContainer);
            put("TUI app heading", tuiAppHeading);
            put("Tui app desc", tuiAppDescription);
            put("Tui app store icon", tuiAppStoreIcon);
            put("Google play", googlePlayIcon);
         }
      };
   }

}
