package uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;

public class VIPLuggageComponent
{
   private final WebElementWait wait;

   private final HashMap<String, WebElement> vipLuggageComponentsMap;

   private final HashMap<String, WebElement> vipTwoAdltsLuggageComponentsMap;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component")
   private WebElement luggageComponent;

   @FindBy(css = "[class*='LuggageAncillary__luggageSummaryContainer']")
   private WebElement luggageDescription;

   @FindBy(css = "[class*='LuggageAncillary__luggageContainer']")
   private WebElement luggageOptions;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component > div > div > section.component.LuggageAncillary__component > div > div > div.LuggageAncillary__luggageContainer > div > div:nth-child(1) > div > div.LuggageAncillary__luggageText.LuggageAncillary__luggages > div:nth-child(1)")
   private WebElement luggageUpgrade;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component > div > div > section.component.LuggageAncillary__component > div > div > div.LuggageAncillary__luggageContainer > div > div:nth-child(1) > div > div.LuggageAncillary__luggageText.LuggageAncillary__luggages > div:nth-child(1) > div > div.cards__priceButton > button")
   private WebElement luggageUpgradeButton;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component > div > div > section.component.LuggageAncillary__component > div > div > div.LuggageAncillary__luggageContainer > div > div:nth-child(1) > div")
   private WebElement adultOneLuggage;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component > div > div > section.component.LuggageAncillary__component > div > div > div.LuggageAncillary__luggageContainer > div.LuggageAncillary__buttonContainer > div > button")
   private WebElement morePassengersButton;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component > div > div > section.component.LuggageAncillary__component > div > div > div.LuggageAncillary__luggageContainer > div > div:nth-child(2) > div")
   private WebElement adultTwoLuggage;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component > div > div > section.component.LuggageAncillary__component > div > div > div.LuggageAncillary__luggageContainer")
   private WebElement luggageComponentExpand;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component > div > div > section.component.LuggageAncillary__component > div > div > div:nth-child(3) > span > div")
   private WebElement moreInformationLink;

   @FindBy(css = "#HubAndSpokeSummaryLuggageAncillary_component > div > div > section.component.LuggageAncillary__component > div > div > div:nth-child(3) > div > section > section")
   private WebElement moreInformationPopUp;

   public VIPLuggageComponent()
   {
      wait = new WebElementWait();
      vipLuggageComponentsMap = new HashMap<>();
      vipTwoAdltsLuggageComponentsMap = new HashMap<>();
   }

   public WebElement getLuggageComponentElement()
   {
      return wait.getWebElementWithLazyWait(luggageComponent);
   }

   public boolean isLuggageComponentDisplayed()
   {
      return WebElementTools.isPresent(getLuggageComponentElement());
   }

   public HashMap<String, WebElement> getVipSummaryComponentsMap()
   {
      vipLuggageComponentsMap.put("Luggage descriptions", luggageDescription);
      vipLuggageComponentsMap.put("Luggage Options", luggageOptions);
      vipLuggageComponentsMap.put("Check in allowance & Price", luggageUpgrade);
      vipLuggageComponentsMap.put("Upgrade CTAs", luggageUpgradeButton);
      vipLuggageComponentsMap.put("Luggage specific T&Cs link", moreInformationLink);
      return vipLuggageComponentsMap;
   }

   public void clickOnMorePassengersButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(morePassengersButton);
   }

   public HashMap<String, WebElement> getTwoAdultLuggageMap()
   {
      vipTwoAdltsLuggageComponentsMap.put("Adult one Luggage", adultOneLuggage);
      vipTwoAdltsLuggageComponentsMap.put("Adult Two Luggage", adultTwoLuggage);
      return vipTwoAdltsLuggageComponentsMap;
   }

   public boolean isLuggageComponentExpandDisplayed()
   {
      return WebElementTools.isPresent(luggageComponentExpand);
   }

   public void clickOnMoreInformation()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(moreInformationLink);
   }

   public boolean ismoreInformationPopUpDisplayed()
   {
      return WebElementTools.isPresent(moreInformationPopUp);
   }

}
