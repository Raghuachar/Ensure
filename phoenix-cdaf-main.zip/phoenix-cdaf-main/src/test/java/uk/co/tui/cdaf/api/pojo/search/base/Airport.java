package uk.co.tui.cdaf.api.pojo.search.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Airport
{
   private String id;

   private String name;

   private boolean available;

}
