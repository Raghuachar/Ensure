package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.roomoptions;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class RoomOptionsPage
{
   public final RoomAndBoardModalComponent modalComponent;

   public final RoomOptionsShowmoreAndShowLessComponent roomOptionsExpandComponent;

   public final ProgressionbarNavigationComponent progressbarComponent;

   public static final ThreadLocal<Double> insPriceDiffDouble = new ThreadLocal<>();

   public RoomOptionsPage()
   {
      modalComponent = new RoomAndBoardModalComponent();
      roomOptionsExpandComponent = new RoomOptionsShowmoreAndShowLessComponent();
      progressbarComponent = new ProgressionbarNavigationComponent();
   }

   public ElementsCollection getAltRoomsSelectButtons()
   {
      return $$("[aria-label='room selecton'] [aria-label='button']");
   }

   public ElementsCollection getAltBoardSelectButtons()
   {
      return $$(".BoardOptionsV2__selectBlock button");
   }

   public void selectFirstAvailableAltRoom()
   {
      getAltRoomsSelectButtons().filterBy(Condition.visible).first().click();
   }

   public void selectFirstAvailableAltBoard()
   {
      getAltBoardSelectButtons().filterBy(Condition.visible).first().click();
   }

   public void navigateBackToSummaryPage()
   {
      $(".BackToYourHolidayButtonComponent__backButtonClass span")
               .shouldBe(Condition.visible).click();
   }

   public SelenideElement insurancePriceChangeBanner()
   {
      return $(".PriceChangeComponent__priceBanner");
   }

   public boolean isPriceChangeIconDisplayed()
   {
      return insurancePriceChangeBanner().$("svg")
               .shouldBe(Condition.visible, Duration.ofSeconds(10)).isDisplayed();
   }

   public SelenideElement getInsurancePriceChangeMessage()
   {
      return insurancePriceChangeBanner().$$(".PriceChangeComponent__priceInfo span").first()
               .shouldBe(Condition.visible, Duration.ofSeconds(10));
   }

   public Double getInsurancePriceDifference()
   {
      return Double.valueOf(getInsurancePriceChangeMessage().getText()
               .split("€")[1].split(" ")[0].trim());
   }

   public SelenideElement getPriceChangeToolTip()
   {
      return $(".PriceChangeComponent__marginLeft .Standard__tooltip");
   }
}
