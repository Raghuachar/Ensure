package uk.co.tui.cdaf.frontend.pom.wr.search.components.destination;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;

import java.util.List;

public interface Destination
{

   boolean isOpen();

   Destination clearSelection();

   Destination selectDestinationFromList(String destination, String resortName);

   Destination selectAllResort(String country, List<String> regions);

   Destination selectRandomDestination();

   ElementsCollection getAllCountryDestinations();

   SelenideElement getCheckBoxSelected();

   ElementsCollection dismissibleTagsDestinations();

   void confirmSelection();
}
