package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class PricebreakdownDetaileddescriptionsBaggageComponents extends AbstractPage
{
   private final WebElementWait wait = new WebElementWait();

   @FindBy(css = ".cards__priceButton button")
   private List<WebElement> baggagepriceButton;

   @FindBy(css = ".UI__priceDetailsSection .UI__subItems li")
   private WebElement checkinbaggage;

   public void baggageSelection()
   {
      if (baggagepriceButton.get(1).isDisplayed())
         wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(baggagepriceButton.get(1));
      WebElementTools.click(baggagepriceButton.get(1));

   }

   public boolean isBaggageDisplayed()
   {
      return WebElementTools.isDisplayed(checkinbaggage);
   }
}
