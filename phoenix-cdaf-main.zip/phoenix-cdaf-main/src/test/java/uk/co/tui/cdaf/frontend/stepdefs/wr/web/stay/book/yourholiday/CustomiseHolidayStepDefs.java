package uk.co.tui.cdaf.frontend.stepdefs.wr.web.stay.book.yourholiday;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.stay.book.StayPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.stay.book.yourholiday.SummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class CustomiseHolidayStepDefs
{
   private final WebElementWait wait;

   private final SummaryPage summaryPage;

   private final StayPageNavigation pageNavigation;

   public CustomiseHolidayStepDefs()
   {
      wait = new WebElementWait();
      summaryPage = new SummaryPage();
      pageNavigation = new StayPageNavigation();
   }

   @Given("the customer is on the Stay Unit Details Page")
   public void the_customer_is_on_the_Stay_Unit_Details_Page()
   {
      pageNavigation.navigateToUnitdetailsPage();
   }

   @When("they select to continue with their hotel selection")
   public void they_select_to_continue_with_their_hotel_selection()
   {
      summaryPage.navigationComponent.selectYourHoliday();
   }

   @Then("they should be navigated to the Customise Your Holiday and the following components should display:")
   public void they_should_be_navigated_to_the_Customise_Your_Holiday_and_the_following_components_should_display(
            List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element =
                     summaryPage.getSummaryPageComponent().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

}
