package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

public class VoucherCodeComponent extends AbstractPage
{
   @FindBy(css = "[aria-label='Voucher Code'] h3")
   private WebElement voucherHeading;

   public WebElement getVoucherHeadingElement()
   {
      return voucherHeading;
   }
}
