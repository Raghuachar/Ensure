package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class AddInsuranceforPackagebookingsComponents extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(AddInsuranceforPackagebookingsComponents.class);

   private final WebElementWait wait;

   @FindAll({ @FindBy(css = ".InsuranceType__selectButton"),
            @FindBy(css = ".InsuranceType__infoText button"),
            @FindBy(css = ".InsuranceType__selectButton") })
   private WebElement insuranceTypeselectButton;

   @FindBy(css = ".BackToYourHolidayLinkComponent__continue span")
   private WebElement backToYourHolidayLinkComponent;

   @FindBy(css = ".Modal__overlay .Modal__modalFooter .Modal__applyButton")
   private WebElement backToYourHolidayAndConfirm;

   public AddInsuranceforPackagebookingsComponents()
   {
      wait = new WebElementWait();
   }

   public void insuranceTypeselectButton()
   {
      TestExecutionParams execParams = ExecParams.getTestExecutionParams();
      if (execParams.getAgent().isThirdparty() && execParams.isNL())
      {
         LOGGER.log(LogLevel.INFO, "No Insurance for NL thirdparty ");
      }
      else if (execParams.getAgent().isThirdparty() && execParams.isBE())
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.scrollAndMouseHover(insuranceTypeselectButton);
         wait.forJSExecutionReadyLazy();
         WebElementTools.click(insuranceTypeselectButton);
         wait.forJSExecutionReadyLazy();
      }
      else if (execParams.getAgent().isInhouse())
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.scrollAndMouseHover(insuranceTypeselectButton);
         wait.forJSExecutionReadyLazy();
         WebElementTools.click(insuranceTypeselectButton);
         wait.forJSExecutionReadyLazy();
      }
   }

   public void backToYourHolidayLinkComponent()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(backToYourHolidayLinkComponent);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(backToYourHolidayLinkComponent);
      wait.forJSExecutionReadyLazy();
   }

   public void backToYourHolidayAndConfirm()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseHover(backToYourHolidayAndConfirm);
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(backToYourHolidayAndConfirm);
      wait.forJSExecutionReadyLazy();
   }
}
