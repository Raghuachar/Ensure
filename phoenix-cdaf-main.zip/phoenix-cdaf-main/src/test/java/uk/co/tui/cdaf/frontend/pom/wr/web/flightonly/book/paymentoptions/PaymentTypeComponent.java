package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class PaymentTypeComponent extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PaymentTypeComponent.class);

   private final WebElementWait wait;

   @FindBy(css = "[aria-label='pay options']")
   private WebElement PaymentOptionPanel;

   @FindBy(css = ".PaymentType__paymentSection h3")
   private WebElement paymentHeading;

   @FindBy(css = "[class*='DepositComponent__DepositComponent'] [class*='inputs__radioButton']")
   private List<WebElement> paymentType;

   @FindBy(css = "span[class*='totalPrice']")
   private WebElement totalPaymentAmount;

   @FindBy(css = "[class*='DiffPaymentType__payBy'] label[class='inputs__radioButton undefined  ']")
   private List<WebElement> paymentCardMethods;

   public PaymentTypeComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getPaymentOptionPanel()
   {
      return wait.getWebElementWithLazyWait(PaymentOptionPanel);
   }

   public WebElement getPaymentHeadingElement()
   {
      return paymentHeading;
   }

   public WebElement getTotalPaymentAmount()
   {
      return totalPaymentAmount;
   }

   public List<WebElement> getPaymentType()
   {
      return wait.getWebElementWithLazyWait(paymentType);
   }

   public void selectFullPay()
   {
      LOGGER.log(LogLevel.INFO, "123");
      if (getPaymentType().size() == 3)
         WebElementTools.click(getPaymentType().get(2));
   }

   public List<WebElement> getPaymentCards()
   {
      return wait.getWebElementWithLazyWait(paymentCardMethods);
   }

}
