package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class TNCpaxdetailspageStepDefs
{
   private final RetailFlightOnlyPageNavigation retailflightNavigation;

   private final RetailPassengerDetailsPage retailPassengerDetailsPage;

   public TNCpaxdetailspageStepDefs()
   {
      retailflightNavigation = new RetailFlightOnlyPageNavigation();
      retailPassengerDetailsPage = new RetailPassengerDetailsPage();
   }

   @Given("that an agent is on the PAX details Page for a flight only customer")
   public void that_an_agent_is_on_the_PAX_details_Page_for_a_flight_only_customer()
   {
      retailflightNavigation.retailLoginFO();
   }

   @When("they select the Terms and Conditions CTA link in the important information section")
   public void they_select_the_Terms_and_Conditions_CTA_link_in_the_important_information_section()
   {

      retailflightNavigation.createOnewayBooking();

   }

   @Then("they will be navigated to new TnC")
   public void they_will_be_navigated_to_new_TnC()
   {
      retailPassengerDetailsPage.nlTnCLink();
      retailPassengerDetailsPage.fillRetailPassengerDetails();
      retailPassengerDetailsPage.userLogout();
   }

}
