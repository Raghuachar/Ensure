package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HeaderComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.browse.homepage.HomePageCommon;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.List;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.hidden;
import static com.codeborne.selenide.Selenide.$;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertTrue;

public class UnitDetailsPage extends AbstractPage
{
   private static int initial_price;

   public final ProgressionbarNavigationComponent progressbarComponent;

   public final AccomodationComponent accomComponent;

   public final HeroBannerComponent heroBannerComponent;

   public final RoomComponent roomComponent;

   public final BoardBasisComponent boardBasisComponent;

   public final WebElementWait wait;

   @FindBy(css = "[aria-label='accomodation header']")
   private WebElement accommdationHeader;

   @FindBy(css = ".sections__sectionTitle")
   private WebElement yourRoomsHeader;

   @FindBy(css = ".stylesRoomTypesV4__selectPricePPn b")
   private List<WebElement> alternativeRoomCard;

   @FindBy(css = "[aria-label*='room option 1']")
   private List<WebElement> yourRoomAccordionList;

   @FindBy(css = "[aria-label*='room option 2']")
   private List<WebElement> yourRoomOption2;

   @FindBy(css = "[aria-label*='room option 2'] .stylesRoomTypesV4__selectPricePPn b")
   private List<WebElement> option2alternativeRoomCard;

   @FindBy(xpath = "//*[@id=\"accomLegacyMessaging__component\"]/div")
   private WebElement legacyMessageShallDisplayed;

   @FindBy(css = "[class='LegacyMessaging__mainTextContainer']")
   private WebElement legacyMessageDisplayed;

   @FindBy(css = "[class='LegacyMessaging__subText']")
   private WebElement legacyMessageSubTextDisplayed;

   @FindAll({ @FindBy(xpath = "//div[@class='Crossover__linkContent']"),
            @FindBy(css = "[class='LegacyMessaging__linkContent']"),
            @FindBy(css = "[class='UI__linkContent']") })
   private WebElement legacyMessagelinkTextDisplayed;

   @FindBy(css = "[class='LegacyMessaging__mainTextContainer'] h2")
   private WebElement legacyMessageMainTextDisplayed;

   @FindAll({ @FindBy(xpath = "//div[@class='Header__headerTitle']/h1/span"),
            @FindBy(xpath = "//h1[@class='UI__title']/span") })
   private WebElement accomadationName;

   @FindBy(css = "[class='hotelpage-name'] h1")
   private WebElement hotelname;

   private String accomName;

   @FindBy(css = "[class='NavigationTabsV2__current']")
   private WebElement guestReviewPosition;

   @FindBy(css = "div[class='Header__guestReviewContainer']")
   private WebElement guestReviewRating;

   public UnitDetailsPage()
   {
      progressbarComponent = new ProgressionbarNavigationComponent();
      accomComponent = new AccomodationComponent();
      heroBannerComponent = new HeroBannerComponent();
      roomComponent = new RoomComponent();
      boardBasisComponent = new BoardBasisComponent();
      wait = new WebElementWait();
      HomePageCommon homepageShared = new HomePageCommon();
      HeaderComponent headercomp = new HeaderComponent();
   }

   public boolean isHotelDetailsPageDisplayed()
   {

      return WebElementTools.isPresent(accommdationHeader);
   }

   public boolean isRoomHeaderDisplayed()
   {
      return $("[area-label*='your rooms']").should(appear, Duration.ofSeconds(5)).isDisplayed();
   }

   public String getYourRoomsHeader()
   {
      try
      {
         return WebElementTools.getElementText(wait.getWebElementWithLazyWait(yourRoomsHeader))
                  .trim();
      }
      catch (Exception e)
      {
         return StringUtils.EMPTY;
      }
   }

   public void getAlternativeRoomCardInAsc()
   {
      if (yourRoomAccordionList.size() == 3)
      {
         initial_price =
                  Integer.parseInt(alternativeRoomCard.get(0).getText().replaceAll("\\D+", ""));
         assertTrue(Integer
                  .parseInt(alternativeRoomCard.get(1).getText()
                           .replaceAll("\\D+", "")) > initial_price);
      }
   }

   public void getAlternativeRoomCards()
   {
      if (yourRoomAccordionList.size() == 3)
      {
         assertThat("Additional Rooms are not present",
                  roomComponent.isAdditionalRoomAccordionDisplayed(), is(true));
      }
   }

   public void getShowDetailsAlternativeRoomCardInAsc()
   {
      if (yourRoomOption2.size() == 3)
      {
         initial_price =
                  Integer.parseInt(
                           option2alternativeRoomCard.get(0).getText().replaceAll("\\D+", ""));
         assertTrue(Integer.parseInt(
                  option2alternativeRoomCard.get(1).getText()
                           .replaceAll("\\D+", "")) > initial_price);
      }
   }

   public boolean islegacyMessageShallDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(legacyMessageShallDisplayed);
      return WebElementTools.isPresent(legacyMessageShallDisplayed);
   }

   public boolean islegacyMessageDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(legacyMessageDisplayed);
      return WebElementTools.isPresent(legacyMessageDisplayed);
   }

   public String getlegacyMessageSubText()
   {
      WebElementTools.scrollTo(legacyMessageSubTextDisplayed);
      return WebElementTools.getElementText(legacyMessageSubTextDisplayed);
   }

   public String getlegacyMessageLinkText()
   {
      WebElementTools.scrollTo(legacyMessagelinkTextDisplayed);
      return WebElementTools.getElementText(legacyMessagelinkTextDisplayed);
   }

   public String getlegacyMessageMainText()
   {
      WebElementTools.scrollTo(legacyMessageMainTextDisplayed);
      return WebElementTools.getElementText(legacyMessageMainTextDisplayed);
   }

   public void clickOnlegacyMessageHyperLink()
   {
      wait.forAppear(legacyMessagelinkTextDisplayed);
      WebElementTools.click(legacyMessagelinkTextDisplayed);
      wait.forComplexPageLoad();

   }

   public String getHotelName()
   {
      return hotelname.getText();
   }

   public void getAccomadationName()
   {
      accomName = accomadationName.getText();
   }

   public void sameAccomadationNameDispalyed()
   {
      wait.forAppear(hotelname);
      String accomadationName = accomName.split(" ")[1];
      assertThat(getHotelName(), containsString(accomadationName));
   }

   public boolean accomadationNameDisplayed()
   {
      return WebElementTools.isPresent(accomadationName);
   }

   public String getLegacyWebSiteUrl()
   {
      return WebDriverUtils.getDriver().getCurrentUrl();
   }

   public boolean isGuestReviewTabPositioned()
   {
      return WebElementTools.isPresent(guestReviewPosition);
   }

   public boolean isGuestReviewDataDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      String mfeParentElemnt = "tui-customer-reviews";
      String guestReviewTabData = "div[class='customer-reviews']";
      return WebElementTools.isPresent(
               SelenideHelper.getShadowRootElement(guestReviewTabData, mfeParentElemnt));
   }

   public boolean isGuestReviewDisplayed()
   {
      return WebElementTools.isPresent(guestReviewRating);
   }

   public boolean isSearchPanelMFEHidden()
   {
      return $("tui-search-panel-mfe").is(hidden);
   }

   public void clickEditSearch()
   {
      $(".EditButton__editSearch a").click();
   }
}
