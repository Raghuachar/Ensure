package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class AccomodationComponent extends AbstractPage
{
   public Map<String, WebElement> accomodationMap;

   public AccomodationComponent()
   {
      accomodationMap = new HashMap<>();
   }

   public Map<String, WebElement> getAccomComponents()
   {
      accomodationMap.put("Hotel name", getHotelName());
      accomodationMap.put("Ratings", getHotelRatings());
      accomodationMap.put("Tooltip", getHotelTooltip());
      return accomodationMap;
   }

   public boolean isHotelNamedisplayed()
   {
      return getHotelName().isDisplayed();
   }

   public SelenideElement validateUnitPageHeaderConceptLabel()
   {
      return $(".Header__conceptLogo");
   }

   public boolean isGeoInformation()
   {
      return $("[aria-label='location destination name']").isDisplayed();
   }

   public boolean isofficialRating()
   {
      return $("[aria-label='Editorial Information']").isDisplayed();
   }

   public boolean isaccommodationDescription()
   {
      return $(".About__content").isDisplayed();
   }

   public boolean isaccommodationUSPs()
   {
      return !$$(".AtAGlance__content").isEmpty();
   }

   private SelenideElement getHotelName()
   {
      return $("[aria-label='accomodation header'] h1");
   }

   private SelenideElement getHotelRatings()
   {
      return $("[aria-label='accomodation header'] [aria-label='ratings']");
   }

   private SelenideElement getHotelTooltip()
   {
      return $("[aria-label='accomodation header'] [role='tooltip']");
   }
}
