package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.extraoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;

public class InsuranceComponent
         extends uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.InsuranceComponent
{
   private final WebElementWait wait;

   @FindBy(css = ".InfantCheckbox .GetQuoteV2__notChecked")
   private List<WebElement> InfantCheckbox;

   @FindBy(css = ".GetQuoteV2__infantNotBorn.GetQuoteV2__notBornChecked")
   private WebElement infantNotyetBornDisabled;

   @FindAll({
            @FindBy(css = ".GetQuoteV2__infantNotBorn.GetQuoteV2__notChecked label[aria-label='checkbox'] span svg[class='inputs__checkIcon']"),
            @FindBy(css = ".GetQuoteV2__infantNotBorn.GetQuoteV2__notChecked"),
            @FindBy(css = ".GetQuoteV2__infantNotBorn.GetQuoteV2__notChecked label[aria-label='checkbox']") })
   private List<WebElement> infantNotyetBornEnabled;

   @FindBy(css = "[class*='expInsurance']")
   private WebElement insuranceComponent;

   @FindBy(css = "[class*='GetQuoteV2__checked']")
   private List<WebElement> selectOnePassengerCheckbox;

   @FindBy(css = "[aria-label*='total price']")
   private WebElement totalPrice;

   @FindBy(css = "[class='GetQuoteV2__getQuote'] [class*='buttons__button']")
   private WebElement updatePriceEnabledButton;

   @FindBy(css = "[class*='AccordionToggle__accordionToggle']")
   private List<WebElement> insuranceAccordion;

   @FindBy(css = "[class*='InsuranceType__selectButton']")
   private List<WebElement> insuranceEnabledButton;

   public InsuranceComponent()
   {
      wait = new WebElementWait();
   }

   public void navigateToInfantNotBornCheckBox()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(InfantCheckbox.get(0));
   }

   public boolean isInfantCheckBoxDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(InfantCheckbox.get(0));
   }

   public boolean isInfantCheckBoxDisabled()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(infantNotyetBornDisabled);
   }

   public void clickInfantNotBornCheckBox()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(InfantCheckbox.get(0));
   }

   public void isInfantNotYetBornCheckBoxClicked()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(infantNotyetBornEnabled.get(0));
   }

   public boolean clickUpdatePriceButton()
   {
      WebElementTools.mouseOverAndClick(updatePriceEnabledButton);
      wait.forJSExecutionReadyLazy();
      return true;
   }

   public void unSelectTickForNonLeadPassenger()
   {
      WebElementTools.scrollToCenter(insuranceComponent);
      WebElementTools.mouseOverAndClick(selectOnePassengerCheckbox.get(1));
      wait.forJSExecutionReadyLazy();
   }

   public String getTotalPrice()
   {
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(totalPrice));
   }

   public void selectEnabledInsuranceButton()
   {
      try
      {
         WebElementTools.scrollToCenter(insuranceAccordion.get(0));
         wait.forJSExecutionReadyLazy();
         WebElementTools.mouseOverAndClick(insuranceAccordion.get(0));
         WebElementTools.mouseOverAndClick(insuranceAccordion.get(1));
         wait.forJSExecutionReadyLazy();
         WebElementTools.mouseOverAndClick(insuranceEnabledButton.get(0));
      }
      catch (Exception e)
      {

      }
   }

}
