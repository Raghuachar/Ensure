package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePagetemplateReconcilePaymentsHeaderStepDefs
{

   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackagePagetemplateReconcilePaymentsHeaderStepDefs()
   {

      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the Agent is on the Reconcile payments page")
   public void that_the_Agent_is_on_the_Reconcile_payments_page()
   {
      packagenavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

   @When("they view the page header beneath the TUI Global header")
   public void they_view_the_page_header_beneath_the_TUI_Global_header()
   {
      assertThat(" Global Header is not present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
   }

   @Then("they can able see the {string} header")
   public void they_can_able_see_the_header(String string)
   {
      wait.forJSExecutionReadyLazy();

   }

}
