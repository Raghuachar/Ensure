package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.*;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class MFESearchPanelDepartureDateStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(MFESearchPanelDepartureDateStepDefs.class);

   private static final WebElementWait wait = new WebElementWait();

   private final SearchPanel searchPanel = getSearchPanel();

   private final PackageNavigation packageNavigation;

   private final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent;

   private final SearchResultsPage searchResultsPage;

   private final SearchPanelComponent searchPanelComponent;

   private final Map<String, WebElement> searchMap;

   private Set<String> initialHandles;

   private String siteId;

   private List<String> availableMonthsBeforeSearchselected;

   private List<String> availableMonthsAfterSearchselected;

   public MFESearchPanelDepartureDateStepDefs()
   {
      packageNavigation = new PackageNavigation();
      departureAirportOrDestinationComponent =
               new DepartureAirportAndDestinationAndDatesComponent();
      searchResultsPage = new SearchResultsPage();
      searchMap = new HashMap<>();
      searchPanelComponent = new SearchPanelComponent();
   }

   @Given("the {string} is on the {string} MFE page")
   public void the_is_on_the_MFE_page(String agent, String respectivePage)
   {
      if (respectivePage.equalsIgnoreCase("Home page"))
      {
         packageNavigation.navigateToHoldaySearchPage();
      }
      else if (respectivePage.equalsIgnoreCase("Search Results page"))
         packageNavigation.navigateToSearchResultPage();
      else if (respectivePage.equalsIgnoreCase("Unit Details page"))
      {
         packageNavigation.navigateToUnitDetailsPage();
         searchResultsPage.editSearch().hover().click();
      }
      else if (respectivePage.equalsIgnoreCase("Single accommodation Search Results page"))
         packageNavigation.navigateToSingleAccomSearchResultPage();
   }

   @When("they select one of the following {string} on the Search Panel Departure Date field")
   public void they_select_one_of_the_following_on_the_Search_Panel_Departure_Date_field(
            String string)
   {
      searchPanelComponent.selectMFEWhenField();
   }

   @Then("the Departure Date modal shall be displayed")
   public void the_Departure_Date_modal_shall_be_displayed()
   {
      assertThat("departure date Calendar is not displayed   ",
               departureAirportOrDestinationComponent.isCalenderDisplayedMFE(), is(true));
   }

   @And("the Departure Date modal shall display the following:")
   public void the_Departure_Date_modal_shall_display_the_following(List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchPanelComponent.getSearchPanelComponentsMFE());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("the Flexibility section on the modal shall display the following:")
   public void the_Flexibility_section_on_the_modal_shall_display_the_following(
            List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap
               .putAll(searchResultsPage.searchPanelComponent.getSearchPanelComponentsFlexibleMFE());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @And("the radio buttons shall be selectable")
   public void the_radio_buttons_shall_be_selectable()
   {
      searchResultsPage.searchPanelComponent.isRadioFlexibleSelectedMFE();
   }

   @And("the {string} days radio button shall be set to selected by default")
   public void the_days_radio_button_shall_be_set_to_selected_by_default(String string)
   {
      assertThat("the +/-3 days radio button shall be set to selected by default not selected",
               searchResultsPage.searchPanelComponent.isDefaultFlexibleSelectedMFE(), is(true));
   }

   @Given("the {string} is viewing the Search Panel Departure Date modal")
   public void the_is_viewing_the_Search_Panel_Departure_Date_modal(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectMFEWhenField();
   }

   @When("they wish to close this modal")
   public void they_wish_to_close_this_modal()
   {
      assertThat("departure date Calendar is not displayed   ",
               departureAirportOrDestinationComponent.isCalenderDisplayedMFE(), is(true));
   }

   @Then("they can do this by selecting the following:")
   public void they_can_do_this_by_selecting_the_following(List<String> closeModal)
   {
      for (String closeDate : closeModal)
      {
         try
         {
            if (closeDate.equalsIgnoreCase("x") || closeDate.equalsIgnoreCase("DONE")
                     || closeDate.equalsIgnoreCase("Select outside of the modal"))
               searchResultsPage.searchPanelComponent.closeDepartureDateModalMFE();
         }
         catch (Exception e)
         {
            LOGGER.log(LogLevel.INFO, closeDate + "component is not present");
         }
      }
   }

   @And("the departure date is set to it's default value")
   public void the_departure_date_is_set_to_it_s_default_value()
   {
      assertThat("the departure date is set to it's default value not",
               searchPanelComponent.isDefaultDepartureMFE(), is(true));
   }

   @And("they select a departure date flexibility option")
   public void they_select_a_departure_date_flexibility_option()
   {
      assertThat("the +/-3 days radio button shall be set to selected by default not selected",
               searchResultsPage.searchPanelComponent.isDefaultFlexibleSelectedMFE(), is(true));
   }

   @And("the previously selected flexibility option shall be deselected")
   public void the_previously_selected_flexibility_option_shall_be_deselected()
   {
      searchResultsPage.searchPanelComponent.isRadioFlexibleSelectedMFE();
   }

   @And("the newly selected flexibility option shall be selected")
   public void the_newly_selected_flexibility_option_shall_be_selected()
   {
      searchResultsPage.searchPanelComponent.verifyFlexibleCheckedMFE();
   }

   @And("the newly selected flexibility option shall be retained on the modal")
   public void the_newly_selected_flexibility_option_shall_be_retained_on_the_modal()
   {
      assertThat("the newly selected flexibility option shall be retained on the modal not",
               "+/-7".equals(searchResultsPage.searchPanelComponent.retainedOnModal()), is(true));
   }

   @And("a flexibility option has been previously entered")
   public void a_flexibility_option_has_been_previously_entered()
   {
      searchPanelComponent.selectMFEWhenField();
      searchResultsPage.searchPanelComponent.isRadioFlexibleSelectedMFE();
      searchResultsPage.searchPanelComponent.clickDepartureDoneButton();
   }

   @And("the previously selected flexibility radio button shall be selected")
   public void the_previously_selected_flexibility_radio_button_shall_be_selected()
   {
      assertThat("the newly selected flexibility option shall be retained on the modal not",
               "+/-7".equals(searchResultsPage.searchPanelComponent.retainedOnModal()), is(true));
   }

   @Given("the {string} is viewing the Search Panel Departure Date modal {string} language")
   public void the_is_viewing_the_Search_Panel_Departure_Date_modal_language(String agent,
            String language)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectLanguageMFE(language);
      searchPanelComponent.selectMFEWhenField();
   }

   @And("the current date is earlier than the configurable package inventory HYBRIS switch date {string}")
   public void the_current_date_is_earlier_than_the_configurable_package_inventory_HYBRIS_switch_date(
            String userDateStr)
   {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
      LocalDate userDate = LocalDate.parse(userDateStr, formatter);
      LocalDate systemDate = LocalDate.now();
      assertTrue(systemDate.isBefore(userDate));
   }

   @And("they view the Month Selector")
   public void they_view_the_Month_Selector()
   {
      assertThat("they view the Month Selector is not displayed",
               departureAirportOrDestinationComponent.isVerifyingMonthSelector(), is(true));
   }

   @Then("they will be able to see a LEAVE EARLIER option in the dropdown list")
   public void they_will_be_able_to_see_a_LEAVE_EARLIER_option_in_the_dropdown_list(
            io.cucumber.datatable.DataTable dataTable)
   {
      departureAirportOrDestinationComponent.selectLegacyDropdownMFE(0);
      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedLeaveEarlier = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("LEAVE EARLIER")).findFirst().orElse(null);

      String actualLeaveEarlier =
               departureAirportOrDestinationComponent.selectLegacyDropdownTextMFE();

      assertEquals("Leave Earlier translations is not matched ", expectedLeaveEarlier,
               actualLeaveEarlier);
   }

   @And("they select the {string} option from the monthly calendar dropdown")
   public void they_select_the_option_from_the_monthly_calendar_dropdown(String string)
   {
      departureAirportOrDestinationComponent.selectLegacyDropdownMFE(0);
   }

   @And("the Departure Date Modal shall be display the following Departure Date inventory HYBRIS switch date message:")
   public void the_Departure_Date_Modal_shall_be_display_the_following_Departure_Date_inventory_HYBRIS_switch_date_message(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId;
      String expectedCrossOverMessageText = "";
      String expectedCrossOverLinkText = "";
      String actualCrossOverMessageText = "";
      String actualCrossOverLinkText = "";
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      actualCrossOverMessageText =
               departureAirportOrDestinationComponent.getDatesCrossOverMessageElementText()
                        .getText();

      for (Map<String, String> dataMap : dataTableTemp)
      {
         siteId = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
                  ? (BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
                  + (BDDSiteIdResolver.getSiteRTId().toLowerCase())
                  : (getTestExecutionParams().getLocaleStr().toLowerCase().contains("fr_be"))
                  ? getTestExecutionParams().getLocaleStr().toLowerCase()
                  : BDDSiteIdResolver.getSiteRTId().toLowerCase();
         if (siteId.equals(dataMap.get("site")))
         {
            if (siteId.equals("inhouse_rt_be") || siteId.equals("inhouse_rt_nl"))
               actualCrossOverLinkText = departureAirportOrDestinationComponent
                        .getDatesCrossOverLinkElementText1().get(0).getText() + " "
                        + departureAirportOrDestinationComponent.getDatesCrossOverLinkElementText1()
                        .get(1).getText();
            else
               actualCrossOverLinkText = departureAirportOrDestinationComponent
                        .getDatesCrossOverLinkElementText().getText();
            expectedCrossOverMessageText = dataMap.get("legacyLookingToFlyText");
            expectedCrossOverLinkText = dataMap.get("legacySiteLinkText");

            // TODO: probably it needs assertion or entire step could be removed from scenario
         }
      }
   }

   @When("they select an available date from the calendar")
   public void they_select_an_available_date_from_the_calendar()
   {
      searchResultsPage.searchPanelComponent.selectAvailableDateFromCalendar();
   }

   @Then("the Departure Date modal shall remain open")
   public void the_Departure_Date_modal_shall_remain_open()
   {
      assertTrue("departure date Calendar is closed",
               departureAirportOrDestinationComponent.isCalenderDisplayedMFE());
   }

   @And("the selected date shall be in selected state")
   public void the_selected_date_shall_be_in_selected_state()
   {
      assertTrue("the selected date shall Not in selected state",
               searchResultsPage.searchPanelComponent.isDateCellIsSelectedStateMFE());
   }

   @And("the Search Panel Departure Date field shall be populated with the date selected from the calendar")
   public void the_Search_Panel_Departure_Date_field_shall_be_populated_with_the_date_selected_from_the_calendar()
   {
      String expectedValue = searchResultsPage.searchPanelComponent.getSelectedTextMFE();
      String[] actualValue =
               searchResultsPage.searchPanelComponent.getMFEDepartureDateFieldTextMFE().split(" ");
      assertEquals(
               "the Search Panel Departure Date field is Not populated with the date selected from the calendar",
               expectedValue, actualValue[0]);
   }

   @Then("the selected departure date in the calendar shall clear")
   public void the_selected_departure_date_in_the_calendar_shall_clear()
   {
      assertTrue("The selected departure date is not cleared",
               searchResultsPage.searchPanelComponent.isNoDateCellIsSelectedStateMFE());
   }

   @And("the month selector shall return to the current month or first month where there is availability")
   public void the_month_selector_shall_return_to_the_current_month_or_first_month_where_there_is_availability()
   {
      String currentMonth = searchResultsPage.searchPanelComponent.getCurrentDisplayedMonth();
      String firstMonthWithAvailability =
               searchResultsPage.searchPanelComponent.getFirstMonthWithAvailability();
      assertEquals(
               "The calendar did not return to the current month or the first month with availability.",
               currentMonth, firstMonthWithAvailability);
   }

   @And("the Search Panel Departure Date shall be set to default value :")
   public void the_Search_Panel_Departure_Date_shall_be_set_to_default_value(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedDepartureDate = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("Departure Date")).findFirst().orElse(null);

      String actualDepartureDate =
               searchResultsPage.searchPanelComponent.getMFEDepartureDateFieldTextMFE();

      assertEquals("Departure Date translations is not matched ", expectedDepartureDate,
               actualDepartureDate);
   }

   @And("then verify the translated for each of the Western Region source markets as follows:")
   public void then_verify_the_translated_for_each_of_the_Western_Region_source_markets_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedDepartureDateTitle =
               maps.stream().filter(row -> row.get("site").equals(siteId))
                        .map(row -> row.get("Departure Date title")).findFirst().orElse(null);
      String expectedClearAll = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("CLEAR ALL")).findFirst().orElse(null);
      String expectedDone = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("DONE")).findFirst().orElse(null);

      String actualDepartureDateTitle =
               searchResultsPage.searchPanelComponent.getDepartureDateTitleTextMFE();
      String actualClearAll = searchResultsPage.searchPanelComponent.getClearAllTextMFE();
      String actualDone = searchResultsPage.searchPanelComponent.getDoneTextMFE();

      assertEquals("Departure Date title translations is not matched ", expectedDepartureDateTitle,
               actualDepartureDateTitle);
      assertEquals("CLEAR ALL translations is not matched ", expectedClearAll, actualClearAll);
      assertEquals("Done translations is not matched ", expectedDone, actualDone);
   }

   @Then("the flexibility section shall be translated for each of the Western Region source markets as follows:")
   public void the_flexibility_section_shall_be_translated_for_each_of_the_Western_Region_source_markets_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedFlexibleTitle = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("How flexible?")).findFirst().orElse(null);
      String expectedNotFlexible = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("Not Flexible")).findFirst().orElse(null);
      String expectedThreeDays = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("+/- 3 days")).findFirst().orElse(null);
      String expectedSevenDays = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("+/- 7 days")).findFirst().orElse(null);
      String expectedFourteenDays = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("+/- 14 days")).findFirst().orElse(null);

      String actualFlexibleTitle = searchResultsPage.searchPanelComponent.getFlexibleTitleTextMFE();
      String actualNotFlexible =
               searchResultsPage.searchPanelComponent.getFlexibleOptionTextMFE().get(0);
      String actualThreeDays =
               searchResultsPage.searchPanelComponent.getFlexibleOptionTextMFE().get(1);
      String actualSevenDays =
               searchResultsPage.searchPanelComponent.getFlexibleOptionTextMFE().get(2);
      String actualFourteenDays =
               searchResultsPage.searchPanelComponent.getFlexibleOptionTextMFE().get(3);

      assertEquals("Flexible title translations is not matched ", expectedFlexibleTitle,
               actualFlexibleTitle);
      assertEquals("Not Flexible translations is not matched ", expectedNotFlexible,
               actualNotFlexible);
      assertEquals("+/- 3 days translations is not matched ", expectedThreeDays, actualThreeDays);
      assertEquals("+/- 7 days translations is not matched ", expectedSevenDays, actualSevenDays);
      assertEquals("+/- 14 days translations is not matched ", expectedFourteenDays,
               actualFourteenDays);
   }

   @And("the months within the Month Selector shall be translated for each of the Western Region source markets as follows:")
   public void the_months_within_the_Month_Selector_shall_be_translated_for_each_of_the_Western_Region_source_markets_as_follows(
            List<Map<String, String>> translations)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      searchResultsPage.searchPanelComponent.verifyMonthSelectorTranslations(siteId, translations);
   }

   @Then("the days within the calendar shall be translated for each of the Western Region source markets as follows:")
   public void the_days_within_the_calendar_shall_be_translated_for_each_of_the_Western_Region_source_markets_as_follows(
            List<Map<String, String>> translations)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      searchResultsPage.searchPanelComponent.verifyDayTranslations(siteId, translations);
   }

   @When("they select the hyperlink within the legacy message in the departure date")
   public void theySelectTheHyperlinkWithinTheLegacyMessageInTheDepartureDate()
   {
      siteId = getTestExecutionParams().getBrandStr();
      searchPanel.departure().clearSelection().selectMonth("EERDER VERTREKKEN");
      SelenideElement element = searchPanel.legacyLink();
      assertTrue("the hyperlink within the legacy message is not displayed", element.isDisplayed());
      element.hover().click();
      initialHandles = WebDriverUtils.getDriver().getWindowHandles();
   }

   @And("the departure date Legacy website shall open on the existing browser tab")
   public void theDepartureDateLegacyWebsiteShallOpenOnTheExistingBrowserTab()
   {
      Set<String> currentHandles = WebDriverUtils.getDriver().getWindowHandles();
      assertTrue("Website did not open in the existing tab",
               (currentHandles.containsAll(initialHandles)));
   }

   @Then("the legacy website site shall be displayed in the relevant source market language for departure date")
   public void theLegacyWebsiteSiteShallBeDisplayedInTheRelevantSourceMarketLanguageForDepartureDate(
            DataTable dataTable)
   {
      List<Map<String, String>> maps = dataTable.asMaps(String.class, String.class);
      String expectedLegacy = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("legacy website URL")).findFirst().orElse(null);
      assertEquals(
               "the legacy website site is not displayed in the relevant source market language",
               WebDriverUtils.getDriver().getCurrentUrl(),
               expectedLegacy);
   }

   @Then("the MFE Departure Date Modal shall be display the following Departure Date inventory HYBRIS switch date message:")
   public void the_MFE_Departure_Date_Modal_shall_be_display_the_following_Departure_Date_inventory_HYBRIS_switch_date_message(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedCrossOverMessageTextMFE =
               maps.stream().filter(row -> row.get("site").equals(siteId))
                        .map(row -> row.get("legacyLookingToFlyText")).findFirst().orElse(null);
      String expectedCrossOverLinkTextMFE =
               maps.stream().filter(row -> row.get("site").equals(siteId))
                        .map(row -> row.get("legacySiteLinkText")).findFirst().orElse(null);

      String actualCrossOverMessageTextMFE =
               departureAirportOrDestinationComponent.getDatesCrossOverMessageElementTextMFE();

      String homePageURL = WebDriverUtils.getDriver().getCurrentUrl();

      String actualCrossOverLinkTextMFE;

      if (homePageURL.contains("-retailagents"))
      {
         actualCrossOverLinkTextMFE =
                  departureAirportOrDestinationComponent.getDatesCrossOverElementTextMFE();
      }
      else
      {
         actualCrossOverLinkTextMFE =
                  departureAirportOrDestinationComponent.getDatesCrossOverLinkElementTextMFE();
      }

      assertEquals("legacy Site Link Text translations is not matched ",
               expectedCrossOverLinkTextMFE, actualCrossOverLinkTextMFE);

      assertEquals("legacy Looking To Fly Text translations is not matched ",
               expectedCrossOverMessageTextMFE, actualCrossOverMessageTextMFE);
   }

   @And("they are viewing the Departure Date inventory HYBRIS switch date message")
   public void they_are_viewing_the_Departure_Date_inventory_HYBRIS_switch_date_message()
   {
      assertTrue("Departure Date inventory HYBRIS switch date message not displayed",
               departureAirportOrDestinationComponent.departureDateLegacyDisplayed());
   }

   @When("they select the hyperlink within the departure legacy message")
   public void they_select_the_hyperlink_within_the_departure_legacy_message()
   {
      siteId = getTestExecutionParams().getBrandStr();
      initialHandles = WebDriverUtils.getDriver().getWindowHandles();
      departureAirportOrDestinationComponent.clickDepartureDateLegacyHyperLink();
   }

   @And("the customer shall be positioned to the new browser tab")
   public void the_customer_shall_be_positioned_to_the_new_browser_tab()
   {
      assertTrue("the WR legacy website, Not opened in a new browser tab",
               departureAirportOrDestinationComponent.isLegacyWebSitePresent());
   }

   @Then("the Month Selector field shall be set to the current month year")
   public void the_month_selector_field_shall_be_set_to_the_current_month_year()
   {
      String currentMonth = searchResultsPage.searchPanelComponent.getCurrentDisplayedMonth();
      String firstMonthWithAvailability =
               searchResultsPage.searchPanelComponent.getFirstMonthWithAvailability();
      assertEquals(
               "The calendar did not return to the current month or the first month with availability",
               currentMonth, firstMonthWithAvailability);
   }

   @And("the calendar shall be populated with the calendar dates for the current month year")
   public void the_calendar_shall_be_populated_with_the_calendar_dates_for_the_current_month_year()
   {
      assertTrue("The calendar is Not populated with the calendar dates for the current month/year",
               searchResultsPage.searchPanelComponent.isCalendarPopulatedWithCurrentMonthDates());
   }

   @And("the Customer or Agent shall be able to select months in the future")
   public void the_customer_or_agent_shall_be_able_to_select_months_in_the_future()
   {
      searchResultsPage.searchPanelComponent.customerAgentAbleToSelectMonthsInFuture();
   }

   @And("the dates that have already passed shall be greyed out on the Calendar")
   public void the_dates_that_have_already_passed_shall_be_greyed_out_on_the_Calendar()
   {
      assertTrue("The dates that have already passed are not greyed out on the Calendar",
               searchResultsPage.searchPanelComponent.verifyPastDatesGreyedOut());
   }

   @And("the dates that have already passed shall not be selectable on the Calendar")
   public void the_dates_that_have_already_passed_shall_not_be_selectable_on_the_Calendar()
   {
      assertTrue("The dates that have already passed are selectable on the Calendar",
               searchResultsPage.searchPanelComponent.verifyPastDatesUnselectable());
   }

   @And("the current date shall be greyed out")
   public void the_current_date_shall_be_greyed_out()
   {
      assertTrue("The current date not greyed out on the Calendar",
               searchResultsPage.searchPanelComponent.verifyCurrentDateGreyedOut());
   }

   @And("the current date shall not be selectable")
   public void the_current_date_shall_not_be_selectable()
   {
      assertTrue("The current date are selectable on the Calendar",
               searchResultsPage.searchPanelComponent.verifyCurrentDateUnselectable());
   }

   @And("there are departure dates where no results are available based on the other selections within the search panel of departure airport and destination")
   public void there_are_departure_dates_where_no_results_are_available_based_on_the_other_selections_within_the_search_panel_of_departure_airport_and_destination()
   {
      searchPanel.airport().clearSelection().setAllAirportsSelected(true).confirmSelection();
      searchPanel.destination().clearSelection();
      List<SelenideElement> availableCountries =
               departureAirportOrDestinationComponent.getMFEDestinationCountryListEnabled();
      availableCountries.get(1).click();
   }

   @And("the unavailable dates shall be greyed out on the Calendar")
   public void the_unavailable_dates_shall_be_greyed_out_on_the_Calendar()
   {
      assertTrue("The unavailable dates are not greyed out on the Calendar",
               searchResultsPage.searchPanelComponent.verifyPastDatesGreyedOut());
   }

   @And("the unavailable dates shall not be selectable on the Calendar")
   public void the_unavailable_dates_shall_not_be_selectable_on_the_Calendar()
   {
      assertTrue("The unavailable dates are selectable on the Calendar",
               searchResultsPage.searchPanelComponent.verifyPastDatesUnselectable());
   }

   @And("a departure date has been previously entered")
   public void a_departure_date_has_been_previously_entered()
   {
      searchPanelComponent.selectMFEWhenField();
      searchResultsPage.searchPanelComponent.customerAgentAbleToSelectMonthsInFuture();
      searchResultsPage.searchPanelComponent.selectAvailableDateFromCalendar();
      searchResultsPage.searchPanelComponent.closeDepartureDateModalMFE();
   }

   @And("the Month Selector field shall be set to the month year of the date previously selected by the customer")
   public void the_month_selector_field_shall_be_set_to_the_month_year_of_the_date_previously_selected_by_the_customer()
   {
      String selectedMonth =
               searchResultsPage.searchPanelComponent.getCurrentDisplayedMonth().toLowerCase();
      String[] departureDateFieldText =
               searchResultsPage.searchPanelComponent.getMFEDepartureDateFieldTextMFE().split(" ");
      String populatedDate = departureDateFieldText[1] + " " + departureDateFieldText[2];
      assertEquals(
               "The Month Selector field Not set to the month/year of the date previously selected by the customer",
               selectedMonth, populatedDate);
   }

   @And("the calendar shall be populated with the calendar dates for the month year of the date previously selected by the customer")
   public void the_calendar_shall_be_populated_with_the_calendar_dates_for_the_month_year_of_the_date_previously_selected_by_the_customer()
   {
      assertTrue(
               "The calendar Not populated with the calendar dates for the month/year of the date previously selected by the customer",
               departureAirportOrDestinationComponent.isCalenderDisplayedMFE());
   }

   @And("the Customer or Agent shall be able to select previous months and future months that are not before the month of the current date")
   public void the_customer_or_agent_shall_be_able_to_select_previous_months_and_future_months_that_are_not_before_the_month_of_the_current_date()
   {
      searchResultsPage.searchPanelComponent.customerAgentAbleToSelectMonthsInFuture();
   }

   @And("there are departure months where no results are available based on the other selections within the search panel departure airport and destination")
   public void there_are_departure_months_where_no_results_are_available_based_on_the_other_selections_within_the_search_panel_departure_airport_and_destination()
   {
      searchPanelComponent.selectMFEWhenField();
      wait.forJSExecutionReadyLazy();
      availableMonthsBeforeSearchselected =
         searchResultsPage.searchPanelComponent.getActualAvailableMonths();
      searchPanel.airport().clearSelection().setAllAirportsSelected(true).confirmSelection();
      searchPanel.destination().clearSelection();
      List<SelenideElement> availableCountries =
               departureAirportOrDestinationComponent.getMFEDestinationCountryListEnabled();
      availableCountries.get(0).click();
   }

   @And("the unavailable months shall not be displayed in the month selector drop down list")
   public void the_unavailable_months_shall_not_be_displayed_in_the_month_selector_drop_down_list()
   {
      searchPanelComponent.selectMFEWhenField();
      availableMonthsAfterSearchselected =
               searchResultsPage.searchPanelComponent.getActualAvailableMonths();
      assertNotEquals("Available months before search and selected months should not be equal",
               availableMonthsBeforeSearchselected, availableMonthsAfterSearchselected);
      assertTrue("Available months before search should contain all selected months",
               availableMonthsBeforeSearchselected.containsAll(availableMonthsAfterSearchselected));
   }
}
