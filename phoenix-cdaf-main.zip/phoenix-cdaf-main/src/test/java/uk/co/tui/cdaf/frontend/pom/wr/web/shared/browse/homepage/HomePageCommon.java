package uk.co.tui.cdaf.frontend.pom.wr.web.shared.browse.homepage;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.*;

import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class HomePageCommon extends AbstractPage
{

   private static final LinkedHashMap<String, String> countryNamesMap;

   private static final LinkedHashMap<String, String> langNamesMap;

   static
   {
      countryNamesMap = new LinkedHashMap<>();
      countryNamesMap.put("be", "België/Belgique");
      countryNamesMap.put("fr", "France");
      countryNamesMap.put("ma", "Maroc");
      countryNamesMap.put("nl", "Nederland");

      langNamesMap = new LinkedHashMap<>();
      langNamesMap.put("english", "English");
      langNamesMap.put("spanish", "Español");
      langNamesMap.put("french", "Français");
      // langNamesMap.put("french", "FranÃ§ais");
      langNamesMap.put("dutch", "Dutch");

   }

   private final Map<String, WebElement> searchMap;

   private final HeaderComponent headercomp;

   private final WebElementWait wait;

   private final HashMap<String, String> wrHeaderCompLabelMap;

   private final HashMap<String, WebElement> wrHeaderCompMap;

   public HomePageCommon()
   {
      searchMap = new HashMap<>();
      wait = new WebElementWait();
      headercomp = new HeaderComponent();
      wrHeaderCompLabelMap = new HashMap<>();
      wrHeaderCompMap = new HashMap<>();
   }

   public void changeLanguage(String langCode)
   {
      clickCountryChangeLink();
      WebElementTools.click(wait.getWebElementWithLazyWait(
               headercomp.getCountryLangSelectorComp().getSelectedlanguageOnly()));
      WebElementTools.clickElementJavaScript(
               headercomp.getCountryLangSelectorComp().getAvailableLanguagesInDropdown().stream()
                        .filter(langLabel -> langLabel.getText().equals(langNamesMap.get(langCode)))
                        .findAny()
                        .orElse(null));
      WebElementTools
               .clickElementJavaScript(
                        headercomp.getCountryLangSelectorComp().getChangeSiteButton());

   }

   public void selectLanguage(String langCode)
   {
//       WebElementTools.clickElementJavaScript(headercomp.getCountrySwitcherLink());
      WebElementTools.click(wait.getWebElementWithLazyWait(
               headercomp.getCountryLangSelectorComp().getSelectedlanguageOnly()));
      WebElementTools.clickElementJavaScript(headercomp.getCountryLangSelectorComp()
               .getAvailableLanguagesInDropdown().stream()
               .filter(
                        langLabel ->
                        {
                           langLabel.getText();
                           langNamesMap.get(langCode);
                           return true;
                        })
               .findAny().orElse(null));
   }

   public void clickChangeSiteButton()
   {
      WebElementTools
               .clickElementJavaScript(
                        headercomp.getCountryLangSelectorComp().getChangeSiteButton());

   }

   public void setHeaderLabelMap()
   {
      try
      {
         wrHeaderCompLabelMap.put("holidays", headercomp.getHolidaysLabel().getText());
         wrHeaderCompLabelMap.put("cruises", headercomp.getCruisesLabel().getText());
         wrHeaderCompLabelMap.put("flights", headercomp.getFlightsLabelInPackage().getText());
         wrHeaderCompLabelMap.put("hotelonly", headercomp.getHotlonlyLabel().getText());
         wrHeaderCompLabelMap.put("deals", headercomp.getDealsLabel().getText());
         wrHeaderCompLabelMap.put("destinations", headercomp.getDestinationsLabel().getText());
         wrHeaderCompLabelMap.put("extras", headercomp.getExtrasLabel().getText());

         wrHeaderCompLabelMap.put("questions", headercomp.getQuestionsLabel().getText());
         wrHeaderCompLabelMap.put("checkin", headercomp.getCheckinLabel().getText());
         wrHeaderCompLabelMap.put("tui fly app",
                  headercomp.getFlyAppLabel().getText().split("\\(")[0].trim());
         wrHeaderCompLabelMap.put("travel information",
                  headercomp.getTravelInformationLabel().getText());
         wrHeaderCompLabelMap.put("account & bookings",
                  headercomp.getAccountBookingLabel().getText());
      }
      catch (Exception e)
      {

      }
   }

   public void setVIPHeaderLabelMap()
   {
      try
      {
         wrHeaderCompLabelMap.put("holidays", headercomp.getHolidaysLabel().getText());
         wrHeaderCompLabelMap.put("cruises", headercomp.getCruisesLabel().getText());
         wrHeaderCompLabelMap.put("flights", headercomp.getFlightsLabelInPackage().getText());
         wrHeaderCompLabelMap.put("deals", headercomp.getDealsVipLabel().getText());
         wrHeaderCompLabelMap.put("destinations", headercomp.getDestinationsVipLabel().getText());
         wrHeaderCompLabelMap.put("extras", headercomp.getExtrasVipLabel().getText());

         wrHeaderCompLabelMap.put("make an appointment in a shop",
                  headercomp.getVisitShopVipLabel().getText());
         wrHeaderCompLabelMap.put("questions", headercomp.getQuestionsVipLabel().getText());
         wrHeaderCompLabelMap.put("shortlist",
                  headercomp.getShortlistLabel().getText().split("\\(")[0].trim());
         wrHeaderCompLabelMap.put("travel information",
                  headercomp.getTravelInformationLabel().getText());
         wrHeaderCompLabelMap.put("account&booking", headercomp.getAccountBookingLabel().getText());
      }
      catch (Exception e)
      {

      }
   }

   public void setHeaderCompMap()
   {
      try
      {

         wrHeaderCompMap.put("headerComp", headercomp.getHeaderComp());
         wrHeaderCompMap.put("Shortlist", headercomp.getShortlistIcon());
         wrHeaderCompMap.put("Account & bookings", headercomp.getAccountBookingIcon());
      }
      catch (Exception e)
      {

      }

   }

   public String getHeaderLabel(String component)
   {
      return getHeaderLabelMap().get(component);
   }

   public boolean checkHeaderLabel(String actual, String expectedvalue)
   {

      return StringUtils.equalsIgnoreCase(actual, expectedvalue);
   }

   public HashMap<String, String> getHeaderLabelMap()
   {
      return wrHeaderCompLabelMap;
   }

   public HashMap<String, WebElement> getHeaderPageMap()
   {

      return wrHeaderCompMap;
   }

   public void viewHeader()
   {

      WebElementTools.scrollToCenter(headercomp.getHeaderComp());
   }

   public void viewLanguageSelector()
   {

      WebElementTools.scrollToCenter(headercomp.getClOverlayComp().getOverlayLabel());
   }

   public void clickBurgerMenu()
   {
      WebElementTools
               .clickElementJavaScript(wait.getWebElementWithLazyWait(headercomp.getBurgerMenu()));
      wait.forJSExecutionReadyLazy();
   }

   public HeaderComponent getHeaderComponent()
   {
      return headercomp;
   }

   public void clickCountryChangeLink()
   {
      $$(".cl-selector__lang, .LanguageCountrySelector__languageText, button[data-testid='country-switcher-button']").first().click();
   }

   public void clickLanguageInDropdown()
   {
      WebElementTools.click(wait
               .getWebElementWithLazyWait(
                        headercomp.getCountryLangSelectorComp().getSelectedlanguage()));
   }

   public boolean validateLanguagesInDropdownForPackage()
   {
      WebElementTools.click(wait.getWebElementWithLazyWait(
                        headercomp.getCountryLangSelectorComp().getSelectedlanguage()));
      return new ArrayList(langNamesMap.values()).containsAll(
               headercomp.getCountryLangSelectorComp().getAvailableLanguagesTextInDropdown());
   }

   public boolean checkVIPLogo()
   {
      return StringUtils.containsIgnoreCase(headercomp.getLogoIcon().getAttribute("src"),
               "VIP-Selection-Logo.svg");
   }

   public Map<String, WebElement> getVIPHeaderComponents()
   {
      searchMap.put("All vacations", headercomp.getVIPheaderLabel().get(0));
      searchMap.put("Last minutes & promotions", headercomp.getVIPheaderLabel().get(1));
      searchMap.put("Enjoy carefree", headercomp.getVIPheaderLabel().get(2));
      searchMap.put("Pure indulgence", headercomp.getVIPheaderLabel().get(3));
      searchMap.put("Extras", headercomp.getVIPheaderLabel().get(4));
      return searchMap;
   }

   public void mouseOver(String string)
   {
      if (string.equalsIgnoreCase("Enjoy carefree"))
      {
         WebElementTools.mouseHover(headercomp.getVIPheaderLabel().get(2));
      }
      else if (string.equalsIgnoreCase("Pure indulgence"))
      {
         WebElementTools.mouseHover(headercomp.getVIPheaderLabel().get(3));
      }
      else
      {
         WebElementTools.mouseHover(headercomp.getVIPheaderLabel().get(0));
      }
   }

   public boolean checkMegaMenuExpanded()
   {
      return WebElementTools.isPresent(headercomp.getMegamenuComponent());
   }

   public boolean isSubmenuValuesPresent(List<String> submenuElements)
   {
      for (int j = 0; j < submenuElements.size(); j++)
      {
         if (!StringUtils.equalsIgnoreCase(submenuElements.get(j),
                  WebElementTools.getElementText(
                           headercomp.getMegamenuComponentSubElement().get(j))))
         {
            return false;
         }
      }
      return true;
   }

   public boolean isClosed()
   {
      return !WebElementTools.isPresent(headercomp.getMegamenuComponent());
   }

   public void changeLanguageFrench()
    {
      clickCountryChangeLink();
      String langValue = "fr-BE";
      String languageText = "French";
      changeLanguage(languageText, langValue);
   }

   public void changeLanguageDutch()
   {
      clickCountryChangeLink();
      String langValue = "nl-BE";
      String languageText = "Dutch";
      changeLanguage(languageText, langValue);
   }

   private void changeLanguage(String languageText, String langValue)
   {
      if (ExecParams.getTestExecutionParams().isVIPBE() || !ExecParams.getAgent().isB2C())
      {
         $(".LanguageCountrySelector__languageCountrySwitcherModal").click();
         $(byText(languageText)).click();
         $("button.Modal__applyButton[aria-label='action apply']").click();
      }
      else if (ExecParams.getAgent().isB2C())
      {
         $("select.cl-form__select.js-language").selectOptionByValue(langValue);
         $("button.cl-form__button.button.tertiary").click();
      }
      else
      {
         WebElementTools.mouseOverAndClick(wait.getWebElementWithLazyWait(
                  headercomp.getCountryLangSelectorComp().getSelectedlanguageFrench().get(2)));
         wait.forJSExecutionReadyLazy();
         WebElementTools.mouseOverAndClick(
                  headercomp.getCountryLangSelectorComp().getAvailableLanguagesInDropdown().get(0));
         WebElementTools.clickElementJavaScript(wait.getWebElementWithLazyWait(
                  headercomp.getCountryLangSelectorComp().getChangeSiteButtonb2b().get(4)));
      }
   }
}
