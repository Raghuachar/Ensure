package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.extraoptions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.hamcrest.Matchers;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.detailedbreakdown.DetailedBreakdownPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.extraoptions.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.HolidaySummaryComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.PassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.InsuranceAndExtrasComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.PriceBreakDownComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.book.extraoptions.MultiSelectInsuranceComponent;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.*;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class MultiSelectInsuranceCustomerStepDefs
{

   private String optExtInsTitle;

   private static final double DELTA = 0.01;

   private final PackageNavigation packageNavigation;

   private final ExtraOptionsPage extraOptionsPage;

   private final SummaryPage summaryPage;

   private final InsuranceAndExtrasComponent insExComponent;

   private final MultiSelectInsuranceComponent multiInsComponent;

   private final PriceBreakDownComponent priceBreakDownComponent;

   private final DetailedBreakdownPage detailedBreakdownPage;

   private final PassengerDetailsPage passengerDetailsPage;

   private final HolidaySummaryComponent paxHolSumComp;

   private final ThreadLocal<Double> totalPrice = new ThreadLocal<>();

   public final WebElementWait wait;

   public MultiSelectInsuranceCustomerStepDefs()
   {
      packageNavigation = new PackageNavigation();
      extraOptionsPage = new ExtraOptionsPage();
      summaryPage = new SummaryPage();
      insExComponent = summaryPage.insExComponent;
      priceBreakDownComponent = summaryPage.priceBreakComponent;
      multiInsComponent = extraOptionsPage.multiInsuranceComponent;
      detailedBreakdownPage = new DetailedBreakdownPage();
      passengerDetailsPage = new PassengerDetailsPage();
      paxHolSumComp = passengerDetailsPage.holidaySummaryComponent;
      MultiSelectInsuranceComponent.selectedInsurancesPrice.set(0.0);
      wait = summaryPage.wait;
   }

   @Given("user is on the package Extras & Options page")
   public void user_is_on_the_package_Extras_Options_page()
   {
      packageNavigation.navigateToExtrasPageOfContractedPkg();
   }

   @And("user updates DOB for {int} years old passenger {int}")
   public void user_updates_DOB_for_one_passenger(int years, int paxIndex)
   {
      multiInsComponent.enterAdultDOB(years, paxIndex - 1);
   }

   @Given("user updates DOB for {int} adults in Extras & Options page")
   public void user_updates_DOB_for_adults_in_Extras_Options_page(int paxAmount)
   {
      packageNavigation.navigateToExtrasPageOfContractedPkg();
      multiInsComponent.enterAdultsDOB(paxAmount);
   }

   @Given("user updates DOB for {int} children in Extras & Options page")
   public void user_updates_DOB_for_children_in_Extras_Options_page(int childrenAmount)
   {
      packageNavigation.navigateToExtrasPageOfContractedPkg();
      multiInsComponent.enterChildrenDOB(childrenAmount);
   }

   @Given("user updates DOB for infant {int} in Extras & Options page")
   public void user_updates_DOB_for_infant_under_one_year_in_Extras_Options_page(int infantIndex)
   {
      packageNavigation.navigateToExtrasPageOfContractedPkg();
      multiInsComponent.enterInfantUnderOneYearDOB(infantIndex - 1);
   }

   @Given("user updates DOB with incorrect day value for passenger {int}")
   public void user_updates_DOB_with_incorrect_day_value_for_passenger(int paxIndex)
   {
      multiInsComponent.enterAdultIncorrectDOBDay(paxIndex - 1);
   }

   @And("user updates DOB with incorrect year value for passenger {int}")
   public void user_updates_DOB_with_incorrect_year_value_for_passenger(int paxIndex)
   {
      multiInsComponent.enterAdultIncorrectDOBYear(paxIndex - 1);
   }

   @And("user updates DOB with incorrect year value for child {int}")
   public void user_updates_DOB_with_incorrect_year_value_for_child(int paxIndex)
   {
      multiInsComponent.enterChildIncorrectDOBYear(paxIndex - 1);
   }

   @And("user updates DOB with incorrect month value for infant {int}")
   public void user_updates_DOB_with_incorrect_month_value_for_infant(int paxIndex)
   {
      multiInsComponent.enterInfantIncorrectDOBMonth(paxIndex - 1);
   }

   @And("user click on the change selection link")
   public void user_click_on_the_change_selection_link()
   {
      multiInsComponent.clickChangeSelectionLink();
   }

   @And("insurance cards are displayed")
   public void insurance_cards_are_displayed()
   {
      assertThat("Insurance cards should be displayed",
               multiInsComponent.isInsuranceCardDisplayed());
   }

   @And("user expands all insurance cards")
   public void user_expands_all_insurance_cards()
   {
      multiInsComponent.expandAllSections();
   }

   @Then("user is able to see checkboxes for {int} passengers")
   public void user_is_able_to_see_checkboxes_and_insurance_prices_for_x_passengers(
            int passengersCount)
   {
      wait.forJSExecutionReadyLazy();
      for (int cardIndex = 0; cardIndex < multiInsComponent
               .getCardsCount(); cardIndex++)
      {
         assertEquals("Wrong number of passengers displayed in card with index " + cardIndex,
                  passengersCount,
                  multiInsComponent.getCountPassengersListedInCard(cardIndex));
         assertPassengersCheckboxDisplayed(passengersCount, cardIndex);
      }
   }

   public void assertPassengersCheckboxDisplayed(int passengersCount, int cardIndex)
   {
      for (int paxIndex = 0; paxIndex < passengersCount; paxIndex++)
      {
         assertThat(
                  "No checkbox displayed for passenger " + paxIndex + " in card with index " + cardIndex,
                  multiInsComponent.isPassengerCheckboxDisplayed(cardIndex,
                           paxIndex));
      }
   }

   @And("user clicks the Choose insurance button")
   public void user_clicks_the_choose_insurance_button()
   {
      multiInsComponent.clickChooseInsuranceButton();
   }

   @When("user clicks Show my selected insurance link")
   public void user_clicks_Show_my_selected_insurance_link()
   {
      multiInsComponent.toggleSelectedInsurancesAccordion();
   }

   @And("user clicks Hide my selected insurance link")
   public void user_clicks_Hide_my_selected_insurance_link()
   {
      multiInsComponent.toggleSelectedInsurancesAccordion();
   }

   @Then("insurance summary list is collapsed")
   public void insurance_summary_list_is_collapsed()
   {
      assertTrue(multiInsComponent.isSelectedInsuranceSummaryVisible());
   }

   @Then("user is able to see a message {string}")
   public void user_is_able_to_see_a_message(String messageText)
   {
      assertEquals("Message text is incorrect", messageText,
               multiInsComponent.getNoInsuranceSelectedText());
      assertTrue("Message should be translated",
               WebElementTools.isTextNotContainsUA(multiInsComponent.getNoInsuranceSelectedText()));
   }

   @And("user is able to see amount and insurance title for {int} passengers in selected insurances list")
   public void user_is_able_to_see_amount_and_insurance_title_for_passengers_in_selected_insurances_list(
            Integer paxAmount)
   {
      List<String> insTextForPassenger = new ArrayList<>();
      wait.forJSExecutionReadyLazy();
      IntStream.range(0, paxAmount).forEach(i ->
      {
         insTextForPassenger.add(multiInsComponent
                  .getSelectedInsuranceTextForPassenger(i));

         assertTrue("Passenger name should be displayed",
                  multiInsComponent.getSelectedInsurancePassengerName(i)
                           .trim().endsWith(String.valueOf(i + 1)));
         assertTrue("Insurance amount should be displayed",
                  insTextForPassenger.get(i).trim().startsWith("1 x "));
         assertFalse("Insurance title shouldn't be empty",
                  insTextForPassenger.get(i).split(" x ")[1].trim().isEmpty());
      });
   }

   @And("user expands insurance category number {int}")
   public void user_expands_insurance_category_number(int index)
   {
      wait.forJSExecutionReadyLazy();
      multiInsComponent.expandSection(index - 1);
   }

   @When("user ticks insurance {int} checkbox in category number {int} for passenger {int}")
   public void user_ticks_insurance_checkbox_in_category_number_for_passenger(Integer cardIndex,
            Integer sectionIndex, Integer paxIndex)
   {
      multiInsComponent.selectInsuranceForPassenger(sectionIndex,
               cardIndex - 1, paxIndex - 1);
   }

   @And("user expands insurance category {int} and selects insurance in card {int} for {int} passengers")
   public void user_expands_insurance_category_selects_insurance_in_card_for_passengers(
            Integer sectionIndex,
            Integer cardIndex, Integer paxAmount)
   {
      multiInsComponent.expandSection(sectionIndex - 1);
      IntStream.range(0, paxAmount)
               .forEach(i -> multiInsComponent.selectInsuranceForPassenger(sectionIndex,
                        cardIndex - 1, i));
   }

   @When("user remembers total price")
   public void user_remembers_total_price()
   {
      totalPrice.set(extraOptionsPage.progressbarComponent.getTotalPriceDoubleValue());
      MultiSelectInsuranceComponent.selectedInsurancesPrice.set(0.0);
   }

   @And("insurance {int} from category number {int} for passenger {int} still selected")
   public void insurance_from_category_number_for_passenger_still_selected(Integer cardIndex,
            Integer sectionIndex, Integer paxIndex)
   {
      wait.forJSExecutionReadyLazy();
      assertTrue("No Cancellation or Travel insurance is presented in Extras & Options page",
               multiInsComponent.
                        isInsuranceForPassengerSelected(sectionIndex, cardIndex - 1, paxIndex - 1));
   }

   @And("insurance {int} from category number {int} for passenger {int} is deselected")
   public void insurance_from_category_number_for_passenger_is_deselected(Integer cardIndex,
            Integer sectionIndex, Integer paxIndex)
   {
      wait.forJSExecutionReadyLazy();
      assertFalse(multiInsComponent.
               isInsuranceForPassengerSelected(sectionIndex, cardIndex - 1, paxIndex - 1));
   }

   @And("REVIEW PRICES AND CONFIRM button is displayed in the page")
   public void review_confirm_button_is_displayed()
   {
      assertTrue("REVIEW PRICES AND CONFIRM button should be displayed",
               multiInsComponent.isReviewConfirmButtonDisplayed());
   }

   @When("user clicks REVIEW PRICES AND CONFIRM button")
   public void user_clicks_review_confirm_button()
   {
      multiInsComponent.clickReviewConfirmButton();
   }

   @Then("REVIEW AND CONFIRM modal is displayed")
   public void review_confirm_modal_is_displayed()
   {
      wait.forJSExecutionReadyLazy();
      assertTrue("REVIEW PRICES AND CONFIRM modal should be displayed",
               multiInsComponent.isReviewConfirmModalDisplayed());
   }

   @And("user is able to see modal title, amount, insurance title and insurance price for {int} passengers in Review and Confirm modal")
   public void user_is_able_to_see_modal_title_amount_insurance_title_and_insurance_price_for_passenger_in_review_confirm_modal(
            int paxAmount)
   {
      assertTrue("Modal title is not displayed or contains UA_ label",
               multiInsComponent.isReviewConfirmModalTitleDisplayed());
      IntStream.range(0, paxAmount).forEach(i ->
      {
         assertTrue("Passenger name should be displayed",
                  multiInsComponent.getReviewConfirmModalPassengerName(i)
                           .trim().endsWith(String.valueOf(i + 1)));
         assertTrue("Insurance amount should be displayed",
                  multiInsComponent.getReviewConfirmModalInsuranceTitle(i).trim()
                           .startsWith("1 x"));
         assertTrue("Insurance title shouldn't be empty",
                  multiInsComponent.isInsuranceTitleEmpty(i));
         assertTrue("Insurance price should be displayed",
                  Double.parseDouble(multiInsComponent.getReviewConfirmModalInsurancePrice(i)
                           .split("€")[1].trim()) > 0);
      });
   }

   @And("user is able to see insurance total price")
   public void user_is_able_to_see_insurance_total_price()
   {
      assertTrue("Total price label is not displayed or contains UA_ label",
               multiInsComponent.isReviewConfirmModalTotalPriceLabelDisplayed());
      assertTrue("Total price should be displayed",
               multiInsComponent.isReviewConfirmModalTotalPriceDisplayed());
      MultiSelectInsuranceComponent.selectedInsurancesPrice
               .set(MultiSelectInsuranceComponent.selectedInsurancesPrice.get()
               + multiInsComponent.getReviewConfirmModalDoubleTotalPrice());
   }

   @And("user clicks Confirm button")
   public void user_clicks_confirm_button()
   {
      multiInsComponent.clickModalConfirmButton();
   }

   @And("user clicks Cancel button")
   public void user_clicks_cancel_button()
   {
      multiInsComponent.clickModalCancelButton();
   }

   @And("REVIEW AND CONFIRM modal is closed")
   public void modal_is_closed()
   {
      assertTrue("REVIEW AND CONFIRM modal should not be displayed",
               multiInsComponent.isReviewConfirmModalHidden());
   }

   @And("user is navigated to Summary page")
   public void user_is_navigated_to_Summary_page()
   {
      assertTrue("user is not navigated to Summary page",
               summaryPage.navigationComponent.isPageDisplayed());
   }

   @And("booking total price is updated with insurance price")
   public void booking_total_price_is_updated_with_insurance_price()
   {
      Double newTotal = extraOptionsPage.progressbarComponent.getTotalPriceDoubleValue();
      assertEquals("Total price is not updated with insurance price",
               MultiSelectInsuranceComponent.selectedInsurancesPrice.get()
                        + totalPrice.get(), newTotal, DELTA);
   }

   @And("user clicks Return to your holiday link")
   public void user_clicks_return_to_your_holiday_link()
   {
      multiInsComponent.clickReturnToYourHolidayLink();
   }

   @And("no insurance selection is saved")
   public void no_insurance_selection_is_saved()
   {
      assertFalse("Insurance shouldn't be selected", insExComponent.isMultiInsuranceSelected());
   }

   @Given("user adds insurance in category {int} and card {int} for {int} adults")
   public void user_adds_insurance_in_category_and_card_for_adults(Integer sectionIndex,
            Integer cardIndex, Integer paxAmount)
   {
      packageNavigation.navigateToExtrasPageOfContractedPkg();
      multiInsComponent.enterAdultsDOB(paxAmount);
      multiInsComponent.clickChooseInsuranceButton();
      multiInsComponent.expandSection(sectionIndex - 1);
      optExtInsTitle = multiInsComponent.getCardInsTitle(sectionIndex, cardIndex - 1).getText();
      IntStream.range(0, paxAmount)
               .forEach(i -> multiInsComponent.selectInsuranceForPassenger(sectionIndex,
                        cardIndex - 1, i));
      multiInsComponent.clickReviewConfirmButton();
      MultiSelectInsuranceComponent.selectedInsurancesPrice
               .set(MultiSelectInsuranceComponent.selectedInsurancesPrice.get()
                        + multiInsComponent.getReviewConfirmModalDoubleTotalPrice());
      multiInsComponent.clickModalConfirmButton();
   }

   @Then("insurance and extras component shows insurance category title selected for {int} passengers")
   public void insurance_component_shows_insurance_selected(Integer paxAmount)
   {
      List<String> insTitle = insExComponent.getSelectedInsuranceTitlesText();
      assertTrue("Insurance amount should be displayed",
               insTitle.get(0).trim().startsWith(paxAmount + " x "));
      assertFalse("Insurance title shouldn't be empty",
               insTitle.get(0).split(" x ")[1].trim().isEmpty());
      assertTrue("Insurance title should be translated",
               WebElementTools.isTextNotContainsUA(insTitle.get(0)));
      assertTrue("Insurance titles are different",
               insTitle.get(0).split(paxAmount + " x ")[1].trim()
                        .equalsIgnoreCase(optExtInsTitle));
   }

   @Then("user clicks Select button of I don't need insurance section")
   public void user_clicks_Select_button_of_I_dont_need_insurance_section()
   {
      insExComponent.clickSelectOfIDontNeedInsuranceSection();
   }

   @Then("user makes sure that {int} children age in DOB component is the same as in the search parameters")
   public void user_makes_sure_that_children_age_in_DOB_component_is_the_same_as_in_search_parameters(int childrenAmount)
   {
      IntStream.range(0, childrenAmount).forEach(i ->
               assertEquals("Age is different",
                        Integer.parseInt(multiInsComponent.getChildrenAgeInDOBComponent().get(i)),
                        (int) multiInsComponent.getChildrenAgeInSearchParams().get(i)));
   }

   @Then("user makes sure that age in insurance category {int} and card {int} for {int} children is the same as in the search parameters")
   public void user_makes_sure_that_children_age_in_insurance_component_is_the_same_as_in_search_parameters(Integer sectionIndex,
            Integer cardIndex, Integer childrenAmount)
   {
      IntStream.range(0, childrenAmount).forEach(i ->
         assertEquals("Age is different",
                  Integer.parseInt(multiInsComponent.getChildrenAgeInInsuranceCard(
                           sectionIndex, cardIndex - 1, i).get(0)),
                  (int) multiInsComponent.getChildrenAgeInSearchParams().get(i)));
   }

   @Then("user makes sure that infant age message in DOB component for {int} infants contains statement {string}")
   public void user_makes_sure_that_infant_age_message_in_DOB_component_contains_statement(int infantAmount, String statement)
   {
      IntStream.range(0, infantAmount).forEach(i ->
               assertTrue("Message doesn't contain infant age info",
                        multiInsComponent.getInfantAgeMessagesInDOBComponent().get(i)
                                 .getText().toLowerCase().contains(statement.toLowerCase())));
   }

   @Then("user makes sure that infant age message in insurance category {int} and card {int} for infant {int} contains statement {string}")
   public void user_makes_sure_that_infant_age_message_in_insurance_card_contains_statement(Integer sectionIndex,
            Integer cardIndex, Integer infantIndex, String statement)
   {
      wait.forJSExecutionReadyLazy();
      assertTrue("Message doesn't contain infant age info",
               multiInsComponent.getPassengerLabelInInsuranceCard(
                        sectionIndex, cardIndex - 1, infantIndex - 1).get(0)
                        .getText().toLowerCase().contains(statement.toLowerCase()));
   }

   @Then("the following DOB error message is displayed for passenger {int}")
   public void the_following_DOB_error_message_is_displayed_for_passenger1(Integer paxIndex, DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String actual = multiInsComponent.getDOBErrorMessagesTexts().get(paxIndex - 1);
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertThat("Error message text is not as expected", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @Then("the following DOB error message is displayed for child {int}")
   public void the_following_DOB_error_message_is_displayed_for_child1(Integer childIndex, DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String actual = multiInsComponent.getDOBErrorMessagesTexts().get(childIndex + 1);
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertThat("Error message text is not as expected", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @Then("the following DOB error message is displayed for infant {int}")
   public void the_following_DOB_error_message_is_displayed_for_infant1(Integer infantIndex, DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String actual = multiInsComponent.getDOBErrorMessagesTexts().get(infantIndex + 2);
      String expected = map.get(getTestExecutionParams().getBrandStr());
      assertThat("Error message text is not as expected", actual,
               Matchers.equalToIgnoringCase(expected));
   }

   @Then("insurance product for {int} passengers for {int} insurance type contains insurance name in the Price Breakdown component")
   public void insurance_product_for_passengers_for_insurance_type_contains_insurance_name_in_price_breakdown_comp(
            Integer paxAmount, Integer insTypeAmount)
   {
      List<String> insTitle = priceBreakDownComponent.getInsuranceProductTitlesTexts();
      for (int i = 0; i < insTypeAmount; i++)
      {
         assertTrue("Insurance amount should be displayed",
                  insTitle.get(i).trim().contains(paxAmount + " x "));
         assertFalse("Insurance title shouldn't be empty",
                  insTitle.get(i).split(" x ")[1].trim().isEmpty());
         assertTrue("Insurance title should be translated",
                  WebElementTools.isTextNotContainsUA(insTitle.get(i)));
         assertTrue("Insurance titles are different",
                  insTitle.get(i).split(paxAmount + " x ")[1].trim()
                           .equalsIgnoreCase(optExtInsTitle));
      }
   }

   @And("insurance product for {int} insurance type contains insurance tax fee information in the Price Breakdown component")
   public void insurance_product_for_insurance_type_contains_insurance_tax_fee_information_in_price_breakdown_comp(
            Integer insTypeAmount, DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      for (int i = 0; i < insTypeAmount; i++)
      {
         String actual = priceBreakDownComponent.getInsuranceProductTaxesFeesTexts().get(i);
         String expected = map.get(getTestExecutionParams().getBrandStr());
         String[] expectedArray;
         if (expected.contains(","))
         {
            expectedArray = expected.split(",");
            for (String s : expectedArray)
            {
               assertTrue("Insurance tax or fee description is incorrect",
                        actual.contains(s.trim()));
            }
         }
         else
         {
            assertTrue("Insurance tax or fee description is incorrect",
                     actual.contains(expected));
         }
      }
   }

   @Then("insurance product for {int} passengers contains insurance name in Detailed Price Breakdown page")
   public void insurance_product_for_passengers_contains_insurance_name_in_detailed_breakdown_page(
            Integer paxAmount)
   {
      List<String> insTitle = detailedBreakdownPage.getInsuranceProductTitlesTexts();
      for (int i = 0; i < paxAmount; i++)
      {
         assertTrue("Insurance amount should be displayed",
                  insTitle.get(i).trim().contains("1 x "));
         assertFalse("Insurance title shouldn't be empty",
                  insTitle.get(i).split(" x ")[1].trim().isEmpty());
         assertTrue("Insurance title should be translated",
                  WebElementTools.isTextNotContainsUA(insTitle.get(i)));
         assertTrue("Insurance titles are different",
                  insTitle.get(i).split("1 x ")[1].trim()
                           .equalsIgnoreCase(optExtInsTitle));
      }
   }

   @And("insurance price is displayed in Detailed Price Breakdown page for {int} passengers")
   public void insurance_price_is_displayed_in_detailed_price_breakdown_page_for_passengers(
            Integer paxAmount)
   {
      for (int i = 0; i < paxAmount; i++)
      {
         assertTrue("Insurance price is absent or equal to zero",
                  detailedBreakdownPage.getInsurancePricesDouble().get(i) > 0);
      }
   }

   @And("user clicks Show Insurance tax links")
   public void user_clicks_show_insurance_tax_links()
   {
      detailedBreakdownPage.clickShowInsuranceTaxLink();
   }

   @And("insurance product for {int} passengers contains insurance tax fee information in Detailed Price Breakdown page")
   public void insurance_product_for_passengers_contains_insurance_tax_fee_information_in_detailed_breakdown_comp(
            Integer paxAmount, DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      for (int i = 0; i < paxAmount; i++)
      {
         String actual = detailedBreakdownPage.getInsuranceProductTaxesTexts().get(i);
         String expected = map.get(getTestExecutionParams().getBrandStr());
         assertTrue("Insurance tax description is incorrect", actual.contains(expected));
         if (getTestExecutionParams().isNL())
         {
            assertTrue("Insurance policy fee line item is absent or it's description is incorrect",
                     detailedBreakdownPage.getInsuranceFeeText()
                              .contains("Poliskosten"));
         }
      }
   }

   @Then("insurance product for {int} passengers for {int} insurance type contains insurance name in the Holiday summary of the PAX page")
   public void insurance_product_for_passengers_for_insurance_type_contains_insurance_name_in_holiday_summary_of_pax_page(
            Integer paxAmount, Integer insTypeAmount)
   {
      paxHolSumComp.wait.forJSExecutionReadyLazy();
      List<String> insTitle = paxHolSumComp.getInsuranceProductTitlesTexts();
      for (int i = 0; i < insTypeAmount; i++)
      {
         assertTrue("Insurance amount should be displayed",
                  insTitle.get(i).trim().contains(paxAmount + "× "));
         assertFalse("Insurance title shouldn't be empty",
                  insTitle.get(i).split("× ")[1].trim().isEmpty());
         assertTrue("Insurance title should be translated",
                  WebElementTools.isTextNotContainsUA(insTitle.get(i)));
         String actualTitle = insTitle.get(i).split(paxAmount + "× ")[1].trim();
         String expectedTitle = optExtInsTitle;
         assertTrue("Insurance titles are different. \nExpected: " + expectedTitle + "\nActual: " + actualTitle,
                  insTitle.get(i).split(paxAmount + "× ")[1].trim()
                           .equalsIgnoreCase(optExtInsTitle));
      }
   }

   @And("insurance product for {int} insurance type contains insurance tax fee information in the Holiday Summary of the PAX page")
   public void insurance_product_for_insurance_type_contains_insurance_tax_fee_information_in_holiday_summary_of_pax_page(
            Integer insTypeAmount, DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      for (int i = 0; i < insTypeAmount; i++)
      {
         String actual = paxHolSumComp.getInsuranceProductTaxesFeesTexts().get(i);
         String expected = map.get(getTestExecutionParams().getBrandStr());
         String[] expectedArray;
         if (expected.contains(","))
         {
            expectedArray = expected.split(",");
            for (String s : expectedArray)
            {
               assertTrue("Insurance tax or fee description is incorrect",
                        actual.contains(s.trim()));
            }
         }
         else
         {
            assertTrue("Insurance tax or fee description is incorrect",
                     actual.contains(expected));
         }
      }
   }

   @Then("{string} divider is presented in the Extras & Options page")
   public void combine_both_divider_is_presented_in_the_extras_options_page(String text)
   {
      if (!getTestExecutionParams().isNL()) {
         assertTrue("Combine both divider is not presented in the Extras & Options page in BE site",
                  multiInsComponent.isCombineBothDividerPresented());
         assertEquals("Translation of combine both divider text is not as expected",
                  text, multiInsComponent.getCombineBothDividerText());
      }
      else
      {
         assertFalse("Combine both divider shouldn't be presented in the Extras & Options page in NL site",
                  multiInsComponent.isCombineBothDividerPresented());
      }
   }

   @Then("{string} line is presented at the top of all insurance cards")
   public void line_is_presented_at_the_top_of_all_insurance_cards(String message)
   {
      assertTrue("'I don't need insurance' line is not presented in the Extras & Option page",
               multiInsComponent.isDontNeedInsurancePresented());
      assertEquals("Translation of 'I don't need insurance' message is not as expected",
               message, multiInsComponent.getDontNeedInsuranceText());
   }

   @Given("user added insurance in category {int} and card {int} for {int} adults")
   public void user_added_insurance_in_category_and_card_for_adults(Integer sectionIndex,
            Integer cardIndex, Integer paxAmount)
   {
      multiInsComponent.enterAdultsDOB(paxAmount);
      multiInsComponent.clickChooseInsuranceButton();
      multiInsComponent.expandSection(sectionIndex - 1);
      optExtInsTitle = multiInsComponent.getCardInsTitle(sectionIndex, cardIndex - 1).getText();
      IntStream.range(0, paxAmount)
               .forEach(i -> multiInsComponent.selectInsuranceForPassenger(sectionIndex,
                        cardIndex - 1, i));
      multiInsComponent.clickReviewConfirmButton();
      MultiSelectInsuranceComponent.selectedInsurancesPrice
               .set(MultiSelectInsuranceComponent.selectedInsurancesPrice.get()
               + multiInsComponent.getReviewConfirmModalDoubleTotalPrice());
      multiInsComponent.clickModalConfirmButton();
   }
}
