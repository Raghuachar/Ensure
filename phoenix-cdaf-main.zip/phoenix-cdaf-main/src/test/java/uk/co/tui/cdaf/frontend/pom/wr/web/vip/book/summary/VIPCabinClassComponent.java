package uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;

public class VIPCabinClassComponent
{

   private final HashMap<String, WebElement> vipCabinClassComponentsMap;

   @FindBy(css = "[class*='View3__childMessage']")
   private WebElement cabinClassDescription;

   @FindBy(css = "[class*='View3__leftContentWrapper']")
   private WebElement cabinClassIncluded;

   @FindBy(css = "[class*='View3__rightContentWrapper']")
   private WebElement DeluxClassUsps;

   @FindBy(css = "[aria-label='DEL_CLASS']")
   private WebElement onlyDeluxClass;

   public VIPCabinClassComponent()
   {
      WebElementWait wait = new WebElementWait();
      vipCabinClassComponentsMap = new HashMap<>();
   }

   public HashMap<String, WebElement> getVipCabinClassComponentsMap()
   {
      vipCabinClassComponentsMap.put("Cabin Class description", cabinClassDescription);
      vipCabinClassComponentsMap.put("Default DELUXE Cabin Class Included", cabinClassIncluded);
      vipCabinClassComponentsMap.put("VIP Deluxe Class USPs", DeluxClassUsps);
      return vipCabinClassComponentsMap;
   }

   public boolean isOnlyDeluxClassDisplayed()
   {
      return WebElementTools.isPresent(onlyDeluxClass);
   }
}
