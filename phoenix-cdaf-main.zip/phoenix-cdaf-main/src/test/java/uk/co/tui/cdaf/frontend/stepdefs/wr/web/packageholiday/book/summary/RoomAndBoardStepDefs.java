package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.MultipleRoomTypeInHolidaySummaryComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class RoomAndBoardStepDefs
{

   public final PackageNavigation packageNavigation;

   public final SummaryPage summaryPage;

   public final MultipleRoomTypeInHolidaySummaryComponent multipleRoomTypeInHolidaySummaryComponent;

   public RoomAndBoardStepDefs()
   {
      packageNavigation = new PackageNavigation();
      summaryPage = new SummaryPage();
      multipleRoomTypeInHolidaySummaryComponent = new MultipleRoomTypeInHolidaySummaryComponent();
   }

   @Given("the customer is on the Customise Page")
   public void the_customer_is_on_the_Customise_Page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they scroll to beneath the Room & Board Information display")
   public void they_scroll_to_beneath_the_Room_Board_Information_display()
   {
      boolean actual = summaryPage.roomAndBoardComponent.isRoomAncillaryDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Room ancillary component wasnt displayed", actual, true), actual, is(true));
      summaryPage.roomAndBoardComponent.scrollToRoomAncillary();
   }

   @Then("they will be presented with the default room card in selected state")
   public void they_will_be_presented_with_the_default_room_card_in_selected_state()
   {
      boolean actual = summaryPage.roomAndBoardComponent.isIncludedButtonDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Included room button wasn't displayed", actual, true), actual, is(true));
   }

   @And("up to 2 other available room type cards with the following component detail")
   public void up_to_other_available_room_type_cards_with_the_following_component_detail(
            DataTable ignore)
   {
      summaryPage.roomAndBoardComponent.getRoomAndBoardComps();

   }

   @When("they select change room or board OR view all room upgrades")
   public void they_select_change_room_or_board_OR_view_all_room_upgrades()
   {
      packageNavigation.summaryPage.roomAndBoardComponent.clickOnRoomUpgrades();
   }

   @Then("they are navigated to the Room and Board page")
   public void they_are_navigated_to_the_Room_and_Board_page()
   {
      boolean actual = summaryPage.roomAndBoardComponent.isYourBoardComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Included room button wasn't displayed", actual, true), actual, is(true));
   }

   @Then("they are navigate to the Room and Board page")
   public void they_are_navigate_to_the_Room_and_Board_page()
   {
      multipleRoomTypeInHolidaySummaryComponent.VerifyRoomUpgrades();
   }

   @Then("are presented with the followings informations:")
   public void are_presented_with_the_followings_informations(DataTable ignore)
   {
      summaryPage.roomAndBoardComponent.getRoomOptionsComps();
   }
}
