package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackagePreviousReconciliationsPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PacakgePreviousReconSameDateSearchErrorMessageStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   public final PackageNavigation fonavigation;

   private final PackagePreviousReconciliationsPageComponents pKgReconcilationPaymentPageComponent;

   public PacakgePreviousReconSameDateSearchErrorMessageStepDefs()
   {
      fonavigation = new PackageNavigation();
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponent = new PackagePreviousReconciliationsPageComponents();
   }

   @When("they have chosen a search criteria")
   public void they_have_chosen_a_search_criteria()
   {
      pKgReconcilationPaymentPageComponent.selectNewDatesToDateOPtion();
   }

   @When("have pressed the search CTA")
   public void have_pressed_the_search_CTA()
   {
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponent.clickOnSeodbSearchCTA();
   }

   @Then("if there are no results available the error message will appear in yellow")
   public void if_there_are_no_results_available_the_error_message_will_appear_in_yellow(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Error message displayed",
               pKgReconcilationPaymentPageComponent.isSeodbSameDateSearchErrorMeassgaes(),
               is(true));

      assertThat("Generating Error Message",
               pKgReconcilationPaymentPageComponent.isSeodbSameDateSearchErrorsBox(), is(true));
   }
}
