package uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.summary;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class VIPFuelProtectionComponent
{
   private final WebElementWait wait;

   @FindBy(css = "[aria-label='Fuel Protection Fee']")
   private WebElement fuelProtection;

   public VIPFuelProtectionComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getFuelProtectionElement()
   {
      return wait.getWebElementWithLazyWait(fuelProtection);
   }

   public void scrollToFuelProtection()
   {
      WebElementTools.javaScriptScrollToElement(getFuelProtectionElement());
   }

   public boolean isFuelProtectionDisplayed()
   {
      return WebElementTools.isPresent(getFuelProtectionElement());
   }
}
