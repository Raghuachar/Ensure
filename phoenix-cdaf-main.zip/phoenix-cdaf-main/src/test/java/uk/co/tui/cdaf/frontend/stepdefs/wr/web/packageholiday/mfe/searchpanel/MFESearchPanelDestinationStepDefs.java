package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.SoftAssertions;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.junit.Assert;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.DestinationMfe;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion.DestinationSuggestion;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.*;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class MFESearchPanelDestinationStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(MFESearchPanelDestinationStepDefs.class);

   final SelenideHelper selenideHelper = new SelenideHelper();

   private final PackageNavigation packageNavigation;

   private final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent;

   private final SearchResultsPage searchResultsPage;

   private final UnitDetailsPage unitPage;

   private final SummaryPage summaryPage;

   private final SearchPanel searchPanel = getSearchPanel();

   private final DestinationMfe destinationMfe = new DestinationMfe();

   private final WebElementWait wait;

   public String siteId;

   public List<String> selectedCountries = new ArrayList<>();

   private Set<String> windowHandles;

   private Set<String> initialHandles;

   private String dismissibleTag;

   private List<String> regions;

   private String destinationName;

   public SoftAssertions softAssert = new SoftAssertions();

   public MFESearchPanelDestinationStepDefs()
   {
      packageNavigation = new PackageNavigation();
      departureAirportOrDestinationComponent =
               new DepartureAirportAndDestinationAndDatesComponent();
      wait = new WebElementWait();
      searchResultsPage = new SearchResultsPage();
      unitPage = new UnitDetailsPage();
      summaryPage = new SummaryPage();
   }

   @Given("the {string} is on the home page")
   public void the_is_on_the_home_page(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
   }

   @And("the Legacy Message switch is set to {string}")
   public void the_Legacy_Message_switch_is_set_to_Off(String string)
   {
      if (string.contains("on"))
         LOGGER.log(LogLevel.INFO, "LegacyMessageSwitch is ON - true :"
                  + departureAirportOrDestinationComponent.legacyMessageSwitchIsDisplayed());
      else if (string.contains("off"))
         LOGGER.log(LogLevel.INFO, "LegacyMessageSwitch is OFF :");
   }

   @When("they select any of the following {string} on the Search Panel Destination or Hotel field")
   public void they_select_any_of_the_following_on_the_Search_Panel_Destination_or_Hotel_field(
            String string)
   {
      if (string.equalsIgnoreCase("List icon"))
         departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
      if (string.equalsIgnoreCase("List text"))
         departureAirportOrDestinationComponent.selectMFEDestinationListText();
   }

   @Then("the Destinations modal shall be displayed")
   public void the_Destinations_modal_shall_be_displayed()
   {
      assertTrue("Destination model is not displayed",
               searchPanel.destination().isOpen());
   }

   @Then("the Destinations modal shall display the following:")
   public void the_Destinations_modal_shall_display_the_following(DataTable dataTable)
   {
      List<Map<String, String>> maps = dataTable.asMaps();
      String site = BDDSiteIdResolver.getAllBrandSiteId();
      String expectedDepartureAirport = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Destination title")).findFirst().orElse(null);
      String expectedDestinations = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Clear All")).findFirst().orElse(null);
      String expectedDates = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Done")).findFirst().orElse(null);
      String actualDestinationHeader = departureAirportOrDestinationComponent.getMFEDestinationHeaderText();
      String actualDestinationClose = departureAirportOrDestinationComponent.getMFEDestinationCloseText();
      String actualDestinationDone = departureAirportOrDestinationComponent.getMFEDestinationDoneText();
      softAssert.assertThat(actualDestinationHeader).isEqualTo(expectedDepartureAirport);
      softAssert.assertThat(actualDestinationClose).isEqualTo(expectedDestinations);
      softAssert.assertThat(actualDestinationDone).isEqualTo(expectedDates);
      softAssert.assertAll();
   }

   @When("they select the Search Panel Destination or Hotel field")
   public void they_select_the_Search_Panel_Destination_or_Hotel_field()
   {
      departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
   }

   @Then("all the unavailable countries and their tick boxes shall be greyed out")
   public void all_the_unavailable_countries_and_their_tick_boxes_shall_be_greyed_out()
   {
      List<SelenideElement> grayedOutCountries =
               departureAirportOrDestinationComponent.getMFEDestinationCountryListDisabled();
      grayedOutCountries.forEach(action ->
               LOGGER.log(LogLevel.INFO,
                        "unavailable Countries is displayed : " + action.getText()));
   }

   @Then("the user agent will not be able to select any of the unavailable countries")
   public void the_user_agent_will_not_be_able_to_select_any_of_the_unavailable_countries()
   {
      List<SelenideElement> unavailableCountries =
               departureAirportOrDestinationComponent.getMFEDestinationCountryListDisabled();
      WebElementTools.click(unavailableCountries.get(0));
   }

   @Then("all of the available countries shall be selectable")
   public void all_of_the_available_countries_shall_be_selectable()
   {
      List<SelenideElement> availableCountries =
               departureAirportOrDestinationComponent.getMFEDestinationCountryListEnabled();
      WebElementTools.click(availableCountries.get(0));
   }

   @When("they wish to close the Destinations modal")
   public void they_wish_to_close_the_Destinations_modal()
   {
      assertThat("Destination model close view is not Displayed",
               departureAirportOrDestinationComponent.mfeCloseDestinationModelIsPresent(),
               is(true));
   }

   @Then("they can do this by close selecting the following:")
   public void they_can_do_this_by_close_selecting_the_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<String> closeSelection = dataTable.asList();
      if (closeSelection.contains("X"))
      {
         departureAirportOrDestinationComponent.mfeClickCloseDestinationX();
         departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
      }
      if (closeSelection.contains("DONE"))
      {
         departureAirportOrDestinationComponent.mfeClickDestinationDone();
         departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
      }
      if (closeSelection.contains("select outside of dropdown"))
         departureAirportOrDestinationComponent.selectOutSide();
   }

   @Then("the list of countries shall be displayed in alphabetical order")
   public void the_list_of_countries_shall_be_displayed_in_alphabetical_order()
   {
      departureAirportOrDestinationComponent.isMFECountryalphabeticalOrder();
   }

   @Then("a tick box shall be displayed before each country and verify legecy message {string}\\(default state unticked)")
   public void a_tick_box_shall_be_displayed_before_each_country_and_verify_legecy_message_default_state_unticked(
            String string, io.cucumber.datatable.DataTable dataTable)
   {
      String actualLegacyMessageText = "";
      String actualLegacyLinkText = "";
      String expectedLegacyMessageText = "";
      String expectedLegacyLinkText = "";
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> dataMap : dataTableTemp)
      {
         if (dataMap.get("siteid").equals(string))
         {
            actualLegacyMessageText =
                     departureAirportOrDestinationComponent.mfeGetDestinationLegacyText().getText();
            actualLegacyLinkText =
                     departureAirportOrDestinationComponent.mfeGetDestinationLegacyLinkText()
                              .getText();
            LOGGER.log(LogLevel.INFO, "1" + actualLegacyLinkText);
            expectedLegacyMessageText = dataMap.get("Looking for more destinations?");
            expectedLegacyLinkText = dataMap.get("Find more holiday destinations");
            LOGGER.log(LogLevel.INFO, "1" + expectedLegacyLinkText);
         }

      }
      assertThat("Legacy cross over message text is not matched ",
               StringUtils.equalsIgnoreCase(expectedLegacyMessageText, actualLegacyMessageText),
               is(true));
      assertThat("Legacy cross over link message text is not matched ",
               StringUtils.equalsIgnoreCase(expectedLegacyLinkText, actualLegacyLinkText),
               is(true));
   }

   @Then("a tick box shall be displayed before each country and verify inhouse legecy message {string}\\(default state unticked)")
   public void a_tick_box_shall_be_displayed_before_each_country_and_verify_inhouse_legecy_message_default_state_unticked(
            String string, io.cucumber.datatable.DataTable dataTable)
   {
      String actualLegacyMessageText = "";
      String actualLegacyLinkText = "";
      String expectedLegacyMessageText = "";
      String expectedLegacyLinkText = "";
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> dataMap : dataTableTemp)
      {
         if (dataMap.get("siteid").equals(string) || dataMap.get("siteid").equals(string))
         {
            actualLegacyMessageText =
                     departureAirportOrDestinationComponent.mfeGetDestinationLegacyText().getText();
            actualLegacyLinkText = departureAirportOrDestinationComponent
                     .mfeGetDestinationLegacyAgentLinkText().getText() + " "
                     + departureAirportOrDestinationComponent.mfeGetDestinationLegacyInhouseLinkText()
                     .getText();
            expectedLegacyMessageText = dataMap.get("Looking for more destinations?");
            expectedLegacyLinkText = dataMap.get("Find more holiday destinations");
         }
      }
      assertThat("Legacy cross over message text is not matched ",
               StringUtils.equalsIgnoreCase(expectedLegacyMessageText, actualLegacyMessageText),
               is(true));
      assertThat("Legacy cross over link message text is not matched ",
               StringUtils.equalsIgnoreCase(expectedLegacyLinkText, actualLegacyLinkText),
               is(true));
   }

   @Then("a tick box shall be displayed before each country and verify tp legecy message {string}\\(default state unticked)")
   public void a_tick_box_shall_be_displayed_before_each_country_and_verify_tp_legecy_message_default_state_unticked(
            String string, io.cucumber.datatable.DataTable dataTable)
   {
      String actualLegacyMessageText = "";
      String actualLegacyLinkText = "";
      String expectedLegacyMessageText = "";
      String expectedLegacyLinkText = "";
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> dataMap : dataTableTemp)
      {
         if (dataMap.get("siteid").equals(string) || dataMap.get("siteid").equals(string))
         {
            actualLegacyMessageText =
                     departureAirportOrDestinationComponent.mfeGetDestinationLegacyText().getText();
            actualLegacyLinkText = departureAirportOrDestinationComponent
                     .mfeGetDestinationLegacyAgentLinkText().getText();
            expectedLegacyMessageText = dataMap.get("Looking for more destinations?");
            expectedLegacyLinkText = dataMap.get("Find more holiday destinations");
         }
      }
      assertThat("Legacy cross over message text is not matched ",
               StringUtils.equalsIgnoreCase(expectedLegacyMessageText, actualLegacyMessageText),
               is(true));
      assertThat("Legacy cross over link message text is not matched ",
               StringUtils.equalsIgnoreCase(expectedLegacyLinkText, actualLegacyLinkText),
               is(true));
   }

   @And("the as changed and {string}")
   public void the_as_changed_and(String string)
   {
      if (string.equals("be"))
         LOGGER.log(LogLevel.INFO, "message");
      if (string.equals("fr-BE"))
         departureAirportOrDestinationComponent.selectLanguage(string);
      if (string.equals("NL") || string.equals("RT_BE") || string.equals("RT_NL"))
         departureAirportOrDestinationComponent.selectSiteID(string);
      if (string.equals("RT_BE true") || string.equals("RT_NL true"))
      {
         String[] destinationValues = string.split(" ");
         departureAirportOrDestinationComponent.selectSiteID(destinationValues[0]);
         departureAirportOrDestinationComponent.set3PATrue(destinationValues[1]);
      }
   }

   @When("they select the {string} hyperlink")
   public void they_select_the_hyperlink(String string)
   {
      WebElementTools
               .click(departureAirportOrDestinationComponent.mfeGetDestinationLegacyLinkText());
   }

   @Then("the legacy website shall open on a new browser tab")
   public void the_legacy_website_shall_open_on_a_new_browser_tab()
   {
      wait.forJSExecutionReadyLazy();
      windowHandles = WebDriverUtils.getDriver().getWindowHandles();
      for (String windowHandle : windowHandles)
      {
         Selenide.switchTo().window(windowHandle);
      }
   }

   @Then("the {string} site shall be displayed in the relevant source market language \\(e.g French when a customer is viewing the TUI Belgium TRIPS website in French)")
   public void the_site_shall_be_displayed_in_the_relevant_source_market_language_e_g_French_when_a_customer_is_viewing_the_TUI_Belgium_TRIPS_website_in_French(
            String string)
   {
      if (WebDriverUtils.getDriver().getCurrentUrl().equalsIgnoreCase("https://www.tui.be/nl"))
         LOGGER.log(LogLevel.INFO,
                  string + "site shall be displayed in the relevant source market language"
                           + WebDriverUtils.getDriver().getCurrentUrl());
      if (string.equalsIgnoreCase(WebDriverUtils.getDriver().getCurrentUrl()))
         LOGGER.log(LogLevel.INFO,
                  string + "site shall be displayed in the relevant source market language"
                           + WebDriverUtils.getDriver().getCurrentUrl());
      else
         LOGGER.log(LogLevel.INFO,
                  string + "site is not displayed in the relevant source market language"
                           + WebDriverUtils.getDriver().getCurrentUrl());
      WebDriverUtils.getDriver().close();
      Selenide.switchTo().window((String) windowHandles.toArray()[0]);
   }

   @Given("the Customer is viewing the legacy message on the TRIPS Destination modal")
   public void the_Customer_is_viewing_the_legacy_message_on_the_TRIPS_Destination_modal(
            io.cucumber.datatable.DataTable dataTable)
   {
      packageNavigation.navigateToHoldaySearchPage();
      departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
      String siteId = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
               ? (BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
               + (BDDSiteIdResolver.getSiteRTId().toLowerCase())
               : (getTestExecutionParams().getLocaleStr().toLowerCase().contains("fr_be"))
               ? getTestExecutionParams().getLocaleStr().toLowerCase()
               : BDDSiteIdResolver.getSiteRTId().toLowerCase();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedLegacyMessage = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("Looking for more destinations?")).findFirst().orElse(null);
      String expectedLegacyMessageHyperLink =
               maps.stream().filter(row -> row.get("site").equals(siteId))
                        .map(row -> row.get("Find more holiday destinations")).findFirst()
                        .orElse(null);

      String actualLegacyMessage =
               departureAirportOrDestinationComponent.mfeGetDestinationLegacyText().getText();
      String actualLegacyMessageHyperLink =
               departureAirportOrDestinationComponent.mfeGetDestinationLegacyLinkText().getText();

      assertEquals("Legacy Message translations is not matched ", expectedLegacyMessage,
               actualLegacyMessage);
      assertEquals("Legacy Message HyperLink translations is not matched ",
               expectedLegacyMessageHyperLink, actualLegacyMessageHyperLink);
   }

   @When("they select the hyperlink within the legacy message")
   public void they_select_the_hyperlink_within_the_legacy_message()
   {
      initialHandles = WebDriverUtils.getDriver().getWindowHandles();
      WebElementTools
               .click(departureAirportOrDestinationComponent.mfeGetDestinationLegacyLinkText());
   }

   @Then("the legacy website shall open on the existing browser tab")
   public void the_legacy_website_shall_open_on_the_existing_browser_tab()
   {
      Set<String> currentHandles = WebDriverUtils.getDriver().getWindowHandles();
      assertThat("Website did not open in the existing tab",
               (currentHandles.containsAll(initialHandles)), is(true));
   }

   @Then("the legacy website site should be displayed in the relevant source market language")
   public void the_legacy_website_site_should_be_displayed_in_the_relevant_source_market_language(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
               ? (BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
               + (BDDSiteIdResolver.getSiteRTId().toLowerCase())
               : (getTestExecutionParams().getLocaleStr().toLowerCase().contains("fr_be"))
               ? getTestExecutionParams().getLocaleStr().toLowerCase()
               : BDDSiteIdResolver.getSiteRTId().toLowerCase();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedLegacyWebsite = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("legacy website")).findFirst().orElse(null);
      String actualLegacyWebsite = WebDriverUtils.getDriver().getCurrentUrl();
      assertEquals("Legacy website is Incorrect ", expectedLegacyWebsite, actualLegacyWebsite);
   }

   @And("they have not already selected a country, region, destination or hotel")
   public void they_have_not_already_selected_a_country_region_destination_or_hotel(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      String actualDefaultText = dataTableTemp.get("be");
      String expectedDefaultText =
               departureAirportOrDestinationComponent.getMFEDestinationDefaultText();
      assertEquals("Destination or Hotel user as not selected", expectedDefaultText,
               actualDefaultText);
   }

   @When("they click on the Search Panel MFE Destination or Hotel field")
   public void they_click_on_the_Search_Panel_MFE_Destination_or_Hotel_field()
   {
      departureAirportOrDestinationComponent.selectMFEDestinationListText();
   }

   @Then("the following destinations or hotel tooltip shall be displayed")
   public void the_following_destinations_or_hotel_tooltip_shall_be_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      String actualToolTip = dataTableTemp.get("be");
      String expectedToolTip =
               departureAirportOrDestinationComponent.getMFEDestinationToolTipMessage();
      assertEquals("Destination or Hotel Tool tip Shall be display", expectedToolTip,
               actualToolTip);
   }

   @And("they have already selected a country, region, destination, hotel or concept")
   public void they_have_already_selected_a_country_region_destination_hotel_or_concept()
   {
      departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
      selectedCountries = departureAirportOrDestinationComponent.getSelectAvailableCountry();
   }

   @Then("a list containing all the countries, regions, destinations, and hotels they have selected shall be displayed")
   public void a_list_containing_all_the_countries_regions_destinations_and_hotels_they_have_selected_shall_be_displayed()
   {
      assertTrue(departureAirportOrDestinationComponent.mfeDismissibleTagDropDownIsDisplay());
   }

   @Then("the list will be ordered in the sequential order that the countries, regions, destinations and hotels were selected")
   public void the_list_will_be_ordered_in_the_sequential_order_that_the_countries_regions_destinations_and_hotels_were_selected()
   {
      assertEquals(departureAirportOrDestinationComponent.getMFEDismissibleTagText(),
               selectedCountries);
   }

   @Then("each country, destination, region and hotel they have selected shall be shown as a dismissible tag")
   public void each_country_destination_region_and_hotel_they_have_selected_shall_be_shown_as_a_dismissible_tag()
   {
      assertTrue(departureAirportOrDestinationComponent.mfeDismissibleTagDropDownIsDisplay());
   }

   @And("the following CLEAR ALL link shall be displayed")
   public void the_following_CLEAR_ALL_link_shall_be_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      String actualClearAll = dataTableTemp.get("be");
      String expectedClearAll =
               departureAirportOrDestinationComponent.getMFEDestinationCloseText();
      assertEquals(expectedClearAll, actualClearAll);
   }

   @And("the following DONE button shall be displayed")
   public void the_following_DONE_button_shall_be_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      String actualDone = dataTableTemp.get("be");
      String expectedDone = departureAirportOrDestinationComponent.getMFEDestinationDoneText();
      assertEquals(expectedDone, actualDone);
   }

   @And("the destinations or hotel tooltip shall NOT be displayed")
   public void the_destinations_or_hotel_tooltip_shall_NOT_be_displayed()
   {
      Assert.assertFalse("the destinations or hotel tooltip shall NOT be displayed",
               departureAirportOrDestinationComponent.getMFEDestinationToolTipDisplayed()
                        .isDisplayed());
   }

   @When("they select the DONE button")
   public void they_select_the_DONE_button()
   {
      departureAirportOrDestinationComponent.getMFEDestinationDone().click();
   }

   @Then("the Destination or Hotel dismissible tag list shall no longer be displayed")
   public void the_Destination_or_Hotel_dismissible_tag_list_shall_no_longer_be_displayed()
   {
      Assert.assertFalse(
               "the Destination or Hotel dismissible tag list shall no longer be displayed",
               departureAirportOrDestinationComponent.mfeDismissibleTagDropDownIsDisplay());
   }

   @And("all the dismissible tag options shall be retained")
   public void all_the_dismissible_tag_options_shall_be_retained()
   {
      String[] countryName =
               departureAirportOrDestinationComponent.getMFEDestinationDefaultText().split(" ");
      assertThat(selectedCountries, Matchers.hasItem(countryName[0]));
   }

   @When("they select the CLEAR ALL option")
   public void they_select_the_CLEAR_ALL_option()
   {
      departureAirportOrDestinationComponent.getMFEDestinationClearAll().click();
   }

   @When("all the removed dismissible tag options shall be deselected \\(unticked) from the Destinations modal")
   public void all_the_removed_dismissible_tag_options_shall_be_deselected_unticked_from_the_Destinations_modal()
   {
      departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
      List<SelenideElement> getAttribute =
               departureAirportOrDestinationComponent.getMFEDestinationAttribute();
      getAttribute.forEach(action ->
               assertFalse(action.isSelected()));
   }

   @And("the Search Panel Destination or Hotel field shall be set to the source market language default value, e.g. {string} for TUI Belgium \\(French)")
   public void the_Search_Panel_Destination_or_Hotel_field_shall_be_set_to_the_source_market_language_default_value_e_g_for_TUI_Belgium_French(
            String string, io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      String actualDefaultText = dataTableTemp.get("be");
      String expectedDefaultText =
               departureAirportOrDestinationComponent.getMFEDestinationDefaultText();
      assertEquals("Destination or Hotel user as not selected", expectedDefaultText,
               actualDefaultText);
   }

   @When("they deselect a dismissible tag")
   public void they_deselect_a_dismissible_tag()
   {
      dismissibleTag = departureAirportOrDestinationComponent.getMFEDismissibleTagClose().get(0)
               .getAttribute("elementid");
      departureAirportOrDestinationComponent.getMFEDismissibleTagClose().get(0).click();
      wait.forJSExecutionReadyLazy();
   }

   @Then("the Destination or Hotel dismissible tag list shall still be displayed")
   public void the_Destination_or_Hotel_dismissible_tag_list_shall_still_be_displayed()
   {
      assertTrue("the Destination or Hotel dismissible tag list shall no longer be displayed",
               departureAirportOrDestinationComponent.mfeDismissibleTagDropDownIsDisplay());
   }

   @And("the option shall be removed from the Destination or Hotel dismissible tag list")
   public void the_option_shall_be_removed_from_the_Destination_or_Hotel_dismissible_tag_list()
   {
      int expected = selectedCountries.size();
      int actual = departureAirportOrDestinationComponent.getMFEDismissibleTagText().size();
      assertNotEquals(expected, actual);
   }

   @And("the removed dismissible tag option shall be deselected \\(unticked) from the Destinations modal")
   public void the_removed_dismissible_tag_option_shall_be_deselected_unticked_from_the_Destinations_modal()
   {
      departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
      List<SelenideElement> getAttribute =
               departureAirportOrDestinationComponent.getMFEDestinationAttribute();
      getAttribute.forEach(action ->
      {
         if (Objects.requireNonNull(action.getAttribute("dest")).equalsIgnoreCase(dismissibleTag))
            assertFalse(action.isSelected());
      });
   }

   @When("the customer enters {string} or more characters in the Destination or Hotel field")
   public void the_customer_enters_three_or_more_characters_in_the_Destination_or_Hotel_field(
            String character)
   {
      searchPanel.destinationSuggestions(character);
   }

   @Then("clickable suggestions should be shown including {string} text")
   public void clickableSuggestionsShouldBeShownIncludingText(String character)
   {
      List<SelenideElement> suggestionElements =
               searchPanel.destinationSuggestions(character).getAllSuggestionElements();

      SoftAssertions softAssert = new SoftAssertions();
      for (SelenideElement element : suggestionElements)
      {
         softAssert.assertThat(element.exists()).isTrue();
         softAssert.assertThat(element.getText().contains(character)).isTrue();
         softAssert.assertThat(element.isEnabled()).isTrue();
      }
      softAssert.assertAll();
   }

   @When("the customer enters {string} and they select SEE ALL DESTINATIONS")
   public void theCustomerEntersAndTheySelectSEEALLDESTINATIONS(String character)
   {
      searchPanel.destinationSuggestions(character).clickAllDestinationBtn().isOpen();
   }

   @Then("the customer enters {string} and following informational message shall be displayed:")
   public void theCustomerEntersAndFollowingInformationalMessageShallBeDisplayed(String character,
            DataTable dataTable)
   {
      DestinationSuggestion destinationSuggestionMfe =
               searchPanel.destinationSuggestions(character);
      String noMatchElement = destinationSuggestionMfe.getNoMatchElement().getText();
      String destinationButtonText =
               destinationSuggestionMfe.getSearchAllDestinationBtn().getText();
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      String actualDefaultText = dataTableTemp.get(getTestExecutionParams().getBrandStr());
      String expectedDefaultText = noMatchElement + " " + destinationButtonText;
      assertEquals("Suggestion error message is not displayed", expectedDefaultText,
               actualDefaultText);
   }

   @Then("Iceland should be displayed in a Destination modal and translation")
   public void iceland_should_be_displayed_in_a_Destination_modal_and_translation(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      String actual = dataTableTemp.get(getTestExecutionParams().getBrandStr());
      ElementsCollection allCountryDestinations =
               searchPanel.destination().getAllCountryDestinations();
      List<String> expected = selenideHelper.getElementsCollectionText(allCountryDestinations);
      MatcherAssert.assertThat(expected, Matchers.equalTo(actual));
   }

   @When("they choose {string} in the destinations modal")
   public void they_choose_in_the_destinations_modal(String destination)
   {
      searchPanel.destination().clearSelection().selectDestinationFromList(destination, "")
               .confirmSelection();
      searchPanel.departure().selectFirstAvailableDate().confirmSelection();
   }

   @Then("the search results with all available Iceland holidays \\(according to the search criteria) should be displayed")
   public void the_search_results_with_all_available_Iceland_holidays_according_to_the_search_criteria_should_be_displayed()
   {
      Assert.assertTrue(departureAirportOrDestinationComponent.getDestinationInSearchCard());
   }

   @Given("customers conducted a search with {string} as a destination")
   public void customers_conducted_a_search_with_as_a_destination(String destination)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanel.destination().clearSelection().selectDestinationFromList(destination, "")
               .confirmSelection();
      searchPanel.departure().selectFirstAvailableDate().confirmSelection();
      searchPanel.doSearch();
   }

   @When("the search results with all available Iceland holidays \\(according to the search criteria) are displayed")
   public void the_search_results_with_all_available_Iceland_holidays_according_to_the_search_criteria_are_displayed()
   {
      departureAirportOrDestinationComponent.getDestinationInSearchCard();
   }

   @Then("customers should be able to open any holiday's UD page and review its details")
   public void customers_should_be_able_to_open_any_holiday_s_UD_page_and_review_its_details()
   {
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      assertTrue(departureAirportOrDestinationComponent.accomadationNameDisplayed());
   }

   @Given("customers are reviewing UD page with {string} holiday")
   public void customers_are_reviewing_UD_page_with_holiday(String destination)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanel.destination().clearSelection().selectDestinationFromList(destination, "")
               .confirmSelection();
      searchPanel.departure().selectFirstAvailableDate().confirmSelection();
      searchPanel.doSearch();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
      wait.forJSExecutionReadyLazy();
   }

   @Given("decide to proceed with the booking")
   public void decide_to_proceed_with_the_booking()
   {
      unitPage.progressbarComponent.clickOnContinueButton();
   }

   @Then("customers should be able to choose this holiday on a UD page and proceed to the next stage")
   public void customers_should_be_able_to_choose_this_holiday_on_a_UD_page_and_proceed_to_the_next_stage()
   {
      assertTrue("Summary page wasn't loaded", summaryPage.navigationComponent.isPageDisplayed());
   }

   @When("they conduct a search with it")
   public void they_conduct_a_search_with_it()
   {
      searchPanel.doSearch();
   }

   @When("they select all the children for a parent")
   public void theySelectAllTheChildrenForAParent(DataTable dataTable)
   {
      String siteId = BDDSiteIdResolver.getAllBrandSiteId();

      List<Map<String, String>> maps = dataTable.asMaps();
      String country = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("country")).findFirst().orElse(null);
      String region = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("region")).findFirst().orElse(null);
      assert region != null;
      regions = List.of(region.split(","));
      searchPanel.destination().selectAllResort(country, regions).confirmSelection();
   }

   @And("the parent tick box within the modal shall be selected")
   public void theParentTickBoxWithinTheModalShallBeSelected()
   {
      destinationMfe.getCheckBoxSelected().isSelected();
   }

   @And("the Destination modal dismissible tags shall be displayed in the order that the children were selected")
   public void theDestinationModalDismissibleTagsShallBeDisplayedInTheOrderThatTheChildrenWereSelected()
   {
      List<String> actual = new ArrayList<>();
      ElementsCollection selenideElements = searchPanel.destination().dismissibleTagsDestinations();
      for (SelenideElement element : selenideElements)
      {
         String elementText = element.getText();
         actual.add(elementText);
      }
      assertEquals("the Destination modal dismissible tags shall be displayed is not the order",
               actual, regions);
   }

   @Then("the Search Panel shall be set to first selected name followed by {string} x more that has been selected")
   public void theSearchPanelShallBeSetToFirstSelectedNameFollowedByXMoreThatHasBeenSelected(
            String arg0, DataTable dataTable)
   {
      Map<String, String> dataTableTemp = dataTable.asMap(String.class, String.class);
      final String displayedDestination = searchPanel.getSelectedDestination();
      String[] splitDestination =
               displayedDestination.split(" ");
      String firstName = splitDestination[0];
      String specialCharacter = splitDestination[1];
      String count = splitDestination[2];
      String more = splitDestination[3];
      SoftAssertions softAssertions = new SoftAssertions();
      softAssertions.assertThat(firstName)
               .withFailMessage("first selected name is not matched")
               .isEqualTo(regions.get(0));
      softAssertions.assertThat(specialCharacter)
               .withFailMessage("Special character + is not available")
               .isEqualTo(arg0);
      softAssertions.assertThat(more)
               .withFailMessage("number of available destination or regions are not available")
               .isEqualTo(dataTableTemp.get(BDDSiteIdResolver.getSiteRTId().toLowerCase()));
   }

   @And("they select the parent for the children that were previously selected")
   public void theySelectTheParentForTheChildrenThatWerePreviouslySelected(DataTable dataTable)
   {
      String siteId = BDDSiteIdResolver.getAllBrandSiteId();
      List<Map<String, String>> maps = dataTable.asMaps();
      String country = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("country")).findFirst().orElse(null);
      destinationName = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("region")).findFirst().orElse(null);
      searchPanel.destination().confirmSelection();
      searchPanel.destination().selectDestinationFromList(country, destinationName);
   }

   @And("a dismissible tag for the parent shall be displayed within the Destinations modal")
   public void aDismissibleTagForTheParentShallBeDisplayedWithinTheDestinationsModal()
   {
      searchPanel.destination();
      String destinationText = destinationMfe.dismissibleTagsDestinations().first().getText();
      assertEquals("dismissible tag for the parent not displayed within the Destinations modal",
               destinationText, destinationName);
   }

   @And("the Search Panel Destination or Hotel field shall be set to the parent")
   public void theSearchPanelDestinationOrHotelFieldShallBeSetToTheParent()
   {
      final String displayedDestination = searchPanel.getSelectedDestination();
      assertEquals("the Search Panel Destination or Hotel field shall be set to the parent",
               displayedDestination, destinationName);
   }

   @And("the customer has selected at least the first {string} characters form the destination")
   public void theCustomerHasSelectedAtLeastTheFirstCharactersFormTheDestination(
            String character)
   {
      destinationName = character;
      searchPanel.destinationSuggestions(character).selectSuggestionFromList(character);
   }

   @And("the customer has selected at least the first three or more characters form the destination")
   public void theCustomerHasSelectedAtLeastTheFirstThreeOrMoreCharactersFormTheDestination(
            DataTable dataTable)
   {
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      String siteId = BDDSiteIdResolver.getAllBrandSiteId();
      destinationName = map.get(siteId);
      searchPanel.destinationSuggestions(map.get(siteId)).selectSuggestionFromList(map.get(siteId));
   }
}
