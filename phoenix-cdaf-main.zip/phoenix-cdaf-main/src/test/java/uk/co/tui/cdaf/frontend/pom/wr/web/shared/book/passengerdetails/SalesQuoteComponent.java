package uk.co.tui.cdaf.frontend.pom.wr.web.shared.book.passengerdetails;

import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;

public class SalesQuoteComponent extends AbstractPage
{

   public SelenideElement getCreateQuoteLink()
   {
      return $("#salesQuote__component .quoteContainer #createQuoteLink");
   }

   public SelenideElement getSalesQuoteModal()
   {
      return $("#salesQuote__component .quoteContainer .popups__opened .popups__modal");
   }

   public SelenideElement getSalesQuoteModalTitle()
   {
      return getSalesQuoteModal().$("header [aria-label=\"title\"]");
   }

   public SelenideElement getSalesQuoteCostTypeFieldById(int index)
   {
      return getSalesQuoteModal().$("select#costTypeField" + index);
   }

   public SelenideElement getSalesQuoteCostTypeFieldWrapperById(int index)
   {
      return getSalesQuoteCostTypeFieldById(index)
               .$(By.xpath("ancestor::*[contains(@class, 'costTypeFieldWrapper')]"));
   }

   public SelenideElement getSalesQuoteSumFieldById(int index)
   {
      return getSalesQuoteModal().$("input[type='number']#sumField" + index);
   }

   public SelenideElement getSalesQuoteSumFieldWrapperById(int index)
   {
      return getSalesQuoteSumFieldById(index)
               .$(By.xpath("ancestor::*[contains(@class, 'sumFieldWrapper')]"));
   }

   public SelenideElement getSalesQuoteNotesFieldById(int index)
   {
      return getSalesQuoteModal().$("textarea#notesField" + index);
   }

   public SelenideElement getSalesQuoteNotesFieldWrapperById(int index)
   {
      return getSalesQuoteNotesFieldById(index)
               .$(By.xpath("ancestor::*[contains(@class, 'notesFieldWrapper')]"));
   }

   public SelenideElement getSalesQuoteDeleteRateLinkById(int index)
   {
      return getSalesQuoteModal().$("a#deleteRateButton" + index);
   }

   public SelenideElement getSalesQuoteAddRateLink()
   {
      return getSalesQuoteModal().$("a#addRateButton");
   }

   public SelenideElement getSalesQuoteSaveAsPDFButton()
   {
      return getSalesQuoteModal().$("footer button.saveAsPdfButton");
   }

   public SelenideElement getAddRateLink()
   {
      return getSalesQuoteModal().$("#addRateButton");
   }

   public List<SelenideElement> getSalesQuoteFeeSections()
   {
      return getSalesQuoteModal().$$(".AdditionalFeesForm__feesSectionWrapper");
   }

   public void fillSalesQuoteFeeSectionByIndex(int index)
   {
      new Select(getSalesQuoteCostTypeFieldById(index)).selectByIndex(1);

      getSalesQuoteSumFieldById(index).type(RandomStringUtils.random(2, false, true));
      getSalesQuoteNotesFieldById(index).type(RandomStringUtils.random(8, true, false));
   }

   public boolean isSalesQuoteFeeSectionDeletedByIndex(int index)
   {
      return !(getSalesQuoteSumFieldById(index).isDisplayed()
               && getSalesQuoteNotesFieldById(index).isDisplayed()
               && getSalesQuoteCostTypeFieldById(index).isDisplayed());
   }
}
