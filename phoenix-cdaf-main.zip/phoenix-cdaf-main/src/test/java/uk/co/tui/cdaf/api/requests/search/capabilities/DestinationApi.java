package uk.co.tui.cdaf.api.requests.search.capabilities;

import lombok.SneakyThrows;
import uk.co.tui.cdaf.api.pojo.search.legacy.DestinationResponse;
import uk.co.tui.cdaf.api.pojo.search.mfe.CountryData;
import uk.co.tui.cdaf.api.pojo.search.mfe.Destination;
import uk.co.tui.cdaf.api.requests.search.parameters.SearchParameters;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class DestinationApi extends BaseApi
{
   @SneakyThrows
   public List<Destination> getAvailableDestinations(@Nullable TestDataAttributes tda,
            SearchParameters searchParameters)
   {
      if (tda == null || tda.getDestination() == null)
         return Collections.emptyList();

      String destinationName = tda.getDestination();
      List<Destination> countries;
      if (!ExecParams.isSitEnv())
      {
         String responseBody =
                  getCapabilitiesResponse(searchParameters, "all-destinations").getBody()
                           .asString();
         countries = objectMapper.readValue(responseBody, CountryData.class).getCountries();
      }
      else
      {
         String responseBody =
                  getCapabilitiesResponse(searchParameters, "countries").getBody()
                           .asString();
         countries = objectMapper.readValue(responseBody, DestinationResponse.class).getData()
                  .getCountries();
      }

      return countries.stream()
               .filter(Objects::nonNull)
               .flatMap(country -> findDestination(country, destinationName).stream())
               .collect(Collectors.toList());
   }

   private List<Destination> findDestination(Destination destination, String destinationName)
   {
      List<Destination> foundDestinations = new ArrayList<>();
      if (destination.getName().equals(destinationName))
      {
         foundDestinations.add(destination);
      }
      List<Destination> children = destination.getChildren();
      if (children == null)
         return foundDestinations;
      for (Destination child : children)
      {
         foundDestinations.addAll(findDestination(child, destinationName));
      }
      return foundDestinations.stream()
               .filter(Destination::isAvailable)
               .collect(Collectors.toList());
   }

}
