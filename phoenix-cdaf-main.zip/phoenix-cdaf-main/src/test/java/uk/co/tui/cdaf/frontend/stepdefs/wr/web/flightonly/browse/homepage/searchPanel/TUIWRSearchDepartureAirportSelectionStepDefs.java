package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.browse.homepage.searchPanel;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TUIWRSearchDepartureAirportSelectionStepDefs
{
   private final FlightOnlyHomePage homepage;

   private final WebElementWait wait;

   private String departureAirport;

   public TUIWRSearchDepartureAirportSelectionStepDefs()
   {
      homepage = new FlightOnlyHomePage();
      wait = new WebElementWait();
   }

   @Given("a {string} is on a TUIfly homepage")
   public void a_is_on_a_TUIfly_homepage(String string)
   {
      homepage.visit();
   }

   @Given("no previous {string} selection has been made \\(default)")
   public void no_previous_selection_has_been_made_default(String string)
   {
      assertThat("Search panel is in default state", homepage.defaultSearchPanelState(), is(true));
   }

   @Given("a customer has clicked in the {string} field")
   public void a_customer_has_clicked_in_the_field(String string)
   {
      wait.forJSExecutionReadyLazy();
      homepage.clickDepartureAirportField();
   }

   @When("a customer clicks on an available airport within the {string} panel")
   public void a_customer_clicks_on_an_available_airport_within_the_panel(String string)
   {
      departureAirport = homepage.clickDepartureAirport(1);
   }

   @Then("the name of the selected airport will replace the text {string} in the {string} field")
   public void the_name_of_the_selected_airport_will_replace_the_text_in_the_field(String string,
            String string2)
   {
      assertThat("Text in airport Field is the same as selected airport",
               homepage.validateDepartureAirportFieldValue(departureAirport), is(true));
   }

   @Then("the {string} panel will collapse")
   public void the_panel_will_collapse(String string)
   {
      assertThat("DestinationAirport DropdownModal is collapsed",
               homepage.validateDepartureAirportsDropdown(),
               is(false));
   }

   @Given("a customer has already selected an airport in the {string} field")
   public void a_customer_has_already_selected_an_airport_in_the_field(String string)
   {
      homepage.clickDepartureAirportField();
      departureAirport = homepage.clickDepartureAirport(1);
   }

   @Given("a customer has clicked in the {string} field again")
   public void a_customer_has_clicked_in_the_field_again(String string)
   {
      homepage.clickDepartureAirportField();
   }

   @When("a customer clicks on a different available airport within the {string} panel")
   public void a_customer_clicks_on_a_different_available_airport_within_the_panel(String string)
   {
      departureAirport = homepage.clickDepartureAirport(2);
   }

   @Then("the name of the selected airport will replace the previous airport name in the {string} field")
   public void the_name_of_the_selected_airport_will_replace_the_previous_airport_name_in_the_field(
            String string)
   {
      assertThat("Text in airport Field is the same as selected airport",
               homepage.validateDepartureAirportFieldValue(departureAirport), is(true));
   }

   @When("a customer is shown airports that are in a disabled state \\(based on availability and search selections)")
   public void a_customer_is_shown_airports_that_are_in_a_disabled_state_based_on_availability_and_search_selections()
   {
      homepage.clickDisabledDepartureAirport();
   }

   @Then("the customer will be unable to click on that selection but the airport will be visible")
   public void the_customer_will_be_unable_to_click_on_that_selection_but_the_airport_will_be_visible()
   {
      assertThat("Disabled airport is not clickable", homepage.validateDepartureAirportsDropdown(),
               is(true));
   }
}
