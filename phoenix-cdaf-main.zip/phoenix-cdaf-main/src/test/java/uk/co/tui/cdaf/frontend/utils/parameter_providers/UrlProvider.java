package uk.co.tui.cdaf.frontend.utils.parameter_providers;

import lombok.SneakyThrows;
import uk.co.tui.cdaf.frontend.utils.LoginHandler;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.Brands;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;

import java.net.URL;

public class UrlProvider
{
   private static final String PROTOCOL = "https";

   protected static URL getBaseUrl(TestExecutionParams executionParams)
   {
      if (ExecParams.getAgent().isB2C())
         return getB2CUrl(executionParams);
      else
         return getB2BUrl(executionParams);
   }

   private static URL getB2BUrl(TestExecutionParams executionParams)
   {
      Brands brand = executionParams.getBrand();

      if (!isValidBrand(brand))
      {
         throw new IllegalArgumentException("Invalid brand for B2B: " + brand);
      }

      if (executionParams.getAgent().isInhouse())
      {
         return getInhouseUrl(executionParams);
      }
      else if (executionParams.getAgent().isThirdparty())
      {
         return getThirdPartyUrl(executionParams);
      }
      else
      {
         throw new IllegalArgumentException(
                  "Invalid B2B agent type: " + executionParams.getAgent().getBussinessType());
      }
   }

   private static boolean isValidBrand(Brands brand)
   {
      return brand.equals(Brands.MA) || brand.equals(Brands.BE) || brand.equals(Brands.NL);
   }

   @SneakyThrows
   private static URL getInhouseUrl(TestExecutionParams executionParams)
   {
      String brandStr = executionParams.getBrandStr();
      String envStr = executionParams.getEnvStr();
      String packageType = executionParams.getAgent().getPackageTypeStr();

      String host = "tuiretail-" + brandStr + "-" + envStr + ".tuiad.net";
      String path = "/retail/inhouse/login";
      LoginHandler.agentLogin(new URL(PROTOCOL, host, path), executionParams);

      return new URL(PROTOCOL, host, "/retail" + packageType);
   }

   @SneakyThrows
   private static URL getThirdPartyUrl(TestExecutionParams executionParams)
   {
      Brands brand = executionParams.getBrand();
      String country = executionParams.getBrandStr();
      String env = executionParams.getEnvStr();
      String packageType = executionParams.getAgent().getPackageTypeStr();

      String host = brand.equals(Brands.MA) ? env + "-retailagents.tuiflyprjuat.ma" :
               env + "-retailagents.tuiprjuat." + country;
      String path = "/retail/thirdpartyagent/login";
      LoginHandler.agentLogin(new URL(PROTOCOL, host, path), executionParams);

      return new URL(PROTOCOL, host, "/retail" + packageType);
   }

   @SneakyThrows
   private static URL getB2CUrl(TestExecutionParams executionParams)
   {
      String packageType = executionParams.getAgent().getPackageTypeStr();
      return new URL(PROTOCOL, getB2CDomain(executionParams), packageType);
   }

   private static String getB2CDomain(TestExecutionParams executionParams)
   {
      Brands brand = executionParams.getBrand();
      String env = executionParams.getEnvStr();
      String domainName = env + ".tuiprjuat.";
      if (brand.equals(Brands.VIP))
      {
         if (executionParams.getAgent().isHolidayPackageType())
            return env + ".vip-selectionprjuat.be";
         else
            throw new IllegalArgumentException("Invalid type for VIP: " +
                     executionParams.getAgent().getPackageTypeStr());
      }

      if (executionParams.getAgent().isFlightPackageType() && !executionParams.isNL())
      {
         domainName = env + ".tuiflyprjuat.";
      }

      return domainName + executionParams.getBrandStr();
   }
}
