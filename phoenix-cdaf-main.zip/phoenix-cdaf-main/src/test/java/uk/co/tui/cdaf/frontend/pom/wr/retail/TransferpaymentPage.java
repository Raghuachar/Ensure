package uk.co.tui.cdaf.frontend.pom.wr.retail;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.TestExecutionParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.TestDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.BookingAttributes;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class TransferpaymentPage extends AbstractPage
{
   private final WebElementWait wait;

   protected BookingAttributes testData;

   @FindBy(css = "input[name='bookingReference']")
   private WebElement bookingReference;

   @FindBy(css = ".UI__paymentTypeTransfer .UI__validateButton")
   private WebElement transferPayvalidate;

   @FindBy(css = ".UI__paymentType h3")
   private WebElement paymentTypeTitle;

   @FindBy(css = ".UI__validateButton ")
   private WebElement ValidateButton;

   @FindBy(css = ".UI__continue")
   private WebElement completebooking;

   public TransferpaymentPage()
   {
      wait = new WebElementWait();
   }

   public void vadaiteCTA()
   {
      WebElementTools.clickElementJavaScript(transferPayvalidate);
      completeBooking();
   }

   public String getVadaiteText()
   {
      return WebElementTools.getElementText(ValidateButton);

   }

   public String getPaymentTypeTitle()
   {
      return WebElementTools.getElementText(paymentTypeTitle);
   }

   public void enterBookingReferenceNumber(String bookingReferenceNumber)
   {
      WebElementTools.enterText(bookingReference, bookingReferenceNumber);
   }

   public void selectValidateButton()
   {
      WebElementTools.clickElementJavaScript(ValidateButton);
   }

   public void completeBooking()
   {
      WebElementTools.clickElementJavaScript(completebooking);
   }

   public void getTransferPayment()
   {
      TestExecutionParams testParams = ExecParams.getTestExecutionParams();
      wait.forJSExecutionReadyLazy();
      if (testParams.isBE())
         testData = TestDataHelper.getTripsBookingData().getTransferPaymentRTBE();
      else if (testParams.isNL())
         testData = TestDataHelper.getTripsBookingData().getTransferPaymentRTNL();
      enterBookingReferenceNumber(testData.getBookingReferenceNumber());
      selectValidateButton();
      wait.forJSExecutionReadyLazy();
   }

}
