package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSEODBPreviousReconPageStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageSEODBPreviousReconPageStepDefs()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the agent is viewing the banking and reconciliations page")
   public void that_the_agent_is_viewing_the_banking_and_reconciliations_page()
   {
      packagenavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

   @When("they click the link to Previous reconciliation Link")
   public void they_click_the_link_to_Previous_reconciliation_Link()
   {
      pKgReconcilationPaymentPageComponents.clickPreviousReconPageLink();
   }

   @Then("the previous reconciliations spoke page will open")
   public void the_previous_reconciliations_spoke_page_will_open()
   {
      assertThat("Previous Reconciliations page opened and Global header displayed",
               pKgReconcilationPaymentPageComponents.isPreviousReconGlobalHeaderAvailable(),
               is(true));
   }

   @Then("this will be within the same tab window")
   public void this_will_be_within_the_same_tab_window()
   {
      wait.forJSExecutionReadyLazy();
   }
}
