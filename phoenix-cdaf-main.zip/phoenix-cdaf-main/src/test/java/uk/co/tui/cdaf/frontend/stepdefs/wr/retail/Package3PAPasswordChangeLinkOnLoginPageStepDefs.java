package uk.co.tui.cdaf.frontend.stepdefs.wr.retail;

import com.codeborne.selenide.Selenide;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.Package3PAPasswordChange;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class Package3PAPasswordChangeLinkOnLoginPageStepDefs
{
   private final Map<String, String> searchMap;

   private final PackageNavigation packageNavigation;

   private final RetailPage retailPage;

   private final Package3PAPasswordChange package3PAPasswordChange;

   public WebElementWait wait;

   AutomationLogManager LOGGER =
            new AutomationLogManager(Package3PAPasswordChangeLinkOnLoginPageStepDefs.class);

   public Package3PAPasswordChangeLinkOnLoginPageStepDefs()
   {
      packageNavigation = new PackageNavigation();
      retailPage = new RetailPage();
      package3PAPasswordChange = new Package3PAPasswordChange();
      wait = new WebElementWait();
      searchMap = new HashMap<>();
   }

   @Given("the {string} has accessed the 3PA log in page")
   public void the_has_accessed_the_3PA_log_in_page(String string)
   {
      packageNavigation.navigateToRetailThirdPartyLoginPage();
   }

   @When("they review the login page")
   public void they_review_the_login_page()
   {
      assertThat("3PA login page is not displayed", retailPage.isRetailLoginPage(), is(true));
   }

   @Then("they can see the following link")
   public void they_can_see_the_following_link(String change)
   {
      assertThat("retail agent is NOT on the TUI.nl site",
               package3PAPasswordChange.getChangePasswordLabel().getText().toLowerCase()
                        .contains(change),
               is(true));
   }

   @When("they select the Change password link")
   public void they_select_the_Change_password_link()
   {
      package3PAPasswordChange.getChangePasswordLabel().click();
   }

   @Then("they are redirected to the change password page")
   public void they_are_redirected_to_the_change_password_page()
   {
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      assertThat("page is not redirected to the change password page",
               searchResultsPageURL.contains("/retail/thirdpartyagent/changepassword"), is(true));
   }

   @Given("the {string} has accessed the change password page")
   public void the_has_accessed_the_change_password_page(String string)
   {
      packageNavigation.navigateToRetailThirdPartyLoginPage();
      package3PAPasswordChange.getChangePasswordLabel().click();
   }

   @When("they browser back")
   public void they_browser_back()
   {
      Selenide.back();
   }

   @Then("they are redirected to the third party agent log in page")
   public void they_are_redirected_to_the_third_party_agent_log_in_page()
   {
      assertThat("3PA login page is not displayed", retailPage.isRetailLoginPage(), is(true));
   }

   @Given("New password must contain all of the following")
   public void new_password_must_contain_all_of_the_following(DataTable dataTable)
   {
      List<String> list = dataTable.asList(String.class);
      package3PAPasswordChange.verifyingNewPasswordLabels(list);

   }

   @Then("they can see the following input fields on the change password page")
   public void they_can_see_the_following_input_fields_on_the_change_password_page(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<String> changePwdList = dataTable.asList(String.class);
      assertThat("change pssword input fields are not dispalyed",
               package3PAPasswordChange.verifyingChangedpasswordfields(changePwdList), is(true));
   }

   @When("they select the {string} input field")
   public void they_select_the_input_field(String string)
   {
      package3PAPasswordChange.clickAndEnterOnOfficeAbTAId();
   }

   @Then("there are no restrictions to the data types that can be entered \\(numbers, letters etc)")
   public void there_are_no_restrictions_to_the_data_types_that_can_be_entered_numbers_letters_etc()
   {
      assertThat(
               "there are restrictions to the data types that can be entered (numbers, letters etc) ",
               package3PAPasswordChange.verifiyingOfficeABTAIdText(), is(true));
   }

   @When("they select the a {string} link")
   public void they_select_the_a_link(String string)
   {
      if (string.equalsIgnoreCase(package3PAPasswordChange.getBackToLogin()))
         package3PAPasswordChange.clickOnBackToLogin();
   }

   @Then("they are redirected back to the log in page")
   public void they_are_redirected_back_to_the_log_in_page()
   {
      assertThat("3PA login page is not displayed", retailPage.isRetailLoginPage(), is(true));
   }

   @Given("the {string} has accessed the {string} page")
   public void the_has_accessed_the_page(String string, String string2)
   {
      packageNavigation.navigateToChangePasswordPage();
   }

   @Given("they have selected the {string} field")
   public void they_have_selected_the_field(String string)
   {
      package3PAPasswordChange.clickOnTextBox(string);
   }

   @When("they tab out or select outside the field without entering any data")
   public void they_tab_out_or_select_outside_the_field_without_entering_any_data()
   {
      package3PAPasswordChange.clickOnOutSide();
   }

   @Then("then the following error appears underneath the field:")
   public void then_the_following_error_appears_underneath_the_field(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<String> currentPswErrorMsg = dataTable.asList(String.class);
      assertThat("change password text Error msg is not dispalyed",
               package3PAPasswordChange.verifiyingErrorMsg(currentPswErrorMsg), is(true));

   }

   @And("they are interacting with the New password input field")
   public void they_are_interacting_with_the_New_password_input_field()
   {
      assertThat("new password input field is not entered",
               package3PAPasswordChange.getNewPasswordIsPresent(), is(true));
   }

   @When("they enter a new prospective password")
   public void they_enter_a_new_prospective_password()
   {
      package3PAPasswordChange.enterNewPassword();
   }

   @Then("the password must contain all of the following:")
   public void the_password_must_contain_all_of_the_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      package3PAPasswordChange.verifyingNewPasswordLabels(dataTable.asList(String.class));
   }

   @And("on the passing of each requirement a tick appears next to the copy")
   public void on_the_passing_of_each_requirement_a_tick_appears_next_to_the_copy()
   {
      assertThat("Tick not Appers New Passwordmsg",
               package3PAPasswordChange.getTickAppersNewPassword(), is(true));
   }

   @When("they review the page content")
   public void they_review_the_page_content()
   {
      assertThat("they are not review the page content of change password",
               package3PAPasswordChange.getChangePasswordCompnentIsPresent(), is(true));
   }

   @Then("the CAPTCHA challenge response test appears on the page")
   public void the_CAPTCHA_challenge_response_test_appears_on_the_page()
   {
      assertThat("CAPTCHA challenge not response test appears on the page",
               package3PAPasswordChange.getCaptchaComponentIsPresent(), is(true));
   }

   @Then("it displays between the final field and the SAVE cta")
   public void it_displays_between_the_final_field_and_the_SAVE_cta()
   {
      assertThat("it not displays between the final field and the SAVE cta",
               package3PAPasswordChange.getBelowCaptchaSaveIsPresent(), is(true));
   }

   @When("they enter a password that does not confirm to at least one of the {string} requirements")
   public void they_enter_a_password_that_does_not_confirm_to_at_least_one_of_the_requirements(
            String string)
   {
      switch (string)
      {
         case "8-20 characters":
            package3PAPasswordChange.verifyingNewPasswordCreteria("abcdefgh");
            break;
         case "lower case letter(s)":
            package3PAPasswordChange.verifyingNewPasswordCreteria("abcd");
            break;
         case "CAPITAL letter(s)":
            package3PAPasswordChange.verifyingNewPasswordCreteria("ABCDE");
            break;
         case "number(s)":
            package3PAPasswordChange.verifyingNewPasswordCreteria("1234");
            break;
      }
   }

   @Given("they have entered a new password in the {string} field")
   public void they_have_entered_a_new_password_in_the_field(String string)
   {
      package3PAPasswordChange.verifyingNewPasswordCreteria("1Ap15is036@");
   }

   @When("they enter a password that does not match the new password")
   public void they_enter_a_password_that_does_not_match_the_new_password()
   {
      package3PAPasswordChange.verifyingReEnterPassword("1Ap15is036");

   }

   @Then("then the following error appears underneath the {string} field:")
   public void then_the_following_error_appears_underneath_the_field(String string,
            io.cucumber.datatable.DataTable dataTable)
   {
      List<String> reEnterPswErrorMsg = dataTable.asList(String.class);
      assertThat("Please make sure the passwords match",
               package3PAPasswordChange.verifyReEnterPasswordErrorMessage(reEnterPswErrorMsg),
               is(true));
   }

   @And("they have entered at least one character in {string} field")
   public void they_have_entered_at_least_one_character_in_field(String string)
   {
      package3PAPasswordChange.enterPassword(string);
   }

   @When("they select the {string} link alongside any of  {string} field")
   public void they_select_the_link_alongside_any_of_fields(String string, String string2)
   {
      package3PAPasswordChange.clickOnLink(string, string2);
   }

   @Then("the respective password displays in full within the input field")
   public void the_respective_password_displays_in_full_within_the_input_field()
   {
      assertThat("the respective password not displays in full within the input field",
               package3PAPasswordChange.verifyingFieldValue(), is(true));
   }

   @Then("the link changes to {string}")
   public void the_link_changes_to(String string)
   {
      assertThat("The link not changed ", package3PAPasswordChange.verifyingLink(string), is(true));
   }

   @Then("the respective password converts to an encrypted format \\(as per the log in page) within the input field")
   public void the_respective_password_converts_to_an_encrypted_format_as_per_the_log_in_page_within_the_input_field()
   {
      assertThat(
               "the respective password not converts to an encrypted format(as per the log in page) within the input field",
               package3PAPasswordChange.verifyingFieldValue(), is(true));
   }

   @And("they have entered an ID into the Agent ABTA ID field that does not exist or is inactive")
   public void they_have_entered_an_ID_into_the_Agent_ABTA_ID_field_that_does_not_exist_or_is_inactive()
   {
      package3PAPasswordChange.enterChangePasswordFileds("6022", "currPassword", "TuiTrips123");
   }

   @When("they select the Save button")
   public void they_select_the_Save_button()
   {
      package3PAPasswordChange.clickOnSaveButton();
   }

   @Then("validation of the ID enters fails")
   public void validation_of_the_ID_enters_fails()
   {
      assertThat("Validation error message is not displayed",
               package3PAPasswordChange.getAlertABTAFailed(), is(true));
   }

   @Given("they have entered data into all fields")
   public void they_have_entered_data_into_all_fields()
   {
      if (BDDSiteIdResolver.getSiteRTId().equalsIgnoreCase("rt_be"))
         package3PAPasswordChange.enterChangePasswordFileds("605502", "Retail@1234", "Retail@1234");
      if (BDDSiteIdResolver.getSiteRTId().equalsIgnoreCase("rt_nl"))
         package3PAPasswordChange.enterChangePasswordFileds("1653", "Retail@1234", "Retail@1234");
   }

   @Given("they have selected the {string} button")
   public void they_have_selected_the_button(String string)
   {
      package3PAPasswordChange.clickOnSaveButton();
   }

   @When("the change password request is authorised Successful response")
   public void the_change_password_request_is_authorised_Successful_response()
   {
      wait.forJSExecutionReadyLazy();
      assertThat("the change password request is authorised NOT Successful",
               package3PAPasswordChange.successMessage(), is(true));
   }

   @Then("then the page content is replaced with a success message:")
   public void then_the_page_content_is_replaced_with_a_success_message(List<String> components)
   {
      package3PAPasswordChange.wait.forJSExecutionReadyLazy();
      searchMap.putAll(package3PAPasswordChange.getSummaryDetails());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final String element = searchMap.get(componentIdentifier.trim());
            LOGGER.log(LogLevel.INFO, searchMap);
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = true;
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     true, true), true, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));

         }
      });
   }

   @Then("they select the log in link")
   public void they_select_the_log_in_link()
   {
      package3PAPasswordChange.clickOnLoginLink();
   }

   @Then("they are redirected back to the {int}PA log in page")
   public void they_are_redirected_back_to_the_PA_log_in_page(Integer int1)
   {
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      assertThat("page is not redirected to the change password page",
               searchResultsPageURL.contains("/retail/thirdpartyagent/login"), is(true));
   }

   @Given("they have only entered a password in the {string} field i.e. the {string} field is blank")
   public void they_have_only_entered_a_password_in_the_field_i_e_the_field_is_blank(String string,
            String string2)
   {
      package3PAPasswordChange.verifyingReEnterPassword("java@123");
   }

   @When("they select the {string} button:")
   public void they_select_the_button(String string)
   {
      package3PAPasswordChange.clickOnSaveButton();
   }

   @And("they have ticked the CAPTCHA checkbox")
   public void they_have_ticked_the_CAPTCHA_checkbox()
   {
      package3PAPasswordChange.clickOnRecaptchaCheckbox();
   }

   @When("they select the {string} button change password")
   public void they_select_the_button_change_password(String string)
   {
      if (package3PAPasswordChange.switchIFrameCaptchImage())
         LOGGER.log(LogLevel.INFO, "Image Validation is not possible");
      else
         package3PAPasswordChange.clickOnSaveButton();
   }

   @When("they're presented with the following message:")
   public void they_re_presented_with_the_following_message(String dataTable)
   {
      boolean captchaError =
               package3PAPasswordChange.getCapthaErrorMessage().equalsIgnoreCase(dataTable);
      assertThat("Specific date filter not displayed", captchaError, is(true));

   }
}
