package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

public class VoucherRemoveComponent extends AbstractPage
{
   @FindBy(css = "[class*=VoucherCode__signinButon]  [aria-label=button]")
   private WebElement AppliedvoucherCode;

   @FindBy(css = "[class*=VoucherCode__marginLeftICon] [class*=HighlightedLink__text]")
   private WebElement voucherRemoveButton;

   @FindBy(css = "[name='voucherCode']")
   private WebElement enterVoucherCode;

   public void getAppliedVoucherCodeElement()
   {
      WebElementTools.enterText(enterVoucherCode, "ABCD");
      WebElementTools.click(AppliedvoucherCode);
   }

   public boolean getVoucherRemoveButtonElement()
   {
      return WebElementTools.isPresent(voucherRemoveButton);
   }
}
