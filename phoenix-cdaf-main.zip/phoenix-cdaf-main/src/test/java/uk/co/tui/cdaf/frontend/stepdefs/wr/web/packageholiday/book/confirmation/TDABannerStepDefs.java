package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.confirmation;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.confirmation.TDABannerPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TDABannerStepDefs
{

   public final PackageNavigation packageNavigation;

   private final TDABannerPage tdaBannerPage;

   public TDABannerStepDefs()
   {
      tdaBannerPage = new TDABannerPage();
      packageNavigation = new PackageNavigation();
   }

   @Given("that a Customer has completed a booking")
   public void that_a_Customer_has_completed_a_booking()
   {
      packageNavigation.navigateToConfirmationPage();
   }

   @When("the Booking Confirmation Page is displayed")
   public void the_Booking_Confirmation_Page_is_displayed()
   {
      assertThat("TDA Banner Component is Not Displayed",
               tdaBannerPage.isTDABannerComponentDisplayed(), is(true));
   }

   @Then("a Banner showing information how to download the TUI app should be displayed below the What Happens Next section of the page")
   public void a_Banner_showing_information_how_to_download_the_TUI_app_should_be_displayed_below_the_What_Happens_Next_section_of_the_page()
   {
      assertThat("TDA Banner is Not Displayed", tdaBannerPage.isTDABannerDisplayed(), is(true));
   }

   @Given("the Booking Confirmation Page has been displayed")
   public void the_Booking_Confirmation_Page_has_been_displayed()
   {
      assertThat("TDA Banner Component is Not Displayed",
               tdaBannerPage.isTDABannerComponentDisplayed(), is(true));
   }

   @When("the TUI app promotion banner is displayed")
   public void the_TUI_app_promotion_banner_is_displayed()
   {
      assertThat("TDA Banner is Not Displayed", tdaBannerPage.isTDABannerDisplayed(), is(true));
   }

   @Then("the below Promotion Text should be displayed inline within the Banner component")
   public void the_below_Promotion_Text_should_be_displayed_inline_within_the_Banner_component()
   {
      assertThat("Text Content is Not Present", tdaBannerPage.isTextContentPresent(), is(true));
   }

   @Then("an image should be displayed inline within the Banner component")
   public void an_image_should_be_displayed_inline_within_the_Banner_component()
   {
      assertThat("Image is Not Present", tdaBannerPage.isImagePresent(), is(true));
   }

   @Given("that the Customer has scrolled to the TUI app promotion banner")
   public void that_the_Customer_has_scrolled_to_the_TUI_app_promotion_banner()
   {
      assertThat("TDA Banner Component is Not Displayed",
               tdaBannerPage.isTDABannerComponentDisplayed(), is(true));
   }

   @When("they view the banner")
   public void they_view_the_banner()
   {
      assertThat("TDA Banner is Not Displayed", tdaBannerPage.isTDABannerDisplayed(), is(true));
   }

   @Then("a QR code should be displayed embedded in the banner")
   public void a_QR_code_should_be_displayed_embedded_in_the_banner()
   {
      assertThat("QRCode is Not Present", tdaBannerPage.isQRPresent(), is(true));
   }

   @Given("that the customer has scrolled to the TUI app promotion banner section")
   public void that_the_customer_has_scrolled_to_the_TUI_app_promotion_banner_section()
   {
      assertThat("TDA Banner Component is Not Displayed",
               tdaBannerPage.isTDABannerComponentDisplayed(), is(true));
   }

   @When("they are viewing the TUI app promotion banner")
   public void they_are_viewing_the_TUI_app_promotion_banner()
   {
      assertThat("TDA Banner is Not Displayed", tdaBannerPage.isTDABannerDisplayed(), is(true));
   }

   @Then("a Google Play Store AND App Store icon should be displayed embedded in the banner")
   public void a_Google_Play_Store_AND_App_Store_icon_should_be_displayed_embedded_in_the_banner()
   {
      assertThat("App Store and Google Store icons are Not Present", tdaBannerPage.isIconsPresent(),
               is(true));
   }
}
