package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.CommissionMarkers;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.Assert.assertEquals;

public class DateFlexibilityStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageChoiceSearchDurationStepDefs.class);

   public final SearchResultsPage searchResultsPage;

   private final PageErrorHandler errorHandler;

   private final PackageNavigation packageNavigation;

   private final CommissionMarkers commissionMarkers;

   public DateFlexibilityStepDefs()
   {
      errorHandler = new PageErrorHandler();
      commissionMarkers = new CommissionMarkers();
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
   }

   @And("they have selected {string} Dagen flexibility for their departure date")
   public void they_have_selected_flexibility_for_their_departure_date(String flexible)
   {
      packageNavigation.navigateToflexibileSearchResultPage(flexible);
      searchResultsPage.searchPanelComponent.searchPanel.doSearch();
      errorHandler.isPageLoadingCorrectly();
   }

   @Given("they have selected {string} Flexibility for their departure date")
   public void they_have_selected_Flexibility_for_their_departure_date(String flexible)
   {
      packageNavigation.navigateToflexibileSearchResultPage(flexible);
      searchResultsPage.searchPanelComponent.searchPanel.doSearch();
      errorHandler.isPageLoadingCorrectly();
   }

   @Then("verify the build version")
   public void verify_the_build_version()
   {
      Date date = new Date();
      Object analytics = commissionMarkers.analyticsDetails("buildVersion");
      LOGGER.log(LogLevel.INFO, "Analytics LOGGER Info" + analytics);
      String[] splitValues = analytics.toString().split("-");
      String substring = splitValues[1].substring(0, splitValues[1].length() - 4);
      SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
      assertEquals(substring, formatter.format(date));
   }
}
