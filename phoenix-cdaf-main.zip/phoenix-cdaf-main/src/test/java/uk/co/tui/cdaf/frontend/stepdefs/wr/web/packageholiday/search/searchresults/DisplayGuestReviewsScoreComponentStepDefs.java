package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.hamcrest.Matchers;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class DisplayGuestReviewsScoreComponentStepDefs
{
   public final UnitDetailsPage unitDetailsPage = new UnitDetailsPage();

   private final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent;

   private final SearchPanelComponent searchPanelComponent;

   private final PackageNavigation packageNavigation;

   private final SearchResultsPage searchResultsPage;

   private String siteId;

   public DisplayGuestReviewsScoreComponentStepDefs()
   {
      departureAirportOrDestinationComponent =
               new DepartureAirportAndDestinationAndDatesComponent();
      searchPanelComponent = new SearchPanelComponent();
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
   }

   @Given("the {string} is on the search results page")
   public void the_is_on_the_search_results_page(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
      selectSearchCreteria();
   }

   @Given("the {string} is on the Search results page")
   public void the_is_on_the_Search_results_page(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
      selectSearchCreteria();
   }

   private void selectSearchCreteria()
   {
      departureAirportOrDestinationComponent.selectMFEDestinationListIcon();
      List<SelenideElement> availableCountries =
               departureAirportOrDestinationComponent.getMFEDestinationCountryListEnabled();
      WebElementTools.click(availableCountries.get(1));
      List<SelenideElement> availableDates = searchPanelComponent.selectAvailableDateMfe();
      WebElementTools.click(availableDates.get(0));
      searchPanelComponent.closeDepartureDate();
      searchPanelComponent.clickSearchBtn();
   }

   @When("they view a search results card where the backend has returned customer review data for the accommodation")
   public void they_view_a_search_results_card_where_the_backend_has_returned_customer_review_data_for_the_accommodation()
   {
      searchResultsPage.isGuestReviewDisplayed();
   }

   @Then("they shall see the guest reviews score component by the TUI rating")
   public void they_shall_see_the_guest_reviews_score_component_by_the_TUI_rating()
   {
      assertTrue("Guest review is not displayed", searchResultsPage.isGuestReviewDisplayed());

   }

   @Then("the guest reviews score component shall display the following:")
   public void the_guest_reviews_score_component_shall_display_the_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertTrue("Guest review is not displayed", searchResultsPage.isGuestReviewDisplayed());
   }

   @Then("total number of reviews shall be a hyperlink")
   public void total_number_of_reviews_shall_be_a_hyperlink()
   {

      assertTrue("Guest review link not found",
               searchResultsPage.isGuestReviewHyperLinkDisplayed());
   }

   @Then("the guest review translation shall display the following:")
   public void the_guest_review_translation_shall_display_the_following(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      siteId = getTestExecutionParams().getBrandStr();
      Map<String, String> matchingRow = dataTableTemp.stream()
               .filter(row -> row.get("Site").equals(siteId)).findFirst().orElseThrow(
                        () -> new IllegalArgumentException(
                                 "Cannot find expected strings for " + siteId));
      String expectedReviewTranslation = matchingRow.get("Review Translation");
      String actualeviewTranslation = searchResultsPage.getGuestReviewText().split(" ")[1];
      assertEquals("Guest Review title translation not found", actualeviewTranslation,
               expectedReviewTranslation);
   }

   @Given("the guest rating description is greater than or equal to {double}")
   public void the_guest_rating_description_is_greater_than_or_equal_to(double expectedRating)
   {
      double rating = searchResultsPage.getGuestReviewRating();
      assertThat("guest rating description is smaller then expected", expectedRating,
               Matchers.greaterThanOrEqualTo(rating));
   }

   @Then("the Guest rating description shall be populated as follows:")
   public void the_Guest_rating_description_shall_be_populated_as_follows(
            io.cucumber.datatable.DataTable dataTable)
   {

      String siteId = getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedRating = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("9")).findFirst().orElse(null);
      String expectedRating1 = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("7.5")).findFirst().orElse(null);
      String expectedRating6 = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("6")).findFirst().orElse(null);
      String expectedRating4 = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("4")).findFirst().orElse(null);
      String expectedRating0 = maps.stream().filter(row -> row.get("Site").equals(siteId))
               .map(row -> row.get("0")).findFirst().orElse(null);

      Double actualRating = searchResultsPage.getGuestReviewRating();
      if (actualRating >= 9)
      {
         assertEquals("guest rating translations is not matched ",
                  searchResultsPage.getGuestReviewDescription(), expectedRating);
      }
      else if (actualRating >= 7.5)
      {
         assertEquals("guest rating translations is not matched ",
                  searchResultsPage.getGuestReviewDescription(), expectedRating1);
      }
      else if (actualRating >= 6)
      {
         assertEquals("guest rating translations is not matched ",
                  searchResultsPage.getGuestReviewDescription(), expectedRating6);
      }
      else if (actualRating >= 4)
      {
         assertEquals("guest rating translations is not matched ",
                  searchResultsPage.getGuestReviewDescription(), expectedRating4);
      }
      else if (actualRating >= 0)
      {
         assertEquals("guest rating translations is not matched ",
                  searchResultsPage.getGuestReviewDescription(), expectedRating0);
      }
   }

   @When("they select the hyperlink within the guest reviews score component")
   public void they_select_the_hyperlink_within_the_guest_reviews_score_component()
   {
      searchResultsPage.selectGuestReviewHyperLink();
   }

   @Then("the customer shall be redirected to the Unit Details page")
   public void the_customer_shall_be_redirected_to_the_Unit_Details_page()
   {
      assertTrue(unitDetailsPage.isHotelDetailsPageDisplayed());
   }

   @Then("the customer shall be positioned to the top of the Guest Reviews tab section on the Unit Details page")
   public void the_customer_shall_be_positioned_to_the_top_of_the_Guest_Reviews_tab_section_on_the_Unit_Details_page()
   {
      assertTrue("Guest Review tab is not displayed", unitDetailsPage.isGuestReviewTabPositioned());

   }

   @Then("the Guest Reviews tab shall be set to selected state")
   public void the_Guest_Reviews_tab_shall_be_set_to_selected_state()
   {
      assertTrue("Guest Review tab is not displayed", unitDetailsPage.isGuestReviewTabPositioned());
   }

   @Then("the Guest Reviews tab shall expand to display the guest reviews content")
   public void the_Guest_Reviews_tab_shall_expand_to_display_the_guest_reviews_content()
   {
      assertTrue("Guest Review tab is not displayed", unitDetailsPage.isGuestReviewDisplayed());

   }
}