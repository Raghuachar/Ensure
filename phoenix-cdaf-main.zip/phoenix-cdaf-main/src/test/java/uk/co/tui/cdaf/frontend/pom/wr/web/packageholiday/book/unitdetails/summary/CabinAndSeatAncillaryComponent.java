package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import com.codeborne.selenide.Condition;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.CabinAndSeatTypeComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import java.util.HashMap;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.refresh;

public class CabinAndSeatAncillaryComponent extends CabinAndSeatTypeComponent
{

   private static final double DELTA = 0.01;

   private final AutomationLogManager LOGGER = new AutomationLogManager(
            LuggageAncillaryComponent.class);

   public final ProgressionbarNavigationComponent progressbarComponent;

   private final ThreadLocal<Double> totalPrice = new ThreadLocal<>();

   private final Map<String, WebElement> cabinMap;

   public CabinAndSeatAncillaryComponent()
   {
      cabinMap = new HashMap<>();
      progressbarComponent = new ProgressionbarNavigationComponent();
   }

   public Map<String, WebElement> getCabinComponents()
   {
      cabinMap.put("YOUR CABIN CLASS & UPGRADES", cabinClassHeading);
      cabinMap.put("Cabin Class Upgrade description", upgradeCabinDesc);
      cabinMap.put("Upgrade Cabin Class", upgradeCabinType);
      cabinMap.put("Upgrade Cabin listed USPs", upgradeCabinUsps);
      cabinMap.put("Cabin Class specific T&Cs link", cabinTypeTNCLink);
      cabinMap.put("Default Economy Cabin Class", economyCabinTypeTitle);
      return cabinMap;
   }

   public void addComfortSeats()
   {
      totalPrice.set(progressbarComponent.getTotalPriceDoubleValue());
      Double newTotalPrice = setNewPriceAfterComfSeatsAdded();
      waitForPriceUpdate(newTotalPrice);
   }

   private Double setNewPriceAfterComfSeatsAdded()
   {
      $("[aria-label='COM_SEAT']").shouldBe(Condition.visible).click();
      return progressbarComponent.getTotalPriceDoubleValue();
   }

   private void waitForPriceUpdate(Double newTotalPrice)
   {
      if ((newTotalPrice - totalPrice.get()) < DELTA)
      {
         LOGGER.log(LogLevel.INFO, "Waiting for the total price to be updated...");
         refresh();
      }
   }

}
