package uk.co.tui.cdaf.frontend.pom.nordics.web.beach_holiday.bookflow.passenger_details;

public class NordicPassengerForm
{

   String address1;

   String city;

   String post;

   String email;

   String fName;

   String lName;

   String houseNum;

   String busNum;

   public NordicPassengerForm()
   {
      address1 = "Address Line 1";
      city = "Luton";
      post = "1234";
      email = "ananthreddy.s@sonata-software.com";
      fName = "sonata";
      lName = "software";
      houseNum = "10";
      busNum = "5";
   }

   public NordicPassengerForm setAdress1(String address1)
   {
      this.address1 = address1;
      return this;
   }

   public NordicPassengerForm setEmail(String email)
   {
      this.email = email;
      return this;
   }

   public NordicPassengerForm setfName(String fName)
   {
      this.fName = fName;
      return this;
   }

   public NordicPassengerForm setLastName(String lName)
   {
      this.lName = lName;
      return this;
   }

   public NordicPassengerForm setBus(String busNum)
   {
      this.busNum = busNum;
      return this;
   }

}
