package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.browse.homepage.searchPanel;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TUIWRSearchPanelErrorMessagesStepDefs
{
   private final FlightOnlyHomePage homepage;

   public TUIWRSearchPanelErrorMessagesStepDefs()
   {
      homepage = new FlightOnlyHomePage();
   }

   @Given("has not selected an airport in the fly from field")
   public void has_not_selected_an_airport_in_the_fly_from_field()
   {
      homepage.setDefaultSearchPanelFieldState("Departure Airport");
   }

   @When("a customer clicks on {string}")
   public void a_customer_clicks_on(String string)
   {
      homepage.submitSearchPanel();
   }

   @Then("the customer is presented with the following message {string}")
   public void the_customer_is_presented_with_the_following_message(String string)
   {
      assertThat("customer is presented with " + string + " message",
               homepage.errorMessagesAreShown(), is(true));
   }

   @Then("the fly from field will be highlighted red")
   public void the_fly_from_field_will_be_highlighted_red()
   {
      assertThat("fly from field is highlighted red",
               homepage.searchPanelFieldColor("Departure Airport"), is(true));
   }

   @Then("the SEARCH button will be disabled")
   public void the_SEARCH_button_will_be_disabled()
   {
      assertThat("SearchButton is Disabled",
               homepage.validateSearchPanelSubmitButton(), is(false));
   }

   @Given("has not selected an airport in the fly to field")
   public void has_not_selected_an_airport_in_the_fly_to_field()
   {
      homepage.setDefaultSearchPanelFieldState("Destination Airport");
   }

   @Then("the fly to field will be highlighted red")
   public void the_fly_to_field_will_be_highlighted_red()
   {
      assertThat("fly to field is highlighted red",
               homepage.searchPanelFieldColor("Destination Airport"), is(true));
   }

   @Given("has not selected a date in the Departing field")
   public void has_not_selected_a_date_in_the_Departing_field()
   {
      homepage.setDefaultSearchPanelFieldState("Departure Date");
   }

   @Then("the departing field will be highlighted red")
   public void the_departing_field_will_be_highlighted_red()
   {
      assertThat("Departure date field is highlighted red",
               homepage.searchPanelFieldColor("Departure Date"), is(true));
   }

   @Given("has not selected a date in the Returning field")
   public void has_not_selected_a_date_in_the_Returning_field()
   {
      homepage.setDefaultSearchPanelFieldState("Return Date");
   }

   @Then("the returning field will be highlighted red")
   public void the_returning_field_will_be_highlighted_red()
   {
      assertThat("Returning date field is highlighted red",
               homepage.searchPanelFieldColor("Return Date"), is(true));
   }

}
