package uk.co.tui.cdaf.frontend.pom.wr.search.components.suggestion;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.Destination;
import uk.co.tui.cdaf.frontend.pom.wr.search.components.destination.DestinationMfe;

import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;

public class DestinationSuggestionMfe implements DestinationSuggestion
{
   private static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   private SelenideElement dropdown;

   public SelenideElement container()
   {
      if (dropdown == null)
      {
         dropdown = $(shadowDeepCss("div.suggestionWrapper"));
      }
      dropdown.should(appear, WAIT_TIMEOUT);
      return dropdown;
   }

   public List<SelenideElement> getAllSuggestionElements()
   {
      return container().$("div.options").$$("a").asDynamicIterable().stream()
               .collect(Collectors.toList());
   }

   public SelenideElement getSearchAllDestinationBtn()
   {
      return container().$("div.footer").$("a.primary");
   }

   public Destination clickAllDestinationBtn()
   {
      getSearchAllDestinationBtn().click();
      return new DestinationMfe();
   }

   public SelenideElement getNoMatchElement()
   {
      return container().$(".noMatch").$(".label");
   }

   public void selectSuggestionFromList(String suggestion)
   {
      container().$(".header").should(Condition.visible, WAIT_TIMEOUT);
      getAllSuggestionElements().stream().filter(el -> el.getText().contains(suggestion))
               .findFirst().orElseThrow().click();
   }
}
