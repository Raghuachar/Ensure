package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.flightoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class FlightPageStepDefs
{
   public static String totalPrice;

   private final WebElementWait wait;

   private final FlightOptionsPage flightOptionsPage;

   private final FlightOnlyPageNavigation flightNavigation;

   public FlightPageStepDefs()
   {
      wait = new WebElementWait();
      flightOptionsPage = new FlightOptionsPage();
      flightNavigation = new FlightOnlyPageNavigation();
   }

   @And("the following components should be displayed on flight page")
   public void the_following_components_should_be_displayed_on_flight_page(List<String> components)
   {
      wait.forJSExecutionReadyLazy();
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element =
                     flightOptionsPage.getFlightComponents().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });

   }

   @When("they click on continue button in flight page")
   public void they_click_on_continue_button_in_flight_page()
   {
      totalPrice = flightNavigation.flightOptionsPage.summaryPanelComponent.getTotalPriceValue();
      flightOptionsPage.clickOnContinue();
      flightNavigation.searchPanelComponent.closePrivacyPopUp();
   }

   @And("Compare search results values with flights option page values")
   public void compare_search_results_values_with_flights_option_page_values()
   {
      Map<String, String> searchValue = searchStoreValues.getSearchValues();
      flightOptionsPage.flightSummaryOpen();
      String flightValue;
      flightValue = flightOptionsPage.flightsSummaryDetails("first");
      assertThat("Total price error message is not matched",
               searchValue.get("Total_Price").trim().equalsIgnoreCase(flightValue), is(true));
      flightValue = flightOptionsPage.flightsSummaryDetails("second");
      assertThat("Pax error message is not matched",
               searchValue.get("PAX").trim().equalsIgnoreCase(flightValue), is(true));
      flightOptionsPage.flightSummaryClose();
   }
}
