package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.DurationFilterComponent;
import uk.co.tui.cdaf.utils.ConfigurationHelper;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class DurationFilterComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public DurationFilterComponent durationFilter;

   public DurationFilterComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      durationFilter = new DurationFilterComponent();
   }

   @When("they are viewing the Dates & Duration Filter")
   public void they_are_viewing_the_Dates_Duration_Filter()
   {
      assertThat("NOt able to view destination filter",
               durationFilter.isDatesAndDurationFilterDisplayed(), is(true));
   }

   @Then("they will see the following that they can filter by")
   public void they_will_see_the_following_that_they_can_filter_by(List<String> headerList)
   {
      for (String headerString : headerList)
      {
         if (headerString.equals("Duration"))
         {
            assertThat("Duration Filter not displayed",
                     durationFilter.isDurationFilterDisplayed(), is(true));
         }
      }
   }

   @Then("the following <item> will be selected by <default>")
   public void the_following_item_will_be_selected_by_default(
            io.cucumber.datatable.DataTable dataTable)
   {
      Map<String, String> data = dataTable.asMap(String.class, String.class);
      assertThat("Specific default duration filter is selected",
               durationFilter.isDefaultDurationSelected("7"), is(true));
      assertThat("Specific date filter not displayed", durationFilter.isAllDatesFilterDisplayed(),
               is(true));
   }

   @When("they view the number of nights available")
   public void they_view_the_number_of_nights_available()
   {
      assertThat("Specific selected duration filter is selected",
               durationFilter.isSelectedDurationSelected("7"), is(true));
   }

   @When("they select Duration")
   public void they_select_Duration()
   {
      assertThat("Specific selected duration filter is selected",
               durationFilter.isSelectedDurationSelected("7"), is(true));
   }

   @Then("the duration they selected in their search will be in a selected state")
   public void the_duration_they_selected_in_their_search_will_be_in_a_selected_state()
   {
      durationFilter.isMaxDurationSelectable();
   }

   @Then("they will be able to select a max of one from each filter")
   public void they_will_be_able_to_select_a_max_of_one_from_each_filter()
   {
      durationFilter.isMaxDurationSelectable();
   }

   @Given("the {string} is on the package search results page on a mobile device")
   public void the_is_on_the_package_search_results_page_on_a_mobile_device(String string)
   {
      if (StringUtils.containsIgnoreCase(ConfigurationHelper.getBrowserDetails(), "mobile"))
      {
         packageNavigation.navigateToSearchResultPage();
      }
   }

   @Given("they have selected the Dates & Duration filter")
   public void they_have_selected_the_Dates_Duration_filter()
   {
      durationFilter.selectMobileDurationFilter();
   }

   @When("they view the number of nights available within the modal")
   public void they_view_the_number_of_nights_available_within_the_modal()
   {
      assertThat("Number of nights is visible", durationFilter.durationListViewable(), is(true));
   }

   @Then("they will be based on what <duration> has been selected during the search")
   public void they_will_be_based_on_what_duration_has_been_selected_during_the_search()
   {
      assertThat("Specific selected duration filter is selected",
               durationFilter.isDefaultDurationSelectedMobile("7"), is(true));
   }

   @Then("they will see <nights>")
   public void they_will_see_nights(Map<String, String> dataTable)
   {
      assertThat("Specific duration filter has proper nights",
               durationFilter.isNightsVisible("5", dataTable), is(true));
   }

}
