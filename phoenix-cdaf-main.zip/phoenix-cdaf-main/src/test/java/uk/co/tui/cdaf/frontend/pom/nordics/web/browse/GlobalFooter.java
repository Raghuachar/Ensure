package uk.co.tui.cdaf.frontend.pom.nordics.web.browse;

import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import static com.codeborne.selenide.Selenide.$;

public class GlobalFooter extends AbstractPage
{
   public boolean navStructure()
   {
      return $(".GlobalFooter__mediaSection.component").isDisplayed();
   }
}
