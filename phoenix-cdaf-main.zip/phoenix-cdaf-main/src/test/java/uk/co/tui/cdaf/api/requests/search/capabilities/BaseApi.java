package uk.co.tui.cdaf.api.requests.search.capabilities;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.Level;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.api.pojo.search.base.Airport;
import uk.co.tui.cdaf.api.pojo.search.mfe.Destination;
import uk.co.tui.cdaf.api.requests.search.parameters.SearchParameters;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

class BaseApi
{

   static final ObjectMapper objectMapper = new ObjectMapper();

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(BaseApi.class);

   private static final String SUGGESTIONS = "suggestions";

   private static final String FROM_PARAMETER = "from";

   private static final String TO_PARAMETER = "to";

   private static final String MARKET_PARAMETER = "market";

   private static final String LANGUAGE_PARAMETER = "language";

   private static final String DURATION_PARAMETER = "duration";

   private static final String FLEXIBLE_DAYS_PARAMETER = "flexibleDays";

   private static final String WHEN_PARAMETER = "when";

   public static final String BRAND_PARAMETER = "brand";

   @NotNull
   static Response makeGetRequest(Map<String, Object> parameters, SearchParameters searchParameters,
            String endpoint)
   {
      RestAssured.baseURI = searchParameters.baseApiUrl();
      RequestSpecification request = RestAssured.given();

      parameters.forEach((key, value) ->
      {
         if (value instanceof List)
         {
            List<?> list = (List<?>) value;
            if (!list.isEmpty())
            {
               list.forEach(item ->
               {
                  if (FROM_PARAMETER.equals(key))
                  {
                     Airport destination = (Airport) item;
                     request.queryParam(key + "[]", destination.getId());
                  }
                  else if (TO_PARAMETER.equals(key))
                  {
                     Destination destination = (Destination) item;
                     request.queryParam(key + "[]",
                              destination.getId() + ":" + destination.getType());
                  }
               });
            }
         }
         else if (value != null)
         {
            request.queryParam(key, value);
         }
      });

      if (!ExecParams.isDevEnv() && !ExecParams.isStngEnv())
         request.param("brand", parameters.get(BRAND_PARAMETER));
      if (LOGGER.isLogLevel(Level.DEBUG))
      {
         request.log().uri();
      }

      Response response = request.when().get(searchParameters.getApiVersion() + endpoint);
      assertThat("Unable to get response from " + endpoint.toUpperCase() + " API\n"
                        + response.body().prettyPrint(), response.getStatusCode(),
               allOf(lessThan(500), greaterThanOrEqualTo(200)));
      return response;
   }

   @NotNull
   static Response getSuggestionsResponse(String searchKey, SearchParameters searchParameters)
   {
      Map<String, Object> parameters = new HashMap<>();
      parameters.put(MARKET_PARAMETER, searchParameters.getMarketParams());
      parameters.put(LANGUAGE_PARAMETER, searchParameters.getLanguageParams());
      parameters.put(BRAND_PARAMETER, searchParameters.getBrandParams());
      parameters.put("searchKey", searchKey);

      Response response = makeGetRequest(parameters, searchParameters, SUGGESTIONS);
      response.then().statusCode(200);
      return response;
   }

   @NotNull
   static Response getCapabilitiesResponse(SearchParameters searchParameters, String apiDirectory)
   {
      Map<String, Object> parameters = new HashMap<>();
      parameters.put(MARKET_PARAMETER, searchParameters.getMarketParams().toString().toLowerCase());
      parameters.put(LANGUAGE_PARAMETER,
               searchParameters.getLanguageParams().toString());
      parameters.put(DURATION_PARAMETER, searchParameters.getDurationParams().getValue());
      parameters.put(FLEXIBLE_DAYS_PARAMETER, searchParameters.getFlexibleDays());
      parameters.put(WHEN_PARAMETER, searchParameters.getWhenDateTime());
      parameters.put(FROM_PARAMETER, searchParameters.getAvailableAirports());
      parameters.put(TO_PARAMETER, getAllDestinations(searchParameters));
      parameters.put(BRAND_PARAMETER, searchParameters.getBrandParams());

      return makeGetRequest(parameters, searchParameters, apiDirectory);
   }

   private static List<Destination> getAllDestinations(SearchParameters searchParameters)
   {
      List<Destination> availableDestinations = searchParameters.getAvailableDestinations();
      List<Destination> suggestions = searchParameters.getSuggestion();

      List<Destination> mergedList = new ArrayList<>();
      if (availableDestinations != null)
      {
         mergedList.addAll(availableDestinations);
      }
      if (suggestions != null)
      {
         mergedList.addAll(suggestions);
      }
      return mergedList;
   }

}
