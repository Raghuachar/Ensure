package uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.book.flightoptions;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class FlightOptionsExtraSpaceSeatComponent extends AbstractPage
{

   WebElementWait wait;

   @FindBy(css = ".View3__confirmationContent span")
   private WebElement seatModalContent;

   @FindBy(css = ".components__close svg")
   private WebElement closeBtn;

   @FindBy(css = "[aria-label='action apply']")
   private WebElement cancelBtn;

   public FlightOptionsExtraSpaceSeatComponent()
   {
      super();
      wait = new WebElementWait();
   }

   public boolean isModalContentDisplayed()
   {
      return WebElementTools.isPresent(seatModalContent);
   }

   public void closeModal(WebElement modalElement)
   {
      WebElementTools.click(modalElement);
   }

   public WebElement getModalComponents(String modaleSelection)
   {
      if (StringUtils.containsIgnoreCase(modaleSelection, "X CTA"))
      {
         return closeBtn;
      }
      else if (StringUtils.containsIgnoreCase(modaleSelection, "Cancel CTA"))
      {
         return cancelBtn;
      }
      return null;
   }
}
