package uk.co.tui.cdaf.frontend.pom.wr.search.components.wrappers;

import com.codeborne.selenide.SelenideElement;
import lombok.Getter;

import java.time.Duration;

import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;

@Getter
public class ComponentWrappersLegacy implements ComponentWrappers
{
   public static final Duration DURATION_5_SEC = Duration.ofSeconds(5);

   final SelenideElement airportWrapper =
            $(shadowDeepCss(".Package__airports, .SearchPanel__airports, .Search__airports"));

   final SelenideElement destinationWrapper =
            $(shadowDeepCss(
                     ".Package__destinations, .SearchPanel__destinations, .Search__destinations"));

   final SelenideElement departureWrapper =
            $(shadowDeepCss(".Package__date, .SearchPanel__date, .Search__date"));

   final SelenideElement durationWrapper =
            $(shadowDeepCss(".Package__duration, .SearchPanel__duration, .Search__duration"));

   final SelenideElement paxAndRoomsWrapper =
            $(shadowDeepCss(".Package__passengers, .SearchPanel__passengers, .Search__passengers"));

   final SelenideElement searchButtonWrapper =
            $(shadowDeepCss(
                     ".Package__searchButton, .SearchPanel__searchButton, .Search__searchButton"));
}
