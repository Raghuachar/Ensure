package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageBankingAndReconciliationRestrictionStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   public final PackageNavigation fonavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageBankingAndReconciliationRestrictionStepDefs()
   {
      fonavigation = new PackageNavigation();
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("that the TUI Shop Agent is viewing the TUI Global header")
   public void that_the_TUI_Shop_Agent_is_viewing_the_TUI_Global_header()
   {
      packagenavigation.retailLoginFO();
      assertThat(" Global Header is present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(false));
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickAgentLink();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.enterAgentAbtaCredentailsTuiShopAgent();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnAgentSearchButton();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnOnlineTravelAgent();

   }

   @When("they view the Admin link")
   public void they_view_the_Admin_link()
   {
      pKgReconcilationPaymentPageComponents.clickAdminTab();
   }

   @Then("they can see the link to Banking & Reconciliation")
   public void they_can_see_the_link_to_Banking_Reconciliation()
   {
      assertThat("Banking and Reconcilaition is present",
               pKgReconcilationPaymentPageComponents.isBankingAndReconciliationLinkPresent(),
               is(true));
   }

   @Given("that the OTA Agent is viewing the TUI Global header")
   public void that_the_OTA_Agent_is_viewing_the_TUI_Global_header()
   {
      packagenavigation.retailLoginFO();
      assertThat(" Global Header is present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickAgentLink();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.enterAgentAbtaCredentailsThreePA();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnAgentSearchButton();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnOnlineTravelAgent();

   }

   @Then("they cannot view the link to Banking & Reconciliation")
   public void they_cannot_view_the_link_to_Banking_Reconciliation()
   {
      pKgReconcilationPaymentPageComponents.clickAdminTab();
      assertThat("Banking and Reconcilaition is not present",
               pKgReconcilationPaymentPageComponents.isBankingAndReconciliationLinkPresent(),
               is(false));
   }

   @Given("that the ThreePA Agent is viewing the TUI Global header")
   public void that_the_ThreePA_Agent_is_viewing_the_TUI_Global_header()
   {
      packagenavigation.retailLoginFO();
      assertThat(" Global Header is present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickAgentLink();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.enterAgentAbtaCredentailsThreePA();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnAgentSearchButton();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnOnlineTravelAgent();

   }

   @Given("that the Direct Billing Agent is viewing the TUI Global header")
   public void that_the_Direct_Billing_Agent_is_viewing_the_TUI_Global_header()
   {
      packagenavigation.retailLoginFO();
      assertThat(" Global Header is present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickAgentLink();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.enterAgentAbtaCredentailsDirectBilling();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnAgentSearchButton();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnOnlineTravelAgent();

   }

   @Given("that the CSC Agent is viewing the TUI Global header")
   public void that_the_CSC_Agent_is_viewing_the_TUI_Global_header()
   {
      packagenavigation.retailLoginFO();
      assertThat(" Global Header is present",
               pKgReconcilationPaymentPageComponents.isGlobalHeaderIsPresent(), is(true));
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickAgentLink();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.enterAgentAbtaCredentailsCsc();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnAgentSearchButton();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickOnOnlineTravelAgent();
      wait.forJSExecutionReadyLazy();

   }
}	
