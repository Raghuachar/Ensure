package uk.co.tui.cdaf.frontend.pom.wr.search.components.destination;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.PendingException;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

import java.time.Duration;
import java.util.List;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class DestinationLegacy extends DestinationMfe
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(DestinationLegacy.class);
   private static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   private SelenideElement dropdown;

   private SelenideElement container()
   {
      if (dropdown == null)
      {
         dropdown = $("section[aria-label='destinations'].DropModal__dropdown");
      }
      dropdown.should(appear, WAIT_TIMEOUT);
      return dropdown;
   }

   @Override
   public boolean isOpen()
   {
      SelenideElement container = container();
      return container.isDisplayed();
   }

   public DestinationLegacy clearSelection()
   {
      container().$("a.DropModal__clear").should(appear, WAIT_TIMEOUT)
               .click();
      return this;
   }

   public DestinationLegacy selectDestinationFromList(String regionName, String resortName)
   {
      container().$(byText(regionName))
               .should(visible, WAIT_TIMEOUT);
      if (resortName == null || resortName.isEmpty())
      {
         _selectFullRegion(regionName);
      }
      else
      {
         _selectResort(regionName, resortName);
      }
      return this;
   }

   public Destination selectAllResort(String regionName, List<String> resortNames)
   {
      openRegionView(regionName);
      for (String resortName : resortNames)
      {
         SelenideElement resortEl = container().$(byText(resortName))
                  .should(visible, WAIT_TIMEOUT);

         SelenideElement checkbox = resortEl.parent().$("input");
         if (!checkbox.isSelected())
            resortEl.click();
      }
      return this;
   }

   @Override
   public ElementsCollection getAllCountryDestinations()
   {
      container().$("ul.DestinationsList__destinationListStyle")
               .should(visible, WAIT_TIMEOUT);
      return container().$$(".DestinationsList__link")
               .filterBy(not(cssClass("DestinationsList__disabled")));
   }

   @Override
   public Destination selectRandomDestination()
   {
      ElementsCollection allCountryDestinations = getAllCountryDestinations();
      int index = (int) (Math.random() * allCountryDestinations.size());
      LOGGER.log(
               "Selecting destination by index: " + index + " from " + allCountryDestinations.size() + " destinations");
      String regionTitle = allCountryDestinations.get(index).getText();
      _selectFullRegion(regionTitle);
      return this;
   }

   @Override
   public SelenideElement getCheckBoxSelected()
   {
      throw new PendingException("Method not implemented for legacy search panel");
   }

   public ElementsCollection dismissibleTagsDestinations()
   {
      throw new PendingException("Method not implemented for legacy search panel");
   }

   public void confirmSelection()
   {
      ElementsCollection applyBtn = $$("button.DropModal__apply");
      applyBtn.asDynamicIterable().stream()
               .filter(SelenideElement::isDisplayed).findFirst().orElseThrow().click();
      Selenide.Wait().until(driver ->
      {
         List<SelenideElement> el = applyBtn.filter(visible);
         return el.isEmpty();
      });
   }

   private void _selectFullRegion(String regionName)
   {
      openRegionView(regionName);
      container().$(".DestinationsList__parentCheckbox").click();
   }

   private void openRegionView(String regionName)
   {
      container().$(".DestinationsList__destinationListStyle").$(byText(regionName)).click();
   }

   private void _selectResort(String regionName, String resortName)
   {
      openRegionView(regionName);
      container().$(byText(resortName)).click();
   }
}
