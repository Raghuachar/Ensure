package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.Arrays;
import java.util.List;

public class BoardBasisComponent extends AbstractPage
{

   public final WebElementWait wait;

   @FindBy(css = "div[class='BoardUpgrades__boardUpgradeTitle'] svg")
   private WebElement boardBasisIcon;

   @FindBy(css = "div[class='BoardUpgrades__boardUpgradeTitle'] span")
   private WebElement boardBasisTitle;

   @FindBy(css = "[class='BoardUpgrades__boardContainer']")
   private WebElement boardBasisCards;

   @FindBy(css = ".BoardUpgrades__totalPrice")
   private List<WebElement> boardBasisUpgrades;

   @FindBy(css = ".BoardUpgrades__boardUpgradeContainer")
   private WebElement boardBasisComponent;

   @FindBy(xpath = "//*[contains(@class, '__selectBoardButton')]")
   private List<WebElement> alternativeBoardBasis;

   @FindBy(xpath = "//*[contains(@class, '__labelSelected')]")
   private WebElement boardUgradeLabelSelected;

   @FindBy(css = "[aria-label='pricePanel total price']")
   private WebElement totalPrice;

   @FindBy(xpath = "//span[@class=\"ProgressbarNavigation__ppPart1\"]")
   private WebElement perPersonPrice;

   @FindBy(xpath = "//*[contains(@class,'__priceContainer')]")
   private List<WebElement> boardBasisPrice;

   @FindAll({
            @FindBy(xpath = "//div[@class='BoardOptionsV2__boardSelected']/../../..//span[@aria-label='board name']"),
            @FindBy(xpath = "//div[@class='BoardUpgradesWR__labelSelected']/../..//div[@class='BoardUpgradesWR__boardName']") })
   private WebElement boardUpgradesTitle;

   @FindBy(css = "[class='RoomAndBoard__changeRoomLink'] a span")
   private WebElement roomAndBoardLink;

   @FindBy(css = ".BackToYourHolidayLinkComponent__continue a")
   private WebElement backToYourHoildayLink;

   @FindBy(css = ".BackToPreviousPageLink__componentWrapper a")
   private WebElement backToPreviousPageLink;

   @FindBy(css = " a.BoardUpgrades__toggleDescriptionLink")
   private WebElement boardBasisShoworeLink;

   @FindBy(css = "div[aria-label='overlay open'] section.popups__modalBody header h4")
   private WebElement boardDetailsmodal;

   @FindBy(css = " div[aria-label='overlay open'] section.popups__modalBody header span")
   private WebElement boardDetailsmodalxicon;

   @FindBy(xpath = "//a//i[@class='BoardUpgrades__toggleDescriptionLinkIcon BoardUpgrades__expanded']")
   private WebElement boardCardShallExpand;

   @FindBy(xpath = "//p[@class='BoardUpgrades__boardDescription']/span/div")
   private WebElement boardCardShall;

   @FindBy(css = "BoardUpgradesWR__boardCard BoardUpgradesWR__selected")
   private WebElement boardBasisCard;

   @FindBy(css = "BoardUpgradesWR__boardName")
   private WebElement boardBasisName;

   public BoardBasisComponent()
   {
      wait = new WebElementWait();
   }

   public boolean boardBasisIconIsPresent()
   {
      return WebElementTools.isPresent(boardBasisIcon);
   }

   public boolean boardBasisTitleIsPresent()
   {
      return WebElementTools.isPresent(boardBasisTitle);
   }

   public boolean boardBasisCardsIsPresent()
   {
      return WebElementTools.isPresent(boardBasisCards);
   }

   public void getBoardBasisUpgrades()
   {
      Arrays.sort(boardBasisUpgrades.toArray());
   }

   public boolean isBoardBasisComponentDisplayed()
   {
      return WebElementTools.isPresent(getBoardBasisComponent());
   }

   public WebElement getBoardBasisComponent()
   {
      return wait.getWebElementWithLazyWait(boardBasisComponent);
   }

   public String isAlternativeBoardBasisDisplayed()
   {
      return WebElementTools.getElementText(alternativeBoardBasis.get(0));
   }

   public void clickOnAlternativeBoardBasis()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(alternativeBoardBasis.get(0));
      WebElementTools.mouseOverAndClick(alternativeBoardBasis.get(0));
   }

   public boolean isboardUgradeLabelSelectedDisplayed()
   {
      return WebElementTools.isPresent(getboardUgradeLabelSelected());
   }

   public WebElement getboardUgradeLabelSelected()
   {
      return wait.getWebElementWithLazyWait(boardUgradeLabelSelected);
   }

   public String getTotalPriceText()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(totalPrice);
   }

   public String getBoardBasisPriceText()
   {
      return WebElementTools.getElementText(boardBasisPrice.get(0));
   }

   public String getBoardUpgradesBoardNameText()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(boardUpgradesTitle);
   }

   public void clickOnRoomAndBoardLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(roomAndBoardLink);
      WebElementTools.mouseOverAndClick(roomAndBoardLink);
   }

   public void clickOnBackToYourHoildayLink()
   {
      WebElementTools.click(backToYourHoildayLink);
   }

   public void clickOnBackToPreviousPageLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(backToPreviousPageLink);
      WebElementTools.mouseOverAndClick(backToPreviousPageLink);
   }

   public String getPerPersonPriceText()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(perPersonPrice);
   }

   public boolean isBoardBasisShoworeLinkDisplayed()
   {
      return WebElementTools.isPresent(boardBasisShoworeLink);
   }

   public void clickOnBoardBasisShoworeLink()
   {
      WebElementTools.click(boardBasisShoworeLink);
   }

   public void clickOnBoardBasisShowLessLink()
   {
      if (WebElementTools.isPresent(boardCardShallExpand))
      {
         WebElementTools.click(boardBasisShoworeLink);
      }
   }

   public boolean isBoardDetailsModalDisplayed()
   {
      return WebElementTools.isPresent(boardDetailsmodal);
   }

   public void clickOnBoardDetailsModalCloseX()
   {
      WebElementTools.click(boardDetailsmodalxicon);
   }

   public boolean isBoardBasisCardDisplayed()
   {
      return WebElementTools.isPresent(boardBasisCard);
   }

   public boolean isBoardCardShallExpanded()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(boardCardShallExpand);
   }

   public boolean isBoardBasisShallDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(boardCardShall);
      return WebElementTools.isPresent(boardCardShall);
   }

   public boolean boardBasisCardComponents()
   {
      return WebElementTools.isPresent(boardBasisName) && WebElementTools.isPresent(boardBasisCards)
               && WebElementTools.isPresent(boardBasisShoworeLink)
               && WebElementTools.isPresent(boardUgradeLabelSelected);

   }
}
