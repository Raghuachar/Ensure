package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.unit_details.AccommodationInfoPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchpanel.DepartureAirportAndDestinationAndDatesComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.DestinationFilterComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageRegionSearchResultsAndUnitDetailsStepDefs
{

   public final DepartureAirportAndDestinationAndDatesComponent
            departureAirportOrDestinationComponent;

   public final PackageNavigation packageNavigation;

   public final DestinationFilterComponent destinationFilterComponent;

   private final SearchResultsPage searchResultsPage;

   private final AccommodationInfoPage unitDetailsaccommodation;

   private final PageErrorHandler errorHandler;

   private final Map<String, WebElement> searchMap;

   private final WebElementWait wait;

   public PackageRegionSearchResultsAndUnitDetailsStepDefs()
   {
      searchResultsPage = new SearchResultsPage();
      unitDetailsaccommodation = new AccommodationInfoPage();
      errorHandler = new PageErrorHandler();
      wait = new WebElementWait();
      searchMap = new HashMap<>();
      departureAirportOrDestinationComponent =
               new DepartureAirportAndDestinationAndDatesComponent();
      packageNavigation = new PackageNavigation();
      destinationFilterComponent = new DestinationFilterComponent();
   }

   @Given("they're reviewing a search card that has region level in the geo-tree")
   public void they_re_reviewing_a_search_card_that_has_region_level_in_the_geo_tree()
   {
      assertThat("Region is not displayed",
               searchResultsPage.searchResultComponent.getSearchCardWithRegion(searchMap),
               is(true));
   }

   @Given("they select that package")
   public void they_select_that_package()
   {
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent
               .selectSpecificResultCard(searchMap.get("Hotel Name").getText());
      errorHandler.isPageLoadingCorrectly();
   }

   @When("they review geo-tree structure on the unit details page, below the hotel\\/resort name")
   public void they_review_geo_tree_structure_on_the_unit_details_page_below_the_hotel_resort_name()
   {
      assertThat("Location component is not displayed",
               unitDetailsaccommodation.getLocation().isDisplayed(), is(true));
   }

   @Then("they can see the region name displayed in the following order")
   public void they_can_see_the_region_name_displayed_in_the_following_order(
            io.cucumber.datatable.DataTable dataTable)
   {
      String expectedLocationNameString =
               unitDetailsaccommodation.getExpectedLocationNameString(dataTable);
      String actualLocationNameString = unitDetailsaccommodation.getActualLocationNameString();
      assertThat("Location was not presented correctly", actualLocationNameString,
               Matchers.equalToIgnoringCase(expectedLocationNameString));
   }

   @And("they are on the search results page with results that include regions with child destinations")
   public void they_are_on_the_search_results_page_with_results_that_include_regions_with_child_destinations()
   {
      departureAirportOrDestinationComponent.verifyingRegionDestination();
   }

   @When("they review the search cards")
   public void they_review_the_search_cards()
   {
      assertThat("the selected destinations are not in order ",
               departureAirportOrDestinationComponent.verifyingSearchCard(), is(true));
   }

   @Then("they can see the region child destination names displayed in the geo-tree")
   public void they_can_see_the_region_child_destination_names_displayed_in_the_geo_tree()
   {
      assertThat("Region is not displayed",
               searchResultsPage.searchResultComponent.getSearchCardWithRegion(searchMap),
               is(true));
   }

   @When("they free type search at least three characters for a region OR child destination \\(e.g Canary Islands, or Tenerife)")
   public void they_free_type_search_at_least_three_characters_for_a_region_OR_child_destination_e_g_Canary_Islands_or_Tenerife()
   {
      departureAirportOrDestinationComponent.enterTheDestination();
   }

   @Then("the region or destination displays in the list of results")
   public void the_region_destination_displays_in_the_list_of_results()
   {
      assertThat("the destination list results not displayed ",
               departureAirportOrDestinationComponent.veriyingRegions(), is(true));
   }

   @When("they select a country that has regions mapped to it \\(E.g. Spain)")
   public void they_select_a_country_that_has_regions_mapped_to_it_E_g_Spain()
   {
      departureAirportOrDestinationComponent.clickOnCountry();
   }

   @Then("they're presented with the geo-tree structure in the list")
   public void they_re_presented_with_the_geo_tree_structure_in_the_list()
   {
      assertThat("the geo-tree structure is not present the list ",
               departureAirportOrDestinationComponent.verifyingGeoTree(), is(true));
   }

   @Then("regions are displayed on the far left with its child destinations \\(E.g Tenerife, Lanzarote) displayed to the right")
   public void regions_are_displayed_on_the_far_left_with_its_child_destinations_E_g_Tenerife_Lanzarote_displayed_to_the_right()
   {
   }

   @Then("they can see the name of the region\\/child destination they have selected \\(e.g Balearic Islands or Majorca)")
   public void they_can_see_the_name_of_the_region_child_destination_they_have_selected_e_g_Balearic_Islands_or_Majorca()
   {

      assertThat("the selected destination is not displayed ",
               departureAirportOrDestinationComponent.verifyingSelectedDestination(), is(true));
   }

   @Then("the first region\\/child destination,is displayed with a {string} sign afterwards")
   public void the_first_region_child_destination_is_displayed_with_a_sign_afterwards(String string)
   {
      assertThat("the selected destinations are not displayed ",
               departureAirportOrDestinationComponent.verifyingDesionations(), is(true));
   }

   @Then("they can see a list of all the regions\\/destinations selected")
   public void they_can_see_a_list_of_all_the_regions_destinations_selected()
   {
      assertThat("the selected destinations are not in order ",
               departureAirportOrDestinationComponent.verifySelectedListOfDestinations(), is(true));
   }

   @Then("its in the order selected")
   public void its_in_the_order_selected()
   {
      assertThat("the selected destinations are not in order ",
               departureAirportOrDestinationComponent.verifySelectedListOfDestinations(), is(true));
   }

   @Given("the {string} has conducted a package search for a region with child destinations mapped to it \\(E.g. Canary Islands) \\(Either by free typing the region or selecting it within the destination field)")
   public void the_has_conducted_a_package_search_for_a_region_with_child_destinations_mapped_to_it_E_g_Canary_Islands_Either_by_free_typing_the_region_or_selecting_it_within_the_destination_field(
            String string)
   {
      packageNavigation.navigateToSingleAccomSearchResultPage();
   }

   @When("they{string}Destination' filter")
   public void they_Destination_filter(String string)
   {
      assertThat("Destination filter is not displayed",
               destinationFilterComponent.isDestinationFilterDisplayed(), is(true));
   }

   @Then("they can see a list of regional child destinations they can filter by \\(E.g. Tenerife, Lanzarote) with its parents above")
   public void they_can_see_a_list_of_regional_child_destinations_they_can_filter_by_E_g_Tenerife_Lanzarote_with_its_parents_above()
   {
      destinationFilterComponent.isDestinationDisplayed();
   }

   @Then("country level is not displayed")
   public void country_level_is_not_displayed()
   {
      assertThat("country level is displayed",
               destinationFilterComponent.verifyCountryLevelFilter(), is(true));
   }

   @Then("the list of results filters down to the region\\(s) they selected")
   public void the_list_of_results_filters_down_to_the_region_s_they_selected()
   {
      assertThat("the list of results filters down to the region they selected not dispalyed",
               destinationFilterComponent.verifyFilterSelectedDestination(), is(true));
   }

   @Then("the count of returned results updates to reflect each selection")
   public void the_count_of_returned_results_updates_to_reflect_each_selection()
   {
      assertThat("the count not returned results updates to reflect each selection ",
               destinationFilterComponent.verifyDestinationCount(), is(true));
   }

   @When("they select at least one {string} checkbox")
   public void they_select_at_least_one_checkbox(String string)
   {
      destinationFilterComponent.clickOnChildDestination();
   }

}
