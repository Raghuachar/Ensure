package uk.co.tui.cdaf.frontend.stepdefs.wr.web.stay.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.stay.search.searchresults.SearchResults;
import uk.co.tui.cdaf.utils.WebDriverUtils;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class SearchResultsStepDefs
{
   private final SearchResults searchresults;

   public SearchResultsStepDefs()
   {
      searchresults = new SearchResults();
   }

   @Given("a customer is on the stay search result page")
   public void a_customer_is_on_the_stay_search_result_page()
   {
      WebDriverUtils.getDriver()
               .get("https://sncuser:U2FsZXMmQ29udGVudERvbWFpbg==@tuinr-slsstg-alb-tbepkg-2120086277.eu-central-1.elb.amazonaws.com/destinations/packages?airports%5B%5D=&units%5B%5D=5000003%3ACOUNTRY&when=12-05-2021&until=&choiceSearch=false&flexibility=true&monthSearch=false&flexibleDays=3&flexibleMonths=&noOfAdults=2&noOfChildren=0&childrenAge=&duration=7115&searchRequestType=ins&searchType=aosearch&sp=true&multiSelect=true&room=&isVilla=false&reqType=&sortBy=NL:https://tuinr-slsstg-alb-tnlpkg-32960951.eu-central-1.elb.amazonaws.com/destinations/packages?airports%5B%5D=&units%5B%5D=5000003%3ACOUNTRY&when=12-05-2021&until=&choiceSearch=false&flexibility=true&monthSearch=false&flexibleDays=3&flexibleMonths=&noOfAdults=2&noOfChildren=0&childrenAge=&duration=7115&searchRequestType=ins&searchType=aosearch&sp=true&multiSelect=true&room=&isVilla=false&reqType=&sortBy=");
   }

   @And("stay search results are available")
   public void stay_search_results_are_available()
   {
      assertThat("Stay search Results are not displayed", searchresults.isSelectableCardPresent(),
               is(true));
   }

   // Scenario image interaction
   @When("I click on one of the images of the hotel")
   public void i_click_on_one_of_the_images_of_the_hotel()
   {
      searchresults.clickResultItemImage();
   }

   @Then("the image gallery for that hotel opens")
   public void the_image_gallery_for_that_hotel_opens()
   {
      assertThat("The image gallery is not present", searchresults.isImageGalleryPresent(),
               is(true));
   }

   // Scenario map view interaction
   @When("I click on 'Map view'")
   public void i_click_on_map_view()
   {
      searchresults.mapLinkClick();
   }

   @Then("a pop-up opens with a map view of the respective hotel")
   public void a_popup_opens_with_a_map_vew_of_the_respective_hotel()
   {
      assertThat("The map modal isn't opened", searchresults.mapModalIsOpened(), is(true));
   }

   // Scenario Only x rooms left tool tip interaction
   @When("I hover over the 'Only x rooms left' tool tip")
   public void i_hover_over_the_only_x_rooms_left_tool_tip()
   {
      searchresults.hoverOverResultItemToolTip();
   }

   @Then("the following text will be displayed:")
   public void the_following_text_will_be_displayed(String textContent)
   {
      assertThat("Only x rooms left tekst is displayed",
               searchresults.tooltipContainsText(textContent), is(true));
   }

   @Then("the following text should be displayed:")
   public void the_following_text_should_be_displayed(String textContent)
   {
      assertThat("Total price text should be displayed",
               searchresults.priceToolTipContainsText(textContent), is(true));
   }
}
