package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PriceChangeAlertComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public final SummaryPage summaryPage;

   public PriceChangeAlertComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      summaryPage = new SummaryPage();
   }

   @Given("that the customer is on the Flight Options page")
   public void that_the_customer_is_on_the_Flight_Options_page()
   {
      packageNavigation.navigateToFlightPage();
   }

   @Given("they have selected an alternative flight as part of their selected package")
   public void they_have_selected_an_alternative_flight_as_part_of_their_selected_package()
   {
      // Will Implement this step once it is available
   }

   @When("they navigate back to Customise page")
   public void they_navigate_back_to_Customise_page()
   {
      summaryPage.backToYourHolidayComponent.clickOnBackToYourHoliday();
   }

   @When("there has been a price increase or decrease in either the unit price or flight price")
   public void there_has_been_a_price_increase_or_decrease_in_either_the_unit_price_or_flight_price()
   {
      // Will implement this step once it is available
   }

   @Then("they will be presented with the appropriate price change message")
   public void they_will_be_presented_with_the_appropriate_price_change_message()
   {
      boolean actual = summaryPage.priceChangeAlertComponent.isPriceChangeComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Price change alert component wasn't displayed", actual, true), actual, is(true));
   }

   @Given("they have selected an alternative Room & Board as part of their selected package")
   public void they_have_selected_an_alternative_Room_Board_as_part_of_their_selected_package()
   {
      // will implement this step once it is available
   }

   @Given("a customer is on the Unit Details Page")
   public void a_customer_is_on_the_Unit_Details_Page()
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @When("they navigate to Customise Page")
   public void they_navigate_to_Customise_Page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @Then("there won't be display of any price messaging, even if prices have changed in background")
   public void there_won_t_be_display_of_any_price_messaging_even_if_prices_have_changed_in_background()
   {
      boolean actual = summaryPage.priceChangeAlertComponent.isPriceChangeComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Price change alert component wasn't displayed", actual, false), actual, is(false));
   }

}
