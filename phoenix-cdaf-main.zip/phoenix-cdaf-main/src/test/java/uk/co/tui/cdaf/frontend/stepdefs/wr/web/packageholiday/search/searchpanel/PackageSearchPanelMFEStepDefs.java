package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchpanel;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class PackageSearchPanelMFEStepDefs
{

   private final SearchPanel searchPanel = getSearchPanel();

   public SoftAssertions softAssert = new SoftAssertions();

   @When("they view the search panel MFE")
   public void they_view_the_search_panel_MFE()
   {
      assertTrue("Search panel is not visible", searchPanel.isSearchPanelMfe());
   }

   @Then("they shall see the following fields text in the relevant source market language:")
   public void they_shall_see_the_following_fields_text_in_the_relevant_source_market_language(
            DataTable dataTable)
   {
      String site = getTestExecutionParams().getLocaleStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedDepartureAirport = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Departure Airport")).findFirst().orElse(null);
      String expectedDestinations = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Destination or hotel")).findFirst().orElse(null);
      String expectedDates = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Departure Date")).findFirst().orElse(null);
      String expectedDuration = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Duration")).findFirst().orElse(null);
      String expectedRoomGuest = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Room & Guests")).findFirst().orElse(null);
      String expectedSearchButton = maps.stream().filter(row -> row.get("siteID").equals(site))
               .map(row -> row.get("Search Button")).findFirst().orElse(null);
      String actualDestination = searchPanel.getDestinationComponentLable();
      String actualDepartureDate = searchPanel.getDepartureComponentLable();
      String actualDuration = searchPanel.getDurationComponentLable();
      String actualRoomAndGuest =
               searchPanel.getPaxAndRoomsdurationComponentLable();
      String actualSearchButton = searchPanel.getSearchButtonLable();
      String actualAirport = searchPanel.getAirportComponentLable();

      softAssert.assertThat(actualAirport).isEqualTo(expectedDepartureAirport);
      softAssert.assertThat(actualDestination).isEqualTo(expectedDestinations);
      softAssert.assertThat(actualDepartureDate).isEqualTo(expectedDates);
      softAssert.assertThat(actualDuration).isEqualTo(expectedDuration);
      softAssert.assertThat(actualRoomAndGuest).isEqualTo(expectedRoomGuest);
      softAssert.assertThat(actualSearchButton).isEqualTo(expectedSearchButton);
      softAssert.assertAll();
   }

   @And("the destination or hotel field shall contain the following text in the relevant source market language after the list icon:")
   public void the_destination_or_hotel_field_shall_contain_the_following_text_in_the_relevant_source_market_language_after_the_list_icon(
            DataTable dataTable)
   {
      String siteId = getTestExecutionParams().getLocaleStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedListIconText = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("List")).findFirst().orElse(null);
      String actualListIconText = searchPanel.getDestinationComponentLable();
      assertEquals("List Icon translations is not matched ", expectedListIconText,
               actualListIconText);
   }

   @Then("it should be in compact view")
   public void it_should_be_in_compact_view()
   {
      assertTrue("Home page Search panel is not in compact view", searchPanel.isCompactView());
   }

   @Then("it should be in full view")
   public void it_should_be_in_full_view()
   {
      assertTrue("Edit Search panel is not in Full view", searchPanel.isFullView());
   }
}
