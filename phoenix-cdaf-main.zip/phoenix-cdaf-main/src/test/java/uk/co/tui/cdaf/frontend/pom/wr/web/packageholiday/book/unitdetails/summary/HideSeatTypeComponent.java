package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class HideSeatTypeComponent extends AbstractPage
{

   @FindBy(css = "[aria-label='seat type ancillary']")
   public WebElement seatTypeComponent;

   @FindBy(css = "[aria-label='flight seat types']")
   public WebElement seatTypeComponentBCP;

   @FindBy(css = "[aria-label='confirmation holiday summary']")
   public WebElement confirmationPage;

   public boolean isTUIPartPlaneFlight()
   {
      JavascriptExecutor executor = (JavascriptExecutor) getDriver();
      return (boolean) executor
               .executeScript("return jsonData.packageViewData.flightViewData[0].isPartPlane");
   }

   public boolean isSeatTypeComponentPresent()
   {
      return WebElementTools.isPresent(seatTypeComponent);
   }

   public boolean isBCPDisplayed()
   {
      return WebElementTools.isPresent(confirmationPage);
   }

   public boolean isSeatTypeComponentPresentBCP()
   {
      return WebElementTools.isPresent(seatTypeComponentBCP);
   }

}
