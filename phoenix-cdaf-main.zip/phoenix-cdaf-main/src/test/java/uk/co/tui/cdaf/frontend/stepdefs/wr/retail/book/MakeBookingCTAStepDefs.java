package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;

public class MakeBookingCTAStepDefs
{
   public final RetailPackageNavigation retailpackagenavigation;

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   public final FlightOnlyHomePage foHomePage;

   public final SearchResultsPage searchResultsPage;

   public final FlightOptionsPage flightOptionsPage;

   public final ExtraOptionsPage extraOptionsPage;

   private final RetailSearchPanelComponent retailsearchpanelcomponent;

   private final RetailFlightOnlyPageNavigation retailFlightOnlyPageNavigation;

   public MakeBookingCTAStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      foHomePage = new FlightOnlyHomePage();
      searchResultsPage = new SearchResultsPage();
      retailsearchpanelcomponent = new RetailSearchPanelComponent();
      flightOptionsPage = new FlightOptionsPage();
      extraOptionsPage = new ExtraOptionsPage();
      retailFlightOnlyPageNavigation = new RetailFlightOnlyPageNavigation();
   }

   @Given("that the Agent is on bookflow")
   public void that_the_Agent_is_on_bookflow()
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPassengerPage();
   }

   @And("they have completed the passenger details page")
   public void they_have_completed_the_passenger_details_page()
   {
      retailpassengerdetailspage.fillRetailPassengerDetails();
   }

   @When("they click {string} CTA passenger details page")
   public void they_click_CTA_passenger_details_page(String string)
   {
      retailpassengerdetailspage.makeBookingText();
   }

   @Then("the Agent will be taken to the confirmation page")
   public void the_Agent_will_be_taken_to_the_confirmation_page()
   {
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }

   @Given("that the Agent is on FO bookflow")
   public void that_the_Agent_is_on_FO_bookflow()
   {
      retailpackagenavigation.retailLogin();
      retailFlightOnlyPageNavigation.wrMFEFoOneWaySearch();
      retailsearchpanelcomponent.selectFlight();
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
   }

   @And("they have completed the FO passenger details page")
   public void they_have_completed_the_FO_passenger_details_page()
   {
      retailpassengerdetailspage.fillRetailPassengerDetails();
   }

   @When("they click {string} CTA on the FO passenger details page")
   public void they_click_CTA_on_the_FO_passenger_details_page(String string)
   {
      retailpassengerdetailspage.makeBookingText();
   }

   @Then("the Agent will be taken to the FO confirmation page")
   public void the_Agent_will_be_taken_to_the_FO_confirmation_page()
   {
      retailpackagenavigation.retailLogin();
      retailpackagenavigation.navigateToPassengerPage();
   }

}
