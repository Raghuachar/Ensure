package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.mmb;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class UnitDetailsComponent extends AbstractPage
{
   public final WebElementWait wait;

   @FindAll({ @FindBy(css = ".UI__hotelContentWrapper .UI__cardWrapper"),
            @FindBy(css = ".Header__accomodationSection") })
   private WebElement unitDetailsCard;

   @FindBy(css = "[class='Image__imgContainer']")
   private WebElement hotelImage;

   @FindAll({ @FindBy(css = ".UI__hotelContentWrapper .UI__title"),
            @FindBy(css = ".Header__headerTitle") })
   private WebElement hotelName;

   public UnitDetailsComponent()
   {
      wait = new WebElementWait();
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getAccomDetailsComponents()
   {
      return new HashMap<>()
      {
         {
            put("Hotel Details Card", unitDetailsCard);
            put("Hotel Image with Gallery Options", hotelImage);
            put("Hotel Name", hotelName);
         }
      };
   }
}
