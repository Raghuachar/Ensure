package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class EditSearchStepDefs
{
   private final PackageNavigation packageNavigation = new PackageNavigation();

   private final SearchPanel searchPanel = getSearchPanel();

   private final SearchResultsPage searchResultsPage = new SearchResultsPage();

   @Given("the Customer or Agent has landed on the unit details page")
   public void theCustomerOrAgentHasLandedOnTheUnitDetailsPage()
   {
      packageNavigation.navigateToUnitDetailsPage();
   }

   @When("they clicked on the hyperlink and edit search button")
   public void theyClickedOnTheHyperlinkAndEditSearchButton()
   {
      searchResultsPage.editSearch().hover().click();
   }

   @Then("the search panel should be opened in full view")
   public void theSearchPanelShouldBeOpenedInFullView()
   {
      assertTrue("the search panel is not opened", searchPanel.isFullView());
   }

   @And("the edit search should be displayed")
   public void theEditSearchShouldBeDisplayed()
   {
      assertTrue("edit search is not displayed", searchResultsPage.editSearch().isDisplayed());
   }

   @And("there should be a link to open the search panel")
   public void checkLinkToOpenSearchPanel()
   {
      assertTrue("No link to open the search panel found", searchResultsPage.editSearch().exists());
   }

   @When("search panel should be closed by default \\(hidden view)")
   public void searchPanelShouldBeClosedByDefaultHiddenView()
   {
      assertFalse("The search panel is not closed by default (hidden view)",
               searchPanel.isSearchPanelDisplayed());
   }
}
