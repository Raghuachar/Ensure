package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class FOSelectInsuranceStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final RetailFlightOnlyPageNavigation retailflightonlypagenavigation;

   private final ExtraOptionsPage extraOptionsPage;

   public FOSelectInsuranceStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      retailflightonlypagenavigation = new RetailFlightOnlyPageNavigation();
      extraOptionsPage = new ExtraOptionsPage();
   }

   @Given("the agent is on extras option page")
   public void the_agent_is_on_extras_option_page()
   {
      retailpackagenavigation.retailLogin();
      retailflightonlypagenavigation.extraOptionsPageOneway();
   }

   @When("they select the insurance")
   public void they_select_the_insurance()
   {
      retailpassengerdetailspage.addInsurance();
      retailpassengerdetailspage.enterAdultDOB();
      retailpassengerdetailspage.updatePriceCTA();
      retailpassengerdetailspage.expandInsuranceAccordion();
      retailpassengerdetailspage.selectInsurance();
   }

   @Then("insurance should be selected")
   public void insurance_should_be_selected()
   {
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();

   }
}
