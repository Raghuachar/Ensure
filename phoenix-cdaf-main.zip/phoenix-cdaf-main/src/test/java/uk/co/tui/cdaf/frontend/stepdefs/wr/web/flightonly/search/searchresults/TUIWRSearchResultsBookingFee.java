package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.search.searchresults.SearchResults;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TUIWRSearchResultsBookingFee
{

   private final SearchResults searchresults;

   public TUIWRSearchResultsBookingFee()
   {
      searchresults = new SearchResults();
   }

   @Given("a {string} is on the flight only search results page")
   public void a_is_on_the_flight_only_search_results_page(String customer)
   {
      searchresults.visit();
      assertThat(customer + " is on the Flight only Search result page",
               searchresults.isOutboundSearchResultsPresent(), is(true));
   }

   @When("a customer hovers or clicks on the Price within the search card")
   public void a_customer_hovers_or_clicks_on_the_Price_within_the_search_card()
   {
      searchresults.hoverOnPriceWithBookingFeeNode();
   }

   @Then("the following message will display {string} \\(price in the message will be driven by the rules engine)")
   public void the_following_message_will_display_price_in_the_message_will_be_driven_by_the_rules_engine(
            String message)
   {
      assertThat(message + " is shown in the price tooltip",
               searchresults.bookingFeeMessageIsShown(), is(true));
   }

   @Given("has selected an outbound flight")
   public void has_selected_an_outbound_flight()
   {
      searchresults.selectOutboundFlight();
   }

   @When("a customer views the summary panel")
   public void a_customer_views_the_summary_panel()
   {
      searchresults.selectReturnFlight();
   }

   @Then("the {string} label and amount will display as per the design above the TOTAL PRICE.")
   public void the_label_and_amount_will_display_as_per_the_design_above_the_TOTAL_PRICE(
            String bookingfeeLabel)
   {
      assertThat(bookingfeeLabel + " is shown in Summary panel",
               searchresults.bookingFeeMessageIsShownInSummary(), is(true));
   }
}
