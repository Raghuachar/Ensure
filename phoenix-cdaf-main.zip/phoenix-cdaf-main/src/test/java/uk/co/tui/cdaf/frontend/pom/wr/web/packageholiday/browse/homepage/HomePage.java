package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class HomePage extends AbstractPage
{
   private final HeaderComponent headercomp = new HeaderComponent();

   // keys should be same as mentioned in feature fie
   private final HashMap<String, String> wrHeaderCompLabelMap = new HashMap<>();

   private final HashMap<String, WebElement> wrHeaderCompMap = new HashMap<>();

   private final Map<String, String> searchCardMap = new HashMap<>();

   public WebElementWait wait = new WebElementWait();

   public SearchResultsPage searchResultsPage = new SearchResultsPage();

   public HashMap<String, WebElement> getHeaderPageMap()
   {
      return wrHeaderCompMap;
   }

   public HashMap<String, String> getHeaderLabelMap()
   {

      return wrHeaderCompLabelMap;
   }

   public String getHeaderLabel(String component)
   {
      return getHeaderLabelMap().get(component);
   }

   public boolean checkHeaderLabel(String actual, String expectedvalue)
   {

      return StringUtils.equalsIgnoreCase(actual, expectedvalue);
   }

   public void viewHeader()
   {

      headercomp.getHeaderComp().scrollTo();
   }

   public void clickBurgerMenu()
   {
      WebElementTools
               .clickElementJavaScript(wait.getWebElementWithLazyWait(headercomp.getBurgerMenu()));
      wait.forJSExecutionReadyLazy();
   }

   public void setHeaderLabelMap()
   {
      try
      {
         wrHeaderCompLabelMap.put("holidays", headercomp.getHolidaysLabel().getText());
         wrHeaderCompLabelMap.put("cruises", headercomp.getCruisesLabel().getText());
         wrHeaderCompLabelMap.put("flights", headercomp.getFlightsLabel().getText());
         wrHeaderCompLabelMap.put("hotelonly", headercomp.getHotlonlyLabel().getText());
         wrHeaderCompLabelMap.put("deals", headercomp.getDealsLabel().getText());
         wrHeaderCompLabelMap.put("destinations", headercomp.getDestinationsLabel().getText());
         wrHeaderCompLabelMap.put("extras", headercomp.getExtrasLabel().getText());

         wrHeaderCompLabelMap.put("questions", headercomp.getQuestionsLabel().getText());
         wrHeaderCompLabelMap.put("blog", headercomp.getBlogLabel().getText());
         wrHeaderCompLabelMap.put("shortlist",
                  headercomp.getShortlistLabel().getText().split("\\(")[0].trim());
         wrHeaderCompLabelMap.put("travel information",
                  headercomp.getTravelInformationLabel().getText());
         wrHeaderCompLabelMap.put("account&booking", headercomp.getAccountBookingLabel().getText());
      }
      catch (Exception e)
      {

      }

   }

   public void setHeaderCompMap()
   {
      try
      {

         wrHeaderCompMap.put("headerComp", headercomp.getHeaderComp());
         wrHeaderCompMap.put("Shortlist", headercomp.getShortlistIcon());
         wrHeaderCompMap.put("Account & bookings", headercomp.getAccountBookingIcon());
      }
      catch (Exception e)
      {

      }
   }

   public boolean checkTUILogo()
   {
      return StringUtils.containsIgnoreCase(headercomp.getTuiLogoIcon().getAttribute("src"),
               "TUI-Logo.svg");
   }

   public Map<String, String> getHeaders()
   {
      searchCardMap.put("VAKANTIES", headercomp.getHolidaysLabel().getText());
      searchCardMap.put("VLUCHTEN", headercomp.getFlightLabel().getText());
      searchCardMap.put("LINKS", headercomp.getLinksLabel().getText());
      return searchCardMap;
   }

   public Map<String, String> getHeadersComponents()
   {
      searchCardMap.put("TRAVEL INFORMATION", headercomp.travelInformationLabel().getText());
      searchCardMap.put("RETRIEVE A BOOKING", headercomp.retrievebookingLabel().getText());
      searchCardMap.put("NEXT CUSTOMER", headercomp.nextCustomerLabel().getText());
      searchCardMap.put("AGENT DETAILS", headercomp.agentlinkLabel().getText());
      searchCardMap.put("LOGOUT", headercomp.logoutlinkLabel().getText());
      searchCardMap.put("COUNTRY FLAG", headercomp.getCountryLabel().getText());
      return searchCardMap;
   }

   public Map<String, String> getB2CHeadersComponents()
   {
      searchCardMap.put("VAKANTIES", headercomp.getHolidaysLabel().getText());
      searchCardMap.put("CRUISES", headercomp.getCruisesLabel().getText());
      searchCardMap.put("VLUCHTEN", headercomp.getFlightsLabel().getText());
      searchCardMap.put("ENKEL VERBLIJF", headercomp.getHotlonlyLabel().getText());
      searchCardMap.put("PROMOTIES", headercomp.getDealsLabel().getText());
      searchCardMap.put("BESTEMMINGEN", headercomp.getDestinationsLabel().getText());
      searchCardMap.put("EXTRAS", headercomp.getExtrasLabel().getText());
      return searchCardMap;
   }

   public Map<String, String> getB2CSecondaryComponents()
   {
      searchCardMap.put("VRAGEN", headercomp.getQuestionsLabel().getText());
      searchCardMap.put("BLOG", headercomp.getBlogLabel().getText());
      searchCardMap.put("BEWAARDE VAKANTIES",
               headercomp.getShortlistLabel().getText().split("\\(")[0].trim());
      searchCardMap.put("REISINFORMATIE", headercomp.getTravelInformationLabel().getText());
      searchCardMap.put("ACCOUNT & RESERVERINGEN", headercomp.getAccountBookingLabel().getText());
      return searchCardMap;
   }
}
