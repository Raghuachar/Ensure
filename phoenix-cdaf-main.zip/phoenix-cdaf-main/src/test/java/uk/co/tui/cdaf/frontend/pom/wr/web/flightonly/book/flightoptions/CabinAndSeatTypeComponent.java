package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CabinAndSeatTypeComponent extends AbstractPage
{

   private static final String ADULT_REGEX = "\"noOfAdults\":(.+?),^^1";

   private static final String CHILD_REGEX = "\"noOfChildren\":(.+?),^^1";

   private final WebElementWait wait;

   @FindBy(css = "[aria-label='seat ancillary'] h2")
   protected WebElement cabinClassHeading;

   @FindBy(css = "[aria-label='ECO_CLASS'] h4[class*='title']")
   protected WebElement economyCabinTypeTitle;

   @FindBy(css = "[aria-label='DEL_CLASS'],[aria-label='FLY_DEL'] [class*='radioButton']")
   protected WebElement upgradeCabinType;

   @FindBy(css = "[aria-label='DEL_CLASS'],[aria-label='FLY_DEL'] ul")
   protected WebElement upgradeCabinUsps;

   @FindBy(css = "[aria-label='seat ancillary'] [class*='childMessage']")
   protected WebElement upgradeCabinDesc;

   @FindBy(css = "[class*='SeatAncillary__tncLink']")
   protected WebElement cabinTypeTNCLink;

   @FindBy(css = "[aria-label='ECO_CLASS'] p[class*='selectedState']")
   private WebElement EconomyCabinTypeDiffPrice;

   @FindBy(css = "[aria-label='ECO_CLASS'] [class*='radioButton']")
   private WebElement economyCabinTypeRadioButton;

   @FindBy(css = "[aria-label='ECO_CLASS'] [class*='tick']")
   private WebElement economyCabinTypeSignMark;

   @FindBy(css = "[aria-label='DEL_CLASS'] h4[class*='title']")
   private WebElement deluxeCabinTypeTitle;

   @FindBy(css = "[aria-label='DEL_CLASS'] p[class*='selectedState']")
   private WebElement deluxeCabinTypeDiffPrice;

   @FindAll({ @FindBy(css = "[aria-label='DEL_CLASS'] [class*='radioButton']"),
            @FindBy(css = "[aria-label='FLY_DEL'] [class*='radioButton']") })
   private WebElement deluxeCabinTypeRadioButton;

   @FindBy(css = "[aria-label='FLY_DEL'] p[class*='selectedState']")
   private WebElement flyCabinTypeDiffPrice;

   @FindBy(css = "[aria-label='FLY_DEL'] [class*='radioButton']")
   private WebElement flyCabinTypeRadioButton;

   @FindBy(css = "[aria-label='overlay open']")
   private WebElement cabinTCOverlay;

   @FindBy(css = "[aria-label='overlay open'] [aria-label='close']")
   private WebElement cabinTCOverlayCloseIcon;

   @FindBy(css = "[aria-label='seat type ancillary'] h2")
   private WebElement seatTypeHeading;

   @FindBy(css = "[aria-label='seat type ancillary'] [class*='title']")
   private List<WebElement> seatTypeTitle;

   @FindBy(css = "[aria-label='seat type ancillary'] [class*='selectedState']")
   private List<WebElement> seatTypeDiffPrice;

   @FindBy(css = "[aria-label='seat type ancillary'] [class*='radioButton']")
   private List<WebElement> seatTypeRadioButton;

   @FindBy(css = "[aria-label='seat type ancillary'] [class*='tick']")
   private List<WebElement> seatTypeSign;

   public CabinAndSeatTypeComponent()
   {
      wait = new WebElementWait();
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getCabinAndSeatTypeComponents()
   {
      return new HashMap<>()
      {
         {
            put("Cabin class title", cabinClassHeading);
            put("Cabin types", economyCabinTypeTitle);
            put("Cabin type amount", EconomyCabinTypeDiffPrice);
            put("Seat type title", seatTypeHeading);
            put("Seat types", seatTypeTitle.get(1));
            put("Seat type amount", seatTypeDiffPrice.get(1));
         }
      };
   }

   public WebElement getSeatTypeHeadingElement()
   {
      return wait.getWebElementWithLazyWait(seatTypeHeading);
   }

   public boolean isSeatTypeComponetDisplayed()
   {
      return WebElementTools.isPresent(getSeatTypeHeadingElement());
   }

   public List<WebElement> getSeatTypeSignElement()
   {
      return wait.getWebElementWithLazyWait(seatTypeSign);
   }

   public WebElement getEcoCabinTypeSignMarkElement()
   {
      return wait.getWebElementWithLazyWait(economyCabinTypeSignMark);
   }

   public void clickOnCabinTermsAndCondition()
   {
      WebElementTools.click(cabinTypeTNCLink);
   }

   public boolean isCabinTCOverlayDisplayed()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(cabinTCOverlay));
   }

   public void closeCabinTCOverlay()
   {
      WebElementTools.click(cabinTCOverlayCloseIcon);
   }

   public void selectEconomyCabinType()
   {
      WebElementTools.click(economyCabinTypeRadioButton);
   }

   public void selectDeluxeCabinType()
   {
      WebElementTools.click(deluxeCabinTypeRadioButton);
   }

   public void selectFlyCabinType()
   {
      WebElementTools.click(flyCabinTypeRadioButton);
   }

   public String getDeluxeCabinDifferencePrice()
   {
      return WebElementTools.getElementText(deluxeCabinTypeDiffPrice);
   }

   public String getFlyCabinDifferencePrice()
   {
      return WebElementTools.getElementText(flyCabinTypeDiffPrice);
   }

   public boolean selectComfortSeat()
   {
      if (!seatTypeRadioButton.isEmpty())
      {
         WebElementTools.click(seatTypeRadioButton.get(1));
         return true;
      }
      return false;
   }

   public boolean isDlecuxeCabinTypeDisplayed()
   {
      return WebElementTools.isPresent(deluxeCabinTypeTitle);
   }

   public String getComfortSeatDifferencePrice()
   {
      if (!seatTypeDiffPrice.isEmpty())
         return WebElementTools.getElementText(seatTypeDiffPrice.get(1));
      return StringUtils.EMPTY;
   }

   public String getTotalPax()
   {
      try
      {
         final String pageSource = WebDriverUtils.getPageSource();
         final String adult = WebDriverUtils.regexExtractor(ADULT_REGEX, pageSource).trim();
         final String child = WebDriverUtils.regexExtractor(CHILD_REGEX, pageSource).trim();
         if (StringUtils.isNotEmpty(child))
            return String.valueOf(Integer.parseInt(adult) + Integer.parseInt(child));
         return adult;
      }
      catch (Exception e)
      {
         return StringUtils.EMPTY;
      }
   }

   public double priceAfterSeatUpgrade(String totPrice, String diffPrice)
   {
      try
      {
         final double totPriceAfterAdd, totPriceAfterConvert;
         totPrice = totPrice.replaceAll("[€]", StringUtils.EMPTY).trim();
         diffPrice = StringUtils.substringBefore(diffPrice, " ");
         totPriceAfterConvert = Double.parseDouble(totPrice);
         double diffPriceAfterConvert = Double.parseDouble(diffPrice.replaceAll("[-+€]", ""));
         final String totPax = getTotalPax();
         diffPriceAfterConvert = StringUtils.isNotEmpty(totPax)
                  ? Integer.parseInt(totPax) * diffPriceAfterConvert : diffPriceAfterConvert;
         if (diffPrice.contains("+"))
            totPriceAfterAdd = totPriceAfterConvert + diffPriceAfterConvert;
         else
            totPriceAfterAdd = totPriceAfterConvert - diffPriceAfterConvert;
         BigDecimal totPrcAfterAdd = new BigDecimal(String.valueOf(totPriceAfterAdd));
         BigDecimal totPrcAfterRoundUp = totPrcAfterAdd.setScale(2, RoundingMode.HALF_EVEN);
         return totPrcAfterRoundUp.doubleValue();
      }
      catch (Exception e)
      {
         return 0;
      }
   }

   public double priceAfterCabinUpgrade(String totPrice, String diffPrice)
   {
      try
      {
         final double totPriceAfterAdd, totPriceAfterConvert;
         totPrice = totPrice.replaceAll("[^\\d\\.]+", StringUtils.EMPTY).trim();
         diffPrice = StringUtils.substringBefore(diffPrice, " ");
         totPriceAfterConvert = Double.parseDouble(totPrice);
         double diffPriceAfterConvert = Double.parseDouble(diffPrice.replaceAll("[-+€]", ""));
         if (diffPrice.contains("+"))
            totPriceAfterAdd = totPriceAfterConvert + diffPriceAfterConvert;
         else
            totPriceAfterAdd = totPriceAfterConvert - diffPriceAfterConvert;
         BigDecimal totPrcAfterAdd = new BigDecimal(String.valueOf(totPriceAfterAdd));
         BigDecimal totPrcAfterRoundUp = totPrcAfterAdd.setScale(2, RoundingMode.HALF_EVEN);
         return totPrcAfterRoundUp.doubleValue();
      }
      catch (Exception e)
      {
         return 0;
      }
   }

}
