package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class ProgressbarNavigationComponent extends AbstractPage
{

   private final WebElementWait wait;

   @FindBy(css = "[class*='pricePanel']")
   private WebElement pricePanel;

   @FindAll({ @FindBy(css = ".navigations__stepIndicator"),
            @FindBy(css = ".ProgressbarNavigation__steps") })
   private WebElement navigationPanel;

   @FindBy(css = ".PricePanel__totalPrice")
   private WebElement totalPrice;

   public ProgressbarNavigationComponent()
   {
      wait = new WebElementWait();
   }

   public WebElement getPricePanel()
   {
      return wait.getWebElementWithLazyWait(pricePanel);
   }

   public WebElement getNavigationPanel()
   {
      return wait.getWebElementWithLazyWait(navigationPanel);
   }

   public String getTotalPrice()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(wait.getWebElementWithLazyWait(totalPrice));
   }
}
