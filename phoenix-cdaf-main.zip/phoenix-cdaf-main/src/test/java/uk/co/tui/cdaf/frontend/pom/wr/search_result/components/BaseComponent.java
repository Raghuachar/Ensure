package uk.co.tui.cdaf.frontend.pom.wr.search_result.components;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;

public class BaseComponent
{
   private static final AutomationLogManager LOGGER = new AutomationLogManager(BaseComponent.class);

   private void waitForResultsFetch()
   {
      $("div.SearchResults__fade").should(Condition.disappear, Duration.ofSeconds(30));
   }

   protected void selectElement(SelenideElement el)
   {
      el.scrollTo().click();
      SelenideElement ooopsSorryMsg = $("div.NoResultsPopup__oopsSorry");
      if (ooopsSorryMsg.exists())
      {
         ooopsSorryMsg.parent().$("button").click();
      }
      waitForResultsFetch();
   }

   protected void selectRandomElement(ElementsCollection els, String filterType)
   {
      int size = els.size();
      int randomIndex = (int) (Math.random() * size);
      LOGGER.log(
               "Found " + size + " unchecked " + filterType + " filter options, selecting #" + (randomIndex + 1));
      selectElement(els.get(randomIndex).parent().parent());
   }
}
