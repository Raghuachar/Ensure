package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.passenger;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomeStayContactStepdefs
{

   @Given("the Customer is on the TUI WR Flight Only {string} page")
   public void the_Customer_is_on_the_TUI_WR_Flight_Only_page(String string)
   {
      throw new PendingException();
   }

   @Given("the customer has selected an NL prefix for their phone number")
   public void the_customer_has_selected_an_NL_prefix_for_their_phone_number()
   {
      throw new PendingException();
   }

   @When("They tries to selects to enter more than {int} characters in the phone number field")
   public void they_tries_to_selects_to_enter_more_than_characters_in_the_phone_number_field(
            Integer int1)
   {
      throw new PendingException();
   }

   @Then("The customer is limited to {int} numbers")
   public void the_customer_is_limited_to_numbers(Integer int1)
   {
      throw new PendingException();
   }

   @Given("They selects to enter less than {int} characters in the Phone Number field")
   public void they_selects_to_enter_less_than_characters_in_the_Phone_Number_field(Integer int1)
   {
      throw new PendingException();
   }

   @When("the customer clicks outside the field")
   public void the_customer_clicks_outside_the_field()
   {
      throw new PendingException();
   }

   @Then("The customer shall see the following error message:")
   public void the_customer_shall_see_the_following_error_message(
            io.cucumber.datatable.DataTable dataTable)
   {
      throw new PendingException();
   }

   @Given("the Customer is on the WR Flight Only {string} page")
   public void the_Customer_is_on_the_WR_Flight_Only_page(String string)
   {
      throw new PendingException();
   }

   @Given("They selects to enter a character which is NOT a number in the Phone Number Field")
   public void they_selects_to_enter_a_character_which_is_NOT_a_number_in_the_Phone_Number_Field()
   {
      throw new PendingException();
   }

   @Given("the customer is on the WR FO Passenger Details Page")
   public void the_customer_is_on_the_WR_FO_Passenger_Details_Page()
   {
      throw new PendingException();
   }

   @When("they hovers over the why? Emergency Mobile Phone tool tip")
   public void they_hovers_over_the_why_Emergency_Mobile_Phone_tool_tip()
   {
      throw new PendingException();
   }

   @Then("they shall see the following content:")
   public void they_shall_see_the_following_content(io.cucumber.datatable.DataTable dataTable)
   {
      throw new PendingException();
   }

}
