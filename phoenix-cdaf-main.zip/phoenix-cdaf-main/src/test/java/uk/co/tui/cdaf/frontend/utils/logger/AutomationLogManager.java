package uk.co.tui.cdaf.frontend.utils.logger;

import io.cucumber.java.Scenario;
import lombok.Getter;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import uk.co.tui.cdaf.frontend.utils.CommonHooks;

public class AutomationLogManager
{

   @Getter
   private static String events = "";

   private final String clazzName;

   private final Logger logger;

   public AutomationLogManager(final Class<?> clazz)
   {
      logger = LogManager.getLogger(clazz);
      clazzName = clazz.getSimpleName();
   }

   public static void appendEvents(String event)
   {
      events = events + "\n" + event;
   }

   public static void resetEvents(Scenario scenario)
   {
      if (scenario != null)
         events = "";
   }

   /**
    * Log a message with DEBUG log level.
    *
    * @param message The log message.
    */
   public void log(Object message)
   {
      log(LogLevel.DEBUG, message);
   }

   /**
    * Log a message to the output console and Cucumber report with the specified log level.
    *
    * @param level   The log level (e.g., "DEBUG", "WARN", "ERROR").
    * @param message The log message.
    */
   public void log(LogLevel level, Object message)
   {
      logToCucumberReport(message, level);
      switch (level)
      {
         case TRACE:
            logger.trace(message);
            break;
         case DEBUG:
            logger.debug(message);
            break;
         case WARN:
            logger.warn(message);
            break;
         case INFO:
            logger.info(message);
            break;
         case ERROR:
            logger.error(message);
            break;
         case FATAL:
            logger.fatal(message);
            break;
      }
   }

   private void logToCucumberReport(Object obj, LogLevel level)
   {
      String message = "[" + clazzName + "] " + level + ": " + obj;
      if (level.equals(LogLevel.ERROR) || level.equals(LogLevel.FATAL))
         CommonHooks.log(message, level.name());
      if (!level.equals(LogLevel.TRACE))
         appendEvents(message);
   }

   public boolean isLogLevel(Level level)
   {
      return logger.getLevel().isMoreSpecificThan(level);
   }
}
