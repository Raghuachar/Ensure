package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.browse;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.mmb.GlobalHeaderComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.shared.browse.homepage.HomePageCommon;

import static org.junit.Assert.assertEquals;

public class HomePageStepDefs
{
   private final GlobalHeaderComponent globalHeaderComponent;

   private final HomePageCommon homepageShared;

   public HomePageStepDefs()
   {
      globalHeaderComponent = new GlobalHeaderComponent();
      homepageShared = new HomePageCommon();
      RetailPassengerDetailsPage retailpassengerdetailspage = new RetailPassengerDetailsPage();
   }

   @Given("that the Agent is accessing the B2B TUI Maroc storefront")
   public void that_the_Agent_is_accessing_the_B_B_TUI_Maroc_storefront()
   {
      homepageShared.visit();
   }

   @Then("the default language should be set to {string}")
   public void the_default_language_should_be_set_to(String countryCode)
   {
      assertEquals("Default language is not equal to expected ", countryCode,
               globalHeaderComponent.getDefaultLanguage());
   }

   @When("the Agent selects the language dropdown")
   public void the_Agent_selects_the_language_dropdown()
   {
      globalHeaderComponent.selectLanguageSelector();
      globalHeaderComponent.clickOnLanguageSelectorDropdown();
   }

   @Then("the following languages should appear")
   public void the_following_languages_should_appear(io.cucumber.datatable.DataTable dataTable)
   {
      assertEquals(dataTable.asList(), globalHeaderComponent.getAvailableLanguages());
   }

   @Then("the Agent can select one to change the language on the site")
   public void the_Agent_can_select_one_to_change_the_language_on_the_site()
   {
      globalHeaderComponent.selectLanguageFromList("Dutch");
      globalHeaderComponent.clickOnChangeLanguageButton();
      assertEquals("Default language is not equal to expected ", "NL",
               globalHeaderComponent.getDefaultLanguage());
   }
}
