package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

public class FreeCancellationComponent extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(FreeCancellationComponent.class);

   private final WebElementWait wait;

   @FindBy(css = ".ResultListItemV2__freeCancellation")
   private List<WebElement> freeCancellationElement;

   @FindBy(css = ".ResultListItemV2__packageInfo")
   private List<WebElement> accomInfoPackage;

   @FindAll({ @FindBy(css = "input[aria-label='select date']"),
            @FindBy(css = "input[aria-label='Kies een datum']") })
   private WebElement depDateInput;

   @FindBy(css = "[aria-label='overlay open'] .popups__modalBody")
   private WebElement freeCancellationPopup;

   @FindBy(css = "[aria-label='overlay open'] .popups__modalBody [aria-label='title']")
   private WebElement freeCancellationTitle;

   @FindBy(css = "[aria-label='overlay open'] .popups__contentBody")
   private WebElement freeCancellationPopupContent;

   public FreeCancellationComponent()
   {
      wait = new WebElementWait();
   }

   public boolean visibileAccomInfoComponent()
   {
      boolean resultElementCancellation = false;
      try
      {
         if (departureDate().isAfter(LocalDate.now().plusDays(41)))
         {
            for (WebElement webElement : accomInfoPackage)
            {
               resultElementCancellation = WebElementTools.isPresent(webElement);
            }
         }
         return resultElementCancellation;
      }
      catch (ParseException e)
      {
         e.getMessage();
      }
      return false;
   }

   public boolean visibileDateFromNowSevenDay(String text)
   {
      AtomicBoolean resultElementCancellation = new AtomicBoolean(false);
      List<String> freeCancelList = freeCancellationElement.stream()
               .filter(webElement -> StringUtils.isNotEmpty(webElement.getText()))
               .map(WebElement::getText).collect(
                        Collectors.toList());
      freeCancelList.forEach(strList ->
      {
         String[] array = strList.split(" ");
         SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy");
         String endDate =
                  new StringJoiner(" ").add(array[3]).add(array[4]).add(array[5]).toString();
         try
         {
            Date theDate = format.parse(endDate);
            Calendar myCal = new GregorianCalendar();
            myCal.setTime(theDate);
            LocalDate localDate =
                     LocalDate.of(Integer.parseInt(array[5]), myCal.get(Calendar.MONTH) + 1,
                              Integer.parseInt(array[3]));
            if (localDate.isAfter(LocalDate.now()) ||
                     localDate.isEqual(LocalDate.now().plusDays(7)))
            {
               resultElementCancellation.set(true);
            }
         }
         catch (ParseException e)
         {
            LOGGER.log(LogLevel.ERROR, e.getMessage());
         }
      });
      return resultElementCancellation.get();
   }

   public boolean visibileFreeCancellationComponent()
   {
      boolean resultElementCancellation = false;
      for (WebElement webElement : freeCancellationElement)
      {
         resultElementCancellation = WebElementTools.isPresent(webElement);
      }
      return resultElementCancellation;
   }

   public boolean clickFreeCancellationLink()
   {
      boolean resultElementCancellation = false;
      for (WebElement webElement : freeCancellationElement)
      {
         if (WebElementTools.isPresent(webElement))
         {
            wait.forJSExecutionReadyLazy();
            WebElementTools.click(webElement);
            resultElementCancellation = true;
            break;
         }
      }
      return resultElementCancellation;
   }

   public boolean isModalHasContent()
   {
      return WebElementTools.isPresent(freeCancellationPopup);
   }

   public boolean isModalHasBodyContent(List<String> elementList)
   {
      wait.forJSExecutionReadyLazy();
      if (elementList.get(0).contains(freeCancellationTitle.getText()))
      {
         WebElementTools.isDisplayed(freeCancellationPopupContent);
         return true;
      }
      return false;
   }

   public LocalDate departureDate() throws ParseException
   {
      SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy");
      String deptDate = depDateInput.getAttribute("value");
      Date strDate = formatter.parse(deptDate);
      return strDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
   }
}
