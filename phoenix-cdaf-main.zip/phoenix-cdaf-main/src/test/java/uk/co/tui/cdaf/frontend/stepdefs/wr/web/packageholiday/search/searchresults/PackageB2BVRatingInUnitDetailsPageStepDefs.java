package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.uk.web.multi_centre.book.unit_details.AccommodationInfoPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.browse.homepage.HeaderComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageB2BVRatingInUnitDetailsPageStepDefs
{
   public final PackageNavigation packageNavigation;

   private final HeaderComponent headercomp;

   private final SearchResultsPage searchResultsPage;

   private final PageErrorHandler errorHandler;

   private final WebElementWait wait;

   private final AccommodationInfoPage unitDetailsaccommodation;

   public PackageB2BVRatingInUnitDetailsPageStepDefs()
   {
      packageNavigation = new PackageNavigation();
      headercomp = new HeaderComponent();
      searchResultsPage = new SearchResultsPage();
      errorHandler = new PageErrorHandler();
      wait = new WebElementWait();
      unitDetailsaccommodation = new AccommodationInfoPage();
   }

   @Given("the {string} has conducted a search via the VIP toggle")
   public void the_has_conducted_a_search_via_the_VIP_toggle(String ignore)
   {
      packageNavigation.navigateToHoldaySearchPage();
      headercomp.isVipButtonSelected();
      packageNavigation.navigateFromHomePageToSearchResultPage();
   }

   @And("they've selected a package")
   public void they_ve_selected_a_package()
   {
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      errorHandler.isPageLoadingCorrectly();
   }

   @When("they review the hotel name\\/destination section")
   public void they_review_the_hotel_name_destination_section()
   {
      assertThat("Hotel name component is not displayed",
               unitDetailsaccommodation.getAccommodationHeader().isDisplayed(), is(true));

   }

   @Then("they can see the V rating icons rather than T rating icons")
   public void they_can_see_the_V_rating_icons_rather_than_T_rating_icons()
   {
      String getVRatingText = unitDetailsaccommodation.getAccomodationRating().getText();
      assertThat("V Rating is not displayed", "V".trim().contains(getVRatingText), is(true));
   }
}
