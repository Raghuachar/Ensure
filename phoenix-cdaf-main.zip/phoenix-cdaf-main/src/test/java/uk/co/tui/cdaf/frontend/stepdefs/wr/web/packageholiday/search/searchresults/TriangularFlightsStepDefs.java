package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SortByComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.TriangularFlightOptionComponent;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.resolver.BDDSiteIdResolver;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams.getTestExecutionParams;

public class TriangularFlightsStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(TriangularFlightsStepDefs.class);

   private final Map<String, WebElement> searchMap;

   private final WebElementWait wait;

   private final PackageNavigation packageNavigation;

   private final TriangularFlightOptionComponent triangularFlightOption;

   private final SearchResultsPage searchResultsPage;

   private final SortByComponent searchResultsSortBy;

   public TriangularFlightsStepDefs()
   {
      packageNavigation = new PackageNavigation();
      triangularFlightOption = new TriangularFlightOptionComponent();
      searchMap = new HashMap<>();
      wait = new WebElementWait();
      searchResultsPage = new SearchResultsPage();
      searchResultsSortBy = new SortByComponent();
   }

   @Given("the customer is on the WR package Search Results page")
   public void the_customer_is_on_the_WR_package_Search_Results_page()
   {
      packageNavigation.navigateToSearchResultPage();
   }

   @Given("triangular flight options are available on both the outbound and return legs")
   public void triangular_flight_options_are_available_on_both_the_outbound_and_return_legs()
   {
      triangularFlightOption.isFlightOptionDisplay();

   }

   @When("the customer clicks on option within a triangular flight search results card")
   public void the_customer_clicks_on_within_a_triangular_flight_search_results_card()
   {
      triangularFlightOption.getflightTypeTriangular(": 1 tussenlanding - Geen overstap");
   }

   @Then("the display of the triangular flight details")
   public void the_display_of_the_triangular_flight_details()
   {
      triangularFlightOption.isFlightDetailsDisplay();

   }

   @Then("the following will be visible:")
   public void the_following_will_be_visible(List<String> components)
   {
      searchMap.putAll(triangularFlightOption.setSearchComponentsMap());
      components.forEach(component ->
               WebElementTools.isPresent(searchMap.get(component)));
   }

   @Given("the customer clicks on flight option within a triangular flight search results card")
   public void the_customer_clicks_on_flight_option_within_a_triangular_flight_search_results_card()
   {
      triangularFlightOption.clickFlightOption();
   }

   @And("is on the Flight Details pop up window")
   public void is_on_the_Flight_Details_pop_up_window()
   {
      triangularFlightOption.isFlightDetailsDisplay();
   }

   @When("the customer selects show more")
   public void the_customer_selects_below_the_text()
   {
      wait.forJSExecutionReadyLazy();
      triangularFlightOption.selectShowMore();
   }

   @Then("the text will appear")
   public void the_following_text_will_appear()
   {
      triangularFlightOption.isTextDisplay();
   }

   @And("a Show less accordion will be present")
   public void a_accordion_will_be_present()
   {
      triangularFlightOption.isShowLessDisplay();
   }

   @When("the customer selects the show less accordion")
   public void the_customer_selects_the_show_less_accordion()
   {
      triangularFlightOption.clickShowLess();
   }

   @Then("the text will disappear")
   public void the_text_will_disappear()
   {
      triangularFlightOption.isDisappearText();
   }

   @And("a Show more accordion will be present")
   public void a_Show_more_accordion_will_be_present()
   {
      triangularFlightOption.isShowMoreDisplay();
   }

   @And("Direct flight options are available on both the outbound and return legs")
   public void Direct_flight_options_are_available_on_both_the_outbound_and_return_legs()
   {
      triangularFlightOption.isFlightDetailsDisplay();
   }

   @When("the customer clicks on flight details within a direct flight search results card")
   public void the_customer_clicks_on_flight_details_within_a_direct_flight_search_results_card()
   {
      triangularFlightOption.getflightTypeAvailable(": Direct");
   }

   @Then("the display of the direct flight details will be as per the zeplin design")
   public void the_display_of_the_direct_flight_details_will_be_as_per_the_zeplin_design()
   {
      triangularFlightOption.isFlightOptionDisplay();
   }

   @And("options are available where a direct flight is on one leg and a triangular flight is on another leg")
   public void options_are_available_where_a_direct_flight_is_on_one_leg_and_a_triangular_flight_is_on_another_leg()
   {
      triangularFlightOption.isFlightDetailsDisplay();

   }

   @Then("the display of the direct flight leg and triangular flight leg will be as per the zeplin design and above scenarios")
   public void the_display_of_the_direct_flight_leg_and_triangular_flight_leg_will_be_as_per_the_zeplin_design_and_above_scenarios()
   {
      triangularFlightOption.isFlightDetailsDisplay();
   }

   @And("they're viewing a search card that includes a flight that is NOT with TUI Fly")
   public void they_re_viewing_a_search_card_that_includes_a_flight_that_is_NOT_with_TUI_Fly()
   {
      triangularFlightOption.isFlightOptionDisplay();
   }

   @Given("it is a direct, same operating flight for both OUT and INB")
   public void it_is_a_direct_same_operating_flight_for_both_OUT_and_INB()
   {
      triangularFlightOption.thirdPartyFlightOptionCheck(":Direct");
   }

   @When("they select a {string} Link")
   public void they_select_a_Link(String string)
   {
      triangularFlightOption.selectFlightDetailsLink();
   }

   @Then("the flight details modal opens")
   public void the_flight_details_modal_opens()
   {
      assertThat("search card flight details modal contents not present",
               triangularFlightOption.isFlightDetailsDisplay(), is(true));
   }

   @And("it contains a reassurance message underneath the flight cards")
   public void it_contains_a_reassurance_message_underneath_the_flight_cards(
            List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(triangularFlightOption.messageSearchComponentsMap());
      components.forEach(component ->
               WebElementTools.isPresent(searchMap.get(component)));
   }

   @And("they are on the search result page")
   public void they_are_on_the_search_result_page()
   {
      boolean isDisplayed = searchResultsSortBy.isHolidayCountDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Search Results page wasn't displayed", isDisplayed, true), isDisplayed, is(true));
   }

   @And("they have opened the flight details pop up for a triangular flight package")
   public void they_have_opened_the_flight_details_pop_up_for_a_triangular_flight_package()
   {
      triangularFlightOption.clickFlightOption();
   }

   @When("they review the pop up")
   public void they_review_the_pop_up()
   {
      triangularFlightOption.isFlightDetailsDisplay();
   }

   @Then("the flight information accordion underneath each flight segment is open by default")
   public void the_flight_information_accordion_underneath_each_flight_segment_is_open_by_default()
   {
      assertThat(
               "flight information accordion underneath each flight segment is NOT opened by default",
               triangularFlightOption.showLessAccordion(), is(true));
   }

   @And("the accordion link states {string}")
   public void the_accordion_link_states(String string)
   {
      triangularFlightOption.showLessAccordion();
   }

   @Then("they can see the word {string} preceding the departure airport")
   public void they_can_see_the_word_preceding_the_departure_airport(String string)
   {
      triangularFlightOption.getflightTypeAvailable(string);
   }

   @When("they review a search card that includes a {string} flight in the package")
   public void they_review_a_search_card_that_includes_a_flight_in_the_package()
   {
      assertThat(
               "flight information accordion underneath each flight segment is NOT opened by default",
               triangularFlightOption.showLessAccordion(), is(true));
   }

   @When("they have opened the {string} flight details pop up for a triangular flight package")
   public void they_have_opened_the_flight_details_pop_up_for_a_triangular_flight_package(
            String string)
   {
      if (WebDriverUtils.getDriver().getCurrentUrl().contains("be"))
      {
         triangularFlightOption.getflightTypeAvailable(": 1 tussenlanding - Geen overstap");
      }
      else if (WebDriverUtils.getDriver().getCurrentUrl().contains("nl"))
      {

         triangularFlightOption.getflightTypeAvailable(": 1 tussenlanding - Geen overstap");
      }
   }

   @And("they're viewing a search card that includes a {string} third party {string} flight")
   public void they_re_viewing_a_search_card_that_includes_a_third_party_flight(String string,
            String changeLanguage)
   {
      if (changeLanguage.equalsIgnoreCase("FR"))
      {
         triangularFlightOption.changeLangaugeSelection();
      }
      if (string.equalsIgnoreCase("Direct") || string.equalsIgnoreCase("Triangular")
               || string.equalsIgnoreCase("Connecting"))
         assertThat("Search card " + string + "flights is not displaying",
                  triangularFlightOption.getFlightType(string), is(true));
   }

   @When("they select {string} the Flight details link")
   public void they_select_the_Flight_details_link(String string)
   {
      triangularFlightOption.getDynamicFlights(string);
   }

   @And("it contains a reassurance message underneath the flight cards:")
   public void it_contains_a_reassurance_message_underneath_the_flight_cards(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actual, expected;
      Map<String, String> map = dataTable.asMap(String.class, String.class);
      try
      {
         expected = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
                  ? map.get((BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
                  + (BDDSiteIdResolver.getSiteRTId().toLowerCase()))
                  : (getTestExecutionParams().getLocaleStr().toLowerCase().contains("fr_be"))
                  ? map.get(getTestExecutionParams().getLocaleStr().toLowerCase())
                  : map.get(BDDSiteIdResolver.getSiteRTId().toLowerCase());
         actual = triangularFlightOption.getDynamicFlightReassurenceMessage();
         assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
                  "Reassurance messaging for third party dynamic flights is not displaying in the Flight details modal",
                  actual, expected), StringUtils.equalsIgnoreCase(expected, actual), is(true));
         LOGGER.log("Expected :" + expected + "\n Actual :" + actual);
      }
      catch (Exception e)
      {
         assertThat("component not found in map", false, is(true));
      }
   }

   @Then("it contains the reassurance message underneath the flight cards")
   public void it_contains_the_reassurance_message_underneath_the_flight_cards(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);

      String site = (BDDSiteIdResolver.getAgent().toLowerCase().contains("inhouse"))
               ? (BDDSiteIdResolver.getAgent().toLowerCase()) + "_"
               + (BDDSiteIdResolver.getSiteRTId().toLowerCase())
               : (getTestExecutionParams().getLocaleStr().toLowerCase().contains("fr_be"))
               ? getTestExecutionParams().getLocaleStr().toLowerCase()
               : BDDSiteIdResolver.getSiteRTId().toLowerCase();

      Map<String, String> matchingRow = dataTableTemp.stream()
               .filter(row -> row.get("siteId").equals(site))
               .findFirst()
               .orElseThrow(() -> new IllegalArgumentException(
                        "Cannot find expected strings for " + site));

      wait.forJSExecutionReadyLazy();
      String expectedMessageText1 = matchingRow.get("expectedMessageText1");
      String actualMessageText1 = triangularFlightOption.getDynamicFlightPopupMessages1().getText();
      assertThat("Legacy message text is not matched ", actualMessageText1,
               equalToIgnoringCase(expectedMessageText1));

      wait.forJSExecutionReadyLazy();
      String expectedMessageText2 = matchingRow.get("expectedMessageText2");
      String actualMessageText2 = triangularFlightOption.getDynamicFlightPopupMessages2().getText();
      assertThat("Legacy message text is not matched ", actualMessageText2,
               equalToIgnoringCase(expectedMessageText2));

      wait.forJSExecutionReadyLazy();
      String expectedMessageText3 = matchingRow.get("expectedMessageText3");
      String actualMessageText3 = triangularFlightOption.getDynamicFlightPopupMessages3().getText();
      assertThat("Legacy message text is not matched ", actualMessageText3,
               equalToIgnoringCase(expectedMessageText3));
   }

   @And("it is the direct, same operating flight for both OUT and INB")
   public void it_is_the_direct_same_operating_flight_for_both_OUT_and_INB()
   {
      triangularFlightOption.selectDynamicFlight();

   }

   @And("they're viewing the search card that includes a flight that is NOT with TUI Fly")
   public void they_re_viewing_the_search_card_that_includes_a_flight_that_is_NOT_with_TUI_Fly()
   {
      triangularFlightOption.dynamicFlight();
   }
}
