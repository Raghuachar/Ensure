package uk.co.tui.cdaf.api.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LocationData
{
   @JsonProperty("COUNTRY")
   private String country;

   @JsonProperty("DESTINATION")
   private String destination;

   @JsonProperty("REGION")
   private String region;

   @JsonProperty("RESORT")
   private String resort;

   public LocationData()
   {
   }

   public String getValueByKey(String key)
   {
      switch (key)
      {
         case "COUNTRY":
            return getCountry();
         case "DESTINATION":
            return getDestination();
         case "REGION":
            return getRegion();
         case "RESORT":
            return getResort();
         default:
            return null;
      }
   }
}
