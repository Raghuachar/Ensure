package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_results.SearchResultsSingleAccomComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;

public class PackageSingleAccomCalendarViewStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageSingleAccomCalendarViewStepDefs.class);

   public final SearchResultsPage searchResultsPage;

   private final PackageNavigation packageNavigation;

   private final SearchResultsSingleAccomComponent searchResultsSingleAccomComponent;

   public PackageSingleAccomCalendarViewStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsPage = new SearchResultsPage();
      searchResultsSingleAccomComponent = new SearchResultsSingleAccomComponent();
   }

   @When("they scroll down the page search results page")
   public void they_scroll_down_the_page_search_results_page()
   {
      WebElementTools.scrollTo(100, 100);
   }

   @Then("they can can see a pricing or availability calendar:")
   public void they_can_can_see_a_pricing_or_availability_calendar(List<String> calendarAvailabilty)
   {
      for (String caledarComp : calendarAvailabilty)
      {
         try
         {
            if (caledarComp.equalsIgnoreCase("Monthly calendar"))
               assertThat("Monthly calendar component is not present",
                        searchResultsSingleAccomComponent.singleAccomCalendar(), is(true));
            if (caledarComp.equalsIgnoreCase("Week running from Sunday to Saturday"))
               assertThat("Week running from Sunday to Saturday component is not present",
                        searchResultsPage.singleAccommodationComponent.isWeekrunningDaysPresent(),
                        is(true));
            if (caledarComp.equalsIgnoreCase("Price in Euro of the package in each cell"))
               assertThat("Price in Euro of the package in each cell component is not present",
                        searchResultsPage.singleAccommodationComponent.isPriceinEuroPresent(),
                        is(true));
            if (caledarComp.equalsIgnoreCase("Date in each cell"))
               assertThat("Date in each cell component is not present",
                        searchResultsPage.singleAccommodationComponent.isDatePresentInCell(),
                        is(true));
            if (caledarComp.equalsIgnoreCase("Month dropdown"))
               assertThat("Month dropdown component is not present",
                        searchResultsPage.singleAccommodationComponent.isMonthDropdownPresent(),
                        is(true));
            if (caledarComp.equalsIgnoreCase("Navigation chevrons"))
               assertThat("Navigation chevrons component is not present",
                        searchResultsPage.singleAccommodationComponent.isNavigationIconPresent(),
                        is(true));
         }
         catch (Exception e)
         {
            LOGGER.log(LogLevel.INFO, caledarComp + "component is not present");
         }
      }

   }

   @When("they review the top of the calendar")
   public void they_review_the_top_of_the_calendar()
   {
      assertTrue("Availability calendar is not present.",
               packageNavigation.searchResultsPage.isAvailabilityCalendarPresent());
   }

   @Then("they can see green dot and lowest price:")
   public void they_can_see_green_dot_and_lowest_price(List<String> ignored)
   {
      assertTrue("Green dot and lowest price is not displayed",
               searchResultsPage.singleAccommodationComponent.isGreenDotAndLowestPriceDisplayed());
      // TODO: this step should be split into multiple verifications, preferably with soft assertions
   }

   @Then("the lowest price date in the calendar has a green parameter")
   public void the_lowest_price_date_in_the_calendar_has_a_green_parameter()
   {
      assertTrue("Lowest price is not displayed in green parameter",
               searchResultsPage.singleAccommodationComponent.isLowestPriceDisplayed());
   }

   @Then("the date itself is coloured green")
   public void the_date_itself_is_coloured_green()
   {
      assertTrue("Lowest price date is not coloured green",
               searchResultsPage.singleAccommodationComponent.isDateColouredGreen());
   }

   @Then("they can see Info icon and all price :")
   public void they_can_see_Info_icon_and_all_price(List<String> ignored)
   {
      assertTrue("Info and All prices shown are per person not displayed",
               searchResultsPage.singleAccommodationComponent.isInfoAndAllPriceDescDisplayed());
      // TODO: this step should be split into multiple verifications, preferably with soft assertions
   }

   @And("they can see a pricing or availability calendar:")
   public void theyCanSeeAPricingOrAvailabilityCalendar(List<String> ignored)
   {
      assertTrue("Pricing/availability calendar not displayed",
               searchResultsPage.singleAccommodationComponent.isSingleAccomCalenderDisplayed());
      // TODO: this step should be split into multiple verifications, preferably with soft assertions
   }
}
