package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FacilitiesFilterComponent extends AbstractPage
{
   private final WebElementWait wait;

   @FindBy(css = "[class='Facilities__holidayTypeWrapper']")
   private WebElement facilitiesFilter;

   @FindBy(css = "[class='Facilities__wrapper'] ul li span[class='Facilities__filterOption']")
   private List<WebElement> facilitiesFilterOptions;

   @FindBy(css = ".Facilities__filterOption")
   private List<WebElement> facilitiesOptionsAlphabeticalOrder;

   @FindBy(css = "[class*='Facilities__showMore'] a")
   private List<WebElement> showMoreFacilites;

   @FindBy(css = "div[class='Facilities__wrapper'] input[type='checkbox']:disabled+span+span span")
   private List<WebElement> facilitiesFilterDisabled;

   @FindBy(css = "[class='Facilities__filterTypeItem Facilities__notChecked'] label input:not(:checked)+span")
   private List<WebElement> FacilitesOptions;

   public FacilitiesFilterComponent()
   {
      wait = new WebElementWait();
   }

   public boolean isFacilitiesDisplayed()
   {
      return WebElementTools.isPresent(getFacilitiesFilter());
   }

   public WebElement getFacilitiesFilter()
   {
      return wait.getWebElementWithLazyWait(facilitiesFilter);
   }

   public boolean facilitiesInAlphaOrder(List<String> facilities)
   {
      ArrayList<String> order = new ArrayList<>();
      List<String> fac = new ArrayList<>(facilities);
      String alpha = null;
      boolean flag = false;
      for (WebElement facilitiesOrder : facilitiesOptionsAlphabeticalOrder)
      {
         String facilitiesInAlphaOrder = WebElementTools.getElementText(facilitiesOrder);
         for (String abc : fac)
         {
            if (facilitiesInAlphaOrder.equalsIgnoreCase(abc))
            {
               alpha = facilitiesOrder.toString();
               flag = true;
            }
         }
      }
      order.add(alpha);
      Collections.sort(order);
      return flag;
   }

   public boolean isMoreThanFiveShowMorePresent()
   {
      return facilitiesOptionsAlphabeticalOrder.size() > 4;
   }

   public boolean isShowMorePresent()
   {
      return WebElementTools.isPresent(wait.getWebElementWithLazyWait(showMoreFacilites.get(0)));
   }

   public void clickShowMoreLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(showMoreFacilites.get(0));
   }

   public void clickFacilitiesFilterOptions()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(facilitiesFilterOptions.get(0));
   }

   public void alphabeticalOrder()
   {
      ArrayList<String> order = new ArrayList<>();
      String apl = null;
      for (WebElement alpha : facilitiesFilterOptions)
      {
         apl = alpha.toString();
      }
      order.add(apl);
      Collections.sort(order);
   }

   public boolean isFacilitesDisableState()
   {
      if (!facilitiesFilterDisabled.isEmpty())
      {
         wait.forJSExecutionReadyLazy();
         return WebElementTools.isPresent(facilitiesFilterDisabled.get(0));
      }
      else
      {
         return false;
      }
   }

   public boolean clickFacilitiesFliterGreyedOut()
   {
      boolean facilites = false;
      if (!facilitiesFilterDisabled.isEmpty())
      {
         wait.forJSExecutionReadyLazy();
         WebElementTools.clickElementJavaScript(facilitiesFilterDisabled.get(0));
      }
      return facilites;
   }

   public List<WebElement> getFacilitesOptions()
   {
      return FacilitesOptions;
   }
}
