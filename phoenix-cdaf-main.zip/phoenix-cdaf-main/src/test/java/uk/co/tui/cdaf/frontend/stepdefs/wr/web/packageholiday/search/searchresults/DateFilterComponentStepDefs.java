package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.DateFilterComponent;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertFalse;

public class DateFilterComponentStepDefs
{

   private final Map<String, WebElement> dateFilterMap;

   public DateFilterComponent DateFilterComponent;

   public DateFilterComponentStepDefs()
   {
      DateFilterComponent = new DateFilterComponent();
      dateFilterMap = new HashMap<>();
   }

   @When("they are viewing the Dates & Durations filter")
   public void they_are_viewing_the_Dates_Durations_filter()
   {
      DateFilterComponent.isDateFilterDisplayed();

   }

   @Then("the date filter will be selected by default")
   public void the_date_filter_will_be_selected_by_default()
   {

      DateFilterComponent.isDateFilterDefaultSelected();

   }

   @When("they select Date filters")
   public void they_select_Date_filters()
   {
      DateFilterComponent.clickAnyDateFilter();
   }

   @Then("the results will filter taking into account the selection")
   public void the_results_will_filter_taking_into_account_the_selection()
   {
      DateFilterComponent.isDisplayedSelectedDateFilter();
   }

   @When("they view the dates available")
   public void they_view_the_dates_available()
   {
      DateFilterComponent.isDisplayedDates();

   }

   @Then("they will see date filter following component")
   public void they_will_see_date_filter_following_component(List<String> components)
   {
      DateFilterComponent.wait.forJSExecutionReadyLazy();
      dateFilterMap.putAll(DateFilterComponent.getDateFilterComponents());
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = dateFilterMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @When("they select show more")
   public void they_select_show_more()
   {
      DateFilterComponent.clickShowMoreLink();
   }

   @Then("they will see additional dates")
   public void they_will_see_additional_dates()
   {
      DateFilterComponent.isAdditionalDateDisplayed();
   }

   @And("a show less link will be visible")
   public void a_show_less_link_will_be_visible()
   {
      DateFilterComponent.isShowLessLinkDisplayed();
   }

   @Then("selecting show less hides the additional dates")
   public void selecting_show_less_hides_the_additional_dates()
   {
      DateFilterComponent.clickShowLessLink();
   }

   @Then("they will NOT see the Dates available filter")
   public void they_will_NOT_see_the_Dates_available_filter()
   {
      assertFalse("Date filter is displayed", DateFilterComponent.isDateFilterNotDisplayed());
   }
}
