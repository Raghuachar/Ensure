package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails;

import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails.HomeStayEmergencyComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails.ImportantInformationComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails.MarketingPermisssionComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails.PassengerFormComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.ProgressionbarNavigationComponent;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class PassengerDetailsPage
{
   public final MarketingPermisssionComponent marketPermissionComponent;

   public final ImportantInformationComponent importantInfoComponent;

   public final ProgressionbarNavigationComponent navigationComponent;

   public final HomeStayEmergencyComponent emergencyComponent;

   public final PassengerFormComponent passengerFormComponent;

   public final WCMSComponent wcmsComponent;

   public final MultipleRoomTypeInHolidaySummaryComponent multipleRoomTypeInHolidaySummaryComponent;

   public final HolidaySummaryComponent holidaySummaryComponent;

   public final WebElementWait wait;

   public final Map<String, WebElement> passengerMap;

   public PassengerDetailsPage()
   {
      marketPermissionComponent = new MarketingPermisssionComponent();
      importantInfoComponent = new ImportantInformationComponent();
      navigationComponent = new ProgressionbarNavigationComponent();
      emergencyComponent = new HomeStayEmergencyComponent();
      passengerFormComponent = new PassengerFormComponent();
      wcmsComponent = new WCMSComponent();
      multipleRoomTypeInHolidaySummaryComponent = new MultipleRoomTypeInHolidaySummaryComponent();
      holidaySummaryComponent = new HolidaySummaryComponent();
      wait = new WebElementWait();
      passengerMap = new HashMap<>();
   }

   public Map<String, WebElement> getPassengerPageComponents()
   {
      passengerMap.put("PASSENGER DETAILS", passengerFormComponent.getPageHeadingElement());
      passengerMap.put("Passenger Details (VOLWASSENE 1, VOLWASSENE 2,KIND 3)",
               passengerFormComponent.getPassengerFormElement());
      passengerMap.put("Continue CTA", wcmsComponent.getContinueElement());
      passengerMap.putAll(navigationComponent.getProgressionBarComponents());
      passengerMap.putAll(emergencyComponent.getEmergencyContactComponents());
      // passengerMap.putAll(marketPermissionComponent.getMarketPermissionComponents());
      passengerMap.putAll(importantInfoComponent.getImpInfoComponents());
      return passengerMap;
   }

   public boolean isReservationFeeDisplayed()
   {
      return holidaySummaryComponent.isReservationFeeDisplayed();
   }
}
