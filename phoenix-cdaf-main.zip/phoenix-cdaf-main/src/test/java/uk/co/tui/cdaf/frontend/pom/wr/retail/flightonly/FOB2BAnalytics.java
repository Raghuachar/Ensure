package uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly;

import org.openqa.selenium.JavascriptExecutor;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.FlightSummaryComponent;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.Map;

public class FOB2BAnalytics extends AbstractPage
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(FlightSummaryComponent.class);

   private final WebElementWait wait;

   public String analyticspassengerdetails = "return dataLayer[0].page";

   public String itemanalyticspassengerdetails = "return dataLayer[0].basket.items";

   public String priceanalyticspassengerdetails = "return dataLayer[0].basket.price";

   public FOB2BAnalytics()
   {
      wait = new WebElementWait();
   }

   @SuppressWarnings("unchecked")
   public Map<String, Object> analyticsPaxPage()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      Map<String, Object> analyticsdata;
      analyticsdata = (Map<String, Object>) ((JavascriptExecutor) WebDriverUtils.getDriver())
               .executeScript(analyticspassengerdetails);
      wait.forJSExecutionReadyLazy();
      LOGGER.log(LogLevel.INFO, "analytics pax details:" + analyticsdata);
      return analyticsdata;

   }

   @SuppressWarnings("unchecked")
   public Map<String, Object> itemAnalyticsPaxPage()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      Map<String, Object> analyticsdata;
      analyticsdata = (Map<String, Object>) ((JavascriptExecutor) WebDriverUtils.getDriver())
               .executeScript(itemanalyticspassengerdetails);
      wait.forJSExecutionReadyLazy();
      LOGGER.log(LogLevel.INFO, "analytics iteam details:" + analyticsdata);
      return analyticsdata;

   }

   @SuppressWarnings("unchecked")
   public Map<String, Object> priceAnalyticsPaxPage()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      Map<String, Object> analyticsdata;
      analyticsdata = (Map<String, Object>) ((JavascriptExecutor) WebDriverUtils.getDriver())
               .executeScript(priceanalyticspassengerdetails);
      wait.forJSExecutionReadyLazy();
      LOGGER.log(LogLevel.INFO, "analytics price details:" + analyticsdata);
      return analyticsdata;

   }

}
