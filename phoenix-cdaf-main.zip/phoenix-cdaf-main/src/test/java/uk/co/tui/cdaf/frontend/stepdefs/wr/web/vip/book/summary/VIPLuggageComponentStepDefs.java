package uk.co.tui.cdaf.frontend.stepdefs.wr.web.vip.book.summary;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.vip.book.summary.VipSummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class VIPLuggageComponentStepDefs
{
   public final PackageNavigation packageNavigation;

   public final VipSummaryPage vipSummaryPage;

   public VIPLuggageComponentStepDefs()
   {
      packageNavigation = new PackageNavigation();
      vipSummaryPage = new VipSummaryPage();
   }

   @When("they scroll to below Cabin Class component")
   public void they_scroll_to_below_Cabin_Class_component()
   {
      boolean actual = vipSummaryPage.vipLuggageComponent.isLuggageComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Luggage Component wasn't displayed", actual, true), actual, is(true));
   }

   @Then("they are presented with the Luggage component with following info:")
   public void they_are_presented_with_the_Luggage_component_with_following_info(
            io.cucumber.datatable.DataTable dataTable)
   {
      vipSummaryPage.vipLuggageComponent.getVipSummaryComponentsMap();
   }

   @Given("that a customer is on the Customise page")
   public void that_a_customer_is_on_the_Customise_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they are presented with the Luggage component")
   public void they_are_presented_with_the_Luggage_component()
   {
      vipSummaryPage.vipLuggageComponent.isLuggageComponentDisplayed();
   }

   @Then("that default luggage amount is {int}kg for short, medium and long haul types")
   public void that_default_luggage_amount_is_kg_for_short_medium_and_long_haul_types(Integer int1)
   {
      // will implement this step once it is available
   }

   @Given("there are more than two passengers on the booking")
   public void there_are_more_than_two_passengers_on_the_booking()
   {
      // will implement this step once it is available
   }

   @When("they are presented with the luggage component")
   public void they_are_presented_with_the_luggage_component()
   {
      vipSummaryPage.vipLuggageComponent.isLuggageComponentDisplayed();
   }

   @Then("by default, there are only two passenger luggage options {string}")
   public void by_default_there_are_only_two_passenger_luggage_options(String string)
   {
      vipSummaryPage.vipLuggageComponent.getTwoAdultLuggageMap();
   }

   @When("they select the View All Passengers CTA")
   public void they_select_the_View_All_Passengers_CTA()
   {
      vipSummaryPage.vipLuggageComponent.clickOnMorePassengersButton();
   }

   @Then("the component is expanded to show luggage options for all passengers on the booking")
   public void the_component_is_expanded_to_show_luggage_options_for_all_passengers_on_the_booking()
   {
      boolean actual = vipSummaryPage.vipLuggageComponent.isLuggageComponentExpandDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Expanded Luggage Component wasn't displayed", actual, true), actual, is(true));
   }

   @Then("the price is updated and reflected in the Book Now component")
   public void the_price_is_updated_and_reflected_in_the_Book_Now_component()
   {
      // Will implement this step once it is available
   }

   @When("they select the More Information within the Luggage component")
   public void they_select_the_More_Information_within_the_Luggage_component()
   {
      vipSummaryPage.vipLuggageComponent.clickOnMoreInformation();
   }

   @Then("they will be presented with a modal")
   public void they_will_be_presented_with_a_modal()
   {
      boolean actual = vipSummaryPage.vipLuggageComponent.ismoreInformationPopUpDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "More Information popup wasn't displayed", actual, true), actual, is(true));
   }

}
