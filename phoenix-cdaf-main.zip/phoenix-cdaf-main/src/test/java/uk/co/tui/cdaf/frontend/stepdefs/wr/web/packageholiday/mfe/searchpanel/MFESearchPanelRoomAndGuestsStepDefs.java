package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.*;

public class MFESearchPanelRoomAndGuestsStepDefs
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(MFESearchPanelRoomAndGuestsStepDefs.class);

   private final PackageNavigation packageNavigation;

   private final SearchPanelComponent searchPanelComponent = new SearchPanelComponent();

   private final Map<String, WebElement> searchMap;

   private final SearchResultsPage searchResultsPage;

   public Set<String> windowHandles;

   private String numberOfAdults;

   private String numberOfChildrens;

   private int numberOfRooms;

   private String firstChildAge;

   public MFESearchPanelRoomAndGuestsStepDefs()
   {
      searchMap = new HashMap<>();
      searchResultsPage = new SearchResultsPage();
      packageNavigation = new PackageNavigation();
   }

   @When("they select one of the following {string} on the Search Panel Room & Guests field")
   public void they_select_one_of_the_following_on_the_Search_Panel_Room_Guests_field(String option)
   {
      if (option.equalsIgnoreCase("Room & Guests field"))
      {
         searchPanelComponent.selectRoomAndGuestMFEInputField();
      }
      if (option.equalsIgnoreCase("Passenger icon"))
      {
         searchPanelComponent.selectPassengerIcon();
      }
   }

   @Then("the Room & Guests modal shall be displayed")
   public void the_Room_Guests_modal_shall_be_displayed()
   {
      assertThat("Room and Guests Modal is not displayed   ",
               searchPanelComponent.isRoomAndGuestModalDisplayed(), is(true));
   }

   @Then("the Room & Guests modal shall display the following:")
   public void the_Room_Guests_modal_shall_display_the_following(
            List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(searchResultsPage.searchPanelComponent.getRoomAndGuestsComponentsMFE());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("the number of adults shall be defaulted to {string}")
   public void the_number_of_adults_shall_be_defaulted_to(String string)
   {
      assertThat(String.format("Number of Adults is not defaulted to %s", string),
               searchPanelComponent
                        .getNumberOfAdults(), is(string));
   }

   @Then("the number of children shall be defaulted to {string}")
   public void the_number_of_children_shall_be_defaulted_to(String string)
   {
      assertThat(String.format("Number of Adults is not defaulted to %s", string),
               searchPanelComponent
                        .getNumberOfChildren(), is(string));
   }

   @Then("the {string} stepper icons shall be enabled by the {string} field")
   public void the_stepper_icons_shall_be_enabled_by_the_field(String string, String string2)
   {
      assertThat(String.format("%s stepper icons are not enabled by %s field", string, string2),
               searchPanelComponent
                        .isAdultsPlusMinusStepperEnabled(), is(true));
   }

   @Then("the {string} stepper icon shall be enabled by the {string} field")
   public void the_stepper_icon_shall_be_enabled_by_the_field(String stepper, String paxType)
   {
      assertThat(String.format("%s stepper icons are not enabled by %s field", stepper, paxType),
               searchPanelComponent
                        .isStepperEnabledInRoom(0, stepper, paxType), is(true));
   }

   @Then("the minus and plus stepper icons shall be enabled by the child field")
   public void the_minus_and_plus_stepper_icons_shall_be_enabled_by_the_child_field()
   {
      assertThat("stepper icons are not enabled by child field",
               searchPanelComponent.isChildrenPlusStepperEnabled(), is(true));
   }

   @Then("the {string} stepper icon shall be disabled by the {string} field")
   public void the_stepper_icon_shall_be_disabled_by_the_field(String string, String string2)
   {
      assertThat(String.format("%s stepper icons are not disabled by %s field", string, string2),
               searchPanelComponent
                        .isChildrenMinusStepperEnabled(), is(false));
   }

   @Given("the {string} is viewing the Search Panel Room & Guests modal via the Home page")
   public void the_is_viewing_the_Search_Panel_Room_Guests_modal_via_the_Home_page(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectRoomAndGuestMFEInputField();
   }

   @When("they wish to close the Room & Guests modal")
   public void they_wish_to_close_the_Room_Guests_modal()
   {
      assertThat("Room and Guests Modal is not displayed   ",
               searchPanelComponent.isRoomAndGuestModalDisplayed(), is(true));
   }

   @Then("they can do this by selecting the following options:")
   public void they_can_do_this_by_selecting_the_following_options(List<String> closeModal)
   {
      for (String closeDate : closeModal)
      {
         try
         {
            if (closeDate.equalsIgnoreCase("x"))
            {
               searchResultsPage.searchPanelComponent.closeRoomAndGuestsModalMFE();
            }
            else if (closeDate.equalsIgnoreCase("DONE"))
            {
               searchPanelComponent.selectRoomAndGuestMFEInputField();
               searchResultsPage.searchPanelComponent.clickRoomsDoneButton();
            }
            else if (closeDate.equalsIgnoreCase("select outside of modal (Desktop only)"))
            {
               searchPanelComponent.selectRoomAndGuestMFEInputField();
               searchResultsPage.searchPanelComponent.clickOutsideOfModal();
            }
            assertThat("Room and Guests Modal is not closed   ",
                     searchPanelComponent.isRoomsModalClosed(), is(true));
         }
         catch (Exception e)
         {
            LOGGER.log(LogLevel.INFO, closeDate + "component is not present");
         }
      }
   }

   @Given("the {string} is on the MFE homepage with {string} language")
   public void the_is_on_the_MFE_homepage_with_language(String Customer, String language)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectLanguageMFE(language);
   }

   @Then("the Room & Guests modal shall display the following with respective translated text {string}  {string}  {string}  {string}  {string}  {string}  {string}")
   public void the_Room_Guests_modal_shall_display_the_following_with_respective_translated_text(
            String roomAndGuests, String noOfRooms, String iDontMind, String adults,
            String children017, String clearAll, String done)
   {
      searchPanelComponent.selectRoomAndGuestMFEInputField();
      List<String> expectedTranslations =
               Arrays.asList(roomAndGuests, noOfRooms, iDontMind, adults, children017, clearAll,
                        done);
      searchResultsPage.wait.forJSExecutionReadyLazy();
      List<String> actualTranslations =
               searchResultsPage.searchPanelComponent.getRoomAndGuestsTranslationMFE();
      assertThat("Number of values do not match",
               expectedTranslations.size() == actualTranslations.size(), is(true));
      for (int i = 0; i < expectedTranslations.size(); i++)
      {
         String expected = expectedTranslations.get(i);
         String actual = actualTranslations.get(i);
         assertThat(String.format("translation does not match, expected:%s, actual:%s", expected,
                  actual), expected.equals(actual), is(true));
      }
   }

   @Given("the {string} is viewing the Room & Guests modal")
   public void the_is_viewing_the_Room_Guests_modal(String agent)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectRoomAndGuestMFEInputField();
   }

   @When("they click on the {string} entry field")
   public void they_click_on_the_entry_field(String string)
   {
      searchPanelComponent.clickNumberOfRooms();
   }

   @Then("the {string} dropdown list shall be displayed")
   public void the_dropdown_list_shall_be_displayed(String string)
   {
      assertThat("dropdown not present", searchPanelComponent.roomsDropDownPresent(), is(true));
   }

   @Then("the {string} dropdown list shall display the following options in the order listed below:")
   public void the_dropdown_list_shall_display_the_following_options_in_the_order_listed_below(
            String agent, List<String> options)
   {
      options.forEach(option ->
               assertThat(String.format("option %s not present", option),
                        searchPanelComponent.roomSelectionOptionPresent(option), is(true)));
   }

   @Given("the {string} is on the Room & Guests modal in {string} language")
   public void the_is_on_the_Room_Guests_modal_in_language(String agent, String language)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectLanguageMFE(language);
      searchPanelComponent.selectRoomAndGuestMFEInputField();
   }

   @Given("the Search Panel Room & Guests was set to the default value \\(i.e. {int} Adults {int} Children)")
   public void the_Search_Panel_Room_Guests_was_set_to_the_default_value_i_e_Adults_Children(
            Integer adults, Integer children)
   {
      assertThat("default adults not set",
               adults.toString().equals(searchPanelComponent.getNumberOfAdults()), is(true));
      assertThat("default children not set",
               children.toString().equals(searchPanelComponent.getNumberOfChildren()),
               is(true));
   }

   @Given("they are viewing the Number of rooms\" dropdown list")
   public void they_are_viewing_the_Number_of_rooms_dropdown_list()
   {
      searchPanelComponent.clickNumberOfRooms();
      assertThat("dropdown not present", searchPanelComponent.roomsDropDownPresent(), is(true));
   }

   @When("they select the option {string}")
   public void they_select_the_option(String option)
   {
      searchPanelComponent.clickRoomOption(option);
   }

   @Then("the following translated text will be displayed  {string} {string} {string}")
   public void the_following_translated_text_will_be_displayed(String room1, String adults,
            String children017)
   {
      List<String> expectedTranslations = Arrays.asList(room1, adults, children017);
      List<String> actualTranslations =
               searchResultsPage.searchPanelComponent.getSingleRoomTranslationsMFE();
      assertThat("Number of values do not match",
               expectedTranslations.size() == actualTranslations.size(), is(true));
      for (int i = 0; i < expectedTranslations.size(); i++)
      {
         String expected = expectedTranslations.get(i);
         String actual = actualTranslations.get(i);
         assertThat(String.format("translation does not match, expected:%s, actual:%s", expected,
                  actual), expected.equals(actual), is(true));
      }
   }

   @Given("the {string} is on the Room & Guests modal")
   public void the_is_on_the_Room_Guests_modal(String string)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectRoomAndGuestMFEInputField();
   }

   @Then("the Room and Guests modal shall display a Room component")
   public void the_Room_and_Guests_modal_shall_display_a_Room_component()
   {
      assertThat("Room component is not displayed", searchPanelComponent.roomComponentPresent(),
               is(true));
   }

   @Then("the Room {int} component shall display the following:")
   public void the_Room_component_shall_display_the_following(Integer roomNumber,
            List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap.putAll(
               searchResultsPage.searchPanelComponent.getRoomAndGuestsSingleRoomComponents());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("the number of adults shall be set to {string}")
   public void the_number_of_adults_shall_be_set_to(String noOfAdults)
   {
      assertThat(String.format("adults not set to %s", noOfAdults),
               noOfAdults.equals(searchPanelComponent.getNumberOfAdults()), is(true));
   }

   @Then("the number of children shall be set to {string}")
   public void the_number_of_children_shall_be_set_to(String noOfChildren)
   {
      assertThat(String.format("children not set to %s", noOfChildren),
               noOfChildren.equals(searchPanelComponent.getNumberOfChildren()), is(true));
   }

   @Then("the {string} and Room {int} component shall be retained")
   public void the_and_Room_component_shall_be_retained(String string, Integer int1)
   {
      assertThat("room 1 is not retained", searchPanelComponent.singleRoomRetained(), is(true));
   }

   @Given("they are viewing the Room {int} component")
   public void they_are_viewing_the_Room_component(Integer int1)
   {
      searchPanelComponent.clickRoomOption("1");
   }

   @When("they select the {string} stepper by the Adults field")
   public void they_select_the_stepper_by_the_Adults_field(String stepper)
   {
      numberOfAdults = searchPanelComponent.getNumberOfAdults();
      searchPanelComponent.clickAdultsStepper(stepper, 1);
   }

   @Then("the number of adults within the Room {int} component shall increase by {int}")
   public void the_number_of_adults_within_the_Room_component_shall_increase_by(Integer int1,
            Integer int2)
   {
      assertThat("number of adults not increased by 1",
               Integer.parseInt(searchPanelComponent.getNumberOfAdults()) == (Integer.parseInt(
                        numberOfAdults) + int2), is(true));
      numberOfAdults = searchPanelComponent.getNumberOfAdults();
   }

   @Then("all the data that has been entered for Room {int} shall be retained on the Room & Guests modal")
   public void all_the_data_that_has_been_entered_for_Room_shall_be_retained_on_the_Room_Guests_modal(
            Integer int1)
   {
      assertThat("data not retained",
               searchPanelComponent.getNumberOfAdults().equals(numberOfAdults),
               is(true));
   }

   @Then("the {string} field in the Search Panel Room & Guests entry field shall also be increased by {int}")
   public void the_field_in_the_Search_Panel_Room_Guests_entry_field_shall_also_be_increased_by(
            String string, Integer int1)
   {
      assertThat("entry field not increased",
               searchPanelComponent.getRoomAndGuestsMFEInputText().startsWith(numberOfAdults),
               is(true));
   }

   @Then("the number of adults within the Room {int} component can only be increased to {int}")
   public void the_number_of_adults_within_the_Room_component_can_only_be_increased_to(Integer int1,
            Integer int2)
   {
      searchPanelComponent.clickAdultsStepper("+", 6);
      numberOfAdults = searchPanelComponent.getNumberOfAdults();
      assertThat("number of adults is not 9", numberOfAdults.equals(int2.toString()), is(true));
   }

   @Then("when {int} adults have been reached then the {string} stepper icon by the {string} field shall be disabled")
   public void when_adults_have_been_reached_then_the_stepper_icon_by_the_field_shall_be_disabled(
            Integer int1, String string, String string2)
   {
      assertThat("number of adults is not 9", numberOfAdults.equals(int1.toString()), is(true));
      assertThat("plus stepper is not disabled", searchPanelComponent.isAdultPlusStepperEnabled(),
               is(false));
   }

   @Then("the number of adults within the Room {int} component shall decrease by {int}")
   public void the_number_of_adults_within_the_Room_component_shall_decrease_by(Integer int1,
            Integer int2)
   {
      assertThat("number of adults not decreased by 1",
               Integer.parseInt(searchPanelComponent.getNumberOfAdults()) == (Integer.parseInt(
                        numberOfAdults) - int2), is(true));
   }

   @Then("the {string} stepper icon shall be disabled by the {string} field if the {string} field has been set to {int}")
   public void the_stepper_icon_shall_be_disabled_by_the_field_if_the_field_has_been_set_to(
            String string, String string2, String string3, Integer int1)
   {
      numberOfAdults = searchPanelComponent.getNumberOfAdults();
      assertThat("number of adults is not 1", numberOfAdults.equals(int1.toString()), is(true));
      assertThat("minus stepper is not disabled",
               searchPanelComponent.isAdultMinusStepperEnabled(), is(false));
   }

   @Then("the {string} field in the Search Panel Room & Guests entry field shall also be decreased by {int}")
   public void the_field_in_the_Search_Panel_Room_Guests_entry_field_shall_also_be_decreased_by(
            String string, Integer int1)
   {
      assertThat("entry field not decreased",
               searchPanelComponent.getRoomAndGuestsMFEInputText().contains(numberOfAdults),
               is(true));
   }

   @Then("the the text in the Search Panel Room & Guests entry field shall be set to {string} if the number of Adults is decreased to {int}")
   public void the_the_text_in_the_Search_Panel_Room_Guests_entry_field_shall_be_set_to_if_the_number_of_Adults_is_decreased_to(
            String adult, Integer int1)
   {
      assertThat("number of adults not 1",
               searchPanelComponent.getRoomAndGuestsMFEInputText().startsWith(int1.toString()),
               is(true));
      assertThat("adult text not set",
               searchPanelComponent.getRoomAndGuestsMFEInputAdultText().equals(adult), is(true));
   }

   @When("they select an option greater than {int}")
   public void they_select_an_option_greater_than(Integer option)
   {
      searchPanelComponent.clickRoomOption(Integer.toString(option + 1));
   }

   @Then("the Room and Guests modal shall display a separate room component for the room number option selected from the dropdown list \\(e.g. if {int} rooms were selected from the dropdown list then {int} rooms components shall be displayed)")
   public void the_Room_and_Guests_modal_shall_display_a_separate_room_component_for_the_room_number_option_selected_from_the_dropdown_list_e_g_if_rooms_were_selected_from_the_dropdown_list_then_rooms_components_shall_be_displayed(
            Integer int1, Integer int2)
   {
      assertThat(String.format("%s rooms are not selected", int1),
               searchPanelComponent.getNumberOfRoomsMFE().equals(int1.toString()),
               is(true));
      assertThat(String.format("%s room components are not displayed", int2),
               searchPanelComponent.getNumberOfRoomsComponentMFE().equals(int2),
               is(true));
   }

   @Then("each room component shall contain the following:")
   public void each_room_component_shall_contain_the_following(List<String> components)
   {
      numberOfRooms = Integer.parseInt(searchPanelComponent.getNumberOfRoomsMFE());
      Map<String, List<SelenideElement>> allRoomComponents =
               searchResultsPage.searchPanelComponent.getAllRoomComponents();
      components.forEach(component ->
      {
         final List<SelenideElement> elements = allRoomComponents.get(component);
         assertThat(String.format("number of %s components is not %s", component, numberOfRooms),
                  elements.size() == numberOfRooms, is(true));

      });
   }

   @Then("the number of adults in the Room {int} component shall be set to {string}")
   public void the_number_of_adults_in_the_Room_component_shall_be_set_to(Integer int1,
            String string)
   {
      assertThat(String.format("number of adults in room %s is not %s", int1, string),
               searchPanelComponent.getNumberOfAdults().equals(string), is(true));
   }

   @Then("the number of adults for each subsequent room component added shall be set to {string}")
   public void the_number_of_adults_for_each_subsequent_room_component_added_shall_be_set_to(
            String noOfAdults)
   {
      for (int i = 1; i < numberOfRooms; i++)
      {
         assertThat(String.format("number of adults in room %s is not %s", i + 1, noOfAdults),
                  searchPanelComponent.getNumberOfAdultsInRoomIndex(i).equals(noOfAdults),
                  is(true));
      }
   }

   @Then("the number of children in every room component shall be set to {int}")
   public void the_number_of_children_in_every_room_component_shall_be_set_to(Integer int1)
   {
      for (int i = 0; i < numberOfRooms; i++)
      {
         assertThat(String.format("number of children in room %s is not %s", i + 1, int1),
                  searchPanelComponent.getNumberOfChildrenInRoom(i).equals(int1.toString()),
                  is(true));
      }
   }

   @Then("the {string} stepper icon shall be enabled by the {string} field in all the room components")
   public void the_stepper_icon_shall_be_enabled_by_the_field_in_all_the_room_components(
            String stepperType, String paxType)
   {
      for (int i = 0; i < numberOfRooms; i++)
      {
         assertThat(String.format("%s %s stepper is not enabled in room %s", paxType, stepperType,
                           i + 1),
                  searchPanelComponent.isStepperEnabledInRoom(i, stepperType, paxType),
                  is(true));
      }
   }

   @Then("the {string} stepper icon shall be enabled by the {string} field in the Room {int} component")
   public void the_stepper_icon_shall_be_enabled_by_the_field_in_the_Room_component(
            String stepperType, String paxType, Integer roomNumber)
   {
      assertThat(String.format("%s %s stepper is not enabled in room %s", paxType, stepperType,
                        roomNumber),
               searchPanelComponent.isStepperEnabledInRoom(roomNumber - 1, stepperType,
                        paxType), is(true));
   }

   @Then("the {string} stepper icon shall be disabled by the {string} field in all the Room components where the field has been set to {int} \\(i.e. all other rooms bar Room {int})")
   public void the_stepper_icon_shall_be_disabled_by_the_field_in_all_the_Room_components_where_the_field_has_been_set_to_i_e_all_other_rooms_bar_Room(
            String stepperType, String paxType, Integer noOfAdults, Integer int1)
   {
      for (int i = int1; i < numberOfRooms; i++)
      {
         if (searchPanelComponent.getNumberOfAdultsInRoomIndex(i).equals(noOfAdults.toString()))
         {
            assertThat(
                     String.format("%s %s stepper is not disabled in room %s", paxType, stepperType,
                              i + 1),
                     searchPanelComponent.isStepperEnabledInRoom(i, stepperType, paxType),
                     is(false));
         }
      }
   }

   @Then("the {string} stepper icon shall be disabled by the {string} field in all room components")
   public void the_stepper_icon_shall_be_disabled_by_the_field_in_all_room_components(
            String stepperType, String paxType)
   {
      for (int i = 0; i < numberOfRooms; i++)
      {
         assertThat(String.format("%s %s stepper is not disabled in room %s", paxType, stepperType,
                           i + 1),
                  searchPanelComponent.isStepperEnabledInRoom(i, stepperType, paxType),
                  is(false));
      }
   }

   @Then("the Room & Guests search panel entry field shall be updated to reflect the number of adults that have been added to all the rooms")
   public void the_Room_Guests_search_panel_entry_field_shall_be_updated_to_reflect_the_number_of_adults_that_have_been_added_to_all_the_rooms()
   {
      int adults = 0;
      for (int i = 0; i < numberOfRooms; i++)
      {
         adults += Integer.parseInt(searchPanelComponent.getNumberOfAdultsInRoomIndex(i));
      }
      numberOfAdults = Integer.toString(adults);
      assertThat(String.format("number of adults in search panel is not %s", numberOfAdults),
               searchPanelComponent.getRoomAndGuestsMFEInputAdultNumber().equals(numberOfAdults),
               is(true));
   }

   @Then("the data entered for the number of rooms and Room components shall be retained")
   public void the_data_entered_for_the_number_of_rooms_and_Room_components_shall_be_retained()
   {
      searchResultsPage.searchPanelComponent.clickRoomsDoneButton();
      searchPanelComponent.selectRoomAndGuestMFEInputField();
      assertThat("number of rooms is not retained",
               searchPanelComponent.getNumberOfRoomsTextMFE()
                        .equals(Integer.toString(numberOfRooms)), is(true));
      assertThat("number of adults in search panel is not retained",
               searchPanelComponent.getRoomAndGuestsMFEInputAdultNumber()
                        .equals(numberOfAdults),
               is(true));
   }

   @When("they select the option {string} option from the number of rooms field")
   public void they_select_the_option_option_from_the_number_of_rooms_field_field(String option)
   {
      searchPanelComponent.clickRoomOption(option);
   }

   @Given("they are viewing any Room component")
   public void they_are_viewing_any_Room_component()
   {
      searchPanelComponent.clickRoomOption("3");
   }

   @When("they select the {string} stepper by the Adults field in that room component")
   public void they_select_the_stepper_by_the_Adults_field_in_that_room_component(String stepper)
   {
      numberOfAdults = searchPanelComponent.getNumberOfAdultsInRoomIndex(2);
      searchPanelComponent.clickAdultStepperSpecificRoomMFE(stepper, 1, 2);
   }

   @Then("the number of adults within that room component shall increase by {int}")
   public void the_number_of_adults_within_that_room_component_shall_increase_by(Integer int1)
   {
      assertThat("number of adults is not increased by 1",
               searchPanelComponent.getNumberOfAdultsInRoomIndex(2)
                        .equals(Integer.toString(Integer.parseInt(numberOfAdults) + 1)), is(true));
      numberOfRooms = Integer.parseInt(searchPanelComponent.getNumberOfRoomsTextMFE());
      numberOfAdults = searchPanelComponent.getRoomAndGuestsMFEInputAdultNumber();
   }

   @Then("all the data that has been entered in the room component\\(s) shall be retained on the Room & Guests modal")
   public void all_the_data_that_has_been_entered_in_the_room_component_s_shall_be_retained_on_the_Room_Guests_modal()
   {
      searchResultsPage.searchPanelComponent.clickRoomsDoneButton();
      searchPanelComponent.selectRoomAndGuestMFEInputField();
      assertThat("number of rooms is not retained",
               searchPanelComponent.getNumberOfRoomsTextMFE()
                        .equals(Integer.toString(numberOfRooms)), is(true));
   }

   @Then("the number of adults within the room and guests component can only be increased to {int}")
   public void the_number_of_adults_within_the_room_and_guests_component_can_only_be_increased_to(
            Integer int1)
   {
      searchPanelComponent.clickAdultStepperSpecificRoomMFE("+", 4, 2);
      assertThat("number of adults is not increased to 9",
               searchPanelComponent.getRoomAndGuestsMFEInputAdultNumber().equals(int1.toString()),
               is(true));
      numberOfAdults = searchPanelComponent.getRoomAndGuestsMFEInputAdultNumber();
   }

   @Given("they are viewing any Room component with {string} stepper enabled for {string} field")
   public void they_are_viewing_any_Room_component_with_stepper_enabled_for_field(String stepper,
            String paxType)
   {
      searchPanelComponent.clickRoomOption("3");
      numberOfAdults = searchPanelComponent.getNumberOfAdultsInRoomIndex(2);
      searchPanelComponent.clickAdultStepperSpecificRoomMFE("+", 1, 2);
      assertThat("stepper is not enabled",
               searchPanelComponent.isStepperEnabledInRoom(2, stepper, paxType),
               is(true));
   }

   @Then("the number of adults within the given room component shall decrease by {int}")
   public void the_number_of_adults_within_the_given_room_component_shall_decrease_by(Integer int1)
   {
      assertThat(String.format("number of adults is not decreased by %s", int1),
               searchPanelComponent.getNumberOfAdultsInRoomIndex(2)
                        .equals(Integer.toString(Integer.parseInt(numberOfAdults) - int1)),
               is(true));
      numberOfRooms = Integer.parseInt(searchPanelComponent.getNumberOfRoomsTextMFE());
      numberOfAdults = searchPanelComponent.getRoomAndGuestsMFEInputAdultText();
   }

   @Then("the {string} stepper icon shall be disabled by the {string} field for the given room component if the {string} field has been set to {int}")
   public void the_stepper_icon_shall_be_disabled_by_the_field_for_the_given_room_component_if_the_field_has_been_set_to(
            String stepper, String paxType, String string3, Integer int1)
   {
      assertThat(String.format("number of %s is not %s", string3, int1),
               searchPanelComponent.getNumberOfAdultsInRoomIndex(2).equals(int1.toString()),
               is(true));
      assertThat("stepper not disabled",
               searchPanelComponent.isStepperEnabledInRoom(2, stepper, paxType),
               is(false));
   }

   @Given("they are viewing a room component")
   public void they_are_viewing_a_room_component()
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectRoomAndGuestMFEInputField();
   }

   @Given("the room component children entry field is set to {string}")
   public void the_room_component_children_entry_field_is_set_to(String noOfChildren)
   {
      assertThat(String.format("children not set to %s", noOfChildren),
               noOfChildren.equals(searchPanelComponent.getNumberOfChildren()), is(true));
   }

   @When("they select the {string} stepper by the children field")
   public void they_select_the_stepper_by_the_field(String stepper)
   {
      numberOfChildrens = searchPanelComponent.getNumberOfChildren();
      searchPanelComponent.clickChildrenStepper(stepper, 1);
   }

   @Then("the room component shall expand")
   public void the_room_component_shall_expand()
   {
      assertThat("Child component is not displayed",
               searchPanelComponent.childComponentPresent(), is(true));
   }

   @Then("the room component shall display the following additional information:")
   public void the_room_component_shall_display_the_following_additional_information(
            List<String> components)
   {
      searchResultsPage.wait.forJSExecutionReadyLazy();
      searchMap
               .putAll(searchResultsPage.searchPanelComponent.getRoomAndGuestsChildRoomComponents());
      components.forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element = searchMap.get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Then("the children field shall be set to {string}")
   public void the_children_field_shall_be_set_to(String string)
   {
      numberOfChildrens = searchPanelComponent.getNumberOfChildren();
      assertThat("number of children is not 1", numberOfChildrens.equals(string), is(true));
   }

   @Then("all the changes made to the Room & Guests modal shall be retained")
   public void all_the_changes_made_to_the_Room_Guests_modal_shall_be_retained()
   {
      assertThat("room 1 is not retained", searchPanelComponent.childComponentPresent(),
               is(true));
   }

   @Then("the Search Panel Room & Guests field shall be updated to reflect the addition of the child")
   public void the_Search_Panel_Room_Guests_field_shall_be_updated_to_reflect_the_addition_of_the_child()
   {
      searchPanelComponent.clickChildrenOption("1");
      assertThat("entry field not increased",
               searchPanelComponent.getRoomAndGuestsMFEInputChildText().startsWith("1"), is(true));
   }

   @Then("the following translated text will displayed  {string} {string} {string}")
   public void the_following_translated_text_will_displayed(String childAges, String child,
            String chooseAge)
   {
      List<String> expectedTranslations = Arrays.asList(childAges, child, chooseAge);
      List<String> actualTranslations =
               searchResultsPage.searchPanelComponent.getChildTranslationsMFE();
      assertThat("Number of values do not match",
               expectedTranslations.size() == actualTranslations.size(), is(true));
      for (int i = 0; i < expectedTranslations.size(); i++)
      {
         String expected = expectedTranslations.get(i);
         String actual = actualTranslations.get(i);
         assertThat(
                  String.format("translation does not match, expected:%s, actual:%s", expected,
                           actual),
                  expected.equals(actual), is(true));
      }
   }

   @Given("they are a viewing a room component in {string} language")
   public void they_are_a_viewing_a_room_component(String language)
   {
      packageNavigation.navigateToHoldaySearchPage();
      searchPanelComponent.selectLanguageMFE(language);
      searchPanelComponent.selectRoomAndGuestMFEInputField();
   }

   @Then("the child dropdown list shall be displayed")
   public void the_child_dropdown_list_shall_be_displayed()
   {
      assertThat("dropdown not present", searchPanelComponent.childrenDropDownPresent(),
               is(true));
   }

   @Then("the child dropdown list shall display the following values:")
   public void the_child_dropdown_list_shall_display_the_following_values(List<String> options)
   {
      options.forEach(option ->
               assertThat(String.format("option %s not present", option),
                        searchPanelComponent.childrenSelectionOptionPresent(option), is(true)));
   }

   @When("they select an age from the child dropdown list for the given room")
   public void they_select_an_age_from_the_child_dropdown_list_for_the_given_room()
   {
      searchPanelComponent.clickChildrenOption("1");
   }

   @Then("the child dropdown list shall be populated with the selected child dropdown list value")
   public void the_child_field_shall_be_populated_with_the_selected_child_dropdown_list_value()
   {
      String noOfChildren = "1";
      assertThat(String.format("children not set to %s", noOfChildren),
               noOfChildren.equals(searchPanelComponent.getNumberOfChildren()), is(true));
   }

   @Then("the selected child value for the given room shall be retained")
   public void the_selected_child_value_for_the_given_room_shall_be_retained()
   {
      assertThat("room 1 is not retained", searchPanelComponent.childComponentPresent(),
               is(true));
   }

   @When("the room component Children entry field is greater than zero")
   public void the_room_component_Children_entry_field_is_greater_than_zero()
   {
      searchPanelComponent.clickChildrenOption("1");
   }

   @Then("the Children field shall be incremented by {int}")
   public void the_Children_field_shall_be_incremented_by(Integer int1)
   {
      numberOfChildrens = searchPanelComponent.getNumberOfChildren();
      assertThat("number of children is not 1", numberOfChildrens.equals(int1.toString()),
               is(true));
   }

   @Then("the number of children within that room component can only be increased to {int}")
   public void the_number_of_children_within_that_room_component_can_only_be_increased_to(
            Integer int1)
   {
      searchPanelComponent.clickAdultsStepper("-", 1);
      searchPanelComponent.clickChildrenStepper("+", int1);
   }

   @Then("when eight children have been reached then the plus stepper icon by the children field shall be disabled")
   public void when_eight_children_have_been_reached_then_the_plus_stepper_icon_by_the_children_field_shall_be_disabled()
   {
      assertThat("stepper icons are enabled by field",
               searchPanelComponent.isChildrenPlusStepperEnabled(), is(false));
   }

   @Given("there is only one child added to the room component")
   public void there_is_only_one_child_added_to_the_room_component()
   {
      searchPanelComponent.clickChildrenStepper("+", 1);
   }

   @When("they select the {string} stepper by the children entry field")
   public void they_select_the_stepper_by_the_children_entry_field(String string)
   {
      searchPanelComponent.clickChildrenStepper(string, 1);
   }

   @Then("the children field within the given room component shall decrease by one and be set to {int}")
   public void the_children_field_within_the_given_room_component_shall_decrease_by_one_and_be_set_to(
            Integer int1)
   {
      assertThat(String.format("children not set to %s", int1),
               int1.toString().equals(searchPanelComponent.getNumberOfChildren()), is(true));
   }

   @Then("the Child ages on return date text shall not be displayed")
   public void the_Child_ages_on_return_date_text_shall_not_be_displayed()
   {
      assertThat("Children header present", searchPanelComponent.childrenHeaderDisplayed(),
               is(true));
   }

   @Then("the Child text and entry field shall not be displayed")
   public void the_Child_text_and_entry_field_shall_not_be_displayed()
   {
      assertThat("Children text present", searchPanelComponent.childrenTextDisplayed(),
               is(true));
   }

   @Then("all changes made to the Room & Guests modal shall be retained")
   public void all_changes_made_to_the_Room_Guests_modal_shall_be_retained()
   {
      assertThat("Children header present", searchPanelComponent.childrenHeaderDisplayed(),
               is(true));
   }

   @Then("the Search Panel Room & Guests field shall be updated to reflect the removal of the child")
   public void the_Search_Panel_Room_Guests_field_shall_be_updated_to_reflect_the_removal_of_the_child()
   {
      assertThat("entry field not increased",
               searchPanelComponent.getRoomAndGuestsMFEInputText().startsWith("2"), is(true));
   }

   @Then("the children field within the given room component shall decrease by {int}")
   public void the_children_field_within_the_given_room_component_shall_decrease_by(Integer int1)
   {
      assertThat("Children header present", searchPanelComponent.childrenHeaderDisplayed(),
               is(true));
   }

   @Then("the room component shall remove the last Child x title and entry field")
   public void the_room_component_shall_remove_the_last_Child_x_title_and_entry_field()
   {
      assertThat("Children text present", searchPanelComponent.childrenTextDisplayed(),
               is(true));
      assertThat("dropdown not present", searchPanelComponent.childrenDropDownDisplayed(),
               is(true));
   }

   @Then("the minus stepper icon shall be disabled by the children field")
   public void the_minus_stepper_icon_shall_be_disabled_by_the_children_field()
   {
      assertThat("stepper icons are not disabled by field",
               searchPanelComponent.isChildrenMinusStepperEnabled(), is(false));
   }

   @Then("the minus stepper icon shall be disabled by the children field if children field has been set to zero")
   public void the_stepper_icon_shall_be_disabled_by_the_children_field_if_children_field_has_been_set_to_zero()
   {
      assertThat("stepper icons are not disabled by field",
               searchPanelComponent.isChildrenMinusStepperEnabled(), is(false));
   }

   @Given("they had previously selected the {string} option")
   public void they_had_previously_selected_the_option(String iDontMind)
   {
      searchPanelComponent.clickRoomOption(iDontMind);
   }

   @Given("they had previously entered Adults & Children for this option")
   public void they_had_previously_entered_Adults_Children_for_this_option()
   {
      searchPanelComponent.clickAdultsStepper("+", 1);
      searchPanelComponent.clickChildrenStepper("+", 1);
   }

   @Given("they have entered the ages for the children")
   public void they_have_entered_the_ages_for_the_children()
   {
      searchPanelComponent.clickChildrenOption("10");
      numberOfAdults = searchPanelComponent.getNumberOfAdults();
      numberOfChildrens = searchPanelComponent.getNumberOfChildren();
      firstChildAge = searchPanelComponent.getFirstChildAge();
   }

   @When("they select any number of rooms greater than or equal to {int}")
   public void they_select_any_number_of_rooms_greater_than_or_equal_to(Integer int1)
   {
      searchPanelComponent.clickRoomOption("2");
   }

   @Then("the number of rooms they have selected shall be displayed")
   public void the_number_of_rooms_they_have_selected_shall_be_displayed()
   {
      assertThat("2 rooms not displayed", searchPanelComponent.getNumberOfRoomsMFE().equals("2"),
               is(true));
   }

   @Then("the number of adults, children, children ages they entered for the {string} option shall be added to room {int}")
   public void the_number_of_adults_children_children_ages_they_entered_for_the_option_shall_be_added_to_room(
            String iDontMind, Integer room1)
   {
      assertThat(String.format(
                        "Number of adults in room %s is not equal to number of adults in %s option", room1,
                        iDontMind),
               searchPanelComponent.getNumberOfAdultsInRoomIndex(0).equals(numberOfAdults),
               is(true));
      assertThat(String.format(
                        "Number of children in room %s is not equal to number of adults in %s option", room1,
                        iDontMind),
               searchPanelComponent.getNumberOfChildrenInRoom(0).equals(numberOfChildrens),
               is(true));
      assertThat(String.format("Child age is not %s", firstChildAge),
               searchPanelComponent.getFirstChildAge().equals(firstChildAge),
               is(true));

   }

   @Then("all of the other rooms shall be defaulted to {int} Adult & {int} Children")
   public void all_of_the_other_rooms_shall_be_defaulted_to_Adult_Children(Integer adults,
            Integer children)
   {
      assertThat(String.format("Other rooms not defaulted to %s adults & %s children", adults,
               children), searchPanelComponent.getNumberOfAdultsInRoomIndex(1)
               .equals(adults.toString()) && searchPanelComponent.getNumberOfChildrenInRoom(1)
               .equals(children.toString()), is(true));
   }

   @Given("they had previously selected one or more rooms")
   public void they_had_previously_selected_one_or_more_rooms()
   {
      searchPanelComponent.clickRoomOption("2");
   }

   @Given("they had previously entered Adults, Children & Children ages for one or more of the room options")
   public void they_had_previously_entered_Adults_Children_Children_ages_for_one_or_more_of_the_room_options()
   {
      searchPanelComponent.clickAdultStepperSpecificRoomMFE("+", 1, 0);
      searchPanelComponent.clickChildrenStepperSpecificRoomMFE("+", 1, 0);
      searchPanelComponent.clickChildrenOption("5");
   }

   @When("they select any additional rooms")
   public void they_select_any_additional_rooms()
   {
      numberOfAdults = searchPanelComponent.getNumberOfAdultsInRoomIndex(0);
      numberOfChildrens = searchPanelComponent.getNumberOfChildrenInRoom(0);
      firstChildAge = searchPanelComponent.getFirstChildAge();
      searchPanelComponent.clickRoomOption("3");
   }

   @Then("the adults, children and child ages they previously entered in their earlier selected rooms shall be retained")
   public void the_adults_children_and_child_ages_they_previously_entered_in_their_earlier_selected_rooms_shall_be_retained()
   {
      assertThat("Adult value is retained",
               searchPanelComponent.getNumberOfAdultsInRoomIndex(0).equals(numberOfAdults),
               is(true));
      assertThat("Child value is retained",
               searchPanelComponent.getNumberOfChildrenInRoom(0).equals(numberOfChildrens),
               is(true));
      assertThat("Child age is retained",
               searchPanelComponent.getFirstChildAge().equals(firstChildAge), is(true));
   }

   @When("they remove one or more of the previously selected rooms")
   public void they_remove_one_or_more_of_the_previously_selected_rooms()
   {
      numberOfAdults = searchPanelComponent.getNumberOfAdultsInRoomIndex(0);
      numberOfChildrens = searchPanelComponent.getNumberOfChildrenInRoom(0);
      firstChildAge = searchPanelComponent.getFirstChildAge();
      searchPanelComponent.clickRoomOption("1");
   }

   @Then("the adults, children and child ages they previously entered in the rooms that have not been removed shall be retained")
   public void the_adults_children_and_child_ages_they_previously_entered_in_the_rooms_that_have_not_been_removed_shall_be_retained()
   {
      assertThat("Adult value is retained",
               searchPanelComponent.getNumberOfAdultsInRoomIndex(0).equals(numberOfAdults),
               is(true));
      assertThat("Child value is retained",
               searchPanelComponent.getNumberOfChildrenInRoom(0).equals(numberOfChildrens),
               is(true));
      assertThat("Child age is retained",
               searchPanelComponent.getFirstChildAge().equals(firstChildAge), is(true));
   }

   @When("they then select the {string} option")
   public void they_then_select_the_option(String iDontMind)
   {
      numberOfAdults = searchPanelComponent.getNumberOfAdultsInRoomIndex(0);
      numberOfChildrens = searchPanelComponent.getNumberOfChildrenInRoom(0);
      firstChildAge = searchPanelComponent.getFirstChildAge();
      searchPanelComponent.clickRoomOption(iDontMind);
   }

   @Then("the adults, children and child ages they previously entered in Room {int} shall be retained for the {string} option")
   public void the_adults_children_and_child_ages_they_previously_entered_in_Room_shall_be_retained_for_the_option(
            Integer int1, String string)
   {
      assertThat("Adult value is retained",
               searchPanelComponent.getNumberOfAdultsInRoomIndex(0).equals(numberOfAdults),
               is(true));
      assertThat("Child value is retained",
               searchPanelComponent.getNumberOfChildrenInRoom(0).equals(numberOfChildrens),
               is(true));
      assertThat("Child age is retained",
               searchPanelComponent.getFirstChildAge().equals(firstChildAge), is(true));
   }

   @Given("they have added one or more children to any room")
   public void they_have_added_one_or_more_children_to_any_room()
   {
      searchPanelComponent.clickChildrenStepper("+", 1);
   }

   @When("they do not enter child ages in the child entry fields and click on done button")
   public void they_do_not_enter_child_ages_in_the_child_entry_fields_and_click_on_done_button()
   {
      searchPanelComponent.clickDoneButton();
   }

   @Then("following translated error message shall be displayed {string}")
   public void following_translated_error_message_shall_be_displayed(String string)
   {

      assertEquals("Translated error message not displayed",
               searchResultsPage.searchPanelComponent.getChildrenAgeNotEnteredErrorMessage(),
               string);
   }

   @Then("all the child fields that do not have a child age shall be outlined in red")
   public void all_the_child_fields_that_do_not_have_a_child_age_shall_be_outlined_in_red()
   {
      assertTrue("Children red border not displayed",
               searchPanelComponent.isChildrenAgeRedBorderDisplayed());
   }

   @Then("the child entry fields that do not have a child age shall be populated with an explanation mark and the text")
   public void the_child_entry_fields_that_do_not_have_a_child_age_shall_be_populated_with_an_explanation_mark_and_the_text()
   {
      assertTrue("Children explanation mark not displayed",
               searchPanelComponent.isChildrenExplanationMarkDisplayed());
      assertTrue("Choose age text not displayed",
               searchPanelComponent.isChildrenAgeSelectionDisplayed());
   }

   @Then("the Customer shall not be able to exit the modal until they have corrected the error")
   public void the_shall_not_be_able_to_exit_the_modal_until_they_have_corrected_the_error()
   {
      searchPanelComponent.clickDoneButton();
      assertTrue("Room and Guests Modal is not displayed",
               searchPanelComponent.isRoomAndGuestModalDisplayed());
   }

   @Then("the SEARCH button shall be disabled")
   public void the_SEARCH_button_shall_be_disabled()
   {
      assertFalse("search button enabled",
               searchPanelComponent.searchButtonEnabled());
   }

   @Given("they have added more children than adults to any room")
   public void they_have_added_more_children_than_adults_to_any_room()
   {
      searchPanelComponent.clickChildrenStepper("+", 3);
   }

   @When("they set all the child ages to those of an infant to {int} or {int}")
   public void they_set_all_the_child_ages_to_those_of_an_infant_to(Integer int1, Integer int2)
   {
      searchPanelComponent.clickChildrenOptions(int1.toString(), 1);
      searchPanelComponent.clickChildrenOptions(int2.toString(), 2);
      searchPanelComponent.clickChildrenOptions(int1.toString(), 3);
   }

   @When("all the child fields where an infant age has been entered shall be outlined in red")
   public void all_the_child_fields_where_an_infant_age_has_been_entered_shall_be_outlined_in_red()
   {
      assertTrue("Children red border not displayed",
               searchPanelComponent.isChildrenAgeRedBorderDisplayed());
   }

   @When("the child entry fields where an infant age has been entered shall be populated with an explanation mark and the infant age")
   public void the_child_entry_fields_where_an_infant_age_has_been_entered_shall_be_populated_with_an_explanation_mark_and_the_infant_age()
   {
      assertTrue("Children explanation mark not displayed",
               searchPanelComponent.isChildrenExplanationMarkDisplayed());
      assertTrue("Choose age text not displayed",
               searchPanelComponent.isChildrenAgeSelectionDisplayed());
   }

   @Given("they have selected I dont mind in the Number of rooms field and they add {int} passengers")
   public void they_have_selected_in_the_field(Integer int1)
   {
      searchPanelComponent.clickAdultsStepper("+", int1);
   }

   @Then("a greater than nine pax error message shall be displayed")
   public void a_greater_than_nine_pax_error_message_shall_be_displayed()
   {
      assertTrue("Children error message not displayed",
               searchPanelComponent.adultAndInfantErrorMessageDisplayed());
   }

   @Then("the SEARCH button will work as intended as the limit {int} will be based on pax amount and not the error messaging displaying.")
   public void the_SEARCH_button_will_work_as_intended_as_the_limit_will_be_based_on_pax_amount_and_not_the_error_messaging_displaying(
            int pax)
   {
      assertTrue("Children error message not displayed",
               searchPanelComponent.adultAndInfantErrorMessageDisplayed());
      searchPanelComponent.clickDoneButton();
      assertEquals("number of adults not same",
               searchPanelComponent.getRoomAndGuestsMFEInputValue(), pax);
   }

   @When("they select {int} rooms")
   public void they_select_rooms(Integer int1)
   {
      searchPanelComponent.clickRoomOption(int1.toString());
   }

   @Then("they shall be positioned to the top of the modal with a scroll animation")
   public void they_shall_be_positioned_to_the_top_of_the_modal_with_a_scroll_animation()
   {
      assertTrue("Pax header not displayed", searchPanelComponent.scrolledToMfePaxHeader());
   }

   @Given("they have added more than {int} pax. to their booking")
   public void they_have_added_more_than_pax_to_their_booking(Integer int1)
   {
      searchPanelComponent.clickAdultsStepper("+", int1);
   }

   @When("they click on the hyperlink within the error message")
   public void they_click_on_the_hyperlink_within_the_error_message()
   {
      searchPanelComponent.clickChildrenErrorLink();
   }

   @Then("the hyperlink within the error message shall be displayed")
   public void the_hyperlink_within_the_error_message_shall_be_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      String actualErrorMessageText;
      String expectedErrorMessageText;
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> dataMap : dataTableTemp)
      {
         actualErrorMessageText = searchPanelComponent.childrenErrorMessageLinkText().getText();
         expectedErrorMessageText = dataMap.get("Error message Item");
         assertEquals("Error Message is not matching ", expectedErrorMessageText.toLowerCase(),
                  actualErrorMessageText.toLowerCase());
      }
   }

   @Then("the source market groups page shall open on a new browser tab and the page {string} shall be displayed in the relevant source market language")
   public void the_source_market_groups_page_shall_be_displayed_in_the_relevant_source_market_language(
            String string)
   {
      String currentUrl;
      windowHandles = WebDriverUtils.getDriver().getWindowHandles();
      for (String windowHandle : windowHandles)
      {
         Selenide.switchTo().window(windowHandle);
      }

      currentUrl = WebDriverUtils.getDriver().getCurrentUrl();
      WebDriverUtils.getDriver().close();
      Selenide.switchTo().window((String) windowHandles.toArray()[0]);
      assertEquals("site is not displayed in the relevant source market language", string,
               currentUrl);
   }

   @Given("they have previously selected several rooms")
   public void they_have_previously_added_one_or_more_rooms()
   {
      searchPanelComponent.selectRoomsFromDropDownValues();
      searchPanelComponent.clickAdultStepperSpecificRoomMFE("+", 3, 0);
   }

   @Given("they have previously added any number of children")
   public void they_have_previously_added_one_or_more_children()
   {
      searchPanelComponent.clickChildrenStepperSpecificRoomMFE("+", 1, 0);
      searchPanelComponent.clickChildrenOptions("3", 1);
   }

   @When("they do select {string}")
   public void they_select(String modalSelection)
   {
      searchPanelComponent.clickOnClearAllPaxAndRooms();
   }

   @Then("the Room & Guests modal shall revert to its default view")
   public void the_Room_Guests_modal_shall_revert_to_its_default_view()
   {
      assertTrue("Auto Room config is not selected",
               searchPanelComponent.getNumberOfRoomsTextMFE().length() > 1);
   }

   @Then("the Search Panel Rooms & Guests field shall be set to the default value of {string}")
   public void the_Search_Panel_Rooms_Guests_field_shall_be_set_to_the_default_value_of(
            String string)
   {
      assertEquals("Default adult value isn't selected", "2",
               searchPanelComponent.getNumberOfAdults());
      assertEquals("Incorrext number of children selected, should be zero", "0",
               searchPanelComponent.getNumberOfChildren());
   }

   @And("they fix the error by adding the childrens age")
   public void they_fix_the_error_by_adding_the_childrens_age()
   {
      searchPanelComponent.clickChildrenOptions("4", 1);
   }

   @And("the Room & Guests modal shall still be displayed")
   public void the_Room_Guests_modal_shall_still_be_displayed()
   {
      assertTrue("Room and Guests Modal is not displayed",
               searchPanelComponent.isRoomAndGuestModalDisplayed());
   }

   @And("the Search button shall be enabled")
   public void the_Search_button_shall_be_enabled()
   {
      assertTrue("search button disabled", searchPanelComponent.searchButtonEnabled());
   }

   @And("the customer can exit the modal by clicking outside of it")
   public void the_customer_can_exit_the_modal_by_clicking_outside_of_it()
   {
      searchResultsPage.searchPanelComponent.clickOutsideOfModal();
      assertTrue("Room and Guests Modal is displayed",
               searchPanelComponent.isRoomAndGuestModalNotDisplayed());
   }

   @Then("the following error message shall be displayed")
   public void the_following_error_message_shall_be_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = ExecParams.getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedChildAgeError = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get(
                        "For legal reasons, the number of infants needs to be same as or less than the number of Adults."))
               .findFirst().orElse(null);

      String actualChildAgeError =
               searchPanelComponent.moreInfantsThanAdultsErrorMessageDisplayed();

      assertEquals(
               "Error message displayed when no child ages entered message translations is not matched ",
               expectedChildAgeError, actualChildAgeError);
   }

   @And("they fix the error by reducing the number of passengers")
   public void they_fix_the_error_by_reducing_the_number_of_passengers()
   {
      searchPanelComponent.clickRoomOption("8");
   }

   @Then("the greater than nine passengers error message is displayed")
   public void the_greater_than_nine_passengers_error_message_is_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      String siteId = ExecParams.getTestExecutionParams().getBrandStr();
      List<Map<String, String>> maps = dataTable.asMaps();
      String expectedNinePaxError = maps.stream().filter(row -> row.get("site").equals(siteId))
               .map(row -> row.get("Room & Guests room component > 9 pax error message"))
               .findFirst()
               .orElse(null);

      String actualNinePaxError = searchPanelComponent.greaterThanNineErrorMessageDisplayed();

      assertEquals(
               "Room & Guests room component > 9 pax error message translations is not matched ",
               expectedNinePaxError, actualNinePaxError);
   }
}
