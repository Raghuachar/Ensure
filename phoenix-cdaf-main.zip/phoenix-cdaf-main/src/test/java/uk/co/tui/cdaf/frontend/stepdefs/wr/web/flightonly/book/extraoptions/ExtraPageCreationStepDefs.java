package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.extraoptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.passengerdetails.PassengerDetailsPage;
import uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.search.searchresults.searchStoreValues;
import uk.co.tui.cdaf.utils.ReportFormatter;
import uk.co.tui.cdaf.utils.tools.WebElementTools;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;

public class ExtraPageCreationStepDefs
{
   private final FlightOptionsPage flightPage;

   private final ExtraOptionsPage extrasPage;

   private final FlightOnlyPageNavigation flightNavigation;

   private final PassengerDetailsPage passengerPage;

   public ExtraPageCreationStepDefs()
   {
      flightPage = new FlightOptionsPage();
      extrasPage = new ExtraOptionsPage();
      flightNavigation = new FlightOnlyPageNavigation();
      passengerPage = new PassengerDetailsPage();
   }

   @When("the select to continue")
   public void the_select_to_continue()
   {
      flightPage.clickOnContinue();
   }

   @Then("the customer should be navigated to the FO Extras Page")
   public void the_customer_should_be_navigated_to_the_FO_Extras_Page()
   {
      boolean isDisplayed = extrasPage.isPageTitleDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Extras page is not loaded", isDisplayed, true), isDisplayed, is(true));
   }

   @Then("the following components should display")
   public void the_following_components_should_display(List<String> components)
   {
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element =
                     extrasPage.getExtrasComponents().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });
   }

   @Given("that a {string} is on the WR FO Flight Extras page")
   public void that_a_is_on_the_WR_FO_Flight_Extras_page(String string)
   {
      flightNavigation.navigateToExtraPage();
   }

   @When("the select to continue in extras page")
   public void the_select_to_continue_in_extras_page()
   {
      extrasPage.clickOnContinue();
   }

   @Then("the customer should be navigated to the FO Passenger Details Page")
   public void the_customer_should_be_navigated_to_the_FO_Passenger_Details_Page()
   {
      boolean isDisplayed = passengerPage.passengerFormComponent.isPassengerFormDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Passenger page is not loaded", isDisplayed, true), isDisplayed, is(true));
   }

   @When("the select to navigate back to the Flight Options Page in the bread crumb")
   public void the_select_to_navigate_back_to_the_Flight_Options_Page_in_the_bread_crumb()
   {
      extrasPage.stepIndicator.clickOnSeatBaggageIndicator();
   }

   @Then("the customer should be navigated to the FO Flight Options Page")
   public void the_customer_should_be_navigated_to_the_FO_Flight_Options_Page()
   {
      boolean isDisplayed = flightPage.isPageTitleDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Flight page is not loaded", isDisplayed, true), isDisplayed, is(true));
   }

   @Given("that a {string} is on the WR FO respective  {string}")
   public void that_a_is_on_the_WR_FO_respective(String customer, String pageName)
   {
      flightNavigation.navigateToPassengerDetailsPage();
   }

   @When("they select the Breadcrumb to navigate to the Flight Extras Page")
   public void they_select_the_Breadcrumb_to_navigate_to_the_Flight_Extras_Page()
   {
      extrasPage.stepIndicator.clickOnExtrasIndicator();
   }

   @Then("the customer should be navigated to the Flight Extras Page")
   public void the_customer_should_be_navigated_to_the_Flight_Extras_Page()
   {
      boolean isDisplayed = extrasPage.isPageTitleDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Extras page is not loaded", isDisplayed, true), isDisplayed, is(true));
   }

   @When("they view the Breadcrumb")
   public void they_view_the_Breadcrumb()
   {
      // not required
   }

   @Then("the Extras Page will be visible")
   public void the_Extras_Page_will_be_visible()
   {
      boolean isDisplayed = extrasPage.stepIndicator.isExtrasStepIndicatorDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Extras step Indicator is displayed", isDisplayed, true), isDisplayed, is(true));
   }

   @Then("the following components should be displayed in extras page")
   public void the_following_components_should_be_displayed_in_extras_page(List<String> components)
   {
      components.stream().forEach(componentIdentifier ->
      {
         try
         {
            final WebElement element =
                     extrasPage.getExtrasComponents().get(componentIdentifier.trim());
            assertThat(componentIdentifier + " component not found in the Map", element,
                     is(notNullValue()));
            boolean actual = WebElementTools.isPresent(element);
            assertThat(ReportFormatter.generateReportStatementForComponentCheck(componentIdentifier,
                     actual, true), actual, is(true));
         }
         catch (Exception e)
         {
            assertThat(componentIdentifier + " component not displayed", false, is(true));
         }
      });

   }

   @And("they click on continue button from extras page")
   public void they_click_on_continue_button_from_extras_page()
   {
      extrasPage.clickOnContinue();
      flightNavigation.searchPanelComponent.closePrivacyPopUp();
   }

   @And("Compare search results values with extra page values")
   public void compare_search_results_values_with_extra_page_values()
   {
      Map<String, String> searchValue = searchStoreValues.getSearchValues();
      extrasPage.extrasSummaryOpen();
      String extrasValue;
      extrasValue = extrasPage.extrasSummaryDetails("first");
      assertThat("Total price error message is not matched",
               searchValue.get("Total_Price").trim().equalsIgnoreCase(extrasValue), is(true));
      extrasValue = extrasPage.extrasSummaryDetails("second");
      assertThat("Pax error message is not matched",
               searchValue.get("PAX").trim().equalsIgnoreCase(extrasValue), is(true));
      extrasPage.extrasSummaryClose();
   }

}
