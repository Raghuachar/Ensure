package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.Map;

public class FlightOptionsPage extends AbstractPage
{
   public final WebElementWait wait;

   public final FlightLuggageComponent luggageComponent;

   public final PriceSummaryPanelComponent summaryPanelComponent;

   public final FlightMealsComponent mealsComponent;

   public final CabinAndSeatTypeComponent seatTypeComponent;

   private final Map<String, WebElement> flightComponents;

   @FindBy(css = "#globalHeader__component")
   private WebElement globaleHeader;

   @FindBy(css = "[aria-label='page heading']")
   private WebElement pageTitle;

   @FindBy(css = "[class*='continue'] a")
   private WebElement continueButton;

   @FindBy(css = "[aria-label='totalPrice Details']")
   private WebElement totalPrice;

   @FindBy(css = "[aria-label*='passenger details']")
   private WebElement pax;

   @FindBy(css = "div[class*='summaryDropdown']")
   private WebElement summarryClick;

   @FindBy(css = "[class*='PriceSummaryPanel__contentBlock PriceSummaryPanel__summaryCloseBtn']")
   private WebElement summarryClose;

   public FlightOptionsPage()
   {
      flightComponents = new HashMap<>();
      wait = new WebElementWait();
      luggageComponent = new FlightLuggageComponent();
      summaryPanelComponent = new PriceSummaryPanelComponent();
      mealsComponent = new FlightMealsComponent();
      seatTypeComponent = new CabinAndSeatTypeComponent();
   }

   public WebElement getContinueButton()
   {
      return wait.getWebElementWithLazyWait(continueButton);
   }

   public void clickOnContinue()
   {
      wait.forAppear(getContinueButton());
      WebElementTools.click(getContinueButton());
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
   }

   public WebElement getPageTitleElement()
   {
      return wait.getWebElementWithLazyWait(pageTitle);
   }

   public boolean isPageTitleDisplayed()
   {
      return WebElementTools.isPresent(getPageTitleElement());
   }

   public Map<String, WebElement> getFlightComponents()
   {
      flightComponents.putAll(seatTypeComponent.getCabinAndSeatTypeComponents());
      flightComponents.putAll(luggageComponent.getFlightLuggageComponent());
      flightComponents.put("Global Header", globaleHeader);
      flightComponents.put("Continue Buttons", getContinueButton());
      flightComponents.put("Continue Button", getContinueButton());
      return flightComponents;
   }

   public String flightsSummaryDetails(String componentValues)
   {
      return componentValues.equalsIgnoreCase("first")
               ? WebElementTools.getElementText(wait.getWebElementWithLazyWait(totalPrice))
               : WebElementTools.getElementText(wait.getWebElementWithLazyWait(pax));
   }

   public void flightSummaryOpen()
   {
      WebElementTools.click(summarryClick);
      wait.forJSExecutionReadyLazy();
   }

   public void flightSummaryClose()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(summarryClose);

   }

}
