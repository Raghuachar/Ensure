package uk.co.tui.cdaf.frontend.utils;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selectors.shadowCss;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class SelenideHelper extends AbstractPage
{

   private static final int TIME_FOR_ELEMENT_TO_WAIT = 12000;

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(SelenideHelper.class);

   public static SelenideElement getShadowRootElement(String shadowRootInnerElement,
            String shadowHostParent)
   {
      return $(shadowCss(shadowRootInnerElement, shadowHostParent));
   }

   public static List<SelenideElement> getShadowRootElements(String shadowRootInnerElement,
            String shadowHostParent)
   {
      return $$(shadowCss(shadowRootInnerElement, shadowHostParent));
   }

   public static String extractText(SelenideElement parent, String locator)
   {
      ElementsCollection childElements = parent.findAll(locator);
      return childElements.asFixedIterable().stream()
               .map(el -> !el.getText().isEmpty() ? el.getText() : el.getOwnText())
               .filter(text -> !text.isEmpty())
               .findFirst()
               .orElse(null);
   }

   public void clickElementSelenide(WebElement element)
   {
      moveToElementSelenide(element);
      $(element).click();
   }

   public void selectGivenTextFromListSelenide(List<WebElement> element, String text)
   {
      WebElement option = $$(element).findBy(text(text));
      option.click();
   }

   public void mouseHoverAndClickSelenide(WebElement element)
   {
      $(element).hover().click();
   }

   public void moveToElementSelenide(WebElement element)
   {
      $(element).should(appear, Duration.ofMillis(TIME_FOR_ELEMENT_TO_WAIT));
      $(element).scrollIntoView(true);
   }

   public List<String> getElementsCollectionText(ElementsCollection elementsCollection)
   {
      LOGGER.log("Getting text for " + elementsCollection.size() + " elements");
      List<String> textList = new ArrayList<>();
      for (SelenideElement selenideElement : elementsCollection)
      {
         textList.add(selenideElement.getText());
      }
      LOGGER.log("Text found from all elements:\n" + textList);
      return textList;
   }
}
