package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.confirmation;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.ConfirmationPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class TuiAppComponentStepDefs
{
   public final ConfirmationPage confirmationPage;

   public TuiAppComponentStepDefs()
   {
      confirmationPage = new ConfirmationPage();
   }

   @When("the customer selects the GooglePlay icon")
   public void the_customer_selects_the_GooglePlay_icon()
   {
      confirmationPage.tuiAppComponent.clickOnGooglePlay();
   }

   @When("the customer selects the App Store icon")
   public void the_customer_selects_the_App_Store_icon()
   {
      confirmationPage.tuiAppComponent.ClickOnTuiAppStore();
   }

   @Then("they should be navigated to the google play page:")
   public void they_should_be_navigated_to_the_google_play_page(List<String> links)
   {
      boolean isDisplayed = confirmationPage.isGooglePlayDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "It doesn't navigated to google play page", confirmationPage.utils.getCurrentURL(),
               links.get(0)), isDisplayed, is(true));
   }

   @Then("they should be navigated to the app store page:")
   public void they_should_be_navigated_to_the_app_store_page(List<String> links)
   {
      boolean isDisplayed = confirmationPage.isAppStoreDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "It doesn't navigated to App store page", confirmationPage.utils.getCurrentURL(),
               links.get(0)), isDisplayed, is(true));
   }

}
