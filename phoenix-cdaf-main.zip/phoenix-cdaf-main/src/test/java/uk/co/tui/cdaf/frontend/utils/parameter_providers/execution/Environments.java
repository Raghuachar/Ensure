package uk.co.tui.cdaf.frontend.utils.parameter_providers.execution;

public enum Environments
{
   DEV,
   STNG,
   SIT;

   public static Environments fromString(String value)
   {
      for (Environments env : Environments.values())
      {
         if (env.name().equalsIgnoreCase(value))
         {
            return env;
         }
      }
      throw new IllegalArgumentException("Invalid Environment: " + value);
   }
}