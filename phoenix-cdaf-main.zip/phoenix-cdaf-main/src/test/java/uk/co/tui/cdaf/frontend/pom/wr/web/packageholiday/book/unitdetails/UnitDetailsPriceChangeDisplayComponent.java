package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

public class UnitDetailsPriceChangeDisplayComponent extends AbstractPage
{

   public final WebElementWait wait;

   public final SearchResultsPage searchResultsPage;

   @FindBy(css = "[aria-label='price change component']")
   private WebElement priceChange;

   @FindBy(css = "[aria-label='price change component'] [class*='PriceChangeComponent__priceInfo']")
   private WebElement priceChangeIncreaseMessage;

   @FindBy(css = "[aria-label='price change component'] [class*='PriceChangeComponent__priceInfo']")
   private WebElement priceChangeDecreaseMessage;

   public UnitDetailsPriceChangeDisplayComponent()
   {
      wait = new WebElementWait();
      searchResultsPage = new SearchResultsPage();
   }

   public boolean isPriceChangeComponentsDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(priceChange);
   }

   public boolean isPriceChangeIncreaseMessageDisplayed()
   {
      return WebElementTools.isPresent(priceChangeIncreaseMessage);
   }

   public boolean isPriceChangeDecreaseMessageDisplayed()
   {
      return WebElementTools.isPresent(priceChangeDecreaseMessage);
   }

   public void changeprice()
   {
      WebDriver driver = new ChromeDriver();
      driver.get(
               "https://sit.tuiprjuat.be/h/updateHolidayPrice?packageId=A053120420220808 TB1771 CRLTFS20220815 TB1772 TFSCRLf0cafa04-54ce-42e7-bf0b-aa5ac97121ea467169d0-2509-46a0-862c-36141ca1225d&totalPrice=3000");
      BrowserCookies.closePrivacyPopUp();
      driver.navigate().refresh();
      WebDriverUtils.switchToParentTabHandles();

   }
}
