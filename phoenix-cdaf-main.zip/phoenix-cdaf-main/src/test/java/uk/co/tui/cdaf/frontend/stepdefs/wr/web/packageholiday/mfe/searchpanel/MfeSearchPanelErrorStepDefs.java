package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.mfe.searchpanel;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class MfeSearchPanelErrorStepDefs
{
   private final PackageNavigation packageNavigation;

   private final SearchPanelComponent searchPanelComponent = new SearchPanelComponent();

   public MfeSearchPanelErrorStepDefs()
   {
      packageNavigation = new PackageNavigation();
   }

   @Given("the Customer\\/Agent is viewing the Search Panel")
   public void the_Customer_Agent_is_viewing_the_Search_Panel()
   {
      packageNavigation.navigateToHoldaySearchPage();
   }

   @And("they leave the Departure Airport field as the default value")
   public void they_leave_the_Departure_Airport_field_as_the_default_value()
   {
      assertTrue(searchPanelComponent.isAirportFieldPresent());
   }

   @And("they leave the Destination or Hotel field as the default value")
   public void they_leave_the_Destination_or_Hotel_field_as_the_default_value()
   {
      assertTrue(searchPanelComponent.isDestinationFieldPresent());
   }

   @And("they leave the Departure Date field as the default value")
   public void they_leave_the_Departure_Date_field_as_the_default_value()
   {
      assertTrue(searchPanelComponent.isDepartureFieldPresent());
   }

   @When("they select the SEARCH button")
   public void they_select_the_button()
   {
      searchPanelComponent.clickSearchBtn();
   }

   @Then("the Departure Airport field shall be outlined in red")
   public void the_Departure_Airport_field_shall_be_outlined_in_red()
   {
      assertTrue(searchPanelComponent.isError());
      assertTrue(searchPanelComponent.airportError());
   }

   @And("the Departure Date field shall be outlined in red")
   public void the_Departure_Date_field_shall_be_outlined_in_red()
   {
      assertTrue(searchPanelComponent.isError());
      assertTrue(searchPanelComponent.departureDateError());
   }

   @Given("they populate airport field correctly")
   public void they_populate_airport_search_panel_fields_correctly()
   {
      searchPanelComponent.selectAirport();
   }

   @And("the following error messages shall be displayed:")
   public void the_following_error_messages_shall_be_displayed(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> dataTableTemp = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> dataMap : dataTableTemp)
      {
         searchPanelComponent.selectLanguageMFE(dataMap.get("language"));
         String actualErrorMessageText = searchPanelComponent.getErrorMessage();
         String expectedErrorMessageText = dataMap.get("Error message");
         assertEquals("Error Message is not matching ", expectedErrorMessageText.toLowerCase(),
                  actualErrorMessageText.toLowerCase());
         String expectedSecondErrorMessageText = dataMap.get("Second Error Message");

         if (StringUtils.isNotEmpty(expectedSecondErrorMessageText))
         {
            String secondErrorActualText = searchPanelComponent.getSecondErrorMessage();
            assertEquals("Error Message is not matching ",
                     expectedSecondErrorMessageText.toLowerCase(),
                     secondErrorActualText.toLowerCase());
         }
      }
   }

   @Given("they populate all the other search panel fields correctly")
   public void they_populate_all_the_other_search_panel_fields_correctly()
   {
      searchPanelComponent.selectDate();
   }

}
