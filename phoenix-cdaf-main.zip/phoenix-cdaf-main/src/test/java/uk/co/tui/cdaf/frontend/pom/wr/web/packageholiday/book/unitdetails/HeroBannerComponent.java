package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails;

import com.codeborne.selenide.SelenideElement;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.WebElement;

import java.util.HashMap;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;

public class HeroBannerComponent
{
   public Map<String, WebElement> getHeroBannerComponents()
   {
      SelenideElement heroBannerImage = $("[aria-label*='hero'] [class*='LazyImage']");
      return new HashMap<>()
      {
         {
            put("Hero banner", heroBannerImage);
            put("Hero banner image", heroBannerImage);
         }
      };
   }

   @NotNull
   public SelenideElement getPageGalleryTitle()
   {
      return $(".Galleries__galleryTitleV2.Galleries__hide");
   }

   public boolean isImageInOrder()
   {
      return $(".Galleries__mainView").isDisplayed();
   }

   public boolean getHeroBannerImageCount()
   {
      return getPageGalleryTitle().$$(".Galleries__index").first().isDisplayed();
   }

}
