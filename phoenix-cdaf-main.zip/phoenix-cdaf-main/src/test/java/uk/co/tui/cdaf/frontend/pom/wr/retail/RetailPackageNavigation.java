package uk.co.tui.cdaf.frontend.pom.wr.retail;

import uk.co.tui.cdaf.frontend.pom.generic_page.PageErrorHandler;
import uk.co.tui.cdaf.frontend.pom.uk.retail.login.RetailPage;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchCustom;
import uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanel;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.browse.homepage.FlightOnlyHomePage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.UnitDetailsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsPage;
import uk.co.tui.cdaf.frontend.utils.BrowserCookies;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static com.codeborne.selenide.Selenide.open;
import static uk.co.tui.cdaf.frontend.pom.wr.search.SearchPanelFactory.getSearchPanel;

public class RetailPackageNavigation
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(RetailPackageNavigation.class);

   private static final String DOT = ".";

   public final SearchResultsPage searchResultsPage = new SearchResultsPage();

   public final UnitDetailsPage unitPage = new UnitDetailsPage();

   public final SummaryPage summaryPage = new SummaryPage();

   public final WebDriverUtils utils = new WebDriverUtils();

   public final RetailPage retailPage = new RetailPage();

   public final FlightOnlyHomePage foHomePage = new FlightOnlyHomePage();

   public final RetailPassengerDetailsPage retailpassengerdetails =
            new RetailPassengerDetailsPage();

   private final PageErrorHandler errorHandler = new PageErrorHandler();

   private final WebElementWait wait = new WebElementWait();

   private final SearchPanel searchPanel = getSearchPanel();

   private final SearchDataHelper searchDataHelper = new SearchDataHelper();

   private final SearchCustom searchCustom = new SearchCustom();

   public final void loginToRetailThirdParty()
   {
      wait.forJSExecutionReadyLazy();

      retailPage.thirdPartyLogin();
      wait.forJSExecutionReadyLazy();
   }



   public void retailLogin()
   {
      searchResultsPage.searchPanelComponent.visit();
      BrowserCookies.closePrivacyPopUp();
      if (ExecParams.getAgent().isThirdparty())
         retailPage.thirdPartyLogin();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
   }

   public void relaunchMAFO()
   {
      wait.forJSExecutionReadyLazy();
      String currentUrl = utils.getCurrentURL();
      String replaceString = currentUrl.replaceAll("/fr/tpa/j_spring_security_check", "/flight");
      open(replaceString);
      wait.forJSExecutionReadyLazy();
      if (ExecParams.getAgent().isThirdparty())
         loginToRetailThirdParty();
      if (ExecParams.getAgent().isInhouse())
         retailPage.inhouseAgentLogin();
      wait.forJSExecutionReadyLazy();
   }

   public void retailLoginChangeagent()
   {
      foHomePage.navigateToHolidayPage();
      BrowserCookies.closePrivacyPopUp();
      BrowserCookies.feedbackPopUp();
   }

   public void navigateToSearchResultPage()
   {
      TestDataAttributes parameter =
               searchDataHelper.getSearchParameters(searchCustom.getScenarioId());
      if (parameter == null)
         searchPanel.searchDefaults();
      else
         searchPanel.searchWithParameters(parameter);
      errorHandler.isPageLoadingCorrectly();
      String searchResultsPageURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Search Result page url:" + searchResultsPageURL);
   }

   public void navigateToUnitDetailsPage()
   {
      navigateToSearchResultPage();
      wait.forJSExecutionReadyLazy();
      searchResultsPage.searchResultComponent.selectFirstAvailableResultCard();
      errorHandler.isPageLoadingCorrectly();
      String unitDetailsURL = WebDriverUtils.getDriver().getCurrentUrl();
      LOGGER.log(LogLevel.INFO, "Unit details page url:" + unitDetailsURL);
   }

   public void navigateToSummaryPage()
   {
      navigateToUnitDetailsPage();
      wait.forJSExecutionReadyLazy();
      unitPage.progressbarComponent.clickOnContinueButton();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPassengerPage()
   {
      navigateToSummaryPage();
      wait.forJSExecutionReadyLazy();
      retailpassengerdetails.selectContinueSummary();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToPaymentPage()
   {
      navigateToPassengerPage();
      wait.forJSExecutionReadyLazy();
      retailpassengerdetails.fillRetailPassengerDetails();
      errorHandler.isPageLoadingCorrectly();
   }

   public void navigateToExtrasPage()
   {
      navigateToSummaryPage();
      wait.forJSExecutionReadyLazy();
      errorHandler.isPageLoadingCorrectly();
   }

   // discounts
   public void addPassengerDetailsandwaitforAddFeetype()
   {
      wait.forJSExecutionReadyLazy();
      retailpassengerdetails.fillThePassengerDetailsForAddFeeType();
      errorHandler.isPageLoadingCorrectly();
   }

   public void selectfeeType()
   {
      retailpassengerdetails.addFee();
   }

   public void calamiteitenfonds()
   {
      retailpassengerdetails.calamiteitenfonds();
      retailpassengerdetails.selectContinueBookingWR();
   }

   public void discountLessthantotal()
   {
      retailpassengerdetails.discounttabclick();
      retailpassengerdetails.selectDiscounttype();
      retailpassengerdetails.addDiscountlessthantotal();
   }

   public void discountMoreThentotal()
   {
      retailpassengerdetails.discounttabclick();
      retailpassengerdetails.selectDiscounttype();
      retailpassengerdetails.addDiscountmorethantotal();
      retailpassengerdetails.selectContinueBookingWR();
   }

   public void skipPaymentsWR()
   {
      wait.forJSExecutionReadyLazy();
      retailpassengerdetails.skippayment();
      errorHandler.isPageLoadingCorrectly();
   }

   public void retailPayment()
   {
      if (ExecParams.getAgent().isThirdparty())
         LOGGER.log(LogLevel.INFO, "No payment for Thirdparty");
      if (ExecParams.getAgent().isInhouse())
         skipPaymentsWR();
      wait.forJSExecutionReadyLazy();
   }

}
