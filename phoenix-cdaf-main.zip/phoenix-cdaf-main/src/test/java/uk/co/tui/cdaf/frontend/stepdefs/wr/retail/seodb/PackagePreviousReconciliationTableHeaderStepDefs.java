package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Then;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePreviousReconciliationTableHeaderStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   public final PackageNavigation fonavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackagePreviousReconciliationTableHeaderStepDefs()
   {

      fonavigation = new PackageNavigation();
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Then("they can see the following table headers for table that fits within the chosen range")
   public void they_can_see_the_following_table_headers_for_table_that_fits_within_the_chosen_range(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Types is displayed",
               pKgReconcilationPaymentPageComponents.isTypesColumnHeaderDisplayed(), is(true));
      assertThat("Payment totals is displayed",
               pKgReconcilationPaymentPageComponents.isPaymentTotalsColumnHeaderDisplayed(),
               is(true));
      assertThat("Banking now is displayed",
               pKgReconcilationPaymentPageComponents.isBankingNowColumnHeaderDisplayed(), is(true));
      assertThat("Discrepancy is displayed",
               pKgReconcilationPaymentPageComponents.isDiscrepancyColumnHeaderDisplayed(),
               is(true));
      assertThat("Currency is displayed",
               pKgReconcilationPaymentPageComponents.isCurrencyColumnHeaderDisplayed(), is(true));
      assertThat("Reason is displayed",
               pKgReconcilationPaymentPageComponents.isReasonColumnHeaderDisplayed(), is(true));
      assertThat("Blank Space is displayed",
               pKgReconcilationPaymentPageComponents.isBlankSpaceColumnHeaderDisplayed(), is(true));
   }
}
