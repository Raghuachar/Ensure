package uk.co.tui.cdaf.frontend.utils.parameter_providers.execution.agent_types;

public enum PackageType
{
   FLIGHT,
   H;

   public static PackageType fromString(String typeString)
   {
      for (PackageType type : PackageType.values())
      {
         if (type.name().equalsIgnoreCase(typeString))
         {
            return type;
         }
      }
      throw new IllegalArgumentException(
               "Invalid entry: " + typeString + "\nAcceptable Package types:\nflight\nh");
   }
}
