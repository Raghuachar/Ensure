package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageSelectReasonErrorMessageStepDefs
{
   public final WebElementWait wait;

   private final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageSelectReasonErrorMessageStepDefs()
   {
      wait = new WebElementWait();
      packagenavigation = new PackageNavigation();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
   }

   @Given("the agent has selected a reason on the end of day banking page")
   public void the_agent_has_selected_a_reason_on_the_end_of_day_banking_page()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
   }

   @When("they press the {string} CTA")
   public void they_press_the_CTA(String string)
   {
      pKgReconcilationPaymentPageComponents.clickSelectReasonListDisplayed();
      pKgReconcilationPaymentPageComponents.clickSelectReasonCTA();

   }

   @When("have not entered any text into the notes field")
   public void have_not_entered_any_text_into_the_notes_field()
   {
      wait.forJSExecutionReadyLazy();
   }

   @Then("the error message {string} will appear")
   public void the_error_message_will_appear(String string)
   {
      assertThat("Select a reason modal error message displayed",
               pKgReconcilationPaymentPageComponents.isSelctReasonMessagePresent(), is(true));
   }

}
