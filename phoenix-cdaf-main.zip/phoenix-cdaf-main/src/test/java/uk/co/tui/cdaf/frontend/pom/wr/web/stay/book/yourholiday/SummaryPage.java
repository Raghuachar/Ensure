package uk.co.tui.cdaf.frontend.pom.wr.web.stay.book.yourholiday;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;

import java.util.HashMap;
import java.util.Map;

public class SummaryPage extends AbstractPage
{
   public final NavigationComponent navigationComponent;

   public final PriceBreakdownComponent pricebreakdown;

   public final YourAccommodationComponent yourAccommodation;

   @FindBy(css = "[aria-label*='back to hotel'] a")
   private WebElement backToHotelLink;

   public SummaryPage()
   {
      navigationComponent = new NavigationComponent();
      pricebreakdown = new PriceBreakdownComponent();
      yourAccommodation = new YourAccommodationComponent();
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getSummaryPageComponent()
   {
      HashMap<String, WebElement> summaryMap = new HashMap<>()
      {
         {
            put("Back to Hotel Details", backToHotelLink);
         }
      };
      summaryMap.putAll(navigationComponent.getNavigationComponent());
      summaryMap.putAll(pricebreakdown.getPriceBreakdownComponent());
      summaryMap.putAll(yourAccommodation.getYourAccommodationComponent());
      return summaryMap;
   }
}
