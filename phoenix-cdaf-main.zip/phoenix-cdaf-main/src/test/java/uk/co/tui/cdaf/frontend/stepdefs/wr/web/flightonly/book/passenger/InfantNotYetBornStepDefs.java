package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.passenger;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.FlightOnlyPageNavigation;

public class InfantNotYetBornStepDefs
{
   private final FlightOnlyPageNavigation pageNavigation;

   public InfantNotYetBornStepDefs()
   {
      pageNavigation = new FlightOnlyPageNavigation();
   }

   @Given("the customer is on the WR Passenger Details Page")
   public void the_customer_is_on_the_WR_Passenger_Details_Page()
   {
      pageNavigation.navigateToPassengerDetailsPage();
   }

   @And("they have a child who is not yet born on their booking")
   public void they_have_a_child_who_is_not_yet_born_on_their_booking()
   {
      throw new PendingException();
   }

   @When("they navigate to the passenger details of the child")
   public void they_navigate_to_the_passenger_details_of_the_child()
   {
      throw new PendingException();
   }

   @Then("the following tick box will display:")
   public void the_following_tick_box_will_display(io.cucumber.datatable.DataTable dataTable)
   {
      throw new PendingException();
   }

   @Then("the following fields should also display:")
   public void the_following_fields_should_also_display(io.cucumber.datatable.DataTable dataTable)
   {
      throw new PendingException();
   }

   @When("they select the Infant not born yet tick box")
   public void they_select_the_Infant_not_born_yet_tick_box()
   {
      throw new PendingException();
   }

   @Then("the following fields shall be hidden:")
   public void the_following_fields_shall_be_hidden(io.cucumber.datatable.DataTable dataTable)
   {
      throw new PendingException();
   }

   @Then("a component shall display with the following text:")
   public void a_component_shall_display_with_the_following_text(
            io.cucumber.datatable.DataTable dataTable)
   {
      throw new PendingException();
   }

   @Given("they have selected the Infant not born yet tick box")
   public void they_have_selected_the_Infant_not_born_yet_tick_box()
   {
      throw new PendingException();
   }

   @When("they deselect the Infant not born yet tick box")
   public void they_deselect_the_Infant_not_born_yet_tick_box()
   {
      throw new PendingException();
   }

   @Then("the following fields shall be displayed:")
   public void the_following_fields_shall_be_displayed(io.cucumber.datatable.DataTable dataTable)
   {
      throw new PendingException();
   }

   @Then("the Please contact us component will be hidden")
   public void the_Please_contact_us_component_will_be_hidden()
   {
      throw new PendingException();
   }

}
