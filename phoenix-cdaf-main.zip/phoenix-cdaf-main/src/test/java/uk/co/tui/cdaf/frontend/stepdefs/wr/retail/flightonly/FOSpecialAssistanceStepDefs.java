package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOSpecialAssistance;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class FOSpecialAssistanceStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final RetailFlightOnlyPageNavigation retailflightonlypagenavigation;

   private final FOSpecialAssistance specialassistancecheckbox;

   public FOSpecialAssistanceStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      retailflightonlypagenavigation = new RetailFlightOnlyPageNavigation();
      specialassistancecheckbox = new FOSpecialAssistance();
   }

   @Given("the agent is on or passenger details pages")
   public void the_agent_is_on_or_passenger_details_pages()
   {
      retailpackagenavigation.retailLogin();
      retailflightonlypagenavigation.createOnewayBooking();
   }

   @When("they the click on specail assistance")
   public void they_the_click_on_specail_assistance()
   {
      specialassistancecheckbox.clickOnspecialassistancecheckbox();
   }

   @Then("the they should see list of specail assistance")
   public void the_they_should_see_list_of_specail_assistance()
   {
      specialassistancecheckbox.selectSpecialAssistanceWCHR();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
   }

}
