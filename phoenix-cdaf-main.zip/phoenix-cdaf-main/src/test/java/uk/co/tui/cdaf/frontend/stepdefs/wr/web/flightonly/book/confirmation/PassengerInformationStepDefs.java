package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.confirmation;

import io.cucumber.java.en.And;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.confirmation.ConfirmationPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PassengerInformationStepDefs
{

   private final ConfirmationPage confirmationPage;

   public PassengerInformationStepDefs()
   {
      confirmationPage = new ConfirmationPage();
   }

   @And("the following information should display in the Passenger Information for the Lead Passenger:")
   public void the_following_information_should_display_in_the_Passenger_Information_for_the_Lead_Passenger(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
      confirmationPage.passengerDetailComponent.passengerLeadInfoVerification();

      boolean isMatched = confirmationPage.passengerDetailComponent.matched;
      String passengerInfo = confirmationPage.passengerDetailComponent.passengerInfo;

      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Passenger Info is not displayed as per the required format", passengerInfo,
               list.get(0).get("Passenger Information")), isMatched, is(true));
   }

   @And("the following information should display in the Passenger Information for the Non-lead Passenger:")
   public void the_following_information_should_display_in_the_Passenger_Information_for_the_Non_lead_Passenger(
            io.cucumber.datatable.DataTable dataTable)
   {
      List<Map<String, String>> list = dataTable.asMaps(String.class, String.class);
      confirmationPage.passengerDetailComponent.passengerLeadInfoVerification();

      boolean isMatched = confirmationPage.passengerDetailComponent.matched;
      String passengerInfo = confirmationPage.passengerDetailComponent.passengerInfo;

      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Passenger Info is not displayed as per the required format", passengerInfo,
               list.get(0).get("Passenger Information")), isMatched, is(true));

      confirmationPage.passengerDetailComponent.passengerNonLeadInfoVerification();

      boolean nonLeadMatched = confirmationPage.passengerDetailComponent.matched;
      String nonLeadPassInfo = confirmationPage.passengerDetailComponent.passengerInfo;

      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Passenger Info is not displayed as per the required format", nonLeadPassInfo,
               list.get(1).get("Passenger Information")), nonLeadMatched, is(true));

   }

   @And("lead and non lead should be dispalyed in below format")
   public void lead_and_non_lead_should_be_dispalyed_in_below_format(List<String> list)
   {
      confirmationPage.passengerDetailComponent.passengerLeadInfoVerification();

      boolean isMatched = confirmationPage.passengerDetailComponent.matched;
      String passengerInfo = confirmationPage.passengerDetailComponent.passengerInfo;

      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Lead Passenger Info is not displayed as per the required format", passengerInfo,
               list.get(0)), isMatched, is(true));

      confirmationPage.passengerDetailComponent.passengerNonLeadInfoVerification();

      boolean nonLeadMatched = confirmationPage.passengerDetailComponent.matched;
      String nonLeadPassInfo = confirmationPage.passengerDetailComponent.passengerInfo;

      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Passenger Info is not displayed as per the required format", nonLeadPassInfo,
               list.get(1)), nonLeadMatched, is(true));
   }

}
