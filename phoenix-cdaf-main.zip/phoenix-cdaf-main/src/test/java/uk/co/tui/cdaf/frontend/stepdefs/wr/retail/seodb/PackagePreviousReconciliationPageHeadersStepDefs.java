package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackagePreviousReconciliationsPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackagePreviousReconciliationPageHeadersStepDefs
{
   public final WebElementWait wait;

   public final PackageNavigation packagenavigation;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   private final PackagePreviousReconciliationsPageComponents
            pkgPreviousReconciliationsPageComponents;

   public PackagePreviousReconciliationPageHeadersStepDefs()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      pkgPreviousReconciliationsPageComponents = new PackagePreviousReconciliationsPageComponents();
   }

   @Then("the previous reconciliations page will open")
   public void the_previous_reconciliations_page_will_open()
   {
      wait.forJSExecutionReadyLazy();
   }

   @Then("the agent can see the following information")
   public void the_agent_can_see_the_following_information(
            io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Previous Reconciliations page opened and Global header displayed",
               pKgReconcilationPaymentPageComponents.isPageHeaderAndLinksPresent(), is(true));
   }

   @Given("that the agent is viewing the previous reconciliations page")
   public void that_the_agent_is_viewing_the_previous_reconciliations_page()
   {
      packagenavigation.retailLoginFO();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      wait.forJSExecutionReadyLazy();
      pKgReconcilationPaymentPageComponents.clickPreviousReconPageLink();
   }

   @When("they click  {string} link")
   public void they_click_link(String string)
   {
      pkgPreviousReconciliationsPageComponents.clickBackToReconciliationPageLink();
   }

   @Then("the Agent will be navigated to the end of day banking page")
   public void the_Agent_will_be_navigated_to_the_end_of_day_banking_page()
   {
      wait.forJSExecutionReadyLazy();
   }
}
