package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.seodb;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PackageReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.FOReconcilationPaymentPageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PackageUpdateBankingModalErrorStepDefs
{
   public final PackageNavigation packagenavigation;

   public final WebElementWait wait;

   private final PackageReconcilationPaymentPageComponents pKgReconcilationPaymentPageComponents;

   public PackageUpdateBankingModalErrorStepDefs()
   {
      packagenavigation = new PackageNavigation();
      wait = new WebElementWait();
      pKgReconcilationPaymentPageComponents = new PackageReconcilationPaymentPageComponents();
      FOReconcilationPaymentPageComponents foReconcilationPaymentPageComponents =
               new FOReconcilationPaymentPageComponents();
   }

   @Given("that the Agent is on the Update banking modal")
   public void that_the_Agent_is_on_the_modal()
   {
      packagenavigation.retailLoginFO();
      pKgReconcilationPaymentPageComponents.navigateToReconcilePaymentPage();
      pKgReconcilationPaymentPageComponents.clickOnUpdateBankingLink();
   }

   @When("they try to press the SAVE CTA")
   public void they_try_to_press_the_CTA()
   {
      pKgReconcilationPaymentPageComponents.clickUpdateBankingSave();
   }

   @When("have not entered any information on the modal")
   public void have_not_entered_any_information_on_the_modal()
   {
      pKgReconcilationPaymentPageComponents.enterBlankUpdateBankingAmount();
      pKgReconcilationPaymentPageComponents.enterBlankSealBagNumber();

   }

   @Then("the modal will display the  error messages")
   public void the_modal_will_display_the_error_messages(io.cucumber.datatable.DataTable dataTable)
   {
      assertThat("Add banking amount error is present",
               pKgReconcilationPaymentPageComponents.isAddBankingAmountValidationError(), is(true));
      assertThat("Seal bag number error is present",
               pKgReconcilationPaymentPageComponents.isAddSealBagValidationError(), is(true));
   }

}
