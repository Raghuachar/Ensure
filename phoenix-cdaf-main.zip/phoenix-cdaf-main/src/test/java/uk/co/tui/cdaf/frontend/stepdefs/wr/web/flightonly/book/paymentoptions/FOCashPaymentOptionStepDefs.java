package uk.co.tui.cdaf.frontend.stepdefs.wr.web.flightonly.book.paymentoptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class FOCashPaymentOptionStepDefs
{
   private final RetailFlightOnlyPageNavigation pageNavigationFO;

   public FOCashPaymentOptionStepDefs()
   {
      pageNavigationFO = new RetailFlightOnlyPageNavigation();
   }

   @Given("that the agent is entering a payer name in the payment component in Bookflow")
   public void that_the_agent_is_entering_a_payer_name_in_the_payment_component_in_Bookflow()
   {
      pageNavigationFO.navigateToPaymentOptionsPageFO();
   }

   @When("they enter a special character")
   public void they_enter_a_special_character()
   {
      pageNavigationFO.enterPayerNameWithAccents();
   }

   @Then("the name will be accepted")
   public void the_name_will_be_accepted()
   {
      assertThat("the name will be accepted", pageNavigationFO.isErrorMessageDisplayed(),
               is(false));
   }

   @Then("will not throw an error message")
   public void will_not_throw_an_error_message()
   {
      assertThat("will not throw an error message", pageNavigationFO.isErrorMessageDisplayed(),
               is(false));
   }

}
