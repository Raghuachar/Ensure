package uk.co.tui.cdaf.frontend.pom.wr.retail;

import com.codeborne.selenide.Condition;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.pom.nordics.web.flight_only.NordicFlightOnlySearchPanelPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.parameter_providers.ExecParams;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.List;
import java.util.Objects;

import static com.codeborne.selenide.Selenide.$;
import static org.junit.Assert.assertEquals;

public class RetailSearchPanelComponent extends NordicFlightOnlySearchPanelPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(RetailPackageNavigation.class);

   private final WebElementWait wait;

   @FindAll({ @FindBy(xpath = "//div[@aria-label='clear search']//a"),
            @FindBy(css = "[aria-label='clear search'] a"),
            @FindBy(css = "[aria-label*='search panel'] a") })
   private List<WebElement> clearSearch;

   @FindAll({ @FindBy(css = ".FlightInformation__selectionStatus > button"),
            @FindBy(css = ".FlightInformation__selectionStatus"),
            @FindBy(css = ".FlightInformation__selectionStatus button"),
            @FindBy(css = ".FlightInformation__button") })
   private WebElement selectflight;

   @FindAll({ @FindBy(css = ".Linkable__linkable"),
            @FindBy(css = ".ContinueButton__continueButton") })
   private WebElement searchcontinue;

   @FindBy(css = "input[aria-label='select date']")
   private WebElement clickdepaturedate;

   @FindAll({ @FindBy(css = ".SelectLegacyDate__monthNavigator"),
            @FindBy(css = ".SelectLegacyDate__monthSelector .SelectLegacyDate__monthNavigator"),
            @FindBy(css = ".SelectDate__monthNavigator") })
   private List<WebElement> nextmonthnavigation;

   @FindAll({ @FindBy(css = ".SelectLegacyDate__calendar .SelectLegacyDate__available"),
            @FindBy(css = ".SelectDate__available ") })
   private List<WebElement> selectdate;

   @FindAll({ @FindBy(css = ".Flights__searchButton"), @FindBy(css = ".Package__searchButton") })
   private WebElement searchButton;

   @FindBy(css = ".price__currency")
   private WebElement pricecurrency;

   public RetailSearchPanelComponent()
   {
      wait = new WebElementWait();
   }

   public void selectDate()
   {
      WebElementTools.clickElementJavaScript(clickdepaturedate);
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(nextmonthnavigation.get(1));
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(selectdate.get(0));
   }

   public final void wrFoselectArrivalAirport()
   {
      selenideHelper.clickElementSelenide(flyingTo);
      wait.forJSExecutionReadyLazy();
      TestDataAttributes parameter =
               new SearchDataHelper().getSearchParameters(customSearch.getScenarioId());
      if (StringUtils.isNotEmpty(customSearch.getArrArpt()))
         WebElementTools.selectElementFromListBasedOnText(arrivalAirport,
                  customSearch.getArrArpt());
      else if (Objects.nonNull(parameter) && StringUtils.isNotEmpty(parameter.getArrAirport()))
         WebElementTools.selectElementFromListBasedOnText(arrivalAirport,
                  parameter.getArrAirport());
      else
      {
         wait.forJSExecutionReadyLazy();
         WebDriverUtils.executeScript("arguments[0].scrollIntoView(true);", arrivalAirport.get(0));
         WebElementTools.newActions().moveToElement(arrivalAirport.get(0)).build().perform();
         WebElementTools.click(arrivalAirport.get(0));
      }
   }

   public final void wrFoOneWaySearch()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      if (!clearSearch.isEmpty())
         WebElementTools.click(wait.getWebElementWithLazyWait(clearSearch.get(0)));
      wait.forAppear(oneWayRadioButton);
      selenideHelper.clickElementSelenide(oneWayRadioButton);
      selectDepartureAirport();
      wrFoselectArrivalAirport();
      selectDate();
      selectAdultAndChild();
      enterChildernAges();
      selenideHelper.clickElementSelenide(searchButton);
   }

   public void selectFlight()
   {
      $(selectflight).should(Condition.appear, Duration.ofSeconds(5)).hover().click();
      $(searchcontinue).should(Condition.appear, Duration.ofSeconds(5)).hover().click();
   }

   public String defaultcurrency()
   {
      return WebElementTools.getElementText(pricecurrency);
   }

   public void defaultCurrencySymbol()
   {
      if (!ExecParams.getAgent().isB2C() && ExecParams.getTestExecutionParams().isMA())
         assertEquals("MAD", defaultcurrency());
      LOGGER.log(LogLevel.INFO, "MAD Currency:" + defaultcurrency());
      wait.forJSExecutionReadyLazy();
      if (!ExecParams.getAgent().isB2C()
               && ExecParams.getTestExecutionParams().isBE())
         assertEquals("€", defaultcurrency());
      LOGGER.log(LogLevel.INFO, "€ Currency:" + defaultcurrency());
      wait.forJSExecutionReadyLazy();
      if (!ExecParams.getAgent().isB2C()
               && ExecParams.getTestExecutionParams().isNL())
         assertEquals("€", defaultcurrency());
      LOGGER.log(LogLevel.INFO, "€ Currency:" + defaultcurrency());
   }

}
