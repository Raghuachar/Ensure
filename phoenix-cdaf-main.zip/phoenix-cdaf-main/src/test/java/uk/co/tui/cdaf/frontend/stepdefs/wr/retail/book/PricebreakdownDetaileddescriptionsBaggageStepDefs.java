package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.PricebreakdownDetaileddescriptionsBaggageComponents;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class PricebreakdownDetaileddescriptionsBaggageStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final PricebreakdownDetaileddescriptionsBaggageComponents baggagepricebreakdown;

   public PricebreakdownDetaileddescriptionsBaggageStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      baggagepricebreakdown = new PricebreakdownDetaileddescriptionsBaggageComponents();
   }

   @Given("that the agent is on the  passenger details price breakdown")
   public void that_the_agent_is_on_the_passenger_details_price_breakdown()
   {
      retailpackagenavigation.retailLogin();
      retailpackagenavigation.navigateToSummaryPage();
   }

   @When("the agent views the Options and Extras section")
   public void the_agent_views_the_Options_and_Extras_section()
   {
      baggagepricebreakdown.baggageSelection();
      retailpassengerdetailspage.clickOnContinueButton();
      retailpassengerdetailspage.fillRetailPassengerDetailsPriceBreakdown();
      retailpassengerdetailspage.expandPriceBreakdown();
   }

   @Then("the {string} data will be displayed")
   public void the_data_will_be_displayed(String string)
   {
      assertThat("verify the baggage",
               baggagepricebreakdown.isBaggageDisplayed(), is(true));
      retailpassengerdetailspage.clickOnContinueButton();
      retailpassengerdetailspage.retailPayment();
   }

}
