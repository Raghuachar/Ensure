package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class MAFODefaultMADCurrencyStepDefs
{
   public final FlightOptionsPage flightOptionsPage;

   public final ExtraOptionsPage extraOptionsPage;

   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final RetailSearchPanelComponent retailrearchpanelcomponent;

   private final RetailSearchPanelComponent retailsearchpanelcomponent;

   private final RetailFlightOnlyPageNavigation retailFlightOnlyPageNavigation;

   public MAFODefaultMADCurrencyStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      retailrearchpanelcomponent = new RetailSearchPanelComponent();
      retailsearchpanelcomponent = new RetailSearchPanelComponent();
      flightOptionsPage = new FlightOptionsPage();
      extraOptionsPage = new ExtraOptionsPage();
      retailFlightOnlyPageNavigation = new RetailFlightOnlyPageNavigation();
   }

   @Given("the agent is on flights search results pages")
   public void the_agent_is_on_flights_search_results_pages()
   {
      retailpackagenavigation.retailLogin();
      retailpackagenavigation.relaunchMAFO();
   }

   @When("they view currency on search results page")
   public void they_view_currency_on_search_results_page()
   {
      retailFlightOnlyPageNavigation.wrMFEFoOneWaySearch();
   }

   @Then("they should see Default currency MAD")
   public void they_should_see_Default_currency_MAD()
   {
      retailsearchpanelcomponent.selectFlight();
      retailrearchpanelcomponent.defaultCurrencySymbol();

   }

   @And("complete the mafo booking")
   public void complete_the_mafo_booking()
   {
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
      retailpassengerdetailspage.userLogout();
   }

}
