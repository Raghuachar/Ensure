package uk.co.tui.cdaf.frontend.pom.nordics.web.flight_only;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import uk.co.tui.cdaf.frontend.pom.uk.web.beach_holiday.search.search_panel.SearchCustom;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.HybrisConfigHelper;
import uk.co.tui.cdaf.frontend.utils.SelenideHelper;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.SearchDataHelper;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.TestDataAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class NordicFlightOnlySearchPanelPage extends AbstractPage
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(NordicFlightOnlySearchPanelPage.class);

   public final SelenideHelper selenideHelper;

   public final WebElementWait wait;

   public final SearchCustom customSearch;

   private final SimpleDateFormat format;

   @FindAll({ @FindBy(css = ".SearchPanel__flighOptionsWrapper li:nth-child(2)"),
            @FindBy(css = "[class*='flighOptionsWrapper'] li:nth-child(2)") })
   protected WebElement oneWayRadioButton;

   @FindAll({ @FindBy(css = ".SearchPanel__flighOptionsWrapper li:nth-child(1)"),
            @FindBy(css = "[class*='flighOptionsWrapper'] li:nth-child(1)") })
   protected WebElement twoWayRadioButton;

   @FindAll({
            @FindBy(css = ".SearchPanel__searchPanelWrapper>div:nth-child(2) [aria-label='text input']"),
            @FindBy(css = "[class*='searchPanelWrapper']>div:nth-child(2) [aria-label='text input']") })
   protected WebElement flyingTo;

   @FindAll({ @FindBy(css = ".SearchPanel__checkCol .SearchPanel__menuWrapper"),
            @FindBy(css = "[aria-label='destination airports'] li a:not([class*='disabled'])") })
   protected List<WebElement> arrivalAirport;

   @FindAll({ @FindBy(css = ".SearchPanel__searchPanelWrapper button"),
            @FindBy(css = "[aria-label='search button'] button") })
   protected WebElement searchButton;

   int noOfAdults, noOfChilds;

   @FindAll({
            @FindBy(css = ".SearchPanel__searchPanelWrapper>div:nth-child(1) [aria-label='text input']"),
            @FindBy(css = "[class*='searchPanelWrapper']>div:nth-child(1) [aria-label='text input']") })
   private WebElement flyingFrom;

   @FindAll({ @FindBy(css = "[aria-label='airport list'] li label span"),
            @FindBy(css = "[aria-label='airports'] li a:not([class*='disabled'])") })
   private List<WebElement> depAirport;

   @FindBy(xpath = "(//div[@class='DropModal__footerContainer'])[1]//button")
   private WebElement doneButton;

   @FindBy(css = "[aria-label='Departure Date'] input[aria-label='select date']")
   private WebElement depDateInput;

   @FindBy(css = "[arialabel='select month'] select")
   private WebElement depMonthDropDown;

   @FindBy(css = "[arialabel='select month'] option")
   private List<WebElement> depMonthValue;

   @FindAll({ @FindBy(css = ".SelectDate__calendar tbody tr td[class*='available']"),
            @FindBy(css = ".SelectLegacyDate__calendar tbody tr td[class*='available']") })
   private List<WebElement> depDate;

   @FindBy(css = "[aria-label='Departure date'] button")
   private WebElement depDateDone;

   @FindBy(css = ".return input[aria-label='select date']")
   private WebElement returnDateInput;

   @FindBy(css = ".ReturnDate__monthSelector select")
   private WebElement retMonthDropDown;

   @FindBy(css = ".ReturnDate__monthSelector option")
   private List<WebElement> retMonthValue;

   @FindBy(css = ".ReturnDate__calendar tbody tr td[class*='available']:not([class*='Selected'])")
   private List<WebElement> retDate;

   @FindBy(css = "input[aria-label='rooms and guests']")
   private WebElement roomAndGuest;

   @FindBy(css = "[aria-label='adult select'] select")
   private WebElement adults;

   @FindBy(css = "[aria-label='child select'] select")
   private WebElement childerns;

   @FindBy(css = "[aria-label='age select'] select")
   private List<WebElement> childAges;

   @FindBy(css = "[aria-label='room and guest'] button")
   private WebElement roomAndGuestDone;

   public NordicFlightOnlySearchPanelPage()
   {
      super();
      selenideHelper = new SelenideHelper();
      wait = new WebElementWait();
      format = new SimpleDateFormat();
      customSearch = new SearchCustom();
   }

   public final void selectDepartureAirport()
   {
      wait.forJSExecutionReadyLazy();
      wait.waitForAWhile(1000);
      selenideHelper.clickElementSelenide(flyingFrom);
      wait.forJSExecutionReadyLazy();
      wait.waitForAWhile(3000);
      LOGGER.log(LogLevel.INFO, customSearch.getScenarioId());
      TestDataAttributes parameter = new SearchDataHelper()
               .getSearchParameters(customSearch.getScenarioId());
      if (StringUtils.isNotEmpty(customSearch.getDepArpt()))
         WebElementTools.selectElementFromListBasedOnText(depAirport, customSearch.getDepArpt());
      else if (Objects.nonNull(parameter) && StringUtils.isNotEmpty(parameter.getDepAirport()))
         WebElementTools.selectElementFromListBasedOnText(depAirport, parameter.getDepAirport());
      else
      {
         WebDriverUtils.executeScript("arguments[0].scrollIntoView(true);", depAirport.get(0));
         WebElementTools.newActions().moveToElement(depAirport.get(0)).build().perform();
         WebElementTools.click(depAirport.get(0));
      }
      if (WebElementTools.isVisible(doneButton))
         selenideHelper.clickElementSelenide(doneButton);
   }

   public final void selectDepartureDate()
   {
      String dateRange = null, depDateValue = null;
      try
      {
         TestDataAttributes parameter = new SearchDataHelper()
                  .getSearchParameters(customSearch.getScenarioId());
         if (StringUtils.isNotEmpty(customSearch.getDepDate()))
            depDateValue = customSearch.getDepDate().trim();
         if (Objects.nonNull(parameter) && StringUtils.isNotEmpty(parameter.getDepDate()))
            depDateValue = parameter.getDepDate().trim();
         selectDate(depDateValue, null, depDateInput, depDate, depMonthDropDown,
                  depMonthValue);
      }
      catch (Exception e)
      {
         LOGGER.log("Unable to enter departure date" + e.getMessage());
      }
   }

   public final void selectReturnDate()
   {
      String dateRange = null, arrDateValue = null;
      try
      {
         TestDataAttributes parameter = new SearchDataHelper()
                  .getSearchParameters(customSearch.getScenarioId());
         if (StringUtils.isNotEmpty(customSearch.getArrDate()))
            arrDateValue = customSearch.getArrDate().trim();
         if (Objects.nonNull(parameter) && StringUtils.isNotEmpty(parameter.getArrDate()))
            arrDateValue = parameter.getArrDate().trim();
         selectDate(arrDateValue, null, returnDateInput, retDate, retMonthDropDown,
                  retMonthValue);
      }
      catch (Exception e)
      {
         LOGGER.log("Unable to enter a return date");
      }
   }

   private void selectDate(String givenDate, String dateRange, final WebElement dateInput,
            final List<WebElement> dateEles, final WebElement monthDropDown,
            final List<WebElement> monthValue) throws Exception
   {
      if (StringUtils.isNotEmpty(givenDate))
         selectMonthAndDate(givenDate, dateInput, monthDropDown, monthValue, dateEles);
      else if (StringUtils.isNotEmpty(dateRange))
         selectMonthAndDateBasedOnRagne(dateRange, dateInput, monthDropDown, monthValue, dateEles);
      else
      {
         wait.waitForElementToBePresent(dateInput);
         selenideHelper.clickElementSelenide(dateInput);
         wait.forJSExecutionReadyLazy();
         selenideHelper.clickElementSelenide(dateEles.get(0));
      }
   }

   private void datePatternMatcher(String dateValue) throws Exception
   {
      if (dateValue.matches("\\w+\\-\\d+\\-\\d+"))
         format.applyPattern("MMM-yyyy-dd");
      if (dateValue.matches("\\d{1,2}\\-\\d{1,2}\\-\\d{2,4}"))
         format.applyPattern("dd-MM-yyyy");
      else
         throw new Exception("passed date value didn't matched the date pattern");
   }

   private void selectMonthAndDate(String dateValue, final WebElement dateInput,
            final WebElement monthDropDown, final List<WebElement> monthValue,
            final List<WebElement> dateEles) throws Exception
   {
      datePatternMatcher(dateValue);
      Date givenDate = format.parse(dateValue);
      format.applyPattern("yyyy-MM");
      wait.forJSExecutionReadyLazy();
      selenideHelper.clickElementSelenide(dateInput);
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(monthDropDown);
      wait.forJSExecutionReadyLazy();

      WebElement monthName = monthValue.stream().filter(month ->
      {
         String monthVal = WebElementTools.getElementAttribute(month, "value").trim();
         return monthVal.equalsIgnoreCase(format.format(givenDate));
      }).findFirst().get();
      selenideHelper.clickElementSelenide(monthName);
      wait.forJSExecutionReadyLazy();
      try
      {
         for (WebElement depDate : dateEles)
         {
            WebElementTools.javaScriptScrollToElement(depDate);
            if (String.valueOf(givenDate.getDate()).equals(WebElementTools.getElementText(depDate))
                     && !depDate.isSelected())
            {
               wait.forClickable(depDate);
               selenideHelper.clickElementSelenide(depDate);
               break;
            }
         }
      }
      catch (Exception e)
      {
         LOGGER.log(LogLevel.ERROR, e.getMessage());
         WebElement date =
                  dateEles.stream().filter(depDate -> !depDate.isSelected()).findAny().get();
         wait.forClickable(date);
         selenideHelper.clickElementSelenide(date);
      }
   }

   private void selectMonthAndDateBasedOnRagne(String dateRange, final WebElement dateInput,
            final WebElement monthDropDown, final List<WebElement> monthValue,
            final List<WebElement> dateEles) throws Exception
   {
      String[] dateRangeAfterSplit = dateRange.split(":");
      datePatternMatcher(dateRangeAfterSplit[0]);
      Date startDate = format.parse(dateRangeAfterSplit[0]);
      Date endDate = format.parse(dateRangeAfterSplit[1]);

      wait.forJSExecutionReadyLazy();
      selenideHelper.clickElementSelenide(dateInput);
      wait.forAppear(monthDropDown);
      selenideHelper.clickElementSelenide(monthDropDown);
      wait.forAppear(monthValue);

      monthIteratorLoop:
      for (WebElement monthName : monthValue)
      {
         wait.forAppear(monthName);
         wait.forJSExecutionReadyLazy();
         for (WebElement date : dateEles)
         {
            wait.forAppear(date);
            String datePickerString =
                     new Select(monthDropDown).getFirstSelectedOption().getAttribute("value")
                              .trim() + "-"
                              + date;
            format.applyPattern("yyyy-MM-dd");
            Date datePickerDate = format.parse(datePickerString);
            if (datePickerDate.after(startDate) && datePickerDate.before(endDate))
            {
               wait.forAppear(date);
               selenideHelper.clickElementSelenide(date);
               break monthIteratorLoop;
            }
         }
         WebElementTools.mouseOverAndClick(monthName);
      }
      selenideHelper.clickElementSelenide(depDateDone);
   }

   public final void selectAdultAndChild()
   {
      TestDataAttributes parameter = new SearchDataHelper()
               .getSearchParameters(customSearch.getScenarioId());
      wait.forComplexPageLoad();
      wait.forAppear(roomAndGuest);
      selenideHelper.clickElementSelenide(roomAndGuest);
      wait.forJSExecutionReadyLazy();
      Random random = new Random();
      if (Objects.nonNull(customSearch.getAdultCount()))
         noOfAdults = customSearch.getAdultCount();
      else if (Objects.nonNull(parameter) && StringUtils.isNotEmpty(parameter.getNoOfAdults()))
         noOfAdults = Integer.parseInt(parameter.getNoOfAdults());
      else
      {
         noOfAdults = random.nextInt(HybrisConfigHelper.getValidTotalAdultCount())
                  + HybrisConfigHelper.getValidLowestAdultCount();
      }
      WebElementTools.selectDropDownByVisibleText(adults, String.valueOf(noOfAdults));
      if (Objects.nonNull(customSearch.getChildCount()))
         noOfChilds = customSearch.getChildCount();
      else if (Objects.nonNull(parameter) && StringUtils.isNotEmpty(parameter.getNoOfChildren()))
         noOfChilds = Integer.parseInt(parameter.getNoOfChildren());
      else
      {
         noOfChilds = random.nextInt(HybrisConfigHelper.getValidTotalChildrenCount())
                  + HybrisConfigHelper.getValidLowestChildrenCount();
      }
      int total = noOfAdults + noOfChilds;
      if (noOfChilds == 0)
         roomAndGuestDone.click();
      else
      {
         while (true)
         {
            if (total <= HybrisConfigHelper.getTotalValidPassengerCount())
            {
               wait.forComplexPageLoad();
               WebElementTools.selectDropDownByVisibleText(childerns,
                        String.valueOf(noOfChilds));
               break;
            }
            else if (total > HybrisConfigHelper.getTotalValidPassengerCount())
            {
               noOfAdults = random.nextInt(HybrisConfigHelper.getValidTotalAdultCount())
                        + HybrisConfigHelper.getValidLowestAdultCount();
               noOfChilds = random.nextInt(HybrisConfigHelper.getValidTotalChildrenCount())
                        + HybrisConfigHelper.getValidLowestChildrenCount();
            }
         }
      }
   }

   public final void enterChildernAges()
   {
      if (noOfChilds == 0)
      {
         LOGGER.log(LogLevel.INFO, "No children present to select the age");
      }
      else
      {
         String childernAges = StringUtils.EMPTY;
         TestDataAttributes parameter = new SearchDataHelper()
                  .getSearchParameters(customSearch.getScenarioId());
         if (Objects.nonNull(customSearch.getChildAges()))
            childernAges = customSearch.getChildAges();
         else if (Objects.nonNull(parameter) && StringUtils.isNotEmpty(parameter.getChildrenAge()))
            childernAges = parameter.getChildrenAge();
         String[] childAgesArray = new String[] {};
         if (!childernAges.isEmpty())
            childAgesArray = childernAges.split(",");
         for (int i = 1; i <= noOfChilds; i++)
         {
            Random random = new Random();
            int randomVal = random.nextInt(HybrisConfigHelper.getMaxValidAge());
            if (randomVal == 0 || randomVal == 1)
            {
               randomVal = random.nextInt(HybrisConfigHelper.getMaxValidAge()) + 2;
               LOGGER.log(LogLevel.INFO, "Children Age is : " + randomVal);
            }
            if (childAgesArray.length > 0)
               WebElementTools.selectDropDownByVisibleText(childAges.get(i - 1),
                        String.valueOf(childAgesArray[i - 1]));
            else
               WebElementTools.selectDropDownByVisibleText(childAges.get(i - 1),
                        String.valueOf(randomVal));
         }
         roomAndGuestDone.click();
      }
   }
}
