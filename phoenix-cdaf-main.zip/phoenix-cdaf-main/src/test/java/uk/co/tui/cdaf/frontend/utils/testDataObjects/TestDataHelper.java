package uk.co.tui.cdaf.frontend.utils.testDataObjects;

import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.BookingTypes;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.PaymentTypes;

public class TestDataHelper
{

   public static BookingTypes getTripsBookingData()
   {
      return TripsBookingDataHelper.getInstance();
   }

   public static PaymentTypes paymentDetailsDataHelper()
   {
      return PaymentDetailsDataHelper.getInstance();
   }

}
