package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.DOMElementHelper;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.codeborne.selenide.Selenide.$;
import static uk.co.tui.cdaf.frontend.utils.logger.LogLevel.ERROR;
import static uk.co.tui.cdaf.utils.WebDriverUtils.getDriver;

public class InsuranceComponent extends AbstractPage
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(InsuranceComponent.class);

   WebElementWait wait;

   @FindBy(css = "[class*='expInsurance']")
   private WebElement insuranceComponent;

   @FindBy(css = "[aria-label='insurance title']")
   private WebElement insuranceHeaderTitle;

   @FindBy(css = "[aria-label='insurance content']")
   private WebElement insuranceHeaderContent;

   @FindBy(css = "[aria-label='tick all passenger']")
   private WebElement tickAllContent;

   @FindBy(css = "[aria-label='insurance passenger form header']")
   private WebElement passengerDetailText;

   @FindBy(css = "[aria-label='passenger checkbox']")
   private WebElement passengerCheckBox;

   @FindAll({ @FindBy(css = "[aria-label*='passengerDob']"),
            @FindBy(css = "[aria-label*='passenger DOB']") })
   private WebElement passengerDOB;

   @FindBy(css = "[aria-label*=' Insurance name']")
   private List<WebElement> InsuranceName;

   @FindBy(css = "[aria-label*='Insurance description']")
   private List<WebElement> InsuranceDesc;

   @FindBy(css = "[aria-label*='Insurance starting form']")
   private List<WebElement> InsuranceFromPrice;

   @FindBy(css = "[aria-label*='collapsible icon open']")
   private WebElement cardInsuranceDefaultClosed;

   @FindBy(css = ".GetQuoteV2__getQuote .GetQuoteV2__light")
   private WebElement updatePriceDisabled;

   @FindBy(css = ".GetQuoteV2__infantNotBorn.GetQuoteV2__notBornChecked")
   private WebElement infantNotyetBornDisabled;

   @FindAll({
            @FindBy(css = ".GetQuoteV2__infantNotBorn.GetQuoteV2__notChecked label[aria-label='checkbox'] span svg[class='inputs__checkIcon']"),
            @FindBy(css = ".GetQuoteV2__infantNotBorn.GetQuoteV2__notChecked"),
            @FindBy(css = ".GetQuoteV2__infantNotBorn.GetQuoteV2__notChecked label[aria-label='checkbox']") })
   private List<WebElement> infantNotyetBornEnabled;

   @FindBy(css = ".GetQuoteV2__infantNotBornMessage")
   private WebElement infantNotyetBornMessage;

   @FindBy(css = ".GetQuoteV2__notChecked")
   private List<WebElement> selectOnePassengerCheckbox;

   @FindBy(css = ".inputs__error span")
   private List<WebElement> passengerErrorMessage;

   @FindBy(css = ".InfantCheckbox .GetQuoteV2__notChecked")
   private List<WebElement> InfantCheckbox;

   @FindBy(css = ".GetQuoteV2__selectAll")
   private WebElement travelInsuranceGetQuoteSelectAllLink;

   @FindBy(css = ".GetQuoteV2__checked")
   private List<WebElement> checkedPassengerCheckBox;

   @FindBy(css = "[class*='GetQuoteV2__secondary']")
   private WebElement updatePriceEnabledButton;

   @FindBy(css = "[class*='InsuranceType__selectButton']")
   private List<WebElement> insuranceEnabledButton;

   @FindBy(css = "[class*='AccordionToggle__accordionToggle']")
   private List<WebElement> insuranceAccordion;

   @FindBy(css = ".GetQuoteV2__getQuote button")
   private WebElement travelInsuranceGetQuoteButton;

   @FindBy(css = "[class*='insuranceSelected']")
   private List<WebElement> selectedInsurance;

   @FindBy(css = "[aria-label= 'Insurance Category 0'] .InsuranceType__insuranceTitleSection .InsuranceType__insuranceDescListItem")
   private List<WebElement> insuranceUsps;

   @FindBy(css = "[aria-label= 'Insurance Category 0'] [aria-label= 'insurance usp item']")
   private List<WebElement> mobileInsuranceUsps;

   @FindBy(css = "[aria-label= 'Insurance Category 0'] [aria-label='show more link']")
   private List<WebElement> showMoreLink;

   @FindBy(css = "[aria-label= 'Insurance Category 0'] [aria-label='show less link']")
   private List<WebElement> showLessLink;

   @FindBy(css = "[aria-label= 'Insurance Category 0'] .InsuranceType__moreInformation")
   private WebElement moreInformationLink;

   @FindBy(css = "[class*='Modal__opened']")
   private WebElement insurancePopup;

   @FindBy(css = "[class*='Modal__opened'] [class*='Modal__closeIcon']")
   private WebElement insurancePopupCloseButton;

   @FindBy(css = ".GetQuoteV2__toolTip")
   private WebElement leadPaxtooltip;

   @FindBy(css = ".GetQuoteV2__toolTip span")
   private WebElement toolTipText;

   public InsuranceComponent()
   {
      wait = new WebElementWait();
   }

   public boolean getInsuranceSeleted()
   {
      return DOMElementHelper.isElementExistByClass("Selectable__selected");
   }

   public boolean getInsuranceDefaultClosed()
   {
      return DOMElementHelper.isElementExistByAriaLabel("collapsible icon open");
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getInsuranceTypeComponents()
   {
      return new HashMap<>()
      {
         {
            put("Insurance Type", InsuranceName.get(0));
            put("Insurance Type Description", InsuranceDesc.get(0));
            put("From Price ", InsuranceFromPrice.get(0));
         }
      };
   }

   public void viewInsurance()
   {
      WebElementTools.scrollToCenter(insuranceComponent);
   }

   public boolean isUpdateButtonDisabled()
   {
      return $(".GetQuoteV2__getQuote .GetQuoteV2__light").should(Condition.appear).exists();
   }

   public boolean isInfantCheckBoxDisabled()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(infantNotyetBornDisabled);
   }

   public boolean isInfantCheckBoxEnabled()
   {
      wait.forJSExecutionReadyLazy();
      wait.forAppear(infantNotyetBornEnabled.get(0));
      return WebElementTools.isDisplayed(infantNotyetBornEnabled.get(0));
   }

   public void isInfantNotYetBornCheckBoxClicked()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(infantNotyetBornEnabled.get(0));
   }

   public boolean isInfantNotYetBornMessageDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(infantNotyetBornMessage);
   }

   public String getInfantErrorMessage()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(infantNotyetBornMessage);
   }

   public void selectTickForLeadPassenger()
   {
      WebElementTools.scrollToCenter(insuranceComponent);
      WebElementTools.mouseOverAndClick(selectOnePassengerCheckbox.get(0));
   }

   public boolean isErrorMessageDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(passengerErrorMessage.get(0));
   }

   public String getDobErromessage()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.getElementText(passengerErrorMessage.get(0));
   }

   public void selectTickForNonLeadPassenger()
   {
      WebElementTools.scrollToCenter(insuranceComponent);
      WebElementTools.mouseOverAndClick(selectOnePassengerCheckbox.get(0));
   }

   public void enterLeadPaxDOB(String day, String month, String year)
   {
      SelenideElement leadPaxContainer = $("div.GetQuoteV2__passenger").should(Condition.appear);
      leadPaxContainer.$("input[placeholder='DD']").shouldBe(Condition.enabled)
               .sendKeys(Keys.chord(Keys.CONTROL, "a"), day);
      leadPaxContainer.$("input[placeholder= 'MM']").shouldBe(Condition.enabled)
               .sendKeys(Keys.chord(Keys.CONTROL, "a"), month);
      leadPaxContainer.$("input[placeholder= 'JJJJ']").shouldBe(Condition.enabled)
               .sendKeys(Keys.chord(Keys.CONTROL, "a"), year);
   }

   public boolean isInfantNotBornCriteria()
   {
      JavascriptExecutor executor = (JavascriptExecutor) getDriver();
      return (boolean) executor.executeScript(
               "return jsonData.packageViewData.passenger.filter( passengers => passengers.age === 0).length > 0");
   }

   public boolean isInfantCheckBoxDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(InfantCheckbox.get(0));
   }

   public void navigateToInfantNotBornCheckBox()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollToCenter(InfantCheckbox.get(0));
   }

   public void clickInfantNotBornCheckBox()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(InfantCheckbox.get(0));
   }

   @SuppressWarnings("serial")
   public Map<String, WebElement> getInsurancePassengerFormComponents()
   {
      return new HashMap<>()
      {
         {
            put("INSURANCE", insuranceHeaderTitle);
            put("Insurance content", insuranceHeaderContent);
            put("TICK ALL WHO NEED INSURANCE", tickAllContent);
            put(
                     "Please enter passengers' dates of birth as they appear on their passport to get an accurate quote",
                     passengerDetailText);
            put("Tick box", passengerCheckBox);
            put("DoB DD/MM/YYYY", passengerDOB);
         }
      };
   }

   public void selectGetQuote()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(travelInsuranceGetQuoteButton);
   }

   public boolean isUpdatePriceButtonEnabled()
   {
      return WebElementTools.isPresent(updatePriceEnabledButton);
   }

   public boolean isSelectAllLinkPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(travelInsuranceGetQuoteSelectAllLink);
   }

   public void clickSelectAllLink()
   {
      WebElementTools.scrollToCenter(travelInsuranceGetQuoteSelectAllLink);
      WebElementTools.mouseOverAndClick(travelInsuranceGetQuoteSelectAllLink);
   }

   public boolean isPassengerTickBoxTicked()
   {
      return !checkedPassengerCheckBox.isEmpty();
   }

   public boolean isPassengersDobDisabled()
   {
      return !selectOnePassengerCheckbox.isEmpty();
   }

   public void selectAllPassengers()
   {
      selectOnePassengerCheckbox.forEach(WebElementTools::mouseOverAndClick);
   }

   public void selectEnabledInsuranceButton()
   {
      try
      {
         this.selectTickForLeadPassenger();
         this.enterLeadPaxDOB("12", "12", "1989");
         wait.forJSExecutionReadyLazy();
         this.selectGetQuote();
         wait.forJSExecutionReadyLazy();
         wait.waitForAWhile(10000);
         WebElementTools.scrollToCenter(insuranceAccordion.get(0));
         wait.forJSExecutionReadyLazy();
         WebElementTools.mouseOverAndClick(insuranceAccordion.get(0));
         WebElementTools.mouseOverAndClick(insuranceAccordion.get(1));
         wait.forJSExecutionReadyLazy();
         WebElementTools.mouseOverAndClick(insuranceEnabledButton.get(0));
      }
      catch (Exception e)
      {
         LOGGER.log(ERROR, "There is an error in selecting the insurance button:" + e);
      }
   }

   public boolean isInsuranceSelected()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(selectedInsurance.get(0));
   }

   public boolean isSingleInsuranceSelected()
   {
      wait.forJSExecutionReadyLazy();
      return selectedInsurance.size() == 1;
   }

   public void selectAlternateInsuranceOption()
   {
      WebElementTools.scrollToCenter(insuranceEnabledButton.get(1));
      WebElementTools.mouseOverAndClick(insuranceEnabledButton.get(1));
   }

   public boolean isMaxInsuranceUspCount(Integer count)
   {
      wait.forJSExecutionReadyLazy();
      return insuranceUsps.size() <= count;
   }

   public boolean isDefaultMobileInsuranceUspCount(Integer count)
   {
      wait.forJSExecutionReadyLazy();
      return mobileInsuranceUsps.size() == count;
   }

   public boolean hasShowMoreLink()
   {
      wait.forJSExecutionReadyLazy();
      return showMoreLink.size() == 1;
   }

   public void selectShowMore()
   {
      WebElementTools.scrollToCenter(insuranceAccordion.get(0));
      WebElementTools.mouseOverAndClick(insuranceAccordion.get(0));
      WebElementTools.mouseOverAndClick(showMoreLink.get(0));
   }

   public boolean hasShowLessLink()
   {
      wait.forJSExecutionReadyLazy();
      return showLessLink.size() == 1;
   }

   public void selectMoreInformationLink()
   {
      wait.forJSExecutionReadyLazy();
      this.viewInsurance();
      WebElementTools.scrollToCenter(insuranceAccordion.get(0));
      WebElementTools.mouseOverAndClick(insuranceAccordion.get(0));
      WebElementTools.mouseOverAndClick(moreInformationLink);

   }

   public boolean isInsuranceDeselected()
   {
      return !insuranceAccordion.isEmpty();
   }

   public boolean isInsurancePopupDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(insurancePopup);
   }

   public void selectInsurancePopupCloseButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(insurancePopupCloseButton);
   }

   public boolean isShowMoreLinkDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isDisplayed(moreInformationLink);
   }

   public boolean isToolTipPresent()
   {
      WebElementTools.mouseHover(leadPaxtooltip);
      wait.forAppear(leadPaxtooltip);
      String paxtoolTipText = toolTipText.getText();
      return !Objects.equals(paxtoolTipText, "");
   }

   public String getLeadPaxToolTipText()
   {
      return toolTipText.getAttribute("data-tooltip");
   }

   public void navigateToInsuranceComponent()
   {
      WebElementTools.scrollToCenter(insuranceAccordion.get(0));
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(insuranceAccordion.get(0));
   }

}
