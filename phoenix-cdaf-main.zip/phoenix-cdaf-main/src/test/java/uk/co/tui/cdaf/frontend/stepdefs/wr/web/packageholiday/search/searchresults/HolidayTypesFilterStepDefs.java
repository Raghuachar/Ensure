package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.search.searchresults;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults.SearchResultsHolidayTypesFilterComponent;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class HolidayTypesFilterStepDefs
{

   static AutomationLogManager LOGGER = new AutomationLogManager(HolidayTypesFilterStepDefs.class);

   public final PackageNavigation packageNavigation;

   private final SearchResultsHolidayTypesFilterComponent searchResultsHolidayTypesFilterComponent;

   public HolidayTypesFilterStepDefs()
   {
      packageNavigation = new PackageNavigation();
      searchResultsHolidayTypesFilterComponent = new SearchResultsHolidayTypesFilterComponent();
   }

   @When("they are viewing the Holiday Types Filter")
   public void they_are_viewing_the_Holiday_Types_Filter()
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypePresent())
         assertThat("Tui holiday types filter component is not present",
                  searchResultsHolidayTypesFilterComponent.isHolidayTypePresent(), is(true));
   }

   @Then("they will see the following Holiday Types that they can filter by")
   public void they_will_see_the_following_Holiday_Types_that_they_can_filter_by(
            String dataTable)
   {
      LOGGER.log(LogLevel.INFO, "is holiday types Filter title same as in scenerio mentioned ? "
               + dataTable);
      assertThat("holiday types Filter title not same as in scenerio mentioned",
               searchResultsHolidayTypesFilterComponent
                        .validateHolidayTypesTitleSameAsScenerio(dataTable),
               is(true));
   }

   @Then("these will be in an unselected state by default holiday")
   public void these_will_be_in_an_unselected_state_by_default_holiday()
   {
      LOGGER.log(LogLevel.INFO, "All of the checkbox deselect when it loads search results page ? "
               + searchResultsHolidayTypesFilterComponent.isAnyOfTheHolidayTypesSelectedPresent());
      assertThat("All of the checkbox not deselect when it loads search results page",
               searchResultsHolidayTypesFilterComponent.isAnyOfTheHolidayTypesSelectedPresent(),
               is(false));
   }

   @Then("there will be a show more link after {int} options")
   public void there_will_be_a_show_more_link_after_options(Integer int1)
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5())
         assertThat("holiday types Filter title not same as in scenerio mentioned",
                  searchResultsHolidayTypesFilterComponent.isShowMoreButtonEnabled(), is(true));
   }

   @When("they want to filter by {string}")
   public void they_want_to_filter_by(String string)
   {
      LOGGER.log(LogLevel.INFO, "is holiday types Filter present in search results ? "
               + searchResultsHolidayTypesFilterComponent.isHolidayTypePresent());
      assertThat("Tui holiday types filter component is not present",
               searchResultsHolidayTypesFilterComponent.isHolidayTypePresent(), is(true));
   }

   @Then("the following will be available")
   public void the_following_will_be_available(io.cucumber.datatable.DataTable dataTable)
   {
      LOGGER.log(LogLevel.INFO, "Holiday Name list is valid ? "
               + searchResultsHolidayTypesFilterComponent.verifyHolidayTypesNameList(dataTable));
      assertThat("Holiday Name list is not valid",
               searchResultsHolidayTypesFilterComponent.verifyHolidayTypesNameList(dataTable),
               is(true));
   }

   @When("there are more than {int} Holidays by TUI options available to filter by")
   public void there_are_more_than_Holidays_by_TUI_options_available_to_filter_by(Integer int1)
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5())
         assertThat("holiday types Filter title not same as in scenerio mentioned",
                  searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5(),
                  is(true));
   }

   @Then("a show more link will display below the options already visible to the customer")
   public void a_show_more_link_will_display_below_the_options_already_visible_to_the_customer()
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5())
         assertThat("holiday types Filter title not same as in scenerio mentioned",
                  searchResultsHolidayTypesFilterComponent.isShowMoreButtonEnabled(), is(true));
   }

   @Given("they are viewing the Holiday Types filter when more than {int} Holidays by TUI options available to filter by")
   public void they_are_viewing_the_Holiday_Types_filter_when_more_than_Holidays_by_TUI_options_available_to_filter_by(
            Integer int1)
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5())
         assertThat("holiday types Filter title not same as in scenerio mentioned",
                  searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5(),
                  is(true));
   }

   @Then("they will see more Holidays by TUI listed")
   public void they_will_see_more_Holidays_by_TUI_listed()
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5())
         assertThat("holiday types Filter title not same as in scenerio mentioned",
                  searchResultsHolidayTypesFilterComponent.isShowMoreButtonEnabled(), is(true));
   }

   @Then("a {string} link will be visible")
   public void a_link_will_be_visible(String string)
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5())
         searchResultsHolidayTypesFilterComponent.clickShowMoreButton();
   }

   @Then("selecting {string} hides the additional facilities")
   public void selecting_hides_the_additional_facilities(String string)
   {
      assertThat("holiday types Filter title not same as in scenerio mentioned",
               searchResultsHolidayTypesFilterComponent.isShowLessButtonEnabled(), is(false));
   }

   @When("they select {string} from holiday types filter")
   public void they_select_from_holiday_types_filter(String string)
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypesCountMoreThan5())
         assertThat("Holiday Name list is not valid",
                  searchResultsHolidayTypesFilterComponent.getMoreResultsWith6thPosition(),
                  is(true));
   }

   @Given("they are viewing the Holiday Types filter")
   public void they_are_viewing_the_Holiday_Types_filter()
   {
      LOGGER.log(LogLevel.INFO, "is holiday types Filter present in search results ? "
               + searchResultsHolidayTypesFilterComponent.isHolidayTypePresent());
      assertThat("Tui holiday types filter component is not present",
               searchResultsHolidayTypesFilterComponent.isHolidayTypePresent(), is(true));
   }

   @When("they select a Holiday Type to filter by")
   public void they_select_a_Holiday_Type_to_filter_by()
   {
      assertThat("Tui holiday types filter component is not present",
               searchResultsHolidayTypesFilterComponent.isHolidayTypePresent(), is(true));
   }

   @Then("they can select {int} or many Holiday Types")
   public void they_can_select_or_many_Holiday_Types(Integer int1)
   {
      searchResultsHolidayTypesFilterComponent.selectHolidayTypesFilter();
   }

   @Then("the search results will filter to reflect the selection holidays")
   public void the_search_results_will_filter_to_reflect_the__holiday_selection()
   {
      searchResultsHolidayTypesFilterComponent.isAnyOfTheHolidayTypesSelectedPresent();
   }

   @Then("the holiday types clear filters links will show")
   public void the_holiday_types_clear_filters_links_will_show()
   {
      assertThat("Tui holiday types filter component is not present",
               searchResultsHolidayTypesFilterComponent.holidayTypeClearLinkPresent(), is(true));
   }

   @Given("they are viewing the holiday types filters")
   public void they_are_viewing_the_holiday_types_filters()
   {
      assertThat("Tui holiday types filter component is not present",
               searchResultsHolidayTypesFilterComponent.isHolidayTypePresent(), is(true));
   }

   @When("a holiday type is unavailable")
   public void a_holiday_type_is_unavailable()
   {
      if (!searchResultsHolidayTypesFilterComponent.isHolidayTypePresent())
         assertThat("Tui holiday types filter component is not present",
                  searchResultsHolidayTypesFilterComponent.disabledHolidayTypes(), is(true));
   }

   @Then("this will be greyed out holiday")
   public void this_will_be_greyed_holiday_out()
   {
      if (!searchResultsHolidayTypesFilterComponent.isHolidayTypePresent())
         assertThat("Tui holiday types filter component is not present",
                  searchResultsHolidayTypesFilterComponent.disabledHolidayTypes(), is(true));
   }

   @Given("they have filtered the Holiday Types")
   public void they_have_filtered_the_Holiday_Types()
   {
      assertThat("Tui holiday types filter component is not present",
               searchResultsHolidayTypesFilterComponent.isHolidayTypePresent(), is(true));
   }

   @Then("they will be able select functionto clear section")
   public void they_will_be_able_select_function_to_clear_section()
   {
      searchResultsHolidayTypesFilterComponent.holidayTypeClearLinkSelection();
   }

   @When("they select the holiday types {string} filter")
   public void they_select_the_filter_holiday_types(String string)
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterDisplayed())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
   }

   @Then("the filter options will open in a modal holiday")
   public void the_filter_options_will_open_in_a_holiday_modal()
   {
      searchResultsHolidayTypesFilterComponent.selectSpecificHolidayTypes();
   }

   @Then("the customer can select the filters they wish to filter by including Holiday types")
   public void the_customer_can_select_the_filters_they_wish_to_filter_by_including_Holiday_types()
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
         searchResultsHolidayTypesFilterComponent.applyMoreFilters();
   }

   @Given("the customer has selected the {string} filter")
   public void the_customer_has_selected_the_filter(String string)
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
         searchResultsHolidayTypesFilterComponent.moreFiltersTextCompare(string);
   }

   @Given("they are viewing the more filters modal")
   public void they_are_viewing_the_more_filters_modal()
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
   }

   @When("they wish to close the modal holiday")
   public void they_wish_to_close_the_modal_holiday()
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
   }

   @Then("they can do this by selecting the following holiday types")
   public void they_can_do_this_by_selecting_the_following(List<String> components)
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
      components.forEach(component ->
      {
         if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
            assertThat("close options not available:",
                     searchResultsHolidayTypesFilterComponent.closeModal(component), is(true));
      });
   }

   @Then("if selections have been made, the filter will show in a selected state holiday")
   public void if_selections_have_been_made_the_filter_will_show_in_a_selected_holiday_state()
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
      searchResultsHolidayTypesFilterComponent.applyMoreFilters();
   }

   @Then("the search results will filter to reflect the selection made holiday types")
   public void the_search_results_will_filter_to_reflect_the_selection_made()
   {
      if (searchResultsHolidayTypesFilterComponent.isAnyOfTheHolidayTypeSelectablePresent())
         searchResultsHolidayTypesFilterComponent.selectSpecificHolidayTypes();
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
   }

   @And("they have filtered the Holiday Types using the {string} filter")
   public void they_have_filtered_the_Holiday_Types_using_the_filter(String string)
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterDisplayed())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
      searchResultsHolidayTypesFilterComponent.isHolidayTypePresent();
      if ("Vakantietype".equalsIgnoreCase(string))
         searchResultsHolidayTypesFilterComponent.selectSpecificHolidayTypes();
   }

   @When("they want to clear the Holiday Types selection")
   public void they_want_to_clear_the_Holiday_Types_selection()
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypePresent())
         searchResultsHolidayTypesFilterComponent.deselectSpecificHolidayTypes();
   }

   @Then("they will be able select clear from the holiday types {string} modal")
   public void they_will_be_able_holiday_types_select_clear_from_the_modal(String string)
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterDisplayed())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
      searchResultsHolidayTypesFilterComponent.closeModal("x");
   }

   @Given("they have filtered the results holiday types")
   public void they_have_filtered_the_results_holiday_types()
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterApplyPresent())
         searchResultsHolidayTypesFilterComponent.clickMoreFilters();
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypePresent())
         searchResultsHolidayTypesFilterComponent.selectSpecificHolidayTypes();
   }

   @When("they want to clear the filter selections holiday types")
   public void they_want_to_clear_the_filter_selections_holiday_types()
   {
      if (searchResultsHolidayTypesFilterComponent.isHolidayTypePresent())
         searchResultsHolidayTypesFilterComponent.deselectSpecificHolidayTypes();
   }

   @Then("they will be able select Clear all from the holiday {string} modal")
   public void they_will_be_able_select_Clear_all_from_the_modal(String string)
   {
      if (searchResultsHolidayTypesFilterComponent.isMoreFilterDisplayed())
         searchResultsHolidayTypesFilterComponent.clearAllModel();
   }

}
