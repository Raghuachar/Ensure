package uk.co.tui.cdaf.frontend.pom.wr.search.components.pad_and_rooms;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.jetbrains.annotations.NotNull;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;
import uk.co.tui.cdaf.frontend.utils.logger.LogLevel;

import java.time.Duration;
import java.util.Objects;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Selectors.shadowDeepCss;
import static com.codeborne.selenide.Selenide.$;

public class PaxAndRoomsMfe implements PaxAndRooms
{
   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PaxAndRoomsMfe.class);
   private static final Duration WAIT_TIMEOUT = Duration.ofSeconds(5);

   private SelenideElement dropdown;

   private static int getCurrentPassengers(SelenideElement passengersBlock)
   {
      String value = passengersBlock.$("span.passengerCount").getText();
      return Integer.parseInt(Objects.requireNonNull(value));
   }

   private SelenideElement container()
   {
      if (dropdown == null)
      {
         dropdown = $(shadowDeepCss("div.paxAndRooms"));
      }
      dropdown.should(appear, WAIT_TIMEOUT);
      return dropdown;
   }

   @Override
   public boolean isOpen()
   {
      return container().isDisplayed();
   }

   @Override
   public PaxAndRooms clearSelection()
   {
      getClearLink().click();
      return this;
   }

   public PaxAndRooms selectNumberOfRooms(int roomsNumber)
   {
      getRoomSelector().selectOptionByValue(Integer.toString(roomsNumber));
      return this;
   }

   public PaxAndRooms setAdultsNumber(int numberOfPersons, int roomNumber)
   {
      setExpectedNumber(numberOfPersons, getPassengersBlock(roomNumber));
      return this;
   }

   @NotNull
   private SelenideElement getPassengersBlock(int roomNumber)
   {
      return getRoom(roomNumber).$("div.passenger.adultBlock > div.controlBlock");
   }

   public PaxAndRooms addChild(String age, int roomNumber)
   {
      SelenideElement room = getRoom(roomNumber);
      SelenideElement passengersBlock = room.$("div.passenger.childrenBlock > div.controlBlock");
      addPassenger(passengersBlock);
      room.$$("[aria-label='Children age selection']").last().selectOptionByValue(age);
      return this;
   }

   public PaxAndRooms selectRandomPaxAndRooms()
   {
      int roomsNumber = (int) (Math.random() * 4) + 1;
      for (int i = 0; i < roomsNumber; i++)
      {
         int room = i + 1;
         selectNumberOfRooms(room);
         setAdultsNumber(1, room);
      }
      addChild("8", 1);
      return this;
   }

   @Override
   public SelenideElement getClearLink()
   {
      return container().$("a.clear");
   }

   @Override
   public SelenideElement getConfirmButton()
   {
      return container().$("button.primary");
   }

   @Override
   public SelenideElement getRoomSelector()
   {
      return container().$("select[aria-label='Rooms selection']");
   }

   public String[] getLabels()
   {
      return $(shadowDeepCss("div.paxContentWrapper")).getText().split("\n");
   }

   @Override
   public String getErrorMessage()
   {
      SelenideElement errorMessageElement = $(shadowDeepCss("div.childrenErrorMessageContent"));
      if (errorMessageElement.exists())
         return errorMessageElement.getText();
      else
         return null;
   }

   public void confirmSelection()
   {
      getConfirmButton().click();
   }

   @Override
   public SelenideElement getAdultSelector(int roomNumber)
   {
      SelenideElement passengersBlock = getPassengersBlock(roomNumber);
      return passengersBlock.$("span.passengerCount");
   }

   private SelenideElement getRoom(int roomNumber)
   {
      int roomIndex = roomNumber - 1;
      return container().$(".paxAndRoomsContainer").$$(".bodyContent").get(roomIndex);
   }

   private void setExpectedNumber(int numberOfPersons, SelenideElement passengersBlock)
   {
      passengersBlock.shouldBe(Condition.visible, WAIT_TIMEOUT);
      while (getCurrentPassengers(passengersBlock) > numberOfPersons)
      {
         removePassenger(passengersBlock);
      }
      while (getCurrentPassengers(passengersBlock) < numberOfPersons)
      {
         if (getErrorMessage() != null)
         {
            LOGGER.log(LogLevel.ERROR, "Imposible to set number of persons to "
                     + numberOfPersons + " because of error message: " + getErrorMessage());
            return;
         }
         addPassenger(passengersBlock);
      }
   }

   private void addPassenger(SelenideElement passengersBlock)
   {
      passengersBlock.$("button.icon-button.passengerIcon.plus").click();
   }

   private void removePassenger(SelenideElement passengersBlock)
   {
      passengersBlock.$("button.icon-button.passengerIcon.minus").click();
   }
}
