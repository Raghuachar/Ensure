package uk.co.tui.cdaf.frontend.pom.wr.retail;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.BookingAttributes;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;

import static com.codeborne.selenide.Selectors.byXpath;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

public class BookingRetrievalPage extends AbstractPage
{
   public final WebDriverUtils utils;

   private final WebElementWait wait;

   protected BookingAttributes testData;

   @FindBy(css = ".UI__buttonWrapper button")
   private WebElement loginToBooking;

   @FindAll({ @FindBy(xpath = "//input[@name='bookingRefereneceId']"),
            @FindBy(xpath = "//input[@name='bookingReferenceId']"),
            @FindBy(css = "#customer-form input[type=text]"), @FindBy(css = "#agent-reference") })
   private WebElement bookingReference;

   private SelenideElement getRetrieveBooking(){
      return $(byXpath("a[href='/retail/travel/managebooking']"));
   }

   public BookingRetrievalPage()
   {
      utils = new WebDriverUtils();
      testData = new BookingAttributes();
      wait = new WebElementWait();
   }

   public void retailretrievebooking()
   {
      getRetrieveBooking().should(Condition.appear, Duration.ofSeconds(10)).scrollTo().click();
   }

   public void enterBookingReferenceNumber(String bookingReferenceNumber)
   {
      wait.forJSExecutionReadyLazy();
      wait.waitForAWhile(2000);
      WebElementTools.clickElementJavaScript(bookingReference);
      WebElementTools.enterText(bookingReference, bookingReferenceNumber);
   }

   public void selectLoginToBookingButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(loginToBooking);
      wait.forJSExecutionReadyLazy();
   }

   public void retrieveRetailBooking(String bookingRefNum)
   {
      retailretrievebooking();
      enterBookingReferenceNumber(bookingRefNum);
      selectLoginToBookingButton();
   }

}
