package uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.search.searchresults;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.tools.WebElementTools;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Selenide.$;

public class SearchResultsFiltersComponent extends AbstractPage
{
   private final Map<String, WebElement> searchCardMap;

   private final WebElementWait wait;

   @FindAll({ @FindBy(css = "[class*='BoardBasis__boardBasisListWraper']"),
            @FindBy(css = "[aria-label*='boardBasis filter']") })
   private WebElement boardBasisFilter;

   @FindBy(css = ".BoardBasis__option label input:not(:checked)+span+span .BoardBasis__boardType")
   private List<WebElement> boardBasisComponent;

   @FindAll({
            @FindBy(css = ".FilterPanelV2__filterPanelContent .Flights__cardWrapper .Flights__clearLink a"),
            @FindBy(css = ".FilterPanelV2__filterPanelContent .BoardBasis__boardBasisListWraper .BoardBasis__clearLink"),
            @FindBy(css = ".FilterPanelV2__childFilterHeader .Flights__cardWrapper .Flights__clearLink a"),
            @FindBy(css = ".FilterPanelV2__childFilterHeader .Price__cardHeader .Price__clearLink a"),
            @FindBy(css = ".FilterPanelV2__filterPanelContent .Facilities__holidayTypeWrapper .Facilities__clearLink a"),
            @FindBy(css = ".FilterPanelV2__childFilterHeader .Facilities__clearLink a"),
            @FindBy(css = "[class='Flights__clearLink']") })
   private WebElement clearLink;

   @FindBy(css = ".FilterPanelV2__clearAll")
   private WebElement clearAllFilters;

   @FindBy(css = ".DropModal__dropModalContent:nth-child(1) .DropModal__footerContainer button[role='button']")
   private List<WebElement> applyButton;

   @FindBy(css = ".MoreFilters__footerContainer button[role='button']")
   private WebElement applyButtonMoreFilter;

   @FindBy(css = ".DropModal__dropModalContent:nth-child(1) .DropModal__footerContainer a")
   private List<WebElement> clearButtonBoardBasis;

   @FindBy(css = ".DropModal__filterModalWindow")
   private WebElement openModel;

   @FindBy(css = ".MoreFilters__filterModalWindow")
   private WebElement openModelMore;

   @FindBy(css = ".DropModal__filterModalWindow:nth-child(1) .DropModal__close")
   private WebElement xWindow;

   @FindBy(css = ".MoreFilters__headerContainer .MoreFilters__close svg")
   private WebElement xWindowMoreFilter;

   @FindBy(css = ".FilterPanelV2__selected[aria-label='More filter']")
   private WebElement flightSelectedState;

   @FindBy(css = "[aria-label='More filter'] span")
   private WebElement moreFiltersModel;

   @FindBy(css = "[class='MoreFilters__contentAlign contentWidth'] div a[class='MoreFilters__clear']")
   private WebElement clearAllModel;

   @FindBy(css = ".FilterPanelV2__holidayCounts span")
   private WebElement hoildayCount;

   @FindBy(css = "[class='BoardBasis__boardBasisItem BoardBasis__checked'] div label input:not(checked)+span+span .BoardBasis__boardType")
   private List<WebElement> boardBasisChecked;

   @FindBy(css = "[class*='Column__col ResultListItemV2__packagePrice ResultListItemV2__showPackage'] div[class='ResultListItemV2__perPersonPrice'] .ResultListItemV2__boardType")
   private List<WebElement> boardFilterSearchResults;

   @FindBy(css = "[class*='Flights__cardWrapper']")
   private WebElement flightFilter;

   @FindBy(css = "[class*='Flights__filterTitle'] b")
   private List<WebElement> flightFilterTitle;

   @FindAll({
            @FindBy(css = ".Flights__wrapper div[aria-label='Vertreklocatiestitle']+ul span[class='Flights__type']"),
            @FindBy(xpath = "//div[@class='Flights__wrapper']//div/b/../..//ul/li/span/label") })
   private List<WebElement> departurePoints;

   @FindBy(css = ".ResultListItemV2__flightName")
   private List<WebElement> flightNameInSearchResults;

   @FindBy(css = "[class='Flights__filterType Flights__notChecked'] label input[type='checkbox'][disabled]+span+span>span")
   private List<WebElement> flightFilterGrayOut;

   @FindBy(css = "[aria-label='Vertrektijd (heen)title'] b")
   private WebElement departureGoingOutTitle;

   @FindBy(css = "[aria-label='Vertrektijd (terug)title'] b")
   private WebElement departureComingBackTitle;

   @FindBy(css = "[aria-label='Vertrektijd (heen)title']+ul span[class='Flights__type'] span")
   private List<WebElement> departureGoingOut;

   @FindBy(css = "[aria-label='Vertrektijd (terug)title']+ul span[class='Flights__type'] span")
   private List<WebElement> departureComingBack;

   @FindBy(css = "[aria-label='Vertrektijd (heen)title']+ul input:not(:disabled)+span+span span[class='Flights__type']")
   private List<WebElement> selectDepartureGoingOut;

   @FindBy(css = "[aria-label='Vertrektijd (terug)title']+ul input:not(:disabled)+span+span span[class='Flights__type']")
   private List<WebElement> selectDepartureComingBack;

   @FindBy(css = "[class*='ResultsListItem__fightInfo'] a")
   private List<WebElement> flightInfo;

   @FindBy(css = "section[class='popups__modalBody'] span[class='popups__close'] svg")
   private List<WebElement> flightInfoCloseButton;

   @FindBy(css = ".BoardBasis__option label input[type='checkbox']:disabled+span+span span")
   private List<WebElement> boardBasisDisabled;

   @FindBy(css = ".BoardBasis__option label input[type='checkbox']:enabled+span+span span")
   private List<WebElement> boardBasisEnabled;

   private String value = "";

   public SearchResultsFiltersComponent()
   {
      wait = new WebElementWait();
      searchCardMap = new HashMap<>();
   }

   public boolean isFlightSelectedState()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(flightSelectedState);
   }

   public boolean isBoardBasisDisableState()
   {
      if (!boardBasisDisabled.isEmpty())
      {
         wait.forJSExecutionReadyLazy();
         return WebElementTools.isPresent(boardBasisDisabled.get(0));
      }
      else
      {
         return false;
      }
   }

   public boolean isBoardBasisDisplayed()
   {
      return WebElementTools.isPresent(getBoardBasisFilter());
   }

   public WebElement getBoardBasisFilter()
   {
      return wait.getWebElementWithLazyWait(boardBasisFilter);
   }

   @NotNull
   private static ElementsCollection getListOfBoardFilters()
   {
      return $("div.BoardBasis__boardBasisListWraper > ul").$$("div.BoardBasis__option");
   }

   public boolean isClearLinkisDisplayed()
   {
      return getClearLink().should(Condition.appear, Duration.ofSeconds(10)).isDisplayed();
   }

   public void clickClearLink()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.click(clearLink);
   }

   public boolean isClearAllLinkisDisplayed()
   {
      return WebElementTools.isPresent(clearAllFilters);
   }

   public void clickClearAllFilter()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(clearAllFilters);
      WebElementTools.clickElementJavaScript(clearAllFilters);
   }

   public boolean isOpenmodelisDisplayed()
   {
      return WebElementTools.isPresent(getOpenModel());
   }

   public WebElement getOpenModel()
   {
      return wait.getWebElementWithLazyWait(openModel);
   }

   public boolean isOpenmodelMoreisDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(openModelMore);
   }

   public SelenideElement getClearLink()
   {
      return $("div.BoardBasis__boardBasisListWraper").$("span.BoardBasis__clearLink");
   }

   public List<String> getListOfBoardFilterNames()
   {
      return getListOfBoardFilters().asDynamicIterable().stream().map(SelenideElement::getText)
               .collect(Collectors.toList());
   }

   public void selectBoardBasis(int randomNum)
   {
      getListOfBoardFilters().get(randomNum).$("label[aria-label='checkbox']")
               .should(Condition.appear).click();
   }

   public void clickOnBoardBasisFilter()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(getBoardBasisFilter());
   }

   public void clickApplyButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(applyButton.get(4));
   }

   public void clickApplyMoreButton()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(applyButtonMoreFilter);
   }

   public boolean closeModal(String component)
   {
      wait.forJSExecutionReadyLazy();
      if (StringUtils.containsIgnoreCase(component, "x"))
         return WebElementTools.isPresent(xWindow);
      if (StringUtils.containsIgnoreCase(component, "Apply"))
         return WebElementTools.isPresent(applyButton.get(4));
      return true;
   }

   public boolean closeModelMoreFilter(String component)
   {
      wait.forJSExecutionReadyLazy();
      if (StringUtils.containsIgnoreCase(component, "x"))
         return WebElementTools.isPresent(xWindowMoreFilter);
      if (StringUtils.containsIgnoreCase(component, "Apply"))
         return WebElementTools.isPresent(applyButtonMoreFilter);
      return true;
   }

   public void clickClearBoardBasis()
   {
      wait.forJSExecutionReadyLazy();
      if (clearButtonBoardBasis.get(4) != null)
      {
         WebElementTools.clickElementJavaScript(clearButtonBoardBasis.get(4));
      }
   }

   public boolean moreFiltersTextCompare(String moreFilter)
   {
      wait.waitForElementToBePresent(moreFiltersModel);
      return moreFiltersModel.getText().equals(moreFilter);
   }

   public void clickMoreFilters()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollAndMouseHover(moreFiltersModel);
      WebElementTools.clickElementJavaScript(moreFiltersModel);
   }

   public void clearAllModel()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(clearAllModel);
   }

   public String hoildayResults()
   {
      wait.forJSExecutionReadyLazy();
      return hoildayCount.getText();
   }

   public boolean verifyBoardBasisSearchResults()
   {
      wait.forJSExecutionReadyLazy();
      Set<String> boardBasisTypeAvailability = new HashSet<>();
      boardBasisChecked.forEach(action ->
      {
         String boardBasisType = action.getText();
         boardBasisTypeAvailability.add(boardBasisType);
      });
      ArrayList<String> boardBasisList = new ArrayList<>(boardBasisTypeAvailability);
      return boardBasisFilterSelections(boardBasisList);

   }

   public boolean boardBasisFilterSelections(List<String> type)
   {
      type.forEach(action ->
      {
         if (!action.isEmpty())
         {
            for (WebElement boardFilterSearchResult : boardFilterSearchResults)
            {

               if (action.toLowerCase().equalsIgnoreCase(boardFilterSearchResult.getText()
                        .replace("(", " ").replace(")", " ").trim()))
               {
                  boardFilterSearchResult.getSize();
               }
            }

         }
      });

      return true;
   }

   public boolean isFilterisDisplayed()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(flightFilter);
   }

   public Map<String, WebElement> getFlightFilterComponents()
   {
      searchCardMap.put("Departure Points", flightFilterTitle.get(0));
      return searchCardMap;
   }

   public boolean isDeparturePointPresent()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(flightFilterTitle.get(0));
   }

   public void clickOnDeparturePoint()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.scrollTo(0, 0);
      WebElementTools.clickElementJavaScript(departurePoints.get(1));
   }

   public String departurePointText()
   {
      setValue(departurePoints.get(1).getText());
      return departurePoints.get(1).getText();
   }

   public boolean verifingDeparturePointinSearchResults()
   {
      wait.forJSExecutionReadyLazy();
      boolean value = false;
      for (WebElement flightName : flightNameInSearchResults)
      {
         String[] flight = flightName.getText().split(" ");
         String[] flights = flight[0].split(":");
         if (getValue().equalsIgnoreCase(flights[0]))
         {
            value = true;
         }
      }
      return value;
   }

   public boolean isFlightFliterGreyedOut()
   {
      wait.forJSExecutionReadyLazy();
      return WebElementTools.isPresent(flightFilterGrayOut.get(0));
   }

   public void clickFlightFliterGreyedOut()
   {
      wait.forJSExecutionReadyLazy();
      WebElementTools.clickElementJavaScript(flightFilterGrayOut.get(0));
   }

   public boolean departureTime(String departure)
   {
      boolean depTime = false;
      if (departure.equalsIgnoreCase("going out"))
         depTime = WebElementTools.isPresent(departureGoingOutTitle);
      if (departure.equalsIgnoreCase("coming back"))
         depTime = WebElementTools.isPresent(departureComingBackTitle);
      return depTime;
   }

   public Map<String, WebElement> getDepartureTime(String departure)
   {

      if (departure.equalsIgnoreCase("going out"))
      {
         searchCardMap.put("Morning - 06:00-11:59", departureGoingOut.get(0));
         searchCardMap.put("Afternoon - 12:00- 17:59", departureGoingOut.get(1));
         searchCardMap.put("Evening - 18:00-20:59", departureGoingOut.get(2));
         searchCardMap.put("Night - 21:00-05:59", departureGoingOut.get(3));
         return searchCardMap;
      }
      else if (departure.equalsIgnoreCase("coming back"))
      {
         searchCardMap.put("Morning - 06:00-11:59", departureComingBack.get(0));
         searchCardMap.put("Afternoon - 12:00- 17:59", departureComingBack.get(1));
         searchCardMap.put("Evening - 18:00-20:59", departureComingBack.get(2));
         searchCardMap.put("Night - 21:00-05:59", departureComingBack.get(3));
         return searchCardMap;
      }
      return searchCardMap;
   }

   public void clickDepartureTime(String departure)
   {
      wait.forJSExecutionReadyLazy();
      if (departure.equalsIgnoreCase("going out"))
         WebElementTools.clickElementJavaScript(selectDepartureGoingOut.get(0));
      if (departure.equalsIgnoreCase("coming back"))
         WebElementTools.clickElementJavaScript(selectDepartureComingBack.get(0));
   }

   public void clickFlightInfo(String info)
   {
      wait.forJSExecutionReadyLazy();
      if (info.equalsIgnoreCase("going out"))
      {
         wait.forJSExecutionReadyLazy();
         setValue(flightInfo.get(0).getText());
         WebElementTools.scrollAndMouseHover(flightInfo.get(0));
         WebElementTools.clickElementJavaScript(flightInfo.get(0));
      }
      if (info.equalsIgnoreCase("coming back"))
      {
         wait.forJSExecutionReadyLazy();
         setValue(flightInfo.get(0).getText());
         WebElementTools.scrollAndMouseHover(flightInfo.get(0));
         WebElementTools.clickElementJavaScript(flightInfo.get(0));
      }
   }

   public void clickflightInfoCloseButton()
   {
      wait.forJSExecutionReadyLazy();
      wait.forJSExecutionReadyLazy();
      WebElementTools.mouseOverAndClick(flightInfoCloseButton.get(1));
   }

   public String getValue()
   {
      return value;
   }

   public void setValue(String value)
   {
      this.value = value;
   }

   public List<WebElement> getEnabledBoardBasisCheckboxes()
   {
      return boardBasisEnabled;
   }
}
