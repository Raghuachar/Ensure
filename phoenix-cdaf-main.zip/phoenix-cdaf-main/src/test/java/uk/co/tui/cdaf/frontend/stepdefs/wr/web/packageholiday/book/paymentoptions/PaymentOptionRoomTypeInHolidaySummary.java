package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.paymentoptions;

import io.cucumber.java.en.Given;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;

public class PaymentOptionRoomTypeInHolidaySummary
{
   public final PackageNavigation packageNavigation;

   public PaymentOptionRoomTypeInHolidaySummary()
   {
      packageNavigation = new PackageNavigation();
   }

   @Given("the customer is on the Payments page")
   public void the_customer_is_on_the_Payments_page()
   {
      packageNavigation.navigateToPaymentPage();
   }
}
