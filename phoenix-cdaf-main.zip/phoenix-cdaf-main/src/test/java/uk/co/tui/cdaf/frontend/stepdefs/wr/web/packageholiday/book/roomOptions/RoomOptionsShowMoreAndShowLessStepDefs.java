package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.roomOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.roomoptions.RoomOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class RoomOptionsShowMoreAndShowLessStepDefs
{
   public final PackageNavigation packageNavigation;

   public final RoomOptionsPage roomOptionsPage;

   public final SummaryPage summaryPage;

   public RoomOptionsShowMoreAndShowLessStepDefs()
   {
      packageNavigation = new PackageNavigation();
      roomOptionsPage = new RoomOptionsPage();
      summaryPage = new SummaryPage();
   }

   @Given("the customer is on the Room & Board page")
   public void the_customer_is_on_the_Room_Board_page()
   {
      packageNavigation.summaryPage.roomAndBoardComponent.clickOnRoomUpgrades();
   }

   @When("there are >{int} room types available for selection")
   public void there_are_room_types_available_for_selection(Integer int1)
   {
      boolean actual = roomOptionsPage.roomOptionsExpandComponent.isRoomOptionsComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Room Options Component wasn't displayed", actual, true), actual, is(true));
   }

   @Then("they will be presented with the following CTA:")
   public void they_will_be_presented_with_the_following_CTA(List<String> components)
   {
      boolean actual =
               roomOptionsPage.roomOptionsExpandComponent.isShowMoreRoomOptionsButtonDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Show More Room Options button wasn't displayed", actual, true), actual, is(true));
   }

   @When("they select the View More Room Options CTA")
   public void they_select_the_View_More_Room_Options_CTA()
   {
      roomOptionsPage.roomOptionsExpandComponent.clickOnShowMoreRoomOptionsLink();
   }

   @Then("the amount of cards available will expand for that particular Room Number")
   public void the_amount_of_cards_available_will_expand_for_that_particular_Room_Number()
   {
      boolean actual = roomOptionsPage.roomOptionsExpandComponent.isRoomOptionsComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Room Options Component wasn't displayed", actual, true), actual, is(true));
   }

   @When("the room types for a particular Room Number have been expanded")
   public void the_room_types_for_a_particular_Room_Number_have_been_expanded()
   {
      boolean actual = roomOptionsPage.roomOptionsExpandComponent.isRoomOptionsComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Room Options Component wasn't displayed", actual, true), actual, is(true));
   }

   @When("the expanded display of cards is exhaustive")
   public void the_expanded_display_of_cards_is_exhaustive()
   {
      boolean actual =
               roomOptionsPage.roomOptionsExpandComponent.isShowMoreRoomOptionsButtonDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Show More Room Options button wasn't displayed", actual, true), actual, is(true));
   }

   @When("they select the View Fewer Room Options CTA")
   public void they_select_the_View_Fewer_Room_Options_CTA()
   {
      roomOptionsPage.roomOptionsExpandComponent.clickOnShowLessRoomOptionsLink();
   }

   @Then("the amount of cards available will collapse back to {int}")
   public void the_amount_of_cards_available_will_collapse_back_to(Integer int1)
   {
      boolean actual = roomOptionsPage.roomOptionsExpandComponent.isRoomOptionsComponentDisplayed();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Room Options Component wasn't displayed", actual, true), actual, is(true));
   }

}
