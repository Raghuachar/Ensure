package uk.co.tui.cdaf.frontend.utils.testDataObjects;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import uk.co.tui.cdaf.frontend.utils.testDataObjects.attributes.PaymentTypes;

import java.io.File;

public class PaymentDetailsDataHelper
{

   private static volatile PaymentTypes instance;

   private PaymentDetailsDataHelper()
   {
   }

   @SneakyThrows
   public static PaymentTypes getInstance()
   {
      if (instance == null)
      {
         String fileName = "src/test/resources/json/paymentDetails.json";
         ObjectMapper objectMapper = new ObjectMapper();
         instance = objectMapper.readValue(new File(fileName), PaymentTypes.class);
      }
      return instance;
   }
}
