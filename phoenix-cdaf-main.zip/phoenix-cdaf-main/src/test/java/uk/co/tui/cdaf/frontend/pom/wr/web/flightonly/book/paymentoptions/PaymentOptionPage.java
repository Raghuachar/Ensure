package uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.paymentoptions;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import uk.co.tui.cdaf.frontend.utils.AbstractPage;
import uk.co.tui.cdaf.utils.WebDriverUtils;
import uk.co.tui.cdaf.utils.tools.WebElementWait;

import java.util.HashMap;

public class PaymentOptionPage extends AbstractPage
{
   public final WebElementWait wait = new WebElementWait();

   public final WebDriverUtils utils = new WebDriverUtils();

   public final PaymentOptionsComponent paymentOptionComponent = new PaymentOptionsComponent();

   public final PaymentTypeComponent paymentTypeComponent = new PaymentTypeComponent();

   public final ProgressbarNavigationComponent progressbarComponent =
            new ProgressbarNavigationComponent();

   public final PaymentProviderPage paymentProviderPage = new PaymentProviderPage();

   public final VoucherRemoveComponent voucherRemove = new VoucherRemoveComponent();

   private final HashMap<String, WebElement> PaymentComponentOptionPageMap = new HashMap<>();

   private final HashMap<String, WebElement> PaymentOptionPageMap = new HashMap<>();

   public VoucherRemainingTextComponent voucherRemainingTextComponent =
            new VoucherRemainingTextComponent();

   @FindBy(css = ".main")
   private WebElement paymentAmount;

   public HashMap<String, WebElement> getPaymentOptionsMap()
   {
      return PaymentOptionPageMap;
   }

   public HashMap<String, WebElement> getPaymentComponentOptionsMap()
   {
      return PaymentComponentOptionPageMap;
   }

   public void setPaymentComponentOptionsMap()
   {
      try
      {
         PaymentComponentOptionPageMap.put("Price Panel", progressbarComponent.getPricePanel());
         PaymentComponentOptionPageMap.put("Navigation Panel",
                  progressbarComponent.getNavigationPanel());
         PaymentComponentOptionPageMap.put("Payment Options",
                  paymentTypeComponent.getPaymentOptionPanel());
         PaymentComponentOptionPageMap.put("Payment Methods",
                  paymentOptionComponent.getPaymentMethodPanel());
         PaymentComponentOptionPageMap.put("Continue", paymentOptionComponent.getContinueElement());
      }
      catch (Exception ignored)
      {

      }
   }

   public void setPaymentOptionsMap()
   {
      try
      {
         PaymentOptionPageMap.put("PAYMENT", paymentTypeComponent.getPaymentHeadingElement());
         PaymentOptionPageMap.put("Payment Amount", paymentAmount);
         PaymentOptionPageMap.put("Total Payment Amount",
                  paymentTypeComponent.getTotalPaymentAmount());
      }
      catch (Exception ignored)
      {

      }
   }

}
