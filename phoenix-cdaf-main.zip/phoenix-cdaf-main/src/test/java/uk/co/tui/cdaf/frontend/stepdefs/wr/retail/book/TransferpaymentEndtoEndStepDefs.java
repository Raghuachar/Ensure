package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.book;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.TransferpaymentPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;
import uk.co.tui.cdaf.frontend.utils.logger.AutomationLogManager;

public class TransferpaymentEndtoEndStepDefs
{

   private static final AutomationLogManager LOGGER =
            new AutomationLogManager(PackageNavigation.class);

   public final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final TransferpaymentPage transferpaymentPage;

   private final RetailPackageNavigation retailpackagenavigation;

   public TransferpaymentEndtoEndStepDefs()
   {
      transferpaymentPage = new TransferpaymentPage();
      retailpackagenavigation = new RetailPackageNavigation();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();

   }

   @Given("the agent is on {string}")
   public void the_agent_is_on(String string)
   {
      retailpackagenavigation.retailLoginChangeagent();
      retailpackagenavigation.navigateToPaymentPage();
      transferpaymentPage.getPaymentTypeTitle().equalsIgnoreCase(string);

   }

   @And("they input Booking Reference Number")
   public void they_input_Booking_Reference_Number()
   {
      transferpaymentPage.getTransferPayment();

   }

   @When("they click on CTA {string} Button")
   public void they_click_on_CTA_Button(String string)
   {
      transferpaymentPage.getVadaiteText().equalsIgnoreCase(string);
      transferpaymentPage.vadaiteCTA();
      retailpassengerdetailspage.userLogout();
   }

}
