package uk.co.tui.cdaf.frontend.stepdefs.wr.web.packageholiday.book.summary;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.PackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.roomoptions.RoomOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.unitdetails.summary.SummaryPage;
import uk.co.tui.cdaf.utils.ReportFormatter;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

public class RoomAndBoardModalStepDefs
{

   public final PackageNavigation packageNavigation;

   public final SummaryPage summaryPage;

   public final RoomOptionsPage roomOptionsPage;

   public RoomAndBoardModalStepDefs()
   {
      packageNavigation = new PackageNavigation();
      summaryPage = new SummaryPage();
      roomOptionsPage = new RoomOptionsPage();
   }

   @Given("that the customer is on the Room & Board page")
   public void that_the_customer_is_on_the_Room_Board_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @Given("there are images available for a Room type option")
   public void there_are_images_available_for_a_Room_type_option()
   {
      boolean actual = summaryPage.roomAndBoardComponent.isRooomImagePresent();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Room Images component wasnt displayed", actual, true), actual, is(true));
   }

   @When("selecting a chevron on the image")
   public void selecting_a_chevron_on_the_image()
   {
      roomOptionsPage.modalComponent.clickOnImageChevron();
   }

   @Then("there will be a carousel of images for that room available for rotation")
   public void there_will_be_a_carousel_of_images_for_that_room_available_for_rotation()
   {
      // will add this Scenario once it is available.
   }

   @Given("that the customer is on the Customise page or Room & Board page")
   public void that_the_customer_is_on_the_Customise_page_or_Room_Board_page()
   {
      packageNavigation.navigateToSummaryPage();
   }

   @When("they select More Details link OR Photo Icon")
   public void they_select_More_Details_link_OR_Photo_Icon()
   {
      roomOptionsPage.modalComponent.clickOnMoreDetailsLink();
   }

   @Then("a modal is expanded with the following information:")
   public void a_modal_is_expanded_with_the_following_information(DataTable ignore)
   {
      roomOptionsPage.modalComponent.getRoomAndBoardOptionsComps();
   }

   @Given("there is no image available for a particular room option type")
   public void there_is_no_image_available_for_a_particular_room_option_type()
   {
      boolean actual = summaryPage.roomAndBoardComponent.isRooomImagePresent();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Room Images component wasnt displayed", actual, true), actual, is(true));
   }

   @Then("we will display Image coming soon")
   public void we_will_display_Image_coming_soon()
   {
      boolean actual = roomOptionsPage.modalComponent.getImageCommingSoonElement();
      assertThat(ReportFormatter.generateReportStatement(StringUtils.EMPTY,
               "Included room button wasn't displayed", actual, true), actual, is(true));
   }

   @Then("there will be no option for carousel")
   public void there_will_be_no_option_for_carousel()
   {
      // will add this Scenario once it is available.
   }

   @Then("there will be no chevrons to interact with")
   public void there_will_be_no_chevrons_to_interact_with()
   {
      // will add this Scenario once it is available.
   }

   @Then("there will be no alternative images or messages")
   public void there_will_be_no_alternative_images_or_messages()
   {
      // will add this Scenario once it is available.
   }
}
