package uk.co.tui.cdaf.frontend.stepdefs.wr.retail.flightonly;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uk.co.tui.cdaf.frontend.pom.wr.retail.FOSpecialBaggage;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailPackageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.retail.RetailSearchPanelComponent;
import uk.co.tui.cdaf.frontend.pom.wr.retail.flightonly.RetailFlightOnlyPageNavigation;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.extras.ExtraOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.flightonly.book.flightoptions.FlightOptionsPage;
import uk.co.tui.cdaf.frontend.pom.wr.web.packageholiday.book.passengerdetails.RetailPassengerDetailsPage;

public class FOSpecialBaggageStepDefs
{
   private final RetailPackageNavigation retailpackagenavigation;

   private final RetailSearchPanelComponent retailsearchPanelComponent;

   private final RetailPassengerDetailsPage retailpassengerdetailspage;

   private final FlightOptionsPage flightOptionsPage;

   private final ExtraOptionsPage extraOptionsPage;

   private final FOSpecialBaggage specialbaggage;

   private final RetailFlightOnlyPageNavigation retailFlightOnlyPageNavigation;

   public FOSpecialBaggageStepDefs()
   {
      retailpackagenavigation = new RetailPackageNavigation();
      retailsearchPanelComponent = new RetailSearchPanelComponent();
      retailpassengerdetailspage = new RetailPassengerDetailsPage();
      flightOptionsPage = new FlightOptionsPage();
      extraOptionsPage = new ExtraOptionsPage();
      specialbaggage = new FOSpecialBaggage();
      retailFlightOnlyPageNavigation = new RetailFlightOnlyPageNavigation();
   }

   @Given("the agent is on flight option page")
   public void the_agent_is_on_flight_option_page()
   {
      retailpackagenavigation.retailLogin();
      retailFlightOnlyPageNavigation.wrMFEFoOneWaySearch();
      retailsearchPanelComponent.selectFlight();
   }

   @When("they the click on sports chevron")
   public void they_the_click_on_sports_chevron()
   {
      specialbaggage.clickOnspecialSports();
   }

   @Then("the they should see list of sports equipment")
   public void the_they_should_see_list_of_sports_equipment()
   {
      specialbaggage.selectSportsEquipment();
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
   }

   @When("they the click on pets chevron")
   public void they_the_click_on_pets_chevron()
   {
      specialbaggage.clickOnspecialPets();
   }

   @Then("the they should see list of pets")
   public void the_they_should_see_list_of_pets()
   {
      specialbaggage.selectpets();
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
   }

   @When("they select the flight extras")
   public void they_select_the_flight_extras()
   {
      specialbaggage.clickOnUpgardeSeats();
   }

   @Then("flight extras should be selected")
   public void flight_extras_should_be_selected()
   {
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
   }

   @When("they select the flight baggage")
   public void they_select_the_flight_baggage()
   {
      specialbaggage.clickOnUpgardeBaggage();
   }

   @Then("flight baggage should be selected")
   public void flight_baggage_should_be_selected()
   {
      flightOptionsPage.clickOnContinue();
      extraOptionsPage.clickOnContinue();
      retailpassengerdetailspage.fillRetailPassengerDetails();
      retailpassengerdetailspage.retailPayment();
   }

}
