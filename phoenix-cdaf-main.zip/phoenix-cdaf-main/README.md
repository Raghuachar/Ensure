# WR Sales UI automation framework (known as phoenix-cdaf)

## Pre-requisites

Install the following on your machine:

* Git
* Java JDK 11 (minimum version)
* Maven 3.3 (minimum version)

## Optional: for Unix users

All the required versions are specified in the `.tool-versions` file.
To use it, you should install [ASDF-VM](https://asdf-vm.com) package manager.

Please refer to their installation guide for further instructions: https://asdf-vm.com/guide/getting-started.html

Our next steps are:

```sh
asdf plugin-add maven
asdf plugin-add java
asdf install
```

## Installation

Initialize an empty git directory in an appropriate location

```git init```

Clone this project

```git clone https://source.tui/osp/tech-practices/qa/phoenix-cdaf.git```

Run the file scripts/install-hooks.sh

From download maven dependencies with: ```mvn clean install```

## Execution

### Local

You can run the tests with:

```mvn clean test -Dcucumber.filter.tags="< your cucumber tags >"```

Your cucumber tags determine which scenarios are run, so for example, if you want to run all Tui UK, UI scenarios on
desktop you would have:

```mvn clean test -Dcucumber.filter.tags="@tuiuk and @ui and @desktop and not @wip"```

#### Note:- While execution if the browser doesn't launches, then try to connect internet connection to another network for the first execution. There is a possibility that there is a network proxy which is blocking to download the latest driver from the global repository. After the first execution when driver is downloaded you can switch back to the desired WiFi/LAN network.

### Remote

Same as for local except with the following properties set:

```-Dselenium.use.grid=true -Dselenium.grid.endpoint=http://<host address>:4444/wd/hub```

### Jenkins

#### For local team Jenkins setup:

Add your jenkinsfile to the subdirectory 'jenkins' under another subdirectory for the brand / team.

#### For Jenkins CI you need the additional args:

Run with ```-Dselenium.browser=chrome-desktop-jenkins -Dselenium.grid.endpoint=http://<host address>:4444/wd/hub```

#### Note: When you run with selenium.browser=chrome-desktop-jenkins, you do not need to set -Dselenium.use.grid=true as the framework knows you are running in jenkins CI and will give you a remote execution by default.

### Parallel execution

This capability is provided under the Maven profile -Pparallel, you will need to set the property -Dthread.count

## Properties

| Property               | State       | Description                                                                                                                                                                 |
|:-----------------------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| selenide.baseUrl       | supported   | String - Describes the site url for the test to start from for example: https://dev.tuiprjuat.be/h/                                                                         |
| cucumber.filter.tags   | supported   | String - Describes cucumber options for controlling which Cucumber scenarios run, for example: "@sanity and @buildversion and not @wip"                                     |
| selenium.browser       | unsupported | String - Describes the browser type and browser configuration type, one of a known set of values listed here: cdaf/src/main/java/uk/co/tui/cdaf/utils/BrowserConstants.java |
| selenium.use.grid      | unsupported | Boolean - Determines if the tests should run remotely, false by default                                                                                                     |
| selenium.grid.endpoint | unsupported | String - Describes the endpoint url for the selenium grid when selenium.use.grid=true, example: http://localhost:4444/wd/hub                                                |

## Logging

Framework use custom logging that intercepts Selenide actions (before, to track all intended) and logs of the automation
to insert into scenario summary.

**Important note:** this logger should be used ONLY for test source classes

Initialization:

```java
private static final AutomationLogManager LOGGER = new AutomationLogManager(Clazz.class);
        LOGGER.log(LogLevel.TRACE, "Any object that has toString method implemented");
        LOGGER.log("By default - DEBUG is used in case if level not set");
```

Levels: DEBUG, WARN, ERROR, INFO, TRACE, FATAL

